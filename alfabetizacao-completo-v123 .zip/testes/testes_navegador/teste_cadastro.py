"""Cadastro padrão NOME + BICHINHO (v122: telas do escola-familia.js) —
as 3 conferências do item 9 do PADRAO_CADASTRO_NOME_BICHINHO.md, num
Chromium de verdade, agora com as telas e palavras do PLANO_CADASTRO_FAMILIA.
(v121 → v122: os textos, os ids das telas e o "com 1 criança entra direto"
mudaram de propósito, pelo plano; o que é conferido continua o mesmo.)"""
from base import *
from ef import *
import json

OFICIAIS = [('🦉','Coruja'),('🦊','Raposa'),('🐰','Coelho'),('🐼','Panda'),('🦋','Borboleta'),('🐨','Coala'),('🐯','Tigre'),('🐴','Pônei')]
FAM = 'familiateste'

def main():
    servidor()
    r = R('CADASTRO PADRÃO — 1ª conferência: funcionamento')
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        ctx, fb = novo_contexto(b)
        erros = []
        p = abrir(ctx, erros)
        T = textos(p)
        r.t('Celular sem nada: abre a T1 "🦉 OLÁ! VAMOS COMEÇAR?" com 🔑 Já tenho cadastro e 🌱 Sou novo por aqui',
            aberta(p,'ef-t1') and T['t1Titulo'] in p.text_content('#efRaiz') and p.is_visible('.ef-t1-ja') and p.is_visible('.ef-t1-novo'))
        r.t('Instalação nova: sem "Agora não"', not p.is_visible('.ef-t1-agoranao'))
        p.click('.ef-t1-novo'); p.wait_for_timeout(300)
        cod = p.input_value('.ef-t3 .ef-codigo')
        r.t('🌱 Sou novo: a T3 sugere um código bicho + 4 números', bool(__import__('re').match(r'^[a-z]+-\d{4}$', cod)), cod)
        p.fill('.ef-t3 .ef-codigo', 'Família Teste'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200)
        r.t('Código livre: cria e pede "📝 ANOTE NUM PAPEL" com o código', T['t3Anote'] in p.text_content('.ef-t3') and p.text_content('.ef-codigo-anotar')=='familia-teste')
        p.click('.ef-ja-anotei'); p.wait_for_timeout(400)
        r.t('Depois de anotar: a T5 "🌟 QUAL É O SEU NOME?" (precisa de pelo menos uma criança)', aberta(p,'ef-t5'))
        bt = p.evaluate("Array.from(document.querySelectorAll('#efRaiz .ef-bicho')).map(b=>[b.textContent,b.title])")
        r.t('Aparecem exatamente os 8 bichinhos, na ordem oficial, com os nomes certos', [tuple(x) for x in bt]==OFICIAIS, bt)
        r.t('A lista vem do escola-pwa.js (EscolaPWA.BICHINHOS v2)', p.evaluate("EscolaPWA.versao==='2' && BICHINHOS===EscolaPWA.BICHINHOS"))
        r.t('A cópia de reserva é idêntica à oficial', p.evaluate("JSON.stringify(BICHINHOS_OFICIAIS)===JSON.stringify(EscolaPWA.BICHINHOS)"))
        r.t('Nenhum bichinho vem escolhido sozinho', p.evaluate("document.querySelectorAll('#efRaiz .ef-bicho.ef-on').length===0"))
        tx = p.evaluate("(()=>{const t=document.querySelector('.ef-t5'); return [t.querySelector('.ef-titulo').textContent, t.querySelector('.ef-nome-campo').placeholder, t.querySelector('.ef-nome-campo').maxLength, t.querySelector('.ef-sub').textContent, t.querySelector('.ef-pronto').textContent]})()")
        r.t('Textos exatos (tabela 3-A): título, "DIGITE O SEU NOME", 14 letras, "ESCOLHA O SEU BICHINHO:", "PRONTO! ✅"',
            tx==[T['t5Titulo'], T['t5Campo'], 14, T['t5Escolha'], T['t5Pronto']], tx)
        r.t('A tela é em CAIXA ALTA (CSS), sem mudar o que é digitado', p.evaluate("getComputedStyle(document.querySelector('.ef-t5 .ef-titulo')).textTransform")=='uppercase')
        p.locator('#efRaiz .ef-bicho').nth(4).click()
        r.t('"VOCÊ ESCOLHEU: 🦋 Borboleta" aparece depois de escolher', p.text_content('.ef-escolhido')=='VOCÊ ESCOLHEU: 🦋 Borboleta', p.text_content('.ef-escolhido'))
        p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(200)
        r.t('Sem nome não cadastra ("ESCREVA O SEU NOME PRIMEIRO 🙂")', T['t5SemNome'] in toast(p) and not perfis(p)['perfis'])
        p.evaluate("document.querySelector('.ef-bicho.ef-on').classList.remove('ef-on')")
        p.close(); p = abrir(ctx, erros)   # recomeça a T5 limpa (família já criada → T4 → ➕)
        r.t('Reabrir com a família e sem criança: T4 só com ➕ NOVA CRIANÇA e ☁️ BUSCAR NA NUVEM',
            aberta(p,'ef-t4') and p.locator('.ef-t4 .ef-crianca:not(.ef-novo)').count()==0 and p.is_visible('.ef-t4 .ef-novo') and p.is_visible('.ef-buscar'))
        p.click('.ef-t4 .ef-novo'); p.wait_for_timeout(300)
        p.fill('.ef-nome-campo','Renata'); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(200)
        r.t('Sem bichinho não cadastra ("ESCOLHA O SEU BICHINHO 🙂")', T['t5SemBicho'] in toast(p) and not perfis(p)['perfis'])
        p.focus('.ef-nome-campo'); p.keyboard.press('Enter'); p.wait_for_timeout(200)
        r.t('Enter sem bichinho: não cadastra e pede o bichinho', T['t5EnterSemBicho'] in toast(p) and not perfis(p)['perfis'])
        p.evaluate("document.querySelector('.ef-nome-campo').value='   Renata    Maria  '")
        p.locator('#efRaiz .ef-bicho').nth(4).click()
        p.focus('.ef-nome-campo'); p.keyboard.press('Enter'); esperar_recarga(p)
        pf = perfis(p)['perfis']
        r.t('Enter com bichinho cadastra', len(pf)==1)
        r.t('Espaços no começo/fim tirados e repetidos viram um só ("Renata Maria")', pf and pf[0]['nome']=='Renata Maria' and pf[0]['av']=='🦋', pf)
        r.t('A criança nova fica ligada à família do celular', estado_familia(p)['criancas'].get(pf[0]['id'])=='familia-teste')
        r.t('Criança nova: o app pergunta dos nomes dos parentes (D9: "Nomes dos parentes")', p.evaluate("document.getElementById('cfmOv').classList.contains('open')") and 'parentes' in p.text_content('#cfmTitulo'))
        fechar_app_popups(p)
        r.t('...e depois entra no app (menu), sem "Quem vai estudar hoje?" de novo', not aberta(p,'ef-t4') and p.evaluate("document.getElementById('hubOv').classList.contains('open')"))
        p.reload(); p.wait_for_timeout(900)
        r.t('D2: reabrir com UMA criança mostra "🦉 QUEM VAI ESTUDAR HOJE?"', aberta(p,'ef-t4') and T['t4Titulo'] in p.text_content('.ef-t4'))
        p.click('.ef-t4 .ef-novo'); p.wait_for_timeout(300)
        p.fill('.ef-nome-campo','  renata maria '); p.locator('#efRaiz .ef-bicho').nth(4).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(300)
        r.t('Mesmo nome + bichinho (maiúscula/espaços diferentes) não cria repetido e avisa "JÁ ESTÁ NESTE CELULAR"',
            len(perfis(p)['perfis'])==1 and 'JÁ ESTÁ NESTE CELULAR' in toast(p), toast(p))
        p.wait_for_timeout(1500); fechar_app_popups(p); fechar_tudo(p)
        p.evaluate("EscolaFamilia.abrir('nova')"); p.wait_for_timeout(300)
        p.fill('.ef-nome-campo','Renata Maria'); p.locator('#efRaiz .ef-bicho').nth(6).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(400)
        r.t('Mesmo nome com outro bichinho na família: pergunta "JÁ EXISTE 🦋 Renata Maria NA FAMÍLIA. É VOCÊ?"', aberta(p,'ef-pergunta') and 'É VOCÊ?' in p.text_content('.ef-pergunta'))
        p.click('.ef-pergunta .ef-nao'); esperar_recarga(p)
        pf = perfis(p)['perfis']
        r.t('"Não, sou outra criança": é outra criança (🐯)', len(pf)==2 and pf[1]['av']=='🐯', pf)
        fechar_app_popups(p)
        p.reload(); p.wait_for_timeout(900)
        r.t('Reabrir mantém os cadastros', len(perfis(p)['perfis'])==2)
        r.t('Com 2: "Quem vai estudar hoje?" com os 2 cartões e ➕', p.locator('.ef-t4 .ef-crianca[data-id]').count()==2 and p.is_visible('.ef-t4 .ef-novo'))
        acoes = p.evaluate("Array.from(document.querySelectorAll('.ef-t4 .ef-barra-botoes .ef-btn')).map(b=>b.textContent)")
        r.t('Botões da T4: ☁️ BUSCAR NA NUVEM, 🔄 ATUALIZAR AGORA, ✏️ ARRUMAR', acoes==[T['t4Buscar'],T['t4Atualizar'],T['t4Arrumar']], acoes)
        id0 = perfis(p)['perfis'][0]['id']
        p.locator('.ef-t4 .ef-crianca[data-id="%s"]' % id0).click(); esperar_recarga(p, 2500)
        r.t('Tocar no cartão entra no progresso daquela criança', perfis(p)['atual']==id0)
        fechar_app_popups(p); fechar_tudo(p)
        p.click('#efChip .ef-chip'); p.wait_for_timeout(300)
        r.t('Tocar no chip (bichinho na barra de cima) abre "Quem vai estudar hoje?"', aberta(p,'ef-t4'))
        p.click('.ef-arrumar'); p.wait_for_timeout(200)
        r.t('✏️ ARRUMAR liga o modo "✏️ ARRUMANDO" com ✏️ e 🗑️ em cada cartão', T['t7Titulo'] in p.text_content('.ef-t4') and p.locator('.ef-t4 .ef-mudar').count()==2 and p.locator('.ef-t4 .ef-tirar').count()==2)
        p.locator('.ef-t4 .ef-crianca[data-id="%s"] .ef-mudar' % id0).click(); p.wait_for_timeout(300)
        r.t('✏️ abre "✏️ MUDAR NOME OU BICHINHO" já com o nome e o bichinho', p.text_content('.ef-t5 .ef-titulo')==T['t5Mudar'] and p.input_value('.ef-nome-campo')=='Renata Maria' and p.evaluate("document.querySelector('.ef-bicho.ef-on').textContent")=='🦋')
        p.locator('#efRaiz .ef-bicho').nth(6).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(300)
        r.t('Mudar para o nome + bichinho de OUTRA criança do celular é bloqueado', 'JÁ EXISTE NESTE CELULAR' in toast(p) and perfis(p)['perfis'][0]['av']=='🦋', toast(p))
        p.fill('.ef-nome-campo','Renata'); p.locator('#efRaiz .ef-bicho').nth(4).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(400)
        r.t('Mudança válida grava certo', perfis(p)['perfis'][0]['nome']=='Renata')
        p.click('.ef-terminei'); p.wait_for_timeout(200)
        r.t('"✅ TERMINEI DE ARRUMAR" volta ao normal', T['t4Titulo'] in p.text_content('.ef-t4'))
        ctx.close()
        # máximo 6 por família
        mx = json.dumps({"perfis":[{"id":"p%d"%i,"nome":"C%d"%i,"av":"🦉"} for i in range(6)],"atual":"p0"})
        ctx, fb = novo_contexto(b, familia=FAM, storage={'ev_perfis':mx})
        p = abrir(ctx)
        r.t('Com 6 crianças na família, o cartão ➕ some', p.locator('.ef-t4 .ef-novo').count()==0)
        p.evaluate("EscolaFamilia.abrir('nova')"); p.wait_for_timeout(200)
        r.t('Máximo de 6 crianças por família', 'O MÁXIMO' in toast(p) and not aberta(p,'ef-t5'))
        ctx.close()
        # bichinho antigo
        ant = json.dumps({"perfis":[{"id":"1","nome":"Hana","av":"👧"},{"id":"p2","nome":"Bia","av":"🦄"}],"atual":"1"})
        ctx, fb = novo_contexto(b, familia=FAM, storage={'ev_perfis':ant,'p2_hana_done':'111'})
        p = abrir(ctx)
        r.t('Criança com bichinho antigo (🦄) continua aparecendo', '🦄' in p.text_content('.ef-t4'))
        p.locator('.ef-t4 .ef-crianca[data-id="p2"]').click(); esperar_recarga(p, 2500)
        r.t('...e abre normalmente, com o progresso dela', perfis(p)['atual']=='p2' and p.evaluate("doneN")==3)
        fechar_app_popups(p); fechar_tudo(p)
        p.evaluate("abrirEditarPerfil('p2')"); p.wait_for_timeout(200)
        r.t('Ao mudar: "O BICHINHO 🦄 MUDOU: ESCOLHA UM DOS 8 NOVOS 🙂" e nenhum pré-escolhido',
            p.text_content('.ef-escolhido')=='O BICHINHO 🦄 MUDOU: ESCOLHA UM DOS 8 NOVOS 🙂' and p.locator('.ef-bicho.ef-on').count()==0, p.text_content('.ef-escolhido'))
        p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(200)
        r.t('Só salva quando um dos 8 for escolhido', perfis(p)['perfis'][1]['av']=='🦄')
        p.locator('#efRaiz .ef-bicho').nth(2).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(300)
        r.t('Escolhendo um dos 8, salva e o progresso continua dela', perfis(p)['perfis'][1]['av']=='🐰' and ls(p,'p2_hana_done')=='111')
        r.t('Nunca troca o bichinho de ninguém automaticamente (Hana 👧 intacta)', perfis(p)['perfis'][0]['av']=='👧')
        ctx.close()
        # sem nuvem configurada
        ctx, fb = novo_contexto(b, config='vazia')
        p = abrir(ctx)
        r.t('Sem nuvem configurada: não pede código (sem T1), abre "Quem vai estudar hoje?"', not aberta(p,'ef-t1') and aberta(p,'ef-t4'))
        r.t('...com a bolinha 🔴 "NUVEM DESLIGADA" e sem "🔄 ATUALIZAR AGORA"', 'NUVEM DESLIGADA' in p.text_content('.ef-t4') and not p.is_visible('.ef-atualizar'))
        nova_crianca(p, 'Lia', 3)
        r.t('...e cadastra normalmente (sem nuvem)', perfis(p)['perfis'][0]['nome']=='Lia')
        ctx.close()
        r.t('Nenhum erro de JavaScript', not [e for e in erros if '404' not in e], erros)
        r1 = r.fim()

        # ---------------- 2ª conferência: tamanhos de tela ----------------
        r = R('CADASTRO PADRÃO — 2ª conferência: celular (tamanhos, com e sem teclado)')
        tamanhos = [('deitado',740,360),('deitado',640,360),('deitado',568,320),('tablet',1024,600),
                    ('em pé',360,740),('em pé',320,568),('em pé',412,915),
                    ('teclado deitado',740,170),('teclado deitado',640,150),('teclado deitado',568,140),
                    ('teclado em pé',360,420),('teclado em pé',320,300)]
        MED = """()=>{
          const vw=innerWidth, vh=innerHeight;
          const visto=el=>{ if(!el) return false; const r=el.getBoundingClientRect(); return r.width>0&&r.height>0&&r.top>=-0.5&&r.bottom<=vh+0.5&&r.left>=-0.5&&r.right<=vw+0.5; };
          const bs=Array.from(document.querySelectorAll('#efRaiz .ef-bicho')).map(b=>b.getBoundingClientRect());
          const top=new Set(bs.map(r=>Math.round(r.top)));
          let sobrepoe=false; for(let i=1;i<bs.length;i++) if(bs[i].left < bs[i-1].right-0.5) sobrepoe=true;
          const dentro=bs.every(r=>r.left>=0&&r.right<=vw&&r.top>=0&&r.bottom<=vh);
          const min=Math.min(...bs.map(r=>Math.min(r.width,r.height)));
          const pr=[document.querySelector('#efRaiz .ef-pronto'),document.querySelector('#efRaiz .ef-pronto-mini')].filter(x=>x&&x.offsetParent)[0];
          const letras=[]; document.querySelectorAll('#efRaiz *').forEach(e=>{ if(e.offsetParent && e.childNodes.length && Array.from(e.childNodes).some(n=>n.nodeType===3&&n.textContent.trim())) letras.push(parseFloat(getComputedStyle(e).fontSize)); });
          const botoes=Array.from(document.querySelectorAll('#efRaiz button')).filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect().height);
          return {linhas:top.size, sobrepoe, dentro, min, nome:visto(document.querySelector('#efRaiz .ef-nome-campo')), pronto:visto(pr),
                  menorLetra:Math.min(...letras), menorBotao:Math.min(...botoes)};
        }"""
        for nome,w,h in tamanhos:
            ctx, fb = novo_contexto(b, largura=w, altura=h, familia=FAM)
            p = abrir(ctx)
            p.evaluate("EscolaFamilia.abrir('nova')"); p.wait_for_timeout(300)
            if 'teclado' in nome: p.focus('#efRaiz .ef-nome-campo'); p.wait_for_timeout(450)
            m = p.evaluate(MED)
            ok = m['linhas']==1 and not m['sobrepoe'] and m['dentro'] and m['min']>=30 and m['nome'] and m['pronto'] and m['menorLetra']>=14 and m['menorBotao']>=30
            p.locator('#efRaiz .ef-bicho').nth(7).tap()
            ponei = p.evaluate("document.querySelector('#efRaiz .ef-bicho.ef-on').textContent")=='🐴'
            r.t('T5 %s %dx%d: 8 numa linha, inteiros, ≥30 px (%.0f), nome e Pronto visíveis, letra ≥14 px (%.0f), tocar no 🐴 escolhe' % (nome,w,h,m['min'],m['menorLetra']), ok and ponei, m)
            if w==740 and h==170: p.screenshot(path=os.path.join(os.path.dirname(__file__),'cad_teclado_740x170.png'))
            if w==360 and h==740: p.screenshot(path=os.path.join(os.path.dirname(__file__),'cad_empe_360x740.png'))
            ctx.close()
        # pop-up do código com teclado: campo e botão visíveis
        for w,h in [(740,170),(568,140),(360,420),(320,300),(740,360)]:
            ctx, fb = novo_contexto(b, largura=w, altura=h)
            p = abrir(ctx)
            p.click('.ef-t1-ja'); p.wait_for_timeout(300); p.focus('.ef-t2 .ef-codigo'); p.wait_for_timeout(400)
            m = p.evaluate("""()=>{ const vh=innerHeight, vw=innerWidth; const v=el=>{ if(!el) return false; const r=el.getBoundingClientRect(); return r.width>0&&r.top>=-0.5&&r.bottom<=vh+0.5&&r.left>=-0.5&&r.right<=vw+0.5; };
              const bt=[document.querySelector('.ef-t2 .ef-procurar'),document.querySelector('.ef-t2 .ef-procurar-mini')].filter(x=>x&&x.offsetParent)[0];
              return {campo:v(document.querySelector('.ef-t2 .ef-codigo')), botao:v(bt), txt: bt?bt.textContent:''}; }""")
            r.t('Código da família %dx%d com teclado: campo e "🔑 PROCURAR A FAMÍLIA" visíveis' % (w,h), m['campo'] and m['botao'] and m['txt']=='🔑 PROCURAR A FAMÍLIA', m)
            ctx.close()
        ctx, fb = novo_contexto(b, largura=360, altura=740, familia=FAM)
        p = abrir(ctx); p.evaluate("EscolaFamilia.abrir('nova')"); p.wait_for_timeout(200)
        r.t('A tela de cadastro não é girada à força (em pé continua em pé)', p.evaluate("getComputedStyle(document.querySelector('.ef-t5')).transform")=='none')
        r.t('Meta viewport com interactive-widget=resizes-content', 'interactive-widget=resizes-content' in p.evaluate("document.querySelector('meta[name=viewport]').content"))
        ctx.close()
        r2 = r.fim()

        # ---------------- 3ª conferência: padronização ----------------
        r = R('CADASTRO PADRÃO — 3ª conferência: padronização')
        ctx, fb = novo_contexto(b)
        p = abrir(ctx)
        r.t('escola-pwa.js é a versão 2 (mesmo arquivo dos outros apps)', p.evaluate("EscolaPWA.versao")=='2')
        r.t('nuvem-sync.js é a versão 4.1', p.evaluate("NuvemSync.versao")=='4.1')
        r.t('escola-familia.js é a versão 1.2', p.evaluate("EscolaFamilia.versao")=='1.2')
        r.t('Chave da criança na nuvem: "Renata"+🦋 → renata_1f98b', p.evaluate("chaveLeitor('Renata','🦋')")=='renata_1f98b')
        r.t('Maiúscula/acento/espaço não mudam a chave ("  RENÁTA "+🦋)', p.evaluate("chaveLeitor('  RENÁTA ','🦋')")=='renata_1f98b')
        r.t('ID do app na nuvem: alfabetizacao', p.evaluate("APP_NUVEM")=='alfabetizacao')
        ctx.close()
        r3 = r.fim()
        b.close()
    return [r1,r2,r3]

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nCADASTRO: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
