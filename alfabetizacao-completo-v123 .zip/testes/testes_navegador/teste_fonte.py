"""F) Tamanho da letra IGUAL em todas as frases (v121).
Antes, cada frase era esticada até encher o quadro × o número escolhido:
frase curta ("a tia") saía gigante e, no 22/24, cortada. Agora o número
escolhido vale um tamanho fixo, medido numa frase-padrão."""
from base import *
import json
PF = json.dumps({"perfis":[{"id":"1","nome":"Teste","av":"🐧"}],"atual":"1"})

MEDIR_LER = """(fsi)=>{
  ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open'));
  trocarPagina('ler'); fsIdx=fsi; FSCALE=FSTEPS[fsi];
  const seq=construirOrdemDificuldade(); const out=[];
  const lista=[]; for(let k=0;k<300;k+=3) lista.push(seq[k]);
  const curta=seq.find(i=>fraseDe(i).split('|')[0].trim().split(/\\s+/).length<=2);
  if(curta!==undefined) lista.push(curta);
  for(const i of lista){ idx=i; render();
    out.push({fs:parseFloat(phraseEl.style.fontSize), pal:fraseDe(i).split('|')[0].trim().split(/\\s+/).length,
      cortada: phraseEl.scrollWidth>areaEl.clientWidth+1 || phraseEl.scrollHeight>areaEl.clientHeight+1, txt:fraseDe(i).split('|')[0]}); }
  return out; }"""

def main():
    servidor()
    r = R('F) Tamanho da letra igual em todas as frases')
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for w,h in [(800,360),(740,360),(1024,600),(412,915)]:
            ctx,fb = novo_contexto(b, config='vazia', largura=w, altura=h, storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
            p = abrir(ctx)
            tam_por_num = {}
            for fsi in (0,5,6,7):
                o = p.evaluate(MEDIR_LER, fsi)
                nome = p.evaluate("FSNOMES[fsIdx]")
                fs = [x['fs'] for x in o]; maior = max(fs)
                iguais = sum(1 for x in o if x['fs']==maior)
                cort = [x['txt'] for x in o if x['cortada']]
                r.t('Ler %dx%d tamanho %s: nenhuma frase cortada' % (w,h,nome), not cort, cort[:3])
                if w>h:
                    r.t('Ler %dx%d tamanho %s: TODAS as %d frases no mesmo tamanho (%dpx)' % (w,h,nome,len(o),maior), iguais==len(o), sorted(set(fs)))
                else:
                    r.t('Ler %dx%d (em pé) tamanho %s: pelo menos 90%% no mesmo tamanho; só frases longas menores' % (w,h,nome),
                        iguais>=0.9*len(o) and all(x['pal']>=5 for x in o if x['fs']<maior), (iguais,len(o)))
                curta = o[-1]
                r.t('Ler %dx%d tamanho %s: frase curtinha ("%s") NÃO fica maior que as outras' % (w,h,nome,curta['txt']), curta['fs']==maior)
                tam_por_num[nome]=maior
            r.t('Ler %dx%d: número maior = letra maior (10 < 20 < 22 < 24)' % (w,h),
                tam_por_num['10'] < tam_por_num['20'] < tam_por_num['22'] < tam_por_num['24'], tam_por_num)
            ctx.close()
        # outros módulos: nada cortado; palavra do Treinar Sílabas com e sem desenho iguais
        for w,h in [(800,360),(412,915)]:
            ctx,fb = novo_contexto(b, config='vazia', largura=w, altura=h, storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
            p = abrir(ctx)
            res = p.evaluate("""()=>{
              ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open'));
              fsIdx=6; FSCALE=FSTEPS[6]; window._testeSemAnimacao=true;
              const seq=construirOrdemDificuldade(); const r={monta:0,silaba:0,montaTot:0,silabaTot:0};
              trocarPagina('monta');
              for(let k=0;k<60;k++){ idxMonta=seq[k*3]; renderMontaPagina(); fitMonta();
                const e=document.getElementById('mtWrap'), a=document.querySelector('#pgMonta .pgConteudo');
                r.montaTot++; if(e.scrollWidth>a.clientWidth+1||e.scrollHeight>a.clientHeight+1) r.monta++; }
              trocarPagina('silaba');
              for(let k=0;k<60;k++){ idxSilaba=seq[k*3]; renderSilabaPagina(); fitSilaba();
                const e=document.getElementById('spWrap'), a=document.querySelector('#pgSilaba .pgConteudo');
                r.silabaTot++; if(e.scrollWidth>a.clientWidth+1||e.scrollHeight>a.clientHeight+1) r.silaba++; }
              trocarPagina('treino'); const f=SILABAS_FASE1[0]; abrirLeitorSimples(f, f.silabas[0].s);
              const tam=p=>{ _lpIdx=_lpLista.findIndex(x=>x.p===p); renderLeitorPalavraAtual(); return [parseFloat(document.getElementById('lpPalavra').style.fontSize), !!_lpLista[_lpIdx].e]; };
              r.mapa=tam('Mapa'); r.mamao=tam('Mamão');
              return r; }""")
            r.t('Monta a Frase %dx%d: nenhuma das 60 frases cortada' % (w,h), res['monta']==0, res)
            r.t('Sílaba Perdida %dx%d: nenhuma das 60 frases cortada' % (w,h), res['silaba']==0, res)
            if w>h:
                r.t('Treinar Sílabas %dx%d: "Mapa" (com desenho) e "Mamão" (sem desenho) no mesmo tamanho' % (w,h),
                    res['mapa'][1] and not res['mamao'][1] and res['mapa'][0]==res['mamao'][0], (res['mapa'],res['mamao']))
            else:
                # em pé a largura é pouca: "MAMÃO" (mais larga) pode precisar diminuir para caber, mas NUNCA fica maior
                r.t('Treinar Sílabas %dx%d (em pé): palavra sem desenho nunca fica maior que a com desenho' % (w,h),
                    res['mapa'][1] and not res['mamao'][1] and res['mamao'][0]<=res['mapa'][0], (res['mapa'],res['mamao']))
            ctx.close()
        b.close()
    return r.fim()

if __name__=='__main__':
    ok,tot = main()
    print('\nFONTE: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
