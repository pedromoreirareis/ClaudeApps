/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Lógica de juntar bibliotecas (nuvem) e de montar o pacote que sobe —
   direto no Node, extraída do index.html publicado. */
const fs = require('fs');
const INDEX = process.env.CORUJA_INDEX || require('path').join(__dirname, '..', 'pacote-netlify', 'index.html');
const TMP = require('path').join(process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'), '_logic_nuvem.js'); require('fs').mkdirSync(require('path').dirname(TMP), { recursive: true });
const html = fs.readFileSync(INDEX, 'utf8');
const script = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m => m[1]).find(t => t.includes('(function(root)'));
const linhas = script.split('\n');
const ini = linhas.findIndex(l => l.startsWith('(function(root)'));
const fim = linhas.findIndex(l => l.startsWith('})(typeof window'));
fs.writeFileSync(TMP, linhas.slice(ini, fim + 1).join('\n'));
const C = require(TMP);

let falhas = 0, total = 0;
function ok(nome, cond, det){ total++; if (cond) console.log('✅', nome); else { falhas++; console.log('❌', nome, det ? '— ' + det : ''); } }
const J = x => JSON.stringify(x);
const T = (id, extra) => Object.assign({ id, titulo: 'T' + id, texto: 'Texto ' + id, criadoEm: '2026-09-01T10:00:00.000Z' }, extra || {});
const M = (l, r, el, er) => C.mesclarBibliotecas({ textos: l, excluidos: el || {} }, { textos: r, excluidos: er || {} });

ok('Funções exportadas', typeof C.mesclarBibliotecas === 'function' && typeof C.montarExportacao === 'function' && C.LIMITE_NUVEM_BYTES === 850000);

// união
let r = M([T('a')], [T('b')]);
ok('Textos diferentes dos dois lados: ficam os dois', r.textos.map(t => t.id).sort().join() === 'a,b');
r = M([T('a')], []);
ok('Nuvem vazia não apaga nada daqui', r.textos.length === 1);
r = M([], [T('a')]);
ok('Celular vazio recebe tudo da nuvem', r.textos.length === 1);
r = M(null, undefined);
ok('Entradas quebradas não travam', Array.isArray(r.textos) && r.textos.length === 0);
r = C.mesclarBibliotecas({ textos: 'x' }, { textos: [null, 5, {}, T('a')] });
ok('Itens inválidos são ignorados', r.textos.length === 1 && r.textos[0].id === 'a');

// edição
r = M([T('a', { titulo: 'Velho', alteradoEm: '2026-09-02T00:00:00Z' })], [T('a', { titulo: 'Novo', alteradoEm: '2026-09-03T00:00:00Z' })]);
ok('Edição mais nova vence (vinda da nuvem)', r.textos.length === 1 && r.textos[0].titulo === 'Novo');
r = M([T('a', { titulo: 'Novo', alteradoEm: '2026-09-05T00:00:00Z' })], [T('a', { titulo: 'Velho', alteradoEm: '2026-09-03T00:00:00Z' })]);
ok('Edição mais nova vence (feita aqui)', r.textos[0].titulo === 'Novo');

// lido
r = M([T('a', { arquivado: true, arquivadoEm: '2026-09-04T00:00:00Z', estadoEm: '2026-09-04T00:00:00Z' })], [T('a')]);
ok('Marcado como lido num aparelho fica lido', r.textos[0].arquivado === true && r.textos[0].arquivadoEm === '2026-09-04T00:00:00Z');
r = M([T('a', { arquivado: true, arquivadoEm: '2026-09-04T00:00:00Z', estadoEm: '2026-09-04T00:00:00Z' })], [T('a', { estadoEm: '2026-09-06T00:00:00Z' })]);
ok('Devolvido depois (mais novo) volta para "Meus textos"', !r.textos[0].arquivado && !('arquivadoEm' in r.textos[0]));
r = M([T('a', { titulo: 'Editado', alteradoEm: '2026-09-07T00:00:00Z' })], [T('a', { arquivado: true, arquivadoEm: '2026-09-04T00:00:00Z', estadoEm: '2026-09-04T00:00:00Z' })]);
ok('Editar num aparelho e marcar lido no outro: ficam as duas coisas', r.textos[0].titulo === 'Editado' && r.textos[0].arquivado === true);

// contadores e quiz
r = M([T('a', { leituras: 3, ultimaLeitura: '2026-09-02T00:00:00Z' })], [T('a', { leituras: 5, ultimaLeitura: '2026-09-01T00:00:00Z' })]);
ok('Vezes que foi aberto: fica o maior', r.textos[0].leituras === 5 && r.textos[0].ultimaLeitura === '2026-09-02T00:00:00Z');
const q1 = { tentativas: [{ em: '2026-09-02T10:00:00Z', acertos: 1, total: 3 }], melhor: 1, total: 3 };
const q2 = { tentativas: [{ em: '2026-09-02T10:00:00Z', acertos: 1, total: 3 }, { em: '2026-09-03T10:00:00Z', acertos: 3, total: 3 }], melhor: 3, total: 3 };
r = M([T('a', { quiz: q1 })], [T('a', { quiz: q2 })]);
ok('Respostas do quiz se juntam sem repetir', r.textos[0].quiz.tentativas.length === 2 && r.textos[0].quiz.melhor === 3, J(r.textos[0].quiz));
const muitas = { tentativas: Array.from({ length: 40 }, (_, i) => ({ em: '2026-09-02T10:' + String(i).padStart(2, '0') + ':00Z', acertos: i % 4, total: 3 })) };
r = M([T('a', { quiz: muitas })], [T('a', { quiz: q1 })]);
ok('Histórico do quiz guarda as 30 mais novas', r.textos[0].quiz.tentativas.length === 30 && r.textos[0].quiz.tentativas[29].em.endsWith('39:00Z'), J(r.textos[0].quiz.tentativas.length));
r = M([T('a')], [T('a', { quiz: q1 })]);
ok('Quiz só de um lado não se perde', r.textos[0].quiz && r.textos[0].quiz.melhor === 1);
r = M([T('a', { criadoEm: '2026-09-03T00:00:00Z' })], [T('a', { criadoEm: '2026-09-01T00:00:00Z' })]);
ok('Data de criação: fica a mais antiga', r.textos[0].criadoEm === '2026-09-01T00:00:00Z');

// exclusão
r = M([], [T('a')], { a: '2026-09-05T00:00:00Z' }, {});
ok('Apagado aqui depois de tudo: não volta da nuvem', r.textos.length === 0 && r.excluidos.a);
r = M([T('a')], [], {}, { a: '2026-09-05T00:00:00Z' });
ok('Apagado em outro aparelho: some daqui também', r.textos.length === 0);
r = M([T('a', { alteradoEm: '2026-09-06T00:00:00Z' })], [], {}, { a: '2026-09-05T00:00:00Z' });
ok('Editado DEPOIS de apagado em outro aparelho: continua (nada se perde)', r.textos.length === 1);
r = M([T('a', { arquivado: true, arquivadoEm: '2026-09-06T00:00:00Z', estadoEm: '2026-09-06T00:00:00Z' })], [], {}, { a: '2026-09-05T00:00:00Z' });
ok('Lido DEPOIS de apagado em outro aparelho: continua', r.textos.length === 1);
r = M([], [T('a', { leituras: 3, ultimaLeitura: '2026-09-12T00:00:00Z' })], { a: '2026-09-10T00:00:00Z' }, {});
ok('Aberto para ler DEPOIS de apagado em outro aparelho: continua', r.textos.length === 1);
r = M([], [T('a', { quiz: { tentativas: [{ em: '2026-09-12T00:00:00Z', acertos: 3, total: 3 }], melhor: 3, total: 3 } })], { a: '2026-09-10T00:00:00Z' }, {});
ok('Quiz respondido DEPOIS de apagado em outro aparelho: continua', r.textos.length === 1 && r.textos[0].quiz.melhor === 3);
r = M([], [T('a', { leituras: 3, ultimaLeitura: '2026-09-08T00:00:00Z' })], { a: '2026-09-10T00:00:00Z' }, {});
ok('Lido ANTES de apagar: some (a exclusão vale)', r.textos.length === 0);
r = M([], [], { a: '2026-09-01T00:00:00Z' }, { a: '2026-09-05T00:00:00Z' });
ok('Lápides se juntam com a data mais nova', r.excluidos.a === '2026-09-05T00:00:00Z');

// texto cortado na nuvem
r = M([T('a', { arquivado: true, estadoEm: '2026-09-02T00:00:00Z' })], [T('a', { texto: '', semTexto: true, arquivado: true, estadoEm: '2026-09-02T00:00:00Z' })]);
ok('Texto que subiu sem conteúdo não apaga o conteúdo do celular', r.textos[0].texto === 'Texto a' && !r.textos[0].semTexto);
r = M([], [T('a', { texto: '', semTexto: true })]);
ok('Celular novo recebe o texto cortado marcado como "semTexto"', r.textos[0].semTexto === true);

// ordem
r = M([T('b', { criadoEm: '2026-09-05T00:00:00Z' })], [T('a', { criadoEm: '2026-09-01T00:00:00Z' })]);
ok('Ordem: o mais antigo primeiro', r.textos.map(t => t.id).join() === 'a,b');

// idempotência / comutatividade
const L = [T('a', { leituras: 2, quiz: q1 }), T('b', { arquivado: true, arquivadoEm: '2026-09-02T00:00:00Z', estadoEm: '2026-09-02T00:00:00Z' })];
const R = [T('a', { titulo: 'X', alteradoEm: '2026-09-04T00:00:00Z', quiz: q2 }), T('c')];
const r1 = M(L, R), r2 = M(R, L);
ok('Juntar A com B dá o mesmo que B com A', J(r1.textos.map(t => [t.id, t.titulo, !!t.arquivado, t.leituras, t.quiz && t.quiz.melhor])) === J(r2.textos.map(t => [t.id, t.titulo, !!t.arquivado, t.leituras, t.quiz && t.quiz.melhor])));
const r3 = M(r1.textos, r1.textos);
ok('Juntar de novo não muda nada', J(r3.textos) === J(r1.textos));

// montarExportacao
let e = C.montarExportacao([T('a')], { z: '2026-09-01' }, '{"fsizeIdx":3}');
ok('Pacote com textos, lápides e ajustes (textos em JSON)', J(JSON.parse(e.dados.textos)) === J([T('a')]) && e.dados.config === '{"fsizeIdx":3}' && JSON.parse(e.dados.excluidos).z && e.cortados === 0);
e = C.montarExportacao([T('a')], {}, null);
ok('Sem ajustes guardados: pacote sem "config"', !('config' in e.dados));
const grande = 'x'.repeat(20000);
const lista = Array.from({ length: 60 }, (_, i) => T('g' + i, { texto: grande, arquivado: i < 50, arquivadoEm: '2026-08-' + String(1 + (i % 28)).padStart(2, '0') + 'T00:00:00Z' }));
const original = J(lista);
e = C.montarExportacao(lista, {}, null, 400000);
const sub = JSON.parse(e.dados.textos);
ok('Biblioteca grande cabe no limite', Buffer.byteLength(J(e.dados)) <= 400000, Buffer.byteLength(J(e.dados)));
ok('Só textos JÁ LIDOS sobem sem o conteúdo', sub.filter(t => t.semTexto).every(t => t.arquivado) && sub.filter(t => !t.arquivado).every(t => t.texto === grande));
ok('Nenhum texto some da lista (histórico completo)', sub.length === 60 && e.cortados > 0 && sub.filter(t => t.semTexto).length === e.cortados);
ok('Os lidos mais antigos são os cortados primeiro', (() => { const cort = sub.filter(t => t.semTexto).map(t => t.arquivadoEm).sort(); const inteiros = sub.filter(t => t.arquivado && !t.semTexto).map(t => t.arquivadoEm).sort(); return !inteiros.length || cort[cort.length - 1] <= inteiros[0]; })());
ok('A lista do celular não é alterada (só o pacote)', J(lista) === original);
const acentos = Array.from({ length: 3 }, (_, i) => T('c' + i, { texto: 'ção'.repeat(60000), arquivado: true, arquivadoEm: '2026-08-0' + (i + 1) }));
e = C.montarExportacao(acentos, {}, null, 500000);
ok('Limite contado em bytes reais (acentos pesam 2)', Buffer.byteLength(J(e.dados)) <= 500000 && e.cortados >= 1);

console.log(`\n===== ${total - falhas}/${total} testes da lógica da nuvem ${falhas ? '— ❌ HÁ FALHAS' : '— ✅ TUDO CERTO'} =====`);
process.exit(falhas ? 1 : 0);
