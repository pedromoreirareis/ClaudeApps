const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = '/home/claude/build';
const PORT = 8936;
const OUT = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad';

const MIME = { '.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };
function serve(){
  return http.createServer((req,res)=>{
    let p = req.url.split('?')[0]; if (p==='/') p='/index.html';
    const fp = path.join(ROOT,p);
    fs.readFile(fp,(err,data)=>{
      if (err){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200,{'Content-Type': MIME[path.extname(fp)]||'application/octet-stream'});
      res.end(data);
    });
  }).listen(PORT);
}

(async () => {
  const server = serve();
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 915 } });
  const page = await ctx.newPage();
  await page.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${OUT}/01-home-retrato.png` });

  // cria um texto de teste para poder ver a biblioteca e a leitura preenchidas
  await page.click('text=PREPARAR TEXTO');
  await page.waitForTimeout(200);
  const textoTeste = `TÍTULO: Por que o coração acelera?
TEXTO:
— Por que meu coração bate tão rápido quando eu corro? — perguntou Hinata.
Isso acontece porque seu corpo precisa de mais "oxigênio" (o ar que a gente respira) para os músculos trabalharem. O coração bate mais rápido — cerca de 3 vezes mais depressa — para levar sangue com mais força para todo o corpo...

PALAVRAS NOVAS:
oxigênio: um gás do ar que o corpo precisa para viver.

PARA PENSAR:
Você já sentiu seu coração bater rápido depois de correr muito?`;
  await page.fill('#caixaTexto', textoTeste);
  await page.click('#btnFormatar');
  await page.waitForTimeout(150);
  await page.fill('#inpTitulo', 'Por que o coração acelera?');
  await page.click('#btnSalvar');
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${OUT}/02-biblioteca-retrato.png` });

  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/03-leitura-retrato.png` });

  // A+ a couple times to make the size difference visible in the screenshot
  await page.click('button[onclick="mudaFontSize(1)"]');
  await page.click('button[onclick="mudaFontSize(1)"]');
  await page.waitForTimeout(150);
  await page.screenshot({ path: `${OUT}/04-leitura-fonte-maior.png` });

  await page.click('#detCard .detX');
  await page.waitForTimeout(200);

  // Landscape now
  await page.setViewportSize({ width: 915, height: 412 });
  await page.waitForTimeout(200);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/05-leitura-paisagem.png` });

  await browser.close();
  server.close();
  console.log('done');
})();
