# 🦉 Padrão de cadastro, acesso e recuperação: NOME + BICHINHO

**Escola São Pedro. Vale para os 7 aplicativos.**
Versão 1 (implementado e testado no Curiosidades v1.7)

Este documento é a **regra oficial**. Serve para o Pedro, para o Claude e para o ChatGPT. Se algum app fizer diferente disto, o app está errado e deve ser corrigido.

---

## 1. A ideia em uma frase

A criança é identificada pelo **nome + bichinho**, por exemplo **Renata 🦋**. É assim em todos os apps, no celular e na nuvem. Não existe senha, e-mail nem número.

- **"Renata 🦋"** e **"renata 🦋"** são a **mesma** criança: maiúscula, acento e espaços sobrando não contam.
- **"Renata 🦋"** e **"Renata 🐯"** são **duas crianças diferentes**.
- Na nuvem, a ficha da criança se chama `nome-sem-acento_código-do-bichinho`. Exemplo: Renata 🦋 → `renata_1f98b`.

---

## 2. Os 8 bichinhos oficiais

**Os mesmos 8, nesta ordem, em todos os apps.** Não pode faltar, sobrar nem mudar a ordem.

| # | Bichinho | Nome | Código na nuvem |
|---|---|---|---|
| 1 | 🦉 | Coruja | `1f989` |
| 2 | 🦊 | Raposa | `1f98a` |
| 3 | 🐰 | Coelho | `1f430` |
| 4 | 🐼 | Panda | `1f43c` |
| 5 | 🦋 | Borboleta | `1f98b` |
| 6 | 🐨 | Coala | `1f428` |
| 7 | 🐯 | Tigre | `1f42f` |
| 8 | 🐴 | Pônei | `1f434` |

- A lista oficial fica no arquivo compartilhado **`escola-pwa.js`** (`EscolaPWA.BICHINHOS`, versão 2). Os apps leem a lista de lá.
- Cada app guarda também uma **cópia idêntica** da lista, que só é usada se o `escola-pwa.js` faltar. A cópia tem que ser igual à oficial.
- Em código:

```js
[{e:'🦉',nome:'Coruja'},{e:'🦊',nome:'Raposa'},{e:'🐰',nome:'Coelho'},{e:'🐼',nome:'Panda'},
 {e:'🦋',nome:'Borboleta'},{e:'🐨',nome:'Coala'},{e:'🐯',nome:'Tigre'},{e:'🐴',nome:'Pônei'}]
```

---

## 3. Como funciona o CADASTRO

**Tela de cadastro, com os textos exatos e nesta ordem, de cima para baixo:**
1. Título: **"🌟 Qual é o seu nome?"** (ao editar: **"✏️ Trocar nome ou bichinho"**)
2. Campo do nome, com o texto de exemplo **"Digite o seu nome..."** (até 14 letras)
3. **"Escolha o seu bichinho:"**
4. **Os 8 bichinhos numa linha só**
5. **"Você escolheu: 🦋 Borboleta"** (aparece depois de escolher)
6. Botões: **"← Voltar"** (só se já existe alguma criança), **"Pronto! ✅"** e **"☁️ Já tenho cadastro"** (este só aparece se a nuvem estiver configurada)

**Regras:**
- **Nenhum bichinho vem escolhido sozinho.** A criança escolhe de propósito, para lembrar depois.
- **Sem nome** → não cadastra e mostra "Escreva o seu nome primeiro 🙂".
- **Sem bichinho** → não cadastra e mostra "Escolha o seu bichinho 🙂".
- **Espaços** no começo e no fim são tirados, e espaços repetidos viram um só.
- **Enter no teclado:** se já escolheu o bichinho, cadastra. Se não, fecha o teclado e pede o bichinho.
- **Já existe no celular** a mesma criança (mesmo nome + bichinho) → **não cria outra igual**. Abre a que já existe ("Renata 🦋 já está neste celular — abrindo!").
- **Mesmo nome com outro bichinho** → é outra criança. É permitido.
- Máximo de **6 crianças** por celular.
- **Depois de cadastrar:** vai direto para a tela inicial do app. Se a nuvem estiver pronta e já existir uma ficha com esse nome + bichinho, **o progresso volta sozinho** ("☁️ Achei o progresso de Renata na nuvem!").

**Layout (obrigatório):**
- **Os 8 bichinhos sempre numa linha só.** Nunca quebram em duas linhas, em nenhum tamanho de tela.
- O tamanho de cada bichinho se ajusta à largura **e** à altura livres, com **no mínimo 30 px** (bom para o dedo).
- Com o **teclado aberto** (em pé ou deitado), continuam visíveis: o **campo do nome**, os **8 bichinhos** e o **Pronto**. O título e o "Você escolheu" podem sumir para caber.
- A tela de cadastro **não é girada à força**: funciona em pé e deitado. O teclado do celular precisa disso.
- A meta viewport tem **`interactive-widget=resizes-content`**. Assim, quando o teclado abre, a página diminui e se reorganiza **acima** do teclado, em vez de ficar escondida atrás dele.

**CSS de referência (Curiosidades v1.7):**

```css
#nuEmojis{display:flex;flex-wrap:nowrap;justify-content:center;align-items:center;
  gap:clamp(3px,1.2vw,9px);max-width:98vw}
.nuEmoji{--t:clamp(30px,min(10.4vw,15vh),62px);width:var(--t);height:var(--t);
  font-size:calc(var(--t)*.58);flex:0 0 auto;padding:0}
@media (max-height:300px){               /* teclado aberto / tela baixinha */
  .nuTitulo,.nuEscolhido{display:none}
  .nuEmoji{--t:clamp(30px,min(10.4vw,22vh),62px)}
}
```

---

## 4. Como funciona o ACESSO (entrar de novo)

| Crianças cadastradas no celular | O que aparece ao abrir o app |
|---|---|
| **Nenhuma** | tela de cadastro |
| **Uma** | entra direto no progresso dela |
| **Duas ou mais** | tela **"Quem vai estudar hoje?"** com um cartão por criança (bichinho grande + nome) |

- Na tela **"Quem vai estudar hoje?"**:
  - tocar no cartão entra no progresso daquela criança;
  - botões: **"✏️ Trocar nome ou bichinho"**, **"🗑️ Apagar este usuário"**, **"☁️ Recuperar da nuvem"** e o cartão **"➕ Novo usuário"**.
- Na tela inicial do app, o **chip com bichinho + nome** mostra quem está usando. Tocar nele volta para "Quem vai estudar hoje?".

---

## 5. Como funciona a RECUPERAÇÃO

Serve para dados apagados, celular novo ou criança que já usa outro app.

1. **Jeito mais simples:** cadastrar com **o mesmo nome e o mesmo bichinho**. O progresso volta sozinho (precisa da nuvem pronta: configuração + código da família).
2. **Pela tela de recuperação:** botão **"☁️ Já tenho cadastro"** (no cadastro) ou **"☁️ Recuperar da nuvem"** (em "Quem vai estudar hoje?" e nas Configurações).
   - Abre a tela **"☁️ Recuperar cadastro"**, com a lista das crianças da família guardadas na nuvem (bichinho + nome + nome do bichinho). A lista inclui crianças cadastradas **em outros apps**.
   - Tocar na criança traz o progresso dela para este celular.
   - Se pedir, digitar o **🔑 código da família**.
3. **Voltar um dia (histórico):** na mesma tela, **"🕘 Versões guardadas"** → tocar no dia. Aquele dia é **juntado** com o progresso atual.

**Nada é apagado na recuperação:** o que está no celular e o que está na nuvem são **juntados**.

---

## 6. Trocar o nome ou o bichinho

- Em "Quem vai estudar hoje?" → **"✏️ Trocar nome ou bichinho"**.
- A troca muda a identidade, e a nova ficha na nuvem **recebe todo o progresso da antiga**. A ficha antiga continua guardada.
- Se o novo nome + bichinho já pertence a **outra** criança do celular, a troca é **bloqueada**.

## 7. Crianças com bichinho antigo (de antes do padrão)

Exemplos: 🐧 🦄 🐸 🐢 🌸.
- **Nada se perde.** A criança continua aparecendo e abrindo normalmente com o bichinho antigo, e a recuperação também encontra a ficha antiga.
- Ao tocar em **"✏️ Trocar nome ou bichinho"**, o app avisa **"O bichinho 🦄 mudou: escolha um dos 8 novos 🙂"** e só salva quando um dos 8 é escolhido. O progresso vai junto (item 6).
- **Recomendação ao Pedro:** trocar, uma vez, o bichinho de quem tem bichinho antigo. **Use o mesmo bichinho novo em todos os apps.**

---

## 8. Como implementar em um app (novo ou já existente)

> ⚠️ **Os apps NÃO são iguais por dentro.** Não copie o código de um app para o outro às cegas. Estude o app, entenda como ele guarda crianças e progresso, e **adapte**. O objetivo é que a **criança** veja e use tudo igual, mesmo que o código por dentro seja diferente.

**App que JÁ TEM cadastro de crianças:**
1. Trocar a lista de bichinhos pela oficial (item 2), lendo de `EscolaPWA.BICHINHOS`, com a cópia de reserva igual.
2. Ajustar a tela de cadastro para os textos, a ordem, as regras e o layout do item 3.
3. Ajustar o acesso (item 4) e a recuperação (item 5).
4. **Não apagar nem trocar o bichinho de ninguém automaticamente.** Crianças com bichinho antigo seguem o item 7.
5. Manter a forma como o app guarda o progresso (localStorage). Só **acrescentar** o que falta.

**App que NÃO TEM cadastro (todo mundo usa o mesmo progresso):**
1. **Primeiro propor ao Pedro e esperar o OK.**
2. Criar o cadastro do item 3.
3. O progresso que já existe no celular vira da **primeira criança cadastrada** (não pode se perder).
4. Cada criança passa a ter o próprio progresso.

**App novo:** já nasce com este padrão, com os 3 arquivos compartilhados (`nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js`) e com a nuvem.

---

## 9. Verificações depois de implementar (tripla conferência)

**1ª conferência: funcionamento** (testes automáticos, se a IA puder rodar; senão, manual)
- ⬜ Aparecem exatamente os 8 bichinhos, na ordem oficial, com os nomes certos.
- ⬜ A lista vem do `escola-pwa.js` e a cópia de reserva é idêntica.
- ⬜ Nenhum bichinho vem escolhido sozinho.
- ⬜ Sem nome não cadastra. Sem bichinho não cadastra.
- ⬜ Nome e bichinho ficam gravados certos (espaços limpos).
- ⬜ Mesmo nome + bichinho não cria repetido. Mesmo nome com outro bichinho cria outra criança.
- ⬜ Reabrir o app mantém os cadastros. Acesso por "Quem vai estudar hoje?" funciona.
- ⬜ Recuperação pela tela e pelo cadastro com mesmo nome + bichinho funcionam.
- ⬜ Trocar nome ou bichinho leva o progresso. Troca para uma identidade de outra criança é bloqueada.
- ⬜ Criança com bichinho antigo continua funcionando.

**2ª conferência: celular** (testar estes tamanhos, com e sem teclado aberto)
- ⬜ Deitado: 740×360, 640×360, 568×320 e tablet 1024×600.
- ⬜ Em pé: 360×740, 320×568, 412×915.
- ⬜ Teclado aberto deitado: 740×170, 640×150, 568×140.
- ⬜ Teclado aberto em pé: 360×420, 320×300.
- Em **todos**, os 8 bichinhos devem estar:
  - ⬜ numa linha só;
  - ⬜ inteiros dentro da tela;
  - ⬜ sem um encostar no outro;
  - ⬜ com pelo menos 30 px;
  - ⬜ tocáveis (tocar no 🐴 escolhe o Pônei).
- ⬜ E também: o campo do nome e o botão Pronto visíveis.

**3ª conferência: padronização**
- ⬜ Mesmos 8 bichinhos, mesma ordem, mesmos textos, mesmas regras de cadastro, acesso e recuperação do que este documento.
- ⬜ O `escola-pwa.js` é o mesmo arquivo (versão 2) usado nos outros apps.
- ⬜ O que o documento diz bate com o que o app faz de verdade.

**No celular do Pedro (5 minutos):**
- ⬜ Abrir o cadastro deitado, tocar no campo do nome: com o teclado aberto, os 8 bichinhos aparecem numa linha, acima do teclado.
- ⬜ Mesma coisa em pé.
- ⬜ Cadastrar "Teste 🐴", fechar o app, abrir de novo: continua lá.
- ⬜ Em outro app já padronizado: cadastrar "Teste 🐴". Com a nuvem pronta, a mesma ficha aparece na recuperação.
