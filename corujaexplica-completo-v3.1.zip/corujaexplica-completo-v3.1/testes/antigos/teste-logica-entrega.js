/* Camada 1 da checagem: testa a lógica de texto (CorujaLogic) direto no Node,
   sem navegador. Extrai o módulo de dentro do index.html para garantir que o
   que está sendo testado é exatamente o que vai ser publicado. */
const fs = require('fs');
const path = require('path');

const INDEX = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad/verif-entrega/index.html';
const TMP = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad/_logic.js';

const html = fs.readFileSync(INDEX, 'utf8');
const script = html.match(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/)[1];
const linhas = script.split('\n');
const ini = linhas.findIndex(l => l.startsWith('(function(root)'));
const fim = linhas.findIndex(l => l.startsWith('})(typeof window'));
if (ini < 0 || fim < 0) { console.error('Não achei o módulo CorujaLogic'); process.exit(1); }
fs.writeFileSync(TMP, linhas.slice(ini, fim + 1).join('\n'));
delete require.cache[TMP];
const C = require(TMP);

let falhas = 0, total = 0;
function ok(nome, cond, detalhe) {
  total++;
  if (cond) { console.log('✅', nome, detalhe ? '— ' + detalhe : ''); }
  else { console.log('❌', nome, detalhe ? '— ' + detalhe : ''); falhas++; }
}

console.log('\n### 1. Formato Coruja — ida e volta pelo Formatar\n');

const comLinhasEmBranco = `TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?

TEXTO:
Você já sentiu o calor do Sol no rosto? Ele é uma estrela enorme.

— Pai, será que eu poderia chegar perto do Sol?

— Não seria possível, porque o Sol é quente demais.

Você pode observar algumas fases da Lua:

• Lua nova: a parte iluminada fica do outro lado.

• Lua cheia: vemos quase toda a face iluminada.

PALAVRAS NOVAS:
atmosfera = é a camada de ar que fica em volta de um planeta inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar que você respira.
rotação = é o movimento de girar em torno de si mesmo, igual a um pião rodando no chão. É por causa dela que existe o dia e a noite.

PARA PENSAR:
Por que a Lua parece brilhar, mesmo não produzindo luz própria?`;

const semLinhasEmBranco = `TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?
TEXTO:
Você já sentiu o calor do Sol no rosto? Ele é uma estrela enorme.

PALAVRAS NOVAS:
atmosfera = camada de ar em volta do planeta, como um cobertor invisível.

PARA PENSAR:
Por que a Lua parece brilhar?`;

[['com linhas em branco', comLinhasEmBranco], ['sem linha em branco entre TÍTULO e TEXTO', semLinhasEmBranco]]
  .forEach(([nome, txt]) => {
    const antes = C.interpretarTexto(txt);
    const arrumado = C.arrumarParaCaixa(txt);
    const depois = C.interpretarTexto(arrumado);
    ok(`Título sobrevive ao Formatar (${nome})`, antes.titulo === depois.titulo && !!depois.titulo, `"${depois.titulo}"`);
    ok(`Emoji sobrevive ao Formatar (${nome})`, antes.emoji === depois.emoji, `${depois.emoji}`);
    ok(`Parágrafos sobrevivem ao Formatar (${nome})`, antes.paragrafos.length === depois.paragrafos.length && depois.paragrafos.length > 0, `${depois.paragrafos.length}`);
    ok(`Palavras novas sobrevivem ao Formatar (${nome})`, Object.keys(depois.palavrasNovas).length === Object.keys(antes.palavrasNovas).length && Object.keys(depois.palavrasNovas).length > 0, `${Object.keys(depois.palavrasNovas).length}`);
    ok(`Para pensar sobrevive ao Formatar (${nome})`, !!depois.paraPensar && depois.paraPensar === antes.paraPensar);
  });

// Formatar duas vezes seguidas não pode mudar nada (idempotência) — importante
// porque agora o Formatar roda sozinho ao colar.
const uma = C.arrumarParaCaixa(comLinhasEmBranco);
const duas = C.arrumarParaCaixa(uma);
ok('Formatar duas vezes dá o mesmo resultado (idempotente)', uma === duas);

const r = C.interpretarTexto(comLinhasEmBranco);
ok('Falas com travessão viram parágrafos próprios', r.paragrafos.filter(p => /^—/.test(p.texto)).length === 2, `${r.paragrafos.filter(p => /^—/.test(p.texto)).length}`);
ok('Itens de lista viram tipo "exemplo"', r.paragrafos.filter(p => p.tipo === 'exemplo').length === 2);
ok('Definição longa do dicionário é preservada inteira',
  (r.palavrasNovas['atmosfera'] || '').length > 80, `${(r.palavrasNovas['atmosfera'] || '').length} caracteres`);

console.log('\n### 2. Texto livre (sem rótulos) continua funcionando\n');

const livre = 'Isso é uma frase solta sem formato nenhum. Aqui vem outra frase.\n\nE aqui um parágrafo novo, com mais conteúdo para testar.';
const arrumadoLivre = C.arrumarParaCaixa(livre);
ok('Texto livre não ganha rótulos indevidos', !/TÍTULO:/.test(arrumadoLivre));
ok('Texto livre mantém o conteúdo', /frase solta/.test(arrumadoLivre));
const rLivre = C.interpretarTexto(livre);
ok('Texto livre ainda gera um título', !!rLivre.titulo, `"${rLivre.titulo}"`);

console.log('\n### 3. Proteções de pontuação\n');

const tricky = 'O Dr. Silva mediu 3.5 metros. Ele pensou: "Eu consigo." Depois foi embora...';
const paras = C.limparEDividirEmParagrafos(tricky);
const junto = paras.map(p => p.texto).join(' ');
ok('Número decimal não vira fim de frase', /3\.5/.test(junto), junto.slice(0, 60));
ok('Abreviação "Dr." não vira fim de frase', /Dr\. Silva/.test(junto));
ok('Aspas de fechamento ficam na mesma frase', /"Eu consigo\."/.test(junto));
ok('Reticências são preservadas', /\.\.\.|…/.test(junto));

console.log('\n### 4. O novo pedido à IA (prompt)\n');

const prompt = C.montarPrompt('explicar', {});
const exigencias = [
  ['pede de 5 a 10 palavras no dicionário', /5 a 10 palavras/],
  ['pede explicações de 2 a 3 linhas', /2 a 3 linhas/],
  ['pede comparação com o mundo da criança', /compara(ção|ções)/i],
  ['traz o exemplo ruim de definição curta', /EXEMPLO RUIM/],
  ['traz o exemplo bom de definição longa', /EXEMPLO BOM/],
  ['exige um gancho no começo', /gancho/i],
  ['proíbe começar com "vamos aprender sobre"', /vamos aprender sobre/i],
  ['pede momentos de surpresa', /não sabia disso/i],
  ['mantém o travessão no diálogo', /travess/i],
  ['mantém a exigência de crase', /crase/i],
  ['mantém a lista com o sinal de bolinha', /•/],
  ['mantém o bloco PARA O PAI', /PARA O PAI/],
  ['mantém os quatro rótulos do formato', /TÍTULO:[\s\S]*TEXTO:[\s\S]*PALAVRAS NOVAS:[\s\S]*PARA PENSAR:/],
  ['mantém as regras de segurança de conteúdo', /cientistas|médico|adulto/i],
  ['proíbe negrito e #', /negrito/i]
];
exigencias.forEach(([nome, re]) => ok('Prompt ' + nome, re.test(prompt)));
ok('Prompt não deixa {{ }} sem preencher', !/\{\{/.test(prompt));
ok('Prompt usa a idade padrão de 6 anos', /IDADE: 6 anos/.test(prompt));

const pAdaptar = C.montarPrompt('adaptar', { texto: 'MEU TEXTO ORIGINAL AQUI' });
ok('Prompt Adaptar inclui o texto do pai', /MEU TEXTO ORIGINAL AQUI/.test(pAdaptar));
ok('Prompt Adaptar também exige dicionário de 2 a 3 linhas', /2 a 3 linhas/.test(pAdaptar));
ok('Prompt Adaptar não deixa {{ }} sobrando', !/\{\{/.test(pAdaptar));

const pContinuar = C.montarPrompt('continuar', { pergunta: 'MINHA PERGUNTA' });
ok('Prompt Continuar inclui a pergunta', /MINHA PERGUNTA/.test(pContinuar));
ok('Prompt Continuar lembra do dicionário longo', /2 a 3 linhas/.test(pContinuar));

const pConsertar = C.montarPrompt('consertar', {});
ok('Prompt Consertar existe e cita o formato', /PARA PENSAR/.test(pConsertar));

console.log('\n### 5. Textos grandes\n');
const grande = Array(400).fill('Esta é uma frase de teste com algumas palavras dentro dela.').join(' ');
const t0 = Date.now();
const rGrande = C.interpretarTexto(grande);
const ms = Date.now() - t0;
ok('Texto de ~4.000 palavras é processado', rGrande.paragrafos.length > 0, `${rGrande.paragrafos.length} parágrafos em ${ms}ms`);
ok('Processamento rápido (menos de 2 segundos)', ms < 2000, `${ms}ms`);

ok('Texto vazio não quebra', (() => { try { C.interpretarTexto(''); C.arrumarParaCaixa(''); return true; } catch (e) { return false; } })());

console.log(`\n===== ${total - falhas}/${total} testes de lógica passaram =====`);
process.exit(falhas === 0 ? 0 : 1);
