/* Camada 2b: as novidades da v2.0, no navegador real (Chromium).
   Mede o que aparece na tela: posição dos botões, tamanho real da letra,
   palavras de fato cortadas em duas linhas, seleção de texto, etc. */
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const ROOT = process.env.CORUJA_ROOT || '/home/claude/build';
const PORT = Number(process.env.CORUJA_PORT || 8961);
const OUT = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad';
const MIME = { '.html':'text/html','.js':'application/javascript','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };
const CRUZEIRO = fs.readFileSync(path.join(OUT, 'fixture-cruzeiro.txt'), 'utf8');
const SH = '­';

function serve(){
  return http.createServer((req,res)=>{
    let p = req.url.split('?')[0]; if (p === '/') p = '/index.html';
    fs.readFile(path.join(ROOT,p),(e,d)=>{
      if (e){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200,{'Content-Type': MIME[path.extname(p)] || 'application/octet-stream'});
      res.end(d);
    });
  }).listen(PORT);
}

let total = 0, falhas = 0;
function ok(nome, cond, det){
  total++;
  if (cond) console.log('✅', nome, det ? '— ' + det : '');
  else { falhas++; console.log('❌', nome, det ? '— ' + det : ''); }
}

const TEXTOS = [
  { id:'t1', titulo:'Como uma cruz no céu podia ajudar os navegadores?', texto: CRUZEIRO, criadoEm:'2026-09-20T10:00:00.000Z' },
  { id:'t2', titulo:'SARA E O SAPO', texto:'SARA E O SAPO FORAM PASSEAR NA FLORESTA ENCANTADA.', criadoEm:'2026-09-21T10:00:00.000Z' },
  { id:'t3', titulo:'Texto antigo já lido', texto:'TÍTULO: Chuva\n\nTEXTO:\nA chuva cai do céu.', criadoEm:'2026-09-01T10:00:00.000Z',
    arquivado:true, arquivadoEm:'2026-09-02T10:00:00.000Z', leituras:2 }
];

async function novaPagina(browser, vp, erros, extraInit){
  const ctx = await browser.newContext({ viewport: vp, hasTouch: true });
  await ctx.addInitScript(() => {
    /* Wake Lock de mentira, para contar os pedidos de "tela acesa" */
    window.__wake = { pedidos: 0, ativos: 0, ultimo: null };
    const fake = {
      request(tipo){
        window.__wake.pedidos++;
        const ouvintes = [];
        const lock = { type: tipo, released: false,
          addEventListener(ev, fn){ if (ev === 'release') ouvintes.push(fn); },
          release(){ this.released = true; window.__wake.ativos--; ouvintes.forEach(f => f()); return Promise.resolve(); } };
        window.__wake.ativos++; window.__wake.ultimo = lock;
        return Promise.resolve(lock);
      }
    };
    Object.defineProperty(navigator, 'wakeLock', { value: fake, configurable: true });
  });
  if (extraInit) await ctx.addInitScript(extraInit);
  const page = await ctx.newPage();
  page.on('pageerror', e => erros.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/favicon/i.test(m.text() + ((m.location() && m.location().url) || ''))) erros.push('console: ' + m.text() + ' @ ' + ((m.location() && m.location().url) || '')); });
  return { ctx, page };
}

async function semelhante(a, b, tol){ return Math.abs(a - b) <= (tol || 2); }

(async () => {
  const server = serve();
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const erros = [];
  const base = `http://localhost:${PORT}/index.html`;

  /* ================= RETRATO (celular 412x915) ================= */
  let { ctx, page } = await novaPagina(browser, { width: 412, height: 915 }, erros);
  await page.goto(base);
  await page.evaluate(t => { localStorage.clear(); localStorage.setItem('explica_textos', JSON.stringify(t)); }, TEXTOS);
  await page.reload();
  await page.waitForTimeout(300);

  console.log('\n### 1. Tela inicial: LER em destaque\n');
  const ini = await page.evaluate(() => {
    const r = s => document.querySelector(s).getBoundingClientRect();
    return { ler: r('.btnInicioLer'), prep: r('.btnInicioPreparar'), lidos: r('.btnInicioLidos'),
             vh: innerHeight, cont: document.getElementById('inicioContagem').textContent };
  });
  const centroLer = ini.ler.top + ini.ler.height / 2;
  ok('LER fica no meio da tela', centroLer > ini.vh * 0.3 && centroLer < ini.vh * 0.7, `centro em ${Math.round(centroLer)} de ${ini.vh}`);
  ok('LER é bem maior que Preparar', ini.ler.height > ini.prep.height * 2.5, `${Math.round(ini.ler.height)} × ${Math.round(ini.prep.height)}`);
  ok('Preparar texto fica embaixo do LER', ini.prep.top > ini.ler.bottom);
  ok('"Textos lidos" também na parte de baixo, ao lado de Preparar', await semelhante(ini.lidos.top, ini.prep.top) && ini.lidos.left > ini.prep.right - 1);
  ok('Nada da tela inicial sai da tela', ini.prep.bottom <= ini.vh && ini.lidos.bottom <= ini.vh);
  ok('Contagem do início conta só os textos para ler (2, não 3)', ini.cont === '2 textos para ler', ini.cont);

  console.log('\n### 2. Tocar em texto não seleciona nada\n');
  const sel = await page.evaluate(() => ({
    body: getComputedStyle(document.body).userSelect,
    area: getComputedStyle(document.getElementById('caixaTexto')).userSelect,
    busca: getComputedStyle(document.getElementById('buscaTexto')).userSelect
  }));
  ok('Página não seleciona texto ao toque (user-select: none)', sel.body === 'none', sel.body);
  ok('A caixa do texto continua selecionável (para colar/editar)', sel.area !== 'none', sel.area);
  ok('A caixa de busca continua selecionável', sel.busca !== 'none', sel.busca);

  console.log('\n### 3. Meus textos: cards novos\n');
  await page.click('.btnInicioLer');
  await page.waitForTimeout(200);
  const cards = await page.$$eval('#listaBiblioteca .cardTexto', els => els.length);
  ok('Meus textos mostra só os não lidos (2)', cards === 2, String(cards));
  await page.dblclick('#listaBiblioteca .cardResumo');
  ok('Duplo toque no resumo do card não seleciona texto', await page.evaluate(() => String(getSelection()).trim() === ''));
  // (o duplo toque pode ter aberto a leitura — fecha)
  if (await page.evaluate(() => document.getElementById('detOv').classList.contains('open'))){
    await page.click('.detX'); await page.waitForTimeout(250);
  }
  const lay = await page.evaluate(() => {
    const c = document.querySelector('#listaBiblioteca .cardTexto');
    const cr = c.getBoundingClientRect(), cs = getComputedStyle(c);
    const inner = cr.width - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    const r = s => c.querySelector(s).getBoundingClientRect();
    return { inner, ler: r('.cardLer'), ed: r('.cardEditar'), ar: r('.cardArquivar'), ex: r('.cardExcluir'),
             txt: [...c.querySelectorAll('.cardAcoes button')].map(b => b.textContent) };
  });
  ok('Botão Ler ocupa a largura toda do card', await semelhante(lay.ler.width, lay.inner, 2), `${Math.round(lay.ler.width)} de ${Math.round(lay.inner)}`);
  ok('Editar / Lido / Excluir ficam numa linha, embaixo do Ler',
    lay.ed.top > lay.ler.bottom - 1 && await semelhante(lay.ed.top, lay.ar.top) && await semelhante(lay.ar.top, lay.ex.top));
  ok('Os três botões de baixo têm o mesmo tamanho', await semelhante(lay.ed.width, lay.ar.width) && await semelhante(lay.ar.width, lay.ex.width));
  ok('Botões com nome escrito (Editar, Lido, Excluir)', lay.txt.join('|') === '✏️ Editar|✅ Lido|🗑️ Excluir', lay.txt.join('|'));
  ok('Link "Textos lidos (1)" aparece embaixo da lista', await page.evaluate(() => {
    const l = document.getElementById('linkArquivo'); return l.offsetParent !== null && /Textos lidos \(1\)/.test(l.textContent);
  }));

  // tocar no TÍTULO abre a leitura
  await page.click('#listaBiblioteca .cardTexto:nth-child(2) .cardTitulo');   // o 2º (mais antigo) = Cruzeiro
  await page.waitForTimeout(400);
  ok('Tocar no título do card já abre a leitura', await page.evaluate(() =>
    document.getElementById('detOv').classList.contains('open') && /CRUZ NO CÉU/i.test(document.getElementById('detTit').textContent)));
  await page.click('.detX'); await page.waitForTimeout(300);
  ok('Abrir a leitura conta no histórico (leituras = 1)', await page.evaluate(() =>
    JSON.parse(localStorage.getItem('explica_textos')).find(x => x.id === 't1').leituras === 1));

  console.log('\n### 4. Marcar como lido → Textos lidos\n');
  await page.click('#listaBiblioteca .cardTexto:nth-child(2) .cardArquivar');
  await page.waitForTimeout(250);
  let est = await page.evaluate(() => ({
    cards: document.querySelectorAll('#listaBiblioteca .cardTexto').length,
    link: document.getElementById('linkArquivoTexto').textContent,
    salvo: JSON.parse(localStorage.getItem('explica_textos')).find(x => x.id === 't1'),
    toast: document.getElementById('toast').textContent
  }));
  ok('Tocar em ✅ Lido tira o card de Meus textos', est.cards === 1);
  ok('O texto continua salvo, marcado como arquivado com data', est.salvo && est.salvo.arquivado === true && /^\d{4}-/.test(est.salvo.arquivadoEm));
  ok('Link passa a mostrar "Textos lidos (2)"', est.link === 'Textos lidos (2)', est.link);
  ok('Aviso "Guardado em Textos lidos"', /Textos lidos/.test(est.toast), est.toast);

  await page.click('#linkArquivo'); await page.waitForTimeout(250);
  est = await page.evaluate(() => ({
    ativa: document.getElementById('telaArquivo').classList.contains('ativa'),
    titulos: [...document.querySelectorAll('#listaArquivo .cardTitulo')].map(e => e.textContent),
    infos: [...document.querySelectorAll('#listaArquivo .cardInfo')].map(e => e.textContent),
    botoes: [...document.querySelectorAll('#listaArquivo .cardTexto:first-child .cardAcoes button')].map(b => b.textContent),
    hash: location.hash
  }));
  ok('Abre a terceira tela, "Textos lidos"', est.ativa && est.hash === '#arquivo');
  ok('O lido mais recente aparece primeiro', /cruz no céu/i.test(est.titulos[0] || ''), est.titulos.join(' | '));
  ok('Card mostra "Lido em dd/mm/aaaa" e quantas vezes foi aberto', /Lido em \d\d\/\d\d\/\d{4} · aberto 1 vez$/.test(est.infos[0] || ''), est.infos[0]);
  ok('Texto antigo lido mostra "aberto 2 vezes"', /aberto 2 vezes/.test(est.infos[1] || ''), est.infos[1]);
  ok('Nos lidos: "Ler de novo" e "Excluir"', est.botoes.join('|') === '↩️ Ler de novo|🗑️ Excluir', est.botoes.join('|'));

  // ler a partir dos lidos atualiza o contador
  await page.click('#listaArquivo .cardTexto:first-child .cardLer'); await page.waitForTimeout(350);
  await page.click('.detX'); await page.waitForTimeout(300);
  ok('Ler de dentro dos lidos atualiza "aberto 2 vezes" no card', await page.evaluate(() =>
    /aberto 2 vezes/.test(document.querySelector('#listaArquivo .cardTexto:first-child .cardInfo').textContent)));

  // busca nos lidos
  await page.fill('#buscaArquivo', 'chuv'); await page.waitForTimeout(150);
  ok('Busca nos textos lidos funciona', await page.evaluate(() =>
    document.querySelectorAll('#listaArquivo .cardTexto').length === 1 && /Texto antigo/.test(document.querySelector('#listaArquivo .cardTitulo').textContent)));
  await page.click('#btnLimparBuscaArquivo'); await page.waitForTimeout(150);

  // devolver
  await page.click('#listaArquivo .cardTexto:first-child .cardDevolver'); await page.waitForTimeout(200);
  ok('"Ler de novo" devolve o texto para Meus textos', await page.evaluate(() => {
    const t = JSON.parse(localStorage.getItem('explica_textos')).find(x => x.id === 't1');
    return !t.arquivado && !t.arquivadoEm && document.querySelectorAll('#listaArquivo .cardTexto').length === 1;
  }));
  // voltar (← / botão voltar do Android) para Meus textos: lista redesenhada
  await page.goBack(); await page.waitForTimeout(250);
  ok('Voltar leva de volta a Meus textos, já com o texto devolvido', await page.evaluate(() =>
    document.getElementById('telaBiblioteca').classList.contains('ativa') &&
    document.querySelectorAll('#listaBiblioteca .cardTexto').length === 2 &&
    document.getElementById('linkArquivoTexto').textContent === 'Textos lidos (1)'));

  // excluir de dentro dos lidos
  await page.click('#linkArquivo'); await page.waitForTimeout(200);
  await page.click('#listaArquivo .cardExcluir'); await page.waitForTimeout(150);
  await page.click('#confirmOv button:has-text("Excluir"), #confirmOv .btnConfirmaOk, #confirmOv button[onclick="confirmarOk()"]');
  await page.waitForTimeout(200);
  ok('Excluir dentro dos lidos apaga o texto de vez', await page.evaluate(() =>
    !JSON.parse(localStorage.getItem('explica_textos')).some(x => x.id === 't3') &&
    /Ainda não há textos lidos/.test(document.getElementById('listaArquivo').textContent)));
  ok('Com os lidos vazios, o link some de Meus textos', await page.evaluate(() => {
    renderizaBiblioteca(); return document.getElementById('linkArquivo').style.display === 'none';
  }));

  // tela inicial → Textos lidos
  await page.evaluate(() => voltarInicio()); await page.waitForTimeout(150);
  await page.click('.btnInicioLidos'); await page.waitForTimeout(150);
  ok('Botão "Textos lidos" da tela inicial abre a tela dos lidos', await page.evaluate(() =>
    document.getElementById('telaArquivo').classList.contains('ativa')));

  // backup leva os lidos junto
  const ida = await page.evaluate(() => {
    const l = JSON.parse(localStorage.getItem('explica_textos'));
    l[0].arquivado = true; l[0].arquivadoEm = '2026-09-22T10:00:00.000Z';
    localStorage.setItem('explica_textos', JSON.stringify(l));
    return { app: 'coruja-explica', textos: l };
  });
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(150);
  await page.setInputFiles('#backupFileInput', { name: 'b.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(ida)) });
  await page.waitForTimeout(250);
  await page.click('#confirmOv button[onclick="confirmarOk()"]'); await page.waitForTimeout(250);
  ok('Backup importado mantém quem está nos lidos e quem está para ler', await page.evaluate(() =>
    document.querySelectorAll('#listaBiblioteca .cardTexto').length === 1 &&
    document.getElementById('linkArquivoTexto').textContent === 'Textos lidos (1)'));
  ok('Backup antigo, sem a marca de lido, abre tudo em Meus textos', await page.evaluate(() => {
    const velho = [{ id:'a', titulo:'A', texto:'Um.' }, { id:'b', titulo:'B', texto:'Dois.' }];
    localStorage.setItem('explica_textos', JSON.stringify(velho)); renderizaBiblioteca();
    return document.querySelectorAll('#listaBiblioteca .cardTexto').length === 2 && textosLidos().length === 0;
  }));
  await ctx.close();

  /* ================= LEITURA (deitado, 915x412) ================= */
  ({ ctx, page } = await novaPagina(browser, { width: 915, height: 412 }, erros));
  await page.goto(base);
  await page.evaluate(t => { localStorage.clear(); localStorage.setItem('explica_textos', JSON.stringify(t)); }, TEXTOS);
  await page.reload(); await page.waitForTimeout(300);

  console.log('\n### 5. Tela sempre acesa\n');
  let w = await page.evaluate(() => window.__wake);
  ok('Ao abrir o app, já pede para a tela não apagar', w.pedidos >= 1 && w.ativos === 1, JSON.stringify(w));
  await page.evaluate(() => window.__wake.ultimo.release());     // o Android soltou (app foi para o fundo)
  await page.mouse.click(10, 10); await page.waitForTimeout(100);
  w = await page.evaluate(() => window.__wake);
  ok('Se o pedido foi solto, o próximo toque pede de novo', w.ativos === 1 && w.pedidos >= 2, JSON.stringify(w));
  await page.mouse.click(20, 20); await page.mouse.click(30, 30); await page.waitForTimeout(100);
  w = await page.evaluate(() => window.__wake);
  ok('Não fica pedindo à toa enquanto o pedido está valendo', w.ativos === 1, JSON.stringify(w));
  await page.evaluate(() => { window.__wake.ultimo.release(); document.dispatchEvent(new Event('visibilitychange')); });
  await page.waitForTimeout(100);
  w = await page.evaluate(() => window.__wake);
  ok('Voltar para o app (visibilitychange) pede de novo', w.ativos === 1, JSON.stringify(w));

  console.log('\n### 6. Tamanhos da letra (10 níveis) e aviso\n');
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(150);
  await page.click('#listaBiblioteca .cardTexto:nth-child(2) .cardLer'); await page.waitForTimeout(450);
  const fs0 = await page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('#detTexto p')).fontSize));
  ok('Tamanho padrão continua o de antes (22px, "Média")', fs0 === 22, fs0 + 'px');
  await page.click('#btnFontMais'); await page.waitForTimeout(120);
  let aviso = await page.evaluate(() => ({ t: document.getElementById('detAviso').textContent, show: document.getElementById('detAviso').classList.contains('show') }));
  ok('A+ mostra o aviso com o nome do tamanho', aviso.show && aviso.t === '🔤 Tamanho: Grande (nível 4 de 10)', aviso.t);
  ok('O aviso fica dentro do cartão de leitura', await page.evaluate(() => document.getElementById('detCard').contains(document.getElementById('detAviso'))));
  for (let i = 0; i < 8; i++){ await page.click('#btnFontMais'); await page.waitForTimeout(40); }
  const fsMax = await page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('#detTexto p')).fontSize));
  aviso = await page.evaluate(() => document.getElementById('detAviso').textContent);
  ok('O maior tamanho agora é 64px (antes era 40px)', fsMax === 64, fsMax + 'px');
  ok('Aviso no limite: "Já está no maior tamanho"', /Já está no maior tamanho/.test(aviso), aviso);
  ok('Botão A+ fica apagadinho no limite', await page.evaluate(() => document.getElementById('btnFontMais').classList.contains('noLimite')));
  ok('Tamanho escolhido fica guardado', await page.evaluate(() => JSON.parse(localStorage.getItem('explica_config')).fsizeIdx === 9));
  const ovf = await page.evaluate(() => { const b = document.getElementById('detTexto'); return b.scrollWidth - b.clientWidth; });
  ok('Em 64px, sem sílabas, nada vaza para o lado', ovf <= 1, `sobra ${ovf}px`);
  await page.screenshot({ path: path.join(OUT, 'v2-64px-sem-silabas.png') });

  console.log('\n### 7. Ajustes (⚙️): sílabas e letra\n');
  const antes = await page.evaluate(() => document.getElementById('detTexto').textContent.includes('­'));
  ok('Por padrão, a separação de sílabas está DESLIGADA (nenhum hífen invisível)', antes === false);
  await page.click('#btnAjustes'); await page.waitForTimeout(200);
  ok('⚙️ abre os ajustes da leitura', await page.evaluate(() => document.getElementById('ajustesOv').classList.contains('open')));
  ok('A chave de sílabas começa desligada', await page.evaluate(() => !document.getElementById('chaveSilabas').classList.contains('on')));
  ok('Duas opções de letra: Bastão (padrão) e Sassoon', await page.evaluate(() =>
    [...document.querySelectorAll('.opcaoFonte .ofNome')].map(e => e.textContent).join('|') === 'Bastão (padrão)|Sassoon'));
  ok('Bastão vem marcada', await page.evaluate(() => document.querySelector('.opcaoFonte.sel .ofNome').textContent.startsWith('Bastão')));
  // rola um pouco o texto antes de ligar, para ver se volta ao mesmo lugar
  await page.evaluate(() => { const b = document.getElementById('detTexto'); b.scrollTop = (b.scrollHeight - b.clientHeight) * 0.5; });
  const rolAntes = await page.evaluate(() => { const b = document.getElementById('detTexto'); return b.scrollTop / (b.scrollHeight - b.clientHeight); });
  await page.click('#chaveSilabas'); await page.waitForTimeout(200);
  const rolDepois = await page.evaluate(() => { const b = document.getElementById('detTexto'); return b.scrollTop / (b.scrollHeight - b.clientHeight); });
  ok('Ligar as sílabas no meio da leitura não volta para o começo', Math.abs(rolAntes - rolDepois) < 0.05, `${rolAntes.toFixed(2)} → ${rolDepois.toFixed(2)}`);
  ok('Chave ligada fica verde e a escolha é guardada', await page.evaluate(() =>
    document.getElementById('chaveSilabas').classList.contains('on') && JSON.parse(localStorage.getItem('explica_config')).silabasOn === true));
  await page.click('.pcardAjustes .ok'); await page.waitForTimeout(150);
  const hif = await page.evaluate(() => {
    const box = document.getElementById('detTexto');
    const partidas = [...box.querySelectorAll('.w')].filter(w => w.getClientRects().length === 2);
    return { temHifen: box.textContent.includes('­'), partidas: partidas.map(w => w.textContent.replace(/­/g, '·')).slice(0, 6),
             nPartidas: partidas.length, ovf: box.scrollWidth - box.clientWidth };
  });
  ok('Com a chave ligada, as palavras recebem os pontos de corte', hif.temHifen);
  ok('Em 64px, palavras de verdade são cortadas em duas linhas (com hífen)', hif.nPartidas >= 3, `${hif.nPartidas}: ${hif.partidas.join(', ')}`);
  ok('Toda palavra cortada foi cortada numa sílaba (tem ponto de corte)', hif.partidas.every(p => p.includes('·')));
  ok('Com sílabas, nada vaza para o lado', hif.ovf <= 1, `sobra ${hif.ovf}px`);
  await page.evaluate(() => { document.getElementById('detTexto').scrollTop = 0; });
  await page.screenshot({ path: path.join(OUT, 'v2-64px-com-silabas.png') });

  // o dicionário continua funcionando com a palavra cortada
  const gl = await page.evaluate(() => {
    const g = [...document.querySelectorAll('#detTexto .w.gloss')].find(w => w.textContent.includes('­'));
    if (!g) return null;
    g.click();
    return { pal: document.getElementById('glossPal').textContent, aberto: document.getElementById('glossOv').classList.contains('open') };
  });
  ok('Palavra do dicionário com pontos de corte abre a explicação certa', gl && gl.aberto && !gl.pal.includes('­') && gl.pal.length > 2, gl && gl.pal);
  await page.evaluate(() => fecharGloss());

  // faixa da linha numa palavra cortada: mede a linha tocada, não as duas
  const faixa = await page.evaluate(() => {
    const box = document.getElementById('detTexto');
    const w = [...box.querySelectorAll('.w')].find(x => x.getClientRects().length === 2);
    const r2 = w.getClientRects()[1];
    w.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1, clientX: r2.left + 3, clientY: (r2.top + r2.bottom) / 2 }));
    const bar = box.querySelector('.lineHi').getBoundingClientRect();
    return { barTop: bar.top, barBottom: bar.bottom, lin2Top: r2.top, lin2Bottom: r2.bottom };
  });
  ok('Tocar na 2ª metade de uma palavra cortada marca a linha de baixo', faixa.barTop <= faixa.lin2Top + 4 && faixa.barBottom >= faixa.lin2Bottom - 4 && faixa.barBottom - faixa.barTop < 140,
     JSON.stringify(faixa));

  // nome em destaque nos itens da lista
  const termos = await page.evaluate(() => [...document.querySelectorAll('#detTexto .w.termo')].map(w => w.textContent.replace(/­/g, '')));
  ok('Nomes da lista ganham destaque (ACRUX, MIMOSA, GACRUX)', termos.join('|') === 'ACRUX,|MIMOSA,|GACRUX,', termos.join('|'));
  ok('O texto antigo "Elas são:." aparece corrigido como "Elas são:"', await page.evaluate(() =>
    /ELAS SÃO:$/.test(document.querySelector('#detTexto p:nth-of-type(4)').textContent.replace(/­/g, '').trim())));
  ok('Duplo toque numa palavra da leitura não seleciona nada', await (async () => {
    await page.dblclick('#detTexto p:nth-of-type(2) .w'); await page.waitForTimeout(100);
    const s = await page.evaluate(() => String(getSelection()).trim());
    await page.evaluate(() => { fecharGloss(); });
    return s === '';
  })());

  // trocar a letra
  await page.click('#btnAjustes'); await page.waitForTimeout(150);
  await page.click('.opcaoFonte:nth-child(2)'); await page.waitForTimeout(250);
  const fonte = await page.evaluate(() => ({
    var: getComputedStyle(document.documentElement).getPropertyValue('--pfont'),
    p: getComputedStyle(document.querySelector('#detTexto p')).fontFamily,
    cfg: JSON.parse(localStorage.getItem('explica_config')).fontIdx,
    carregada: document.fonts.check('700 30px HanaSassoon')
  }));
  ok('Escolher Sassoon troca a letra da leitura', /HanaSassoon/.test(fonte.p) && fonte.cfg === 1, fonte.p);
  ok('A fonte Sassoon está embutida e carregada (funciona sem internet)', fonte.carregada);
  await page.screenshot({ path: path.join(OUT, 'v2-ajustes-sassoon.png') });

  // voltar do Android com os ajustes abertos
  await page.goBack(); await page.waitForTimeout(250);
  ok('Voltar do Android fecha só os ajustes, a leitura continua', await page.evaluate(() =>
    !document.getElementById('ajustesOv').classList.contains('open') && document.getElementById('detOv').classList.contains('open')));
  await page.screenshot({ path: path.join(OUT, 'v2-sassoon-silabas.png') });

  // tudo guardado após recarregar
  await page.reload(); await page.waitForTimeout(300);
  ok('Depois de fechar e abrir o app: 64px, sílabas ligadas e Sassoon continuam', await page.evaluate(() => {
    const c = JSON.parse(localStorage.getItem('explica_config'));
    return c.fsizeIdx === 9 && c.silabasOn === true && c.fontIdx === 1 &&
      /HanaSassoon/.test(getComputedStyle(document.documentElement).getPropertyValue('--pfont'));
  }));
  // desligar volta a ser exatamente como antes
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(150);
  await page.click('#listaBiblioteca .cardTexto:nth-child(2) .cardLer'); await page.waitForTimeout(400);
  await page.evaluate(() => { toggleSilabas(); });
  ok('Desligando a chave, nenhum hífen invisível sobra', await page.evaluate(() => !document.getElementById('detTexto').textContent.includes('­')));
  // A- até o fim
  for (let i = 0; i < 11; i++){ await page.click('#btnFontMenos'); await page.waitForTimeout(30); }
  ok('A− até o fim chega em 16px e avisa o limite', await page.evaluate(() =>
    parseFloat(getComputedStyle(document.querySelector('#detTexto p')).fontSize) === 16 &&
    /menor tamanho/.test(document.getElementById('detAviso').textContent)));
  await ctx.close();

  /* ========= Letra gigante em celular pequeno (retrato girado) ========= */
  ({ ctx, page } = await novaPagina(browser, { width: 360, height: 640 }, erros));
  await page.goto(base);
  await page.evaluate(t => { localStorage.clear(); localStorage.setItem('explica_textos', JSON.stringify(t));
    localStorage.setItem('explica_config', JSON.stringify({ fsizeIdx: 9, capsMode: true, fontIdx: 0, silabasOn: false })); }, TEXTOS);
  await page.reload(); await page.waitForTimeout(300);
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(150);
  await page.click('#listaBiblioteca .cardTexto:nth-child(2) .cardLer'); await page.waitForTimeout(450);
  let v = await page.evaluate(() => { const b = document.getElementById('detTexto'); return b.scrollWidth - b.clientWidth; });
  ok('Celular pequeno, 64px, sem sílabas: nada vaza', v <= 1, `sobra ${v}px`);
  await page.evaluate(() => toggleSilabas()); await page.waitForTimeout(150);
  v = await page.evaluate(() => { const b = document.getElementById('detTexto'); return b.scrollWidth - b.clientWidth; });
  ok('Celular pequeno, 64px, com sílabas: nada vaza', v <= 1, `sobra ${v}px`);
  await page.screenshot({ path: path.join(OUT, 'v2-360-64px-silabas.png') });
  await ctx.close();

  /* ========= Tela inicial em celular pequeno ========= */
  ({ ctx, page } = await novaPagina(browser, { width: 360, height: 640 }, erros));
  await page.goto(base); await page.waitForTimeout(250);
  const p2 = await page.evaluate(() => {
    const r = s => document.querySelector(s).getBoundingClientRect();
    return { ler: r('.btnInicioLer'), prep: r('.btnInicioPreparar'), vh: innerHeight, sw: document.documentElement.scrollWidth };
  });
  ok('Celular pequeno: tela inicial cabe sem rolar e sem vazar', p2.prep.bottom <= p2.vh && p2.sw <= 360, JSON.stringify({ b: Math.round(p2.prep.bottom), vh: p2.vh, sw: p2.sw }));
  await page.screenshot({ path: path.join(OUT, 'v2-inicio-360.png') });
  await ctx.close();

  ({ ctx, page } = await novaPagina(browser, { width: 412, height: 915 }, erros));
  await page.goto(base);
  await page.evaluate(t => { localStorage.clear(); localStorage.setItem('explica_textos', JSON.stringify(t)); }, TEXTOS);
  await page.reload(); await page.waitForTimeout(250);
  await page.screenshot({ path: path.join(OUT, 'v2-inicio-412.png') });
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(200);
  await page.screenshot({ path: path.join(OUT, 'v2-biblioteca.png') });
  await page.evaluate(() => entrarArquivo()); await page.waitForTimeout(200);
  await page.screenshot({ path: path.join(OUT, 'v2-lidos.png') });
  await ctx.close();

  console.log('\n===== ERROS DE CONSOLE/JAVASCRIPT =====');
  console.log(erros.length ? erros.join('\n') : '(nenhum)');
  ok('Nenhum erro de JavaScript em todo o teste', erros.length === 0);

  console.log(`\n${total - falhas}/${total} verificações da v2.0 — ${falhas ? '❌ HÁ FALHAS' : '✅ TUDO CERTO'}`);
  await browser.close(); server.close();
  process.exit(falhas ? 1 : 0);
})().catch(e => { console.error('ERRO NO TESTE:', e); process.exit(2); });
