/* v118 — três pedidos:
   1) O pop-up "Toque no desenho da frase!" (quiz) segue a fonte e a caixa
      alta das Configurações (antes a frase dele saía em minúscula).
   2) Configurações › Imagens: liga/desliga TODOS os desenhos das frases
      (Ler) e das palavras (Treinar Sílabas). Sem imagens, o quiz de
      desenho não aparece.
   3) Tela sempre acesa (Wake Lock) enquanto o app está aberto — a tela de
      bloqueio do celular não pode aparecer no meio da leitura. */
const { carregarApp, t, tAsync, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_12_quiz_imagens_tela');
  // simula a Wake Lock API do Chrome (o JSDOM não tem) ANTES do app carregar
  const dom = carregarApp({
    antes(w){
      w._pedidosWake = 0;
      Object.defineProperty(w.navigator, 'wakeLock', { configurable:true, value:{
        request(tipo){ w._pedidosWake++; w._tipoWake = tipo;
          const ouvintes = [];
          const trava = { released:false, addEventListener(ev, f){ ouvintes.push(f); },
            release(){ trava.released = true; ouvintes.forEach(f => f()); return Promise.resolve(); } };
          w._ultimaTrava = trava;
          return Promise.resolve(trava); }
      }});
    }
  });
  const { window } = dom;
  const doc = window.document;
  await esperar(300);

  // ---------- 1) quiz ----------
  t('Quiz com CAIXA ALTA ligada: a frase do quiz fica em caixa alta', () => {
    window.eval("fontIdx = 2; capsMode = true; quizFor = construirOrdemDificuldade()[0]; openQuiz();");
    const qf = doc.getElementById('qzFrase');
    assert(qf.classList.contains('caps'), 'qzFrase sem a classe .caps');
    doc.getElementById('qzOv').classList.remove('open');
  });

  t('Quiz usa a MESMA fonte escolhida nas Configurações', () => {
    window.eval("fontIdx = 4; openQuiz();");
    const qf = doc.getElementById('qzFrase');
    const fonte = window.eval('FONTS[4].css');
    assert(qf.style.fontFamily && fonte.indexOf(qf.style.fontFamily.split(',')[0].replace(/["']/g,'').trim()) >= 0,
      'fonte do quiz (' + qf.style.fontFamily + ') diferente da escolhida (' + fonte + ')');
    doc.getElementById('qzOv').classList.remove('open');
  });

  t('Quiz com caixa alta DESLIGADA: frase começa com maiúscula (igual o Ler)', () => {
    window.eval("fontIdx = 2; capsMode = false; openQuiz();");
    const qf = doc.getElementById('qzFrase');
    assert(!qf.classList.contains('caps'), 'não devia ter .caps');
    const c = qf.textContent.charAt(0);
    assertEq(c, c.toUpperCase(), '1ª letra devia ser maiúscula');
    doc.getElementById('qzOv').classList.remove('open');
    window.eval("capsMode = true;");
  });

  t('CSS #qzFrase.caps usa text-transform:uppercase', () => {
    const css = Array.from(doc.querySelectorAll('style')).map(s => s.textContent).join('\n');
    assert(/#qzFrase\.caps\{text-transform:uppercase\}/.test(css));
  });

  // ---------- 2) imagens ----------
  t('Configurações tem a linha "Imagens"', () => {
    assert(doc.getElementById('cfgImg'), 'botão cfgImg não existe');
  });

  t('Padrão: imagens LIGADAS', () => {
    assertEq(window.eval('imagensOn()'), true);
    assert(!doc.body.classList.contains('semImagens'));
  });

  t('Desligar imagens esconde o desenho do Ler e do Treinar Sílabas (CSS)', () => {
    doc.getElementById('cfgImg').onclick();
    assertEq(window.eval('imagensOn()'), false);
    assert(doc.body.classList.contains('semImagens'), 'body sem a classe semImagens');
    const css = Array.from(doc.querySelectorAll('style')).map(s => s.textContent).join('\n');
    assert(/body\.semImagens #pic,body\.semImagens #lpEmoji,body\.semImagens \.treinoCartaoEmoji\{display:none!important\}/.test(css),
      'regra CSS que esconde as imagens não encontrada');
  });

  t('A escolha fica salva (hana_imagens) e entra no backup da leitora', () => {
    assertEq(window.eval("localStorage.getItem('hana_imagens')"), '0');
    assert(window.eval("CHAVES_LEITORA.indexOf('hana_imagens')") >= 0, 'hana_imagens fora de CHAVES_LEITORA');
  });

  await tAsync('Com imagens desligadas, o quiz "toque no desenho" NÃO aparece', async () => {
    window.eval("doc0=document.getElementById('qzOv'); doc0.classList.remove('open'); window._testeSemAnimacao=true;");
    // força o momento do quiz (r===0) e chama o celebrate que agenda ele
    window.eval("quizPend = true; quizFor = 0; doneN = 15; celebrate();");
    await esperar(1700);
    assert(!doc.getElementById('qzOv').classList.contains('open'), 'o quiz abriu mesmo sem imagens');
  });

  await tAsync('Religando as imagens, o quiz volta a aparecer normalmente', async () => {
    doc.getElementById('cfgImg').onclick();
    assertEq(window.eval('imagensOn()'), true);
    window.eval("quizPend = true; quizFor = 0; doneN = 15; celebrate();");
    await esperar(1700);
    assert(doc.getElementById('qzOv').classList.contains('open'), 'o quiz devia abrir com imagens ligadas');
    doc.getElementById('qzOv').classList.remove('open');
  });

  // ---------- 3) tela acesa ----------
  await tAsync('Ao abrir, o app pede pra manter a TELA ACESA (wakeLock "screen")', async () => {
    await esperar(50);
    assert(window._pedidosWake >= 1, 'navigator.wakeLock.request não foi chamado');
    assertEq(window._tipoWake, 'screen');
  });

  await tAsync('Se o sistema soltar a trava (app foi pro fundo), ela é pedida de novo', async () => {
    // desde a v120 quem cuida disso é o escola-pwa.js (igual em todos os apps)
    const antes = window._pedidosWake;
    window._ultimaTrava.release();            // simula o sistema soltando a trava
    doc.dispatchEvent(new window.Event('visibilitychange'));
    await esperar(1000);
    assert(window._pedidosWake > antes, 'não pediu a trava de novo ao voltar');
  });

  resumo();
})();
