# ☁️ Guia do Firebase — passo a passo (para quem nunca usou)

**Escola São Pedro — guardar o progresso das crianças na internet**
Versão do guia: 4 (acompanha o Curiosidades v1.7)

---

## 🗺️ Visão geral: como funciona o sistema completo (7 apps)

```
                 ┌──────────────── FIREBASE (1 projeto só) ────────────────┐
                 │  familias → (código da família) → usuarios → renata_1f98b │
                 │                                   └ apps → curiosidades   │
                 │                                          → alfabetizacao  │
                 │                                          → matematica ... │
                 └──────────────────────────▲──────────────────────────────┘
                                            │ (sobe sozinho quando tem internet)
   📚 Alfabetização  🔢 Matemática  📖 Fluência  🦉 Coruja  📝 Provinha  📕 Historinhas  🌍 Curiosidades
       └──────────── todos usam os MESMOS 3 arquivos compartilhados ────────────┘
                    nuvem-config.js · nuvem-sync.js · escola-pwa.js
```

- **No Firebase você faz tudo UMA vez só** (etapas 1 a 6). **Não** precisa cadastrar os 7 apps no Firebase: um projeto e uma configuração servem para todos.
- Cada criança tem **uma ficha** na nuvem (nome + bichinho), com uma "gaveta" para cada app.
- Cada app recebe **os mesmos 3 arquivos compartilhados**:

| Arquivo | O que faz | Você mexe? |
|---|---|---|
| `nuvem-config.js` | diz aos apps **onde** fica a sua nuvem | **Sim, uma vez** (etapa 7). Depois copia o mesmo para todos os apps |
| `nuvem-sync.js` | o "motor" que guarda e recupera o progresso | Não |
| `escola-pwa.js` | tela sempre acesa, tela cheia e convite para instalar | Não |

**O passo a passo de cada app** (depois do Firebase pronto) está no documento `COMO_PEDIR_NOS_OUTROS_APPS.md`.

---

## 🧭 O que vai acontecer com o progresso das crianças

- 📱 **O celular continua sendo o principal.** Tudo é gravado nele na hora, como sempre. O app funciona igualzinho sem internet.
- ☁️ **Quando tem internet**, o app manda sozinho uma cópia para a nuvem (cerca de 1,5 segundo depois de cada mudança).
- 📴 **Sem internet**, as mudanças esperam guardadas no celular e sobem sozinhas quando a internet voltar.
- 🛟 **Se os dados forem apagados** (ou usar outro celular), o progresso volta pelo **nome + bichinho** da criança.
- 🕘 **Histórico de versões:** além do progresso atual, a nuvem guarda **uma cópia por dia**, para sempre. Se algo sumir, dá para **juntar** uma versão antiga com a atual (nada é apagado).
- 🔐 **Nada se perde nem quando dois celulares gravam ao mesmo tempo:** antes de gravar, o app lê a nuvem, junta com o que tem no celular e só então grava. Se outro celular gravou no meio do caminho, ele junta de novo e tenta outra vez.

**O que você precisa:**
- Uma conta Google (Gmail). Pode ser a sua.
- Um **computador** (dá no celular, mas no computador é bem mais fácil).
- Uns **30 a 40 minutos** com calma.
- **Não precisa de cartão de crédito.** O plano grátis (**Spark**) é mais do que suficiente.

> 💡 O Firebase muda a aparência das telas de vez em quando. Se algum botão estiver com um nome um pouco diferente, procure o mais parecido. Os passos continuam os mesmos. Coloco os nomes em **Português (English)**, porque a tela pode aparecer em inglês.

---

## Etapa 1 — Entrar no Firebase

1. No computador, abra o **Google Chrome**.
2. Entre em: **https://console.firebase.google.com**
3. Se pedir, entre com a sua conta Google.
4. Se aparecer uma tela pedindo para aceitar os termos, marque a caixinha e clique em **Continuar**.

✅ Você está no **Console do Firebase**.

---

## Etapa 2 — Criar o projeto

1. Clique em **Criar um projeto** (*Create a project*) — ou **Comece a usar criando um projeto do Firebase** (*Get started by setting up a Firebase project*).
2. **Nome do projeto:** `escola-sao-pedro`
   - O Firebase pode acrescentar um código no fim (ex.: `escola-sao-pedro-4f2a1`). **Normal.**
3. Marque a caixinha dos termos (se aparecer) → **Continuar**.
4. **Gemini no Firebase** (assistente de IA): pode **desligar** → **Continuar**.
5. **Google Analytics**: **desligue** a chavinha → **Criar projeto**.
6. Quando aparecer "Seu projeto está pronto" → **Continuar**.

✅ Você está dentro do projeto **escola-sao-pedro**.

---

## Etapa 3 — Registrar o "app da Web" e copiar a configuração

Mesmo tendo 7 apps, você registra **só um** aqui — a mesma configuração serve para todos.

1. Na página inicial do projeto, procure **"Adicione o Firebase ao seu app"** e clique no ícone **`</>`** (**Web**).
   - Se não achar: **engrenagem ⚙️** (em cima, à esquerda) → **Configurações do projeto** (*Project settings*) → role até **Seus apps** (*Your apps*) → ícone **`</>`**.
2. **Apelido do app:** `Escola Sao Pedro`
3. **NÃO** marque "Configurar também o Firebase Hosting" (usamos o Netlify).
4. Clique em **Registrar app** (*Register app*).
5. Vai aparecer um código. Tanto faz a opção (**npm** ou **`<script>`**): o que importa é **só um pedaço**.
6. Procure o bloco que começa com **`const firebaseConfig = {`** e termina com **`};`**. Parecido com isto (os seus valores serão outros):

```js
const firebaseConfig = {
  apiKey: "AIzaSyB-exemplo-exemplo-exemplo-123456",
  authDomain: "escola-sao-pedro-4f2a1.firebaseapp.com",
  projectId: "escola-sao-pedro-4f2a1",
  storageBucket: "escola-sao-pedro-4f2a1.firebasestorage.app",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};
```

7. **Selecione só esse bloco** (do `const` até o `};`), copie (**Ctrl + C**), abra o **Bloco de Notas**, cole (**Ctrl + V**) e salve como `firebase-escola.txt` na Área de Trabalho.
   - ⚠️ **Não** copie linhas que começam com `import` nem `<script>`.
8. Clique em **Continuar no console** (*Continue to console*).

> 🔒 **Pode ficar tranquilo:** esse `apiKey` **não é uma senha**. O Google diz que ele pode ficar visível nos sites. Quem protege os dados são as **Regras** (etapa 6) e o **código da família** (etapa 9).

✅ Você tem o bloco `firebaseConfig` guardado.

---

## Etapa 4 — Ligar o "login anônimo"

É a "carteirinha" que os apps usam para entrar na nuvem — sem e-mail, sem senha, a criança não faz nada.

1. No menu da esquerda, clique em **Criação** (*Build*). (Se o menu estiver escondido: **três linhas ☰** em cima, à esquerda.)
2. Clique em **Authentication**.
3. Clique em **Vamos começar** (*Get started*).
4. Na aba **Método de login** (*Sign-in method*), procure **Anônimo** (*Anonymous*) — geralmente em "Provedores adicionais". Clique nele.
5. Ligue **Ativar** (*Enable*) → **Salvar** (*Save*).

✅ **Anônimo** aparece como **Ativado** (*Enabled*).

---

## Etapa 5 — Criar o banco de dados (Firestore)

1. No menu da esquerda, em **Criação** (*Build*), clique em **Firestore Database**.
2. Clique em **Criar banco de dados** (*Create database*).
3. Se perguntar a **edição** (*edition*): **Standard** → **Próxima**.
4. Se perguntar o **ID do banco** (*Database ID*): deixe **`(default)`** → **Próxima**.
5. **Local** (*Location*): **`southamerica-east1 (São Paulo)`** → **Próxima**.
   - ⚠️ **Não dá para trocar depois.** São Paulo é o mais perto de Goiás.
6. **Regras:** **Iniciar no modo de produção** (*Start in production mode*).
7. **Criar** (*Create*). Espere aparecer a tela com as abas **Dados**, **Regras**, **Índices**...

✅ O banco existe (vazio por enquanto — normal).

---

## Etapa 6 — Colar as Regras de segurança

As regras dizem: só os nossos apps (com a carteirinha da etapa 4) leem e gravam, **só dentro da pasta da família**; ninguém lista as famílias e **ninguém apaga nada**.

1. Em **Firestore Database**, aba **Regras** (*Rules*).
2. Clique na caixa de texto, **apague tudo** (Ctrl + A, depois Delete).
3. Cole exatamente isto:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Escola São Pedro: cada família fica numa pasta com o código dela.
    // Só os apps (login anônimo) podem ler e gravar. Ninguém pode apagar.
    // "versoes" = histórico: uma cópia do progresso por dia.
    match /familias/{familia}/usuarios/{usuario} {
      allow read, create, update: if request.auth != null;
      match /apps/{app} {
        allow read, create, update: if request.auth != null;
        match /versoes/{versao} {
          allow read, create, update: if request.auth != null;
        }
      }
    }
  }
}
```

4. Clique em **Publicar** (*Publish*).

✅ Mensagem de regras publicadas. **Pronto: o Firebase está 100% configurado para os 7 apps.**

> 🔁 **Já tinha colado as regras de uma versão anterior deste guia?** Cole estas de novo e publique. As antigas não tinham a parte `versoes` (histórico). Sem ela, o progresso continua subindo normalmente, mas o histórico diário não é guardado, e o app avisa em ⚙️ → ☁️ Nuvem.

---

## Etapa 7 — Preencher o `nuvem-config.js` (uma vez, serve para todos)

1. Descompacte o `.zip` do Curiosidades (botão direito → **Extrair tudo**).
2. Na pasta, botão direito em `nuvem-config.js` → **Abrir com** → **Bloco de Notas**.
3. Procure:

```js
/* ======== COLE AQUI (apague daqui ...) ======== */
const firebaseConfig = {
  apiKey: "",
  projectId: "",
};
/* ======== (... até aqui) ======== */
```

4. Apague **só** as 4 linhas do meio (de `const firebaseConfig = {` até `};`) e **cole no lugar** o bloco do `firebase-escola.txt`:

```js
/* ======== COLE AQUI (apague daqui ...) ======== */
const firebaseConfig = {
  apiKey: "AIzaSyB-exemplo-exemplo-exemplo-123456",
  authDomain: "escola-sao-pedro-4f2a1.firebaseapp.com",
  projectId: "escola-sao-pedro-4f2a1",
  storageBucket: "escola-sao-pedro-4f2a1.firebasestorage.app",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};
/* ======== (... até aqui) ======== */
```

5. **Não mexa em mais nada.** Salve (**Ctrl + S**) e feche.
6. **Guarde uma cópia** desse arquivo preenchido numa pasta segura, por exemplo `Documentos\Escola São Pedro\nuvem-config.js`. **É esse mesmo arquivo que vai em todos os 7 apps.**

> 🔑 **"Código da família"** (mais abaixo no mesmo arquivo): **deixe vazio** `""`. Assim o código é digitado no celular e não fica visível na internet.

---

## Etapa 8 — Publicar no Netlify (como sempre)

1. **https://app.netlify.com** → abra o site do app (ex.: **escolasaopedrocuriosidades**).
2. Aba **Deploys**.
3. **Arraste a pasta inteira** do app (com o seu `nuvem-config.js` preenchido) para a área **"Drag and drop your site output folder here"**.
4. Espere ficar **Published** (verde).

**A pasta de cada app deve ter:**

| Arquivo | Para que serve |
|---|---|
| `index.html` | o aplicativo |
| `sw.js` | faz funcionar sem internet |
| `manifest.webmanifest` | nome e ícone na tela do celular |
| `icon-192.png` e `icon-512.png` | ícone |
| `nuvem-config.js` | **a sua configuração** (a mesma em todos os apps) |
| `nuvem-sync.js` | motor da nuvem (igual em todos, não mexa) |
| `escola-pwa.js` | tela acesa + tela cheia + convite para instalar (igual em todos, não mexa) |

> 🛟 **O histórico da Renata não se perde.** O endereço do site é o mesmo, então o celular continua com tudo. Na primeira vez que o app abrir com a nuvem ligada e o código digitado, ele **sobe** esse histórico para a nuvem.

---

## Etapa 9 — No celular: atualizar, instalar e digitar o código da família

1. Abra o site do app no **Chrome** do celular.
   - Se o app já estava instalado, abra pelo ícone, **feche e abra de novo** (às vezes 2 vezes) para a versão nova chegar.
2. **Convite para instalar:** ao abrir pelo navegador, aparece a janelinha **📲 Instalar o app**. Toque em **Instalar agora**.
   - Se aparecer só o passo a passo (⋮ → **Instalar app**), siga ele. O convite aparece toda vez que abrir pelo navegador até o app ser instalado.
   - Depois de instalado, **use sempre pelo ícone** na tela do celular (abre em tela cheia).
3. Abra o app (pelo ícone) → **engrenagem ⚙️**. Tem um **pontinho vermelho**: é a nuvem pedindo o código.
4. Role até **☁️ Nuvem** → **Código da família** → **🔑 Digitar** → digite o código → **OK**.

**Como escolher o código:**
- Pelo menos **6 letras ou números** (hífen pode; espaço vira hífen; acento é ignorado).
- Algo que **só a família sabe**, ex.: `saopedro-mararosa-7391`
- ⚠️ **Anote num papel.** É o **mesmo código em todos os apps e todos os celulares**.

> 📌 Cada app tem memória separada no celular, então o código é digitado **uma vez em cada app** (e de novo só se os dados forem apagados).

---

## Etapa 10 — Conferir se deu certo

**No celular:**
- ⚙️ → **☁️ Nuvem** → **Situação**: **✅ Tudo guardado na nuvem (às 14:32)**.
- **Pontinho na engrenagem** verde.
- ⚙️ → **📺 Tela** → deve dizer **✅ Ligado** (ou **✅ Ligado (modo reserva)**).

| Pontinho na ⚙️ | Quer dizer |
|---|---|
| (nenhum) | nuvem não configurada neste app (falta o `nuvem-config.js` preenchido) |
| 🟢 verde | tudo guardado na nuvem |
| 🟠 laranja | mudança esperando (sem internet ou enviando) — **normal**, sobe sozinho |
| 🔴 vermelho | falta o código da família, ou deu erro (a mensagem diz qual) |

**No computador (Firebase):** **Firestore Database** → aba **Dados** (*Data*):
`familias` → (seu código) → `usuarios` → `renata_1f98b` → `apps` → `curiosidades`
(dentro: `nome`, `av` = bichinho, `dados` = progresso, `atualizadoEm`).

✅ **Se aparecer isso, está funcionando!** 🎉

---

## 🛟 Como recuperar o progresso

1. **Dados apagados ou celular novo:** abra o app → **☁️ Já tenho cadastro** → **🔑 Código da família** → toque no nome da criança.
2. **Jeito mais rápido:** cadastre com **o mesmo nome e o mesmo bichinho** (depois de digitar o código). O progresso volta sozinho.
3. **Tela "Quem vai estudar hoje?"** → **☁️ Recuperar da nuvem**.
4. **Voltar uma versão (histórico):** com a criança escolhida, abra **☁️ Recuperar da nuvem** → **🕘 Versões guardadas** → toque no dia. O app **junta** aquele dia com o progresso atual: volta o que estiver faltando, e nada do que existe hoje é apagado.

> Recuperar **nunca apaga** o que está no celular: **junta** as duas coisas. Marcada como lida em qualquer lugar = continua lida.

---

## 🧹 E se eu limpar o histórico, os cookies ou os dados do navegador?

Explicação honesta, sem enrolação:

| O que você limpa no Chrome | O que acontece |
|---|---|
| **Histórico de navegação** (só o histórico) | **Nada se perde.** O progresso não fica no histórico. |
| **Cache / imagens e arquivos** | **Nada se perde.** Na próxima vez com internet, o app baixa os arquivos de novo. |
| **Cookies e dados de sites** (ou "Limpar armazenamento" do app) | O celular **apaga** a cópia dele. **Tudo que já subiu para a nuvem volta** (Recuperar, ou cadastrar com o mesmo nome + bichinho). |

**O único risco que existe:** limpar os **dados de sites** num momento em que o celular está **sem internet** e ainda tem alteração que **não conseguiu subir**. Nenhum app de navegador consegue salvar o que foi apagado do próprio celular antes de chegar à internet. Por isso o sistema foi feito para esse momento ser o menor possível:
- Com internet, cada mudança sobe em **cerca de 1,5 segundo**.
- Sem internet, o **pontinho laranja** na ⚙️ avisa que tem coisa esperando, e em ⚙️ → ☁️ Nuvem aparece: **"⚠️ Não limpe os dados do navegador até conectar na internet"**.
- O app pede ao Android para **não apagar os dados sozinho** quando falta espaço (armazenamento persistente).
- Para ficar 100% tranquilo antes de limpar tudo: conecte no Wi-Fi, espere o **pontinho verde**, e só então limpe. Se estiver sem internet e precisar limpar, use antes o **⬇️ Exportar backup** (Configurações).

## 🦉 Nome + Bichinho: os 8 bichinhos oficiais

A identidade da criança na nuvem é **nome + bichinho**. Por isso, **todos os apps têm exatamente os mesmos 8 bichinhos**, nesta ordem e numa linha só:

**🦉 Coruja · 🦊 Raposa · 🐰 Coelho · 🐼 Panda · 🦋 Borboleta · 🐨 Coala · 🐯 Tigre · 🐴 Pônei**

- **Cadastre cada criança com o mesmo nome e o mesmo bichinho em todos os apps.** Assim a ficha dela é uma só.
- Quem ficou com um **bichinho antigo** (🐧 🦄 🐸 🐢 🌸) continua funcionando. Troque uma vez em "Quem vai estudar hoje?" → **✏️ Trocar nome ou bichinho**, e o progresso vai junto. Escolha **o mesmo bichinho novo em todos os apps**.
- As regras completas (cadastro, acesso, recuperação) estão no `PADRAO_CADASTRO_NOME_BICHINHO.md`.

## ⚠️ Cuidados importantes

- **Nome + bichinho = identidade na nuvem.** Trocar o nome ou o bichinho (pelo botão ✏️) cria uma ficha nova **que recebe todo o progresso da antiga**. A antiga continua guardada. Mesmo assim, troque só quando precisar.
- **Use o mesmo nome e o mesmo bichinho da criança em todos os apps.**
- **Duas crianças não podem ter o mesmo nome + mesmo bichinho.**
- **Exportar backup** continua existindo — é uma segunda proteção.
- **Os apps nunca apagam nada da nuvem.**
- **Desmarcar** uma curiosidade funciona normal no celular. Só se a mesma criança usar **dois celulares**, algo marcado no outro celular volta a aparecer marcado (a regra é: na dúvida, nunca perder uma leitura).

---

## 📺 Tela sempre acesa · ⛶ Tela cheia · 📲 Instalar

- **Tela sempre acesa:** com o app aberto e na frente, o celular **não apaga e não bloqueia** (mesmo que o celular esteja configurado para bloquear em 1 minuto). Se minimizar o app, volta ao normal.
  - O app usa o recurso oficial do Chrome ("Wake Lock"). Se o celular recusar, entra o **modo reserva** (um vídeo invisível e mudo, o mesmo truque dos apps de vídeo). Um vigia confere a cada 15 segundos.
  - Desligar/ligar: ⚙️ → **📺 Tela** → **Tela sempre acesa**. A linha mostra o modo em uso.
  - Se ainda assim bloquear: desligue a **Economia de bateria/energia** do Android, confira se está usando o **Chrome atualizado** e toque uma vez na tela do app. Deixe o celular **na tomada** quando usar muito tempo na TV.
- **Tela cheia:** a cada toque, se o app saiu da tela cheia, ele volta. Usando pelo ícone instalado, já abre em tela cheia.
- **Convite para instalar:** aparece ao abrir pelo navegador, toda vez, até instalar. Se tocar em "Agora não", volta a oferecer quando abrir de novo (depois de 10 minutos). Também tem o botão ⚙️ → **📲 Instalar**.

---

## 🆘 Se aparecer alguma mensagem

| Mensagem (⚙️ → Nuvem → Situação) | O que fazer |
|---|---|
| "falta o arquivo nuvem-config.js" | O arquivo não foi junto na pasta arrastada no Netlify. Etapa 8. |
| "nuvem-config.js está vazio ou com erro de digitação" | Refaça a etapa 7. Cole **só** o bloco `const firebaseConfig = { ... };`, sem `import`; não apague aspas `"`, vírgulas ou `}`. |
| "Falta digitar o código da família" | Etapa 9. |
| "O login Anônimo não está ativado" | Etapa 4. |
| "A chave (apiKey) está errada" | Copie o bloco de novo (⚙️ Configurações do projeto → Seus apps) e refaça a etapa 7. |
| "As Regras do Firestore estão bloqueando" | Etapa 6 — colou tudo e clicou em **Publicar**? |
| "O banco Firestore não foi encontrado" | Etapa 5 — o banco precisa ser `(default)`; confira o `projectId`. |
| "📴 Sem internet" | Normal. Está guardado no celular e sobe sozinho depois. |
| Tela: "⚠️ O celular recusou" | Desligue a Economia de bateria e toque na tela. Se continuar, me mande um print dessa linha. |

---

## 💰 Custo

O plano grátis (Spark) permite **por dia** cerca de **50 mil leituras** e **20 mil gravações**, e guarda até **1 GB**. Cada envio do app usa 1 leitura e 3 gravações (progresso, ficha e cópia do dia). O histórico ocupa poucos KB por dia por criança. Com poucas crianças, **nunca passa do grátis**. Sem cartão cadastrado, o Firebase **não cobra nada**.

---

## 🔒 O que fica guardado na nuvem

- Primeiro nome e bichinho da criança.
- O progresso em cada app (lidas, favoritas, palavras aprendidas, conquistas, preferências de letra e cor, onde parou).
- **Nada de e-mail, telefone, foto, localização ou senha.**

---

## ✅ Checklist do Firebase (fazer uma vez)

- ⬜ Etapa 1 — Entrei no console do Firebase
- ⬜ Etapa 2 — Criei o projeto `escola-sao-pedro`
- ⬜ Etapa 3 — Registrei o app da Web e guardei o bloco `firebaseConfig`
- ⬜ Etapa 4 — Ativei o login **Anônimo**
- ⬜ Etapa 5 — Criei o **Firestore** em **São Paulo**, modo produção
- ⬜ Etapa 6 — Colei e **publiquei** as Regras
- ⬜ Etapa 7 — Preenchi o `nuvem-config.js` e guardei uma cópia
- ⬜ Etapa 8 — Publiquei o Curiosidades v1.7 no Netlify
- ⬜ Etapa 9 — Instalei pelo convite e digitei o código da família (e anotei no papel)
- ⬜ Etapa 10 — Pontinho verde + dados aparecendo no Firestore + tela não bloqueia
- ⬜ Depois: seguir o `COMO_PEDIR_NOS_OUTROS_APPS.md` para os outros 6 apps
