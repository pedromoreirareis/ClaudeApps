/* Confere que os blocos de dados principais do app existem, têm o
   tamanho esperado e não foram corrompidos por alguma edição. */
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_01_estrutura_dados');
  const dom = carregarApp();
  const { window } = dom;
  await esperar(300);

  t('DATA (frases pra ler) tem 2039 itens', () => {
    assertEq(window.eval('DATA.length'), 2039);
  });

  t('SILABAS_FASE1 (famílias simples) tem 17 famílias', () => {
    assertEq(window.eval('SILABAS_FASE1.length'), 17);
  });

  t('SILABAS_COMPLEXAS_MACRO tem 14 grupos', () => {
    assertEq(window.eval('SILABAS_COMPLEXAS_MACRO.length'), 14);
  });

  t('Toda família de SILABAS_FASE1 tem ao menos 1 sílaba com palavras', () => {
    const semPalavra = window.eval(`
      SILABAS_FASE1.filter(f => !f.silabas.some(s => s.palavras && s.palavras.length > 0)).map(f => f.fam)
    `);
    assert(semPalavra.length === 0, 'famílias sem nenhuma palavra: ' + JSON.stringify(semPalavra));
  });

  t('Todo grupo de SILABAS_COMPLEXAS_MACRO existe em SILABAS_COMPLEXAS_GRUPOS e tem padrões', () => {
    const problemas = window.eval(`
      SILABAS_COMPLEXAS_MACRO.filter(m => {
        const g = SILABAS_COMPLEXAS_GRUPOS[m.id];
        return !g || !g.padroes || g.padroes.length === 0;
      }).map(m => m.id)
    `);
    assert(problemas.length === 0, 'grupos sem padroes: ' + JSON.stringify(problemas));
  });

  t('Trilha (LEVELS) cobre 0..DATA.length-1 sem buracos nem sobreposição', () => {
    const r = window.eval(`
      (function(){
        var ordenado = LEVELS;
        var vistos = new Array(DATA.length).fill(0);
        ordenado.forEach(function(L){ L.ix.forEach(function(i){ if(i>=0 && i<vistos.length) vistos[i]++; }); });
        var buracos = [], duplicados = [];
        for(var i=0;i<vistos.length;i++){
          if(vistos[i]===0) buracos.push(i);
          if(vistos[i]>1) duplicados.push(i);
        }
        return {buracos: buracos.slice(0,10), nBuracos: buracos.length, duplicados: duplicados.slice(0,10), nDuplicados: duplicados.length};
      })()
    `);
    assert(r.nBuracos === 0, 'índices de DATA não cobertos por nenhum LEVEL: ' + r.nBuracos + ' (ex: ' + JSON.stringify(r.buracos) + ')');
    assert(r.nDuplicados === 0, 'índices de DATA cobertos por mais de um LEVEL: ' + r.nDuplicados + ' (ex: ' + JSON.stringify(r.duplicados) + ')');
  });

  t('BLOCOS_CONTEUDO (faixas de conteúdo antigas) continuam cobrindo o array inteiro sem buraco', () => {
    const r = window.eval(`
      (function(){ var v=new Array(DATA.length).fill(0);
        BLOCOS_CONTEUDO.forEach(function(B){ for(var i=B.s;i<B.e;i++) v[i]++; });
        return v.filter(function(x){return x!==1;}).length; })()
    `);
    assertEq(r, 0, 'índices sem bloco ou em mais de um bloco');
  });

  t('Toda frase de DATA tem separador "|" (frase e emoji)', () => {
    const semBarra = window.eval(`
      (function(){
        var n = 0;
        for(var i=0;i<DATA.length;i++){ if(DATA[i].indexOf('|') < 0) n++; }
        return n;
      })()
    `);
    assertEq(semBarra, 0, 'frases sem "|": ' + semBarra);
  });

  resumo();
})();
