"""P) Tela sempre acesa (+ modo reserva), convite de instalação, tela cheia
a cada toque, e o app abrindo SEM internet com o service worker real."""
from base import *
import json

WAKE_OK = """
window.__wake={pedidos:0,locks:[]};
Object.defineProperty(Navigator.prototype,'wakeLock',{configurable:true,get(){return {request:(t)=>{
  window.__wake.pedidos++; const ouv=[]; const l={released:false,type:t,addEventListener:(e,f)=>ouv.push(f),
  release:()=>{l.released=true; ouv.forEach(f=>f()); return Promise.resolve();}}; window.__wake.locks.push(l); return Promise.resolve(l);}};}});
"""
WAKE_RECUSA = """
window.__wake={pedidos:0};
Object.defineProperty(Navigator.prototype,'wakeLock',{configurable:true,get(){return {request:()=>{window.__wake.pedidos++; const e=new Error('recusado'); e.name='NotAllowedError'; return Promise.reject(e);}};}});
"""
WAKE_SEM = "try{ delete Navigator.prototype.wakeLock; }catch(e){}"
FS_STUB = """
window.__fs=0;
Element.prototype.requestFullscreen=function(){ window.__fs++; return Promise.resolve(); };
"""
STANDALONE = """
(function(){ const mm=window.matchMedia.bind(window);
  window.matchMedia=q=>(/display-mode: *(standalone|fullscreen)/.test(q))?{matches:true,media:q,addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}}:mm(q); })();
"""
PF = json.dumps({"perfis":[{"id":"1","nome":"Hana","av":"🦊"}],"atual":"1"})

def main():
    servidor()
    res=[]
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        r = R('P) Tela sempre acesa')
        ctx, fb = novo_contexto(b, storage={'ev_perfis':PF})
        ctx.add_init_script(WAKE_OK)
        p = abrir(ctx); p.wait_for_timeout(500)
        r.t('Ao abrir, o app pede a tela acesa (Wake Lock "screen")', p.evaluate("__wake.pedidos")>=1 and p.evaluate("__wake.locks[0].type")=='screen')
        r.t('Modo em uso: nativo', p.evaluate("EscolaPWA.estado().telaAcesa.modo")=='nativo')
        n = p.evaluate("__wake.pedidos")
        p.evaluate("__wake.locks[__wake.locks.length-1].release()"); p.wait_for_timeout(1200)
        r.t('Quando o sistema solta a trava, o app pede de novo sozinho', p.evaluate("__wake.pedidos")>n)
        p.evaluate("EscolaFamilia.fecharTudo(); ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open')); openConfig(); atualizaTelaAcesaUI();")
        r.t('Configurações: "📺 Tela sempre acesa" ligada por padrão, mostrando "Ligado"', p.text_content('#cfgTelaSw')=='✅' and 'Ligado' in p.text_content('#cfgTelaSt'), p.text_content('#cfgTelaSt'))
        p.click('#cfgTela'); p.wait_for_timeout(200)
        r.t('Tocar desliga (e grava a escolha no celular)', p.text_content('#cfgTelaSw')=='❌' and ls(p,'ev_telaAcesa')=='0')
        p.click('#cfgTela'); p.wait_for_timeout(300)
        r.t('Tocar de novo liga', p.text_content('#cfgTelaSw')=='✅' and ls(p,'ev_telaAcesa')=='1')
        r.t('A tela acesa própria antiga (v118) não roda junto (sem duplicar)', p.evaluate("typeof _wakeLock==='undefined' || _wakeLock===null"))
        ctx.close()
        ctx, fb = novo_contexto(b, storage={'ev_perfis':PF}); ctx.add_init_script(WAKE_RECUSA)
        p = abrir(ctx); p.wait_for_timeout(800)
        st = p.evaluate("EscolaPWA.estado().telaAcesa")
        r.t('Wake Lock recusado: entra no modo reserva (vídeo mudo)', st['erro']=='NotAllowedError' and p.evaluate("!!document.querySelector('video')"), st)
        p.evaluate("EscolaFamilia.fecharTudo(); ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open')); openConfig();")
        t = p.text_content('#cfgTelaSt')
        r.t('...e as Configurações mostram o modo reserva ou o aviso do celular', 'reserva' in t or 'recusou' in t, t)
        ctx.close()
        ctx, fb = novo_contexto(b, storage={'ev_perfis':PF}); ctx.add_init_script(WAKE_SEM)
        p = abrir(ctx); p.wait_for_timeout(800)
        r.t('Navegador sem Wake Lock: usa o modo reserva (vídeo mudo)', p.evaluate("!('wakeLock' in navigator)") and p.evaluate("!!document.querySelector('video')"))
        ctx.close()
        res.append(r.fim())

        r = R('P) Convite para instalar e tela cheia')
        ctx, fb = novo_contexto(b, storage={'ev_perfis':PF}, convite=True); ctx.add_init_script(FS_STUB)
        p = abrir(ctx); p.wait_for_timeout(3000)
        r.t('Aberto pelo navegador: o convite aparece sozinho', p.is_visible('#escolaConvite'))
        r.t('Sem o evento do Chrome: mostra o passo a passo (⋮ → Instalar app)', 'Instalar app' in (p.text_content('#escolaConvite') or ''))
        r.t('O banner antigo do próprio app não aparece junto (sem duplicar)', not p.evaluate("document.getElementById('install').classList.contains('show')"))
        p.evaluate("""()=>{ const e=new Event('beforeinstallprompt'); e.prompt=()=>{window.__prompt=1; return Promise.resolve();}; e.userChoice=Promise.resolve({outcome:'accepted'}); window.dispatchEvent(e); }""")
        p.wait_for_timeout(300)
        r.t('Com o evento do Chrome: aparece "📲 Instalar agora"', p.is_visible('#ecInstalar'))
        fs0 = p.evaluate("__fs")
        p.click('#ecInstalar'); p.wait_for_timeout(400)
        r.t('Tocar em "Instalar agora" chama a instalação do Chrome', p.evaluate("window.__prompt===1"))
        r.t('Tocar no convite não força tela cheia', p.evaluate("__fs")==fs0)
        r.t('Depois de instalar, o convite some e fica marcado como instalado', not p.is_visible('#escolaConvite') and ls(p,'escola_instalado')=='1')
        # tela cheia a cada toque
        p.evaluate("EscolaFamilia.fecharTudo(); document.getElementById('hubOv').classList.add('open')")
        fs1 = p.evaluate("__fs")
        p.locator('.hubBtn[data-hub="ler"]').click(); p.wait_for_timeout(300)
        r.t('Tela cheia volta a cada toque num botão', p.evaluate("__fs")>fs1)
        p.evaluate("abrirEditarPerfil('1')"); p.wait_for_timeout(300)
        fs2 = p.evaluate("__fs")
        p.click('#efRaiz .ef-nome-campo'); p.wait_for_timeout(300)
        r.t('Tocar num campo de digitar NÃO força tela cheia (teclado funciona)', p.evaluate("__fs")==fs2)
        p.evaluate("EscolaFamilia.fecharTudo(); openConfig()"); p.wait_for_timeout(200)
        r.t('Configurações: linha "📲 Instalar" aparece no navegador', p.is_visible('#cfgInst'))
        ctx.close()
        ctx, fb = novo_contexto(b, storage={'ev_perfis':PF}, convite=True); ctx.add_init_script(STANDALONE)
        p = abrir(ctx); p.wait_for_timeout(3000)
        r.t('Aberto pelo ícone instalado: o convite não aparece', not p.is_visible('#escolaConvite'))
        p.evaluate("EscolaFamilia.fecharTudo(); ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open')); openConfig()")
        r.t('...e a linha "📲 Instalar" some das Configurações', not p.is_visible('#cfgInst'))
        ctx.close()
        res.append(r.fim())

        r = R('P) Instalável e funcionando sem internet (service worker real)')
        man = json.load(open(os.path.join(PASTA,'manifest.webmanifest'),encoding='utf-8'))
        r.t('manifest: name, short_name, start_url, display, ícones 192 e 512', all(man.get(k) for k in ('name','short_name','start_url','display')) and
            {i['sizes'] for i in man['icons']}>={'192x192','512x512'})
        sw = open(os.path.join(PASTA,'sw.js'),encoding='utf-8').read()
        r.t('sw.js: versão do cache nova (esforco-vence-v123)', "const C='esforco-vence-v123'" in sw)
        r.t('sw.js: nuvem-sync.js, escola-pwa.js e escola-familia.js no cache de instalação', './nuvem-sync.js' in sw and './escola-pwa.js' in sw and './escola-familia.js' in sw)
        r.t('sw.js: não intercepta outros endereços (Firebase)', 'url.origin!==self.location.origin) return' in sw)
        r.t('sw.js: nuvem-config.js buscado primeiro na internet', "REDE_PRIMEIRO=['nuvem-config.js']" in sw)
        fb = FakeFirebase()
        ctx, _ = novo_contexto(b, fb=fb, service_worker='allow', familia='familiateste', storage={'ev_perfis':PF,'hana_done':'1'})
        p = abrir(ctx)
        p.evaluate("navigator.serviceWorker.ready"); p.wait_for_timeout(2500)
        cache = p.evaluate("caches.keys().then(ks=>Promise.all(ks.map(k=>caches.open(k).then(c=>c.keys()).then(rs=>[k,rs.map(r=>new URL(r.url).pathname)]))))")
        nomes = cache[0][1] if cache else []
        r.t('Service worker instalado e guardou o app + arquivos compartilhados',
            cache and cache[0][0]=='esforco-vence-v123' and all(('/'+f) in nomes for f in ['index.html','nuvem-sync.js','escola-pwa.js','escola-familia.js','nuvem-config.js','manifest.webmanifest']), cache)
        ok_sync = False
        for _ in range(30):
            if fb.dados_app('hana_1f98a'): ok_sync=True; break
            p.wait_for_timeout(250)
        r.t('Com o service worker ativo, a nuvem continua funcionando (não é interceptada)', ok_sync)
        ctx.set_offline(True)
        erros=[]; p.on('pageerror', lambda e: erros.append(str(e)))
        p.reload(wait_until='load'); p.wait_for_timeout(1200)
        r.t('SEM INTERNET: o app abre inteiro pelo service worker', p.evaluate("typeof DATA!=='undefined' && DATA.length")==2039)
        r.t('...com a nuvem, o escola-pwa e o escola-familia carregados do cache', p.evaluate("!!window.NuvemSync && !!window.EscolaPWA && !!window.EscolaFamilia && NuvemSync.configurada()"))
        r.t('...e abre "Quem vai estudar hoje?" sem internet', p.evaluate("!!document.querySelector('#efRaiz .ef-t4')"))
        r.t('...e mostra "sem internet" (fila guardada no celular)', p.evaluate("NuvemSync.status().estado")=='offline')
        r.t('...sem erros de JavaScript', not erros, erros)
        ctx.close()
        res.append(r.fim())
        b.close()
    return res

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nPWA: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
