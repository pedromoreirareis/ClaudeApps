"""Nuvem (Firebase simulado) — envio, fila offline, recuperação, mistura
entre celulares, regras, histórico de versões, isolamento por leitora e
regras da função mesclar para cada tipo de dado de aprendizagem."""
from base import *
from ef import *
import json

FAM = 'familiateste'
def perfis_json(lista, atual): return json.dumps({"perfis":[{"id":i,"nome":n,"av":a} for i,n,a in lista],"atual":atual})
def estado(p): return p.evaluate("NuvemSync.status()")
def esperar_ok(p, ms=6000):
    for _ in range(ms//250):
        st = estado(p)
        if st['estado']=='ok' and st['pendentes']==0: return True
        p.wait_for_timeout(250)
    return False
def fechar(p):
    fechar_tudo(p)

def main():
    servidor()
    res=[]
    with sync_playwright() as pw:
        b = pw.chromium.launch()

        # ---------------- A) sem configuração ----------------
        r = R('A) Sem configuração: o app funciona igual e não chama a nuvem')
        for modo in ('vazia','falta'):
            fb = FakeFirebase()
            ctx, _ = novo_contexto(b, fb=fb, config=modo, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':'11'})
            erros=[]; p = abrir(ctx, erros); p.wait_for_timeout(3000)
            fechar(p); p.evaluate("trocarPagina('ler'); go(1); go(1);"); p.wait_for_timeout(1500)
            r.t('nuvem-config %s: nenhuma chamada ao Firebase' % modo, len(fb.chamadas)==0, fb.chamadas[:3])
            r.t('nuvem-config %s: o progresso continua sendo gravado no celular' % modo, (ls(p,'hana_done') or '').count('1')>=3)
            p.evaluate("openConfig()")
            txt = p.text_content('.ef-cfg-nuvem')
            r.t('nuvem-config %s: Configurações explicam que a nuvem está desligada' % modo, 'NUVEM DESLIGADA (FALTA O ARQUIVO NUVEM-CONFIG.JS)' in txt, txt)
            r.t('nuvem-config %s: sem pedir código, sem "🔄 Atualizar agora", bolinha 🔴 na ⚙️ (v122: a bolinha sempre aparece)' % modo,
                not p.is_visible('.ef-cfg-atualizar') and ponto_cfg(p).endswith('ef-p-vermelho'))
            r.t('nuvem-config %s: nenhum erro de JavaScript' % modo, not [e for e in erros if '404' not in e and 'nuvem-config' not in e], erros)
            ctx.close()
        res.append(r.fim())

        # ---------------- B) envio, histórico antigo, fila offline ----------------
        r = R('B) Envio: histórico antigo sobe, alterações e desmarcações sobem, fila offline')
        fb = FakeFirebase()
        antigo = '1'*40
        ctx, _ = novo_contexto(b, fb=fb, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':antigo,
                  'hana_sil_lidas':json.dumps(['SIMP_M_ma::Mala']),'hana_fav':json.dumps([3,7]),'hana_words':'120'})
        erros=[]; p = abrir(ctx, erros); p.wait_for_timeout(1500)
        r.t('Sem código da família: estado "sem-codigo" e bolinha vermelha na ⚙️',
            estado(p)['estado']=='sem-codigo' and ponto_cfg(p).endswith('ef-p-vermelho'))
        r.t('Caso B do plano: T1 com "ESTE CELULAR JÁ TEM: 🦊 Hana" e "AGORA NÃO ›"', aberta(p,'ef-t1') and 'Hana' in p.text_content('.ef-t1-jatem') and p.is_visible('.ef-t1-agoranao'))
        p.click('.ef-t1-novo'); p.wait_for_timeout(300)
        r.t('O código da família é pedido num pop-up do app (não no do navegador)', aberta(p,'ef-t3'))
        p.fill('.ef-t3 .ef-codigo','Família Teste'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200); p.click('.ef-ja-anotei')
        r.t('Depois do código, tudo sobe sozinho', esperar_ok(p))
        d = fb.dados_app('hana_1f98a', familia='familia-teste')
        r.t('O histórico antigo do celular subiu na 1ª sincronização (frases, sílabas, favoritas, palavras)',
            d and d.get('hana_done')==antigo and 'SIMP_M_ma::Mala' in d.get('hana_sil_lidas','') and json.loads(d.get('hana_fav','[]'))==[3,7] and d.get('hana_words')=='120', d)
        r.t('Ficha na nuvem = nome + bichinho (hana_1f98a) com o app "alfabetizacao"',
            'familias/familia-teste/usuarios/hana_1f98a' in fb.docs and 'apps' in fb.docs['familias/familia-teste/usuarios/hana_1f98a']['fields'])
        # alteração
        fechar(p); p.evaluate("trocarPagina('ler'); idx=construirOrdemDificuldade().find(i=>!isDone(i)); go(1);")
        esperar_ok(p); d = fb.dados_app('hana_1f98a', familia='familia-teste')
        r.t('Ler uma frase nova sobe em ~1,5 s', d['hana_done'].count('1')==41, d['hana_done'].count('1'))
        # desmarcar (favorita)
        p.evaluate("favArr=[3]; localStorage.setItem('hana_fav',JSON.stringify(favArr));")
        esperar_ok(p); d = fb.dados_app('hana_1f98a', familia='familia-teste')
        r.t('Desmarcar/alterar também sobe (favorita tirada)', d['hana_fav']=='[3]', d['hana_fav'])
        # offline
        ctx.set_offline(True); p.evaluate("window.dispatchEvent(new Event('offline'))")
        p.evaluate("markDone(construirOrdemDificuldade().find(i=>!isDone(i)));"); p.wait_for_timeout(2500)
        st=estado(p); p.evaluate("openConfig()"); txt=p.text_content('.ef-cfg-nuvem')
        r.t('Sem internet: fica na fila (pendente) no celular', st['estado']=='offline' and st['pendentes']>=1, st)
        r.t('Aviso "📴 SEM INTERNET: 1 CRIANÇA ESPERANDO. NÃO LIMPE OS DADOS DO NAVEGADOR."', 'SEM INTERNET: 1 CRIANÇA ESPERANDO. NÃO LIMPE OS DADOS DO NAVEGADOR.' in txt, txt)
        r.t('Bolinha amarela na ⚙️ com fila offline', ponto_cfg(p).endswith('ef-p-amarelo'))
        ctx.set_offline(False); p.evaluate("window.dispatchEvent(new Event('online'))")
        r.t('Quando a internet volta, a fila sobe sozinha', esperar_ok(p, 8000))
        d = fb.dados_app('hana_1f98a', familia='familia-teste')
        r.t('...com a frase lida offline', d['hana_done'].count('1')==42, d['hana_done'].count('1'))
        r.t('Sem erros de JavaScript', not [e for e in erros if '404' not in e and 'ERR_INTERNET' not in e], erros)
        ctx.close()
        res.append(r.fim())

        # ---------------- F) isolamento por leitora ----------------
        r = R('F) Duas crianças no mesmo celular: a nuvem nunca mistura uma com a outra')
        fb = FakeFirebase()
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦊'),('p2','Hinata','🐰')],'p2'),
                  'hana_done':'1111','p2_hana_done':'1','p2_hana_trilha_v2':'1','p2_hana_idx':'0'})
        p = abrir(ctx); esperar_ok(p)
        fechar(p); p.evaluate("trocarPagina('ler'); idx=construirOrdemDificuldade()[0]; go(1); go(1); go(1);"); esperar_ok(p)
        brutas = p.evaluate("['hana_done','p2_hana_done'].map(k=>_rawGet(k))")
        r.t('O que a Hinata lê fica só nas chaves dela (p2_…); as da Hana não mudam', brutas[0]=='1111' and brutas[1].count('1')>=3, brutas)
        dh = fb.dados_app('hana_1f98a'); dn = fb.dados_app('hinata_1f430')
        r.t('Na nuvem, a ficha da Hana tem só o progresso da Hana', dh and dh['hana_done']=='1111', dh and dh.get('hana_done'))
        r.t('Na nuvem, a ficha da Hinata tem só o progresso da Hinata', dn and dn['hana_done']==brutas[1])
        r.t('Nenhuma chave de progresso gravada sem prefixo pela Hinata', p.evaluate("_rawGet('hana_idx')")==None)
        ctx.close()
        res.append(r.fim())

        # ---------------- C) recuperação num celular limpo pela tela ----------------
        r = R('C) Recuperação num celular limpo: 🔑 Já tenho cadastro → código → a criança da nuvem')
        fb = FakeFirebase()
        fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'1'*25,'hana_sil_lidas':json.dumps(['a','b']),'hana_theme':'3','hana_trilha_v2':'1'}, familia='familia-teste')
        fb.gravar_app('bia_1f430','Bia','🐰',{'hana_done':'1'}, app='curiosidades', familia='familia-teste')
        ctx, _ = novo_contexto(b, fb=fb)
        erros=[]; p = abrir(ctx, erros)
        p.click('.ef-t1-ja'); p.wait_for_timeout(400)
        r.t('"🔑 Já tenho cadastro" pede o código da família (T2)', aberta(p,'ef-t2'))
        p.fill('.ef-t2 .ef-codigo','familia teste'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1500)
        cards = p.evaluate("Array.from(document.querySelectorAll('.ef-t2 .ef-mini')).map(c=>c.textContent)")
        r.t('"🎉 ACHEI A SUA FAMÍLIA!" mostra as crianças, inclusive de outro app (📚 e 🌍)', 'ACHEI A SUA FAMÍLIA' in p.text_content('.ef-t2') and any('Renata' in c and '📚' in c for c in cards) and any('Bia' in c and '🌍' in c for c in cards), cards)
        p.click('.ef-t2 .ef-escolher'); p.wait_for_timeout(1200)
        r.t('"ESCOLHER": a T4 mostra as crianças da nuvem com ☁️ "TOQUE PARA TRAZER" (D6)', p.locator('.ef-t4 .ef-nuvemcard').count()==2)
        p.locator('.ef-t4 .ef-nuvemcard', has_text='Renata').click()
        esperar_recarga(p, 4500)
        pf = json.loads(ls(p,'ev_perfis'))
        r.t('Tocar na criança cria ela neste celular com nome + bichinho', pf['perfis'][0]['nome']=='Renata' and pf['perfis'][0]['av']=='🦋')
        r.t('...e traz o progresso dela (25 frases)', p.evaluate("doneN")==25, p.evaluate("doneN"))
        r.t('...e as preferências (tema) numa recuperação', p.evaluate("themeIdx")==3)
        d = fb.dados_app('renata_1f98b', familia='familia-teste')
        r.t('A nuvem não foi apagada', d['hana_done'].count('1')==25)
        r.t('Sem erros de JavaScript', not [e for e in erros if '404' not in e], erros)
        ctx.close()
        res.append(r.fim())

        # ---------------- D) recuperação automática ----------------
        r = R('D) Recuperação automática ao cadastrar o mesmo nome + bichinho')
        fb = FakeFirebase()
        fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'1'*30,'hana_parentes':json.dumps({'pai':'Pedro'}),'hana_trilha_v2':'1'})
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM)
        p = abrir(ctx); p.wait_for_timeout(1500)
        p.click('.ef-t4 .ef-novo'); p.wait_for_timeout(300)
        cadastrar_t5(p, 'renata', 4)
        r.t('O progresso volta sozinho (30 frases)', p.evaluate("doneN")==30, p.evaluate("doneN"))
        r.t('Os nomes da família voltam junto', json.loads(ls(p,[k for k in [p.evaluate("prefixoDe(PERF.atual)")+'hana_parentes']][0]) or '{}').get('pai')=='Pedro')
        esperar_ok(p)
        r.t('A nuvem continua com as 30 frases (nada apagado)', fb.dados_app('renata_1f98b')['hana_done'].count('1')==30)
        ctx.close()
        res.append(r.fim())

        # ---------------- E) mistura entre celulares ----------------
        r = R('E) Mistura com outro celular (inclusive gravando no meio do envio e relógio atrasado)')
        fb = FakeFirebase()
        fb.gravar_app('hana_1f98a','Hana','🦊',{'hana_done':'0011','hana_fav':'[9]','hana_words':'300'})
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':'1100','hana_fav':'[1]','hana_words':'50','hana_trilha_v2':'1'})
        p = abrir(ctx); esperar_ok(p, 8000)
        r.t('Ao abrir, junta o que o outro celular fez: frases 1100 + 0011 = 1111', (ls(p,'hana_done') or '').startswith('1111'), ls(p,'hana_done'))
        r.t('...favoritas juntas e palavras lidas ficam com o maior valor', json.loads(ls(p,'hana_fav'))==[1,9] and ls(p,'hana_words')=='300')
        r.t('...e a tela (memória) também foi atualizada', p.evaluate("doneN")>=4 and p.evaluate("favArr.indexOf(9)>=0"))
        r.t('A nuvem recebe o resultado já juntado', fb.dados_app('hana_1f98a')['hana_done'].startswith('1111'))
        # outro celular grava no meio do envio (e com relógio atrasado)
        def outro(fbx, caminho):
            if caminho.endswith('/apps/alfabetizacao'):
                d = fbx.dados_app('hana_1f98a'); d['hana_sil_lidas']=json.dumps(['OUTRO::Pato']); d['hana_done']=d['hana_done']
                fbx.docs['familias/%s/usuarios/hana_1f98a/apps/alfabetizacao'%FAM]['fields']['dados']['stringValue']=json.dumps(d)
                fbx.docs['familias/%s/usuarios/hana_1f98a/apps/alfabetizacao'%FAM]['fields']['atualizadoEm']={'integerValue':'1000'}
                fbx.docs['familias/%s/usuarios/hana_1f98a/apps/alfabetizacao'%FAM]['fields']['dispositivo']={'stringValue':'outro'}
                fbx.docs['familias/%s/usuarios/hana_1f98a/apps/alfabetizacao'%FAM]['updateTime']=fbx._now()
        fb.antes_de_gravar = outro
        fechar(p); p.evaluate("localStorage.setItem('hana_sil_lidas', JSON.stringify(['MEU::Gato']))"); esperar_ok(p, 8000)
        d = fb.dados_app('hana_1f98a')
        r.t('Outro celular gravou no meio do envio: nada se perde (as 2 sílabas ficam)', 'OUTRO::Pato' in d['hana_sil_lidas'] and 'MEU::Gato' in d['hana_sil_lidas'], d['hana_sil_lidas'])
        r.t('...e o celular também fica com as duas', 'OUTRO::Pato' in ls(p,'hana_sil_lidas'))
        ctx.close()
        res.append(r.fim())

        # ---------------- M) regras da mesclar ----------------
        r = R('M) Regra de ouro da junção — cada tipo de dado de aprendizagem')
        ctx, fb = novo_contexto(b, config='vazia', storage={'ev_perfis':perfis_json([('1','Hana','🦊'),('p2','Bia','🐰')],'1'),
            'p2_hana_done':'1010','p2_hana_sil_lidas':'["a","b"]','p2_hana_sil_estudadas':'["M"]','p2_hana_monta_ok':'[1]','p2_hana_silaba_ok':'[5]',
            'p2_hana_fav':'[2]','p2_hana_stars':'["2026-09-01"]','p2_hana_help':'{"4":2,"7":1}','p2_hana_diario':'{"2026-09-20":[1,2]}',
            'p2_hana_words':'100','p2_hana_streak':'2','p2_hana_bstreak':'5','p2_hana_goalday':'2026-09-10',
            'p2_hana_day':'2026-09-23','p2_hana_today':'4','p2_hana_parentes':'{"pai":"Pedro","mae":""}',
            'p2_hana_idx':'10','p2_hana_theme':'1','p2_hana_font':'2'})
        p = abrir(ctx)
        nuvem = {'hana_done':'0101','hana_sil_lidas':'["b","c"]','hana_sil_estudadas':'["P"]','hana_monta_ok':'[2]','hana_silaba_ok':'[5,6]',
                 'hana_fav':'[3]','hana_stars':'["2026-09-02"]','hana_help':'{"4":1,"7":3,"9":1}','hana_diario':'{"2026-09-20":[2,3],"2026-09-21":[8]}',
                 'hana_words':'90','hana_streak':'3','hana_bstreak':'4','hana_goalday':'2026-09-12',
                 'hana_day':'2026-09-23','hana_today':'6','hana_parentes':'{"pai":"Paulo","mae":"Roberta"}',
                 'hana_idx':'99','hana_theme':'4','hana_font':'5'}
        p.evaluate("d=>nuvemMesclar('p2', d, false)", nuvem)
        g = lambda k: p.evaluate("k=>_rawGet('p2_'+k)", k)
        r.t('Frases lidas (bitmap): OU — 1010 + 0101 = 1111', g('hana_done')=='1111')
        for k,exp in [('hana_sil_lidas',['a','b','c']),('hana_sil_estudadas',['M','P']),('hana_monta_ok',[1,2]),('hana_silaba_ok',[5,6]),('hana_fav',[2,3]),('hana_stars',['2026-09-01','2026-09-02'])]:
            r.t('Lista %s: união (nada some)' % k, json.loads(g(k))==exp, g(k))
        r.t('Pedidos de ajuda por frase: maior de cada frase', json.loads(g('hana_help'))=={'4':2,'7':3,'9':1}, g('hana_help'))
        r.t('Diário: junta dia a dia', json.loads(g('hana_diario'))=={'2026-09-20':[1,2,3],'2026-09-21':[8]}, g('hana_diario'))
        r.t('Contadores e recordes: maior (palavras 100, sequência 3, recorde 5)', (g('hana_words'),g('hana_streak'),g('hana_bstreak'))==('100','3','5'))
        r.t('Dia da estrela: o mais recente', g('hana_goalday')=='2026-09-12')
        r.t('Frases lidas hoje (mesmo dia): o maior', g('hana_today')=='6')
        r.t('Nomes da família: o preenchido aqui fica, o vazio vem da nuvem', json.loads(g('hana_parentes'))=={'pai':'Pedro','mae':'Roberta'})
        r.t('Onde parou e preferências: o celular manda no dia a dia', (g('hana_idx'),g('hana_theme'),g('hana_font'))==('10','1','2'))
        p.evaluate("d=>nuvemMesclar('p2', d, true)", nuvem)
        r.t('Numa recuperação, onde parou e preferências vêm da nuvem', (g('hana_idx'),g('hana_theme'),g('hana_font'))==('99','4','5'))
        r.t('Juntar a Bia não mexeu em nada da Hana (aberta)', p.evaluate("_rawGet('hana_done')")==None)
        # v123 (C1): o app só junta numa criança que está na lista; a criança nova entra na lista ANTES (como no trazer/cadastrar)
        p.evaluate("PERF.perfis.push({id:'p3novo', nome:'Novo', av:'🦊'})")
        p.evaluate("d=>nuvemMesclar('p3novo', d, false)", {'hana_idx':'77','hana_done':'1'})
        r.t('Criança sem nada neste celular adota também onde parou/preferências', p.evaluate("_rawGet('p3novo_hana_idx')")=='77')
        ctx.close()
        res.append(r.fim())

        # ---------------- G/H) regras ----------------
        r = R('G/H) Erros de regras em português; regras sem "versoes"')
        fb = FakeFirebase(); fb.negar_tudo = True
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':'1'})
        p = abrir(ctx); p.wait_for_timeout(4000); fechar(p); p.evaluate("openConfig()")
        txt = p.text_content('.ef-cfg-nuvem')
        r.t('Regras bloqueando: aviso em português nas Configurações', 'As Regras do Firestore estão bloqueando' in txt, txt)
        r.t('...bolinha vermelha na ⚙️', ponto_cfg(p).endswith('ef-p-vermelho'))
        r.t('...e o progresso continua no celular', ls(p,'hana_done')=='1')
        ctx.close()
        fb = FakeFirebase(); fb.negar_versoes = True
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':'11'})
        p = abrir(ctx); esperar_ok(p, 8000); fechar(p); p.evaluate("openConfig()")
        txt = p.text_content('.ef-cfg-nuvem') + ' ' + p.evaluate("NuvemSync.status().avisoVersoes")
        r.t('Regras sem "versoes": o principal sobe mesmo assim', fb.dados_app('hana_1f98a') and fb.dados_app('hana_1f98a')['hana_done']=='11')
        r.t('...e o app avisa ("Histórico de versões não gravou")', 'Histórico de versões não gravou' in txt, txt)
        ctx.close()
        res.append(r.fim())

        # ---------------- V) histórico de versões ----------------
        r = R('V) Histórico de versões')
        fb = FakeFirebase()
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦊')],'1'),'hana_done':'1100','hana_sil_lidas':'["hoje"]','hana_trilha_v2':'1'})
        p = abrir(ctx); esperar_ok(p, 8000)
        hoje = p.evaluate("(()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')})()")
        r.t('A cópia do dia foi criada em .../versoes/AAAA-MM-DD', 'familias/%s/usuarios/hana_1f98a/apps/alfabetizacao/versoes/%s' % (FAM,hoje) in fb.docs)
        # versão antiga com algo que hoje não tem
        base = 'familias/%s/usuarios/hana_1f98a/apps/alfabetizacao/versoes/2026-09-01' % FAM
        fb.docs[base] = {'updateTime': fb._now(), 'fields': {'dados': {'stringValue': json.dumps({'hana_done':'0011','hana_sil_lidas':'["antiga"]'})}, 'atualizadoEm': {'integerValue':'1'}}}
        fechar(p); p.evaluate("openConfig()"); p.wait_for_timeout(300)
        p.click('.ef-cfg-copias-bt'); p.wait_for_timeout(300)
        r.t('"🕘 CÓPIAS DE CADA DIA" com um toque só NÃO abre (trava do adulto)', not aberta(p,'ef-copias'))
        segurar(p, '.ef-cfg-copias-bt'); p.wait_for_timeout(1200)
        r.t('...segurando 3 s abre', aberta(p,'ef-copias'))
        cards = p.evaluate("Array.from(document.querySelectorAll('.ef-copias .ef-mini')).map(c=>c.textContent)")
        r.t('A lista de cópias aparece (uma por dia, com resumo do progresso)', len(cards)==2 and any('01/09/2026' in c and '2 frases' in c for c in cards), cards)
        p.locator('.ef-copias .ef-mini', has_text='01/09/2026').click(); p.wait_for_timeout(300)
        r.t('Tocar numa cópia pergunta num pop-up do app (não no do navegador)', aberta(p,'ef-pergunta') and 'JUNTAR A CÓPIA' in p.text_content('.ef-pergunta'))
        p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(1500)
        r.t('Juntar a versão antiga traz o que faltava sem apagar o de hoje (frases 1111)', (ls(p,'hana_done') or '').startswith('1111'), ls(p,'hana_done'))
        r.t('...sílabas de hoje + da versão antiga', set(json.loads(ls(p,'hana_sil_lidas')))=={'hoje','antiga'})
        r.t('...e a tela (memória) já mostra', p.evaluate("doneN")==4)
        ctx.close()
        res.append(r.fim())

        # ---------------- K) trocar nome leva a ficha ----------------
        r = R('K) Trocar nome ou bichinho leva a ficha da nuvem; bichinho antigo funciona com a nuvem')
        fb = FakeFirebase()
        ctx, _ = novo_contexto(b, fb=fb, familia=FAM, storage={'ev_perfis':perfis_json([('1','Hana','🦄')],'1'),'hana_done':'111','hana_trilha_v2':'1'})
        p = abrir(ctx); esperar_ok(p, 8000)
        r.t('Criança com bichinho antigo (🦄) sobe normalmente (hana_1f984)', fb.dados_app('hana_1f984') and fb.dados_app('hana_1f984')['hana_done']=='111')
        fb.gravar_app('hana_1f984','Hana','🦄',{'hana_done':'111','hana_sil_lidas':'["so_na_nuvem"]'}, dispositivo='outro')
        fechar(p); p.evaluate("abrirEditarPerfil('1')"); p.wait_for_timeout(300); p.locator('#efRaiz .ef-bicho').nth(1).click(); p.click('#efRaiz .ef-pronto')
        p.wait_for_timeout(2500); esperar_ok(p, 8000); p.wait_for_timeout(1500)
        novo = fb.dados_app('hana_1f98a')
        r.t('Trocou para 🦊: a ficha nova recebe todo o progresso da antiga', novo and novo['hana_done']=='111' and 'so_na_nuvem' in novo.get('hana_sil_lidas',''), novo)
        r.t('A ficha antiga continua guardada na nuvem', fb.dados_app('hana_1f984') is not None)
        r.t('v122: a ficha antiga ganha movidoPara = a nova (e some da lista da família)', (fb.ficha('hana_1f984') or {}).get('movidoPara',{}).get('stringValue')=='hana_1f98a', fb.ficha('hana_1f984'))
        r.t('...e a nova fica sem movidoPara (não aponta de volta: sem ciclo)', (fb.ficha('hana_1f98a') or {}).get('movidoPara',{}).get('stringValue','')=='')
        r.t('...e a mudança saiu da lista de pendentes', estado_familia(p)['mudancasPendentes']==[])
        ctx.close()
        res.append(r.fim())
        b.close()
    return res

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nNUVEM: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
