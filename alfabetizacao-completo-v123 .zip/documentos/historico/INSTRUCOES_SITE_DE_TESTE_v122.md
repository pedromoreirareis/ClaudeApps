# 🧪 Testar o novo cadastro no SITE DE TESTE (Alfabetização v122)

> ## ⚠️ NUNCA digite o código da família de verdade no site de teste.
> Use **só** `teste-pedro-2026`. O próprio app do site de teste recusa qualquer código que não comece com "teste" — mas não conte só com isso.

O site de teste é **outro endereço**. O celular guarda os dados dele **separados** do app que as meninas usam. O app de verdade (`escolasaopedroalfabetizacao.netlify.app`) **não é tocado**.

---

## 1. Criar o site de teste no Netlify (uma vez só)

1. Entre no Netlify → **Add new site** → **Deploy manually**.
2. Arraste o arquivo **`alfabetizacao-v122-SITE-DE-TESTE-netlify.zip`**.
3. Em **Site configuration → Change site name**, coloque: `escolasaopedroalfabetizacao-teste`
   (o endereço fica `https://escolasaopedroalfabetizacao-teste.netlify.app/`).
   - O nome **precisa** terminar em `-teste`: é assim que o app sabe que é o site de teste (aparece uma faixa roxa "🧪 SITE DE TESTE" no alto).
4. Abra o endereço no celular. Tem que aparecer a faixa roxa. **Se não aparecer, pare** e me avise.

## 2. Primeiro celular (o seu)

1. Abra o site de teste. Aparece **🦉 OLÁ! VAMOS COMEÇAR?**
2. Toque **🌱 SOU NOVO POR AQUI**. Apague o código sugerido e escreva `teste-pedro-2026`. Toque **✅ CRIAR A FAMÍLIA**.
   - Se aparecer "ESSE CÓDIGO JÁ TEM CRIANÇAS", é porque você já testou antes: feche e use **🔑 JÁ TENHO CADASTRO** com o mesmo código.
3. Toque **✅ JÁ ANOTEI** → cadastre uma criança de teste, ex.: **TESTE ANA** com 🐼.
4. Leia umas 3 frases. Volte para "Quem vai estudar hoje?" tocando no **bichinho ao lado da ⚙️**.
5. Confira: a bolinha embaixo fica **🟢 TUDO GUARDADO NA NUVEM (ÀS hh:mm)**.
6. Cadastre outra criança: **TESTE BIA** com 🐰. Leia 1 frase.

## 3. Segundo celular (o da Roberta, ou outro)

1. Abra o site de teste → **🔑 JÁ TENHO CADASTRO** → `teste-pedro-2026` → **🔑 PROCURAR A FAMÍLIA**.
2. Tem que aparecer **🎉 ACHEI A SUA FAMÍLIA!** com 🐼 TESTE ANA e 🐰 TESTE BIA.
3. Toque **TRAZER TODAS**. As duas aparecem com o progresso (3 frases e 1 frase).
4. No 2º celular, leia mais 2 frases com a TESTE ANA. Espere a bolinha ficar 🟢.
5. No 1º celular, toque **🔄 ATUALIZAR AGORA**. A TESTE ANA tem que mostrar **5 frases**.

## 4. Testes de "sem internet"

1. No 1º celular, ligue o **modo avião**. Leia 2 frases com a TESTE BIA.
   - A bolinha fica **🟡 SEM INTERNET: 1 CRIANÇA ESPERANDO…**
2. Toque em ✏️ **ARRUMAR** → 🗑️ na TESTE BIA → **🗑️ TIRAR**.
   - Tem que aparecer **⚠️ AINDA NÃO DÁ PARA GARANTIR**. Toque **✕ CANCELAR**. A BIA continua.
3. Desligue o modo avião. Espere 🟢. Agora tire a TESTE BIA: ela sai.
4. **☁️ BUSCAR NA NUVEM** → toque na 🐰 TESTE BIA → ela volta com tudo.
5. **O caminho mais arriscado (importante):** de novo em **modo avião**, leia 2 frases com a TESTE BIA → ✏️ ARRUMAR → 🗑️ → **🗑️ TIRAR** → aparece "AINDA NÃO DÁ PARA GARANTIR" → **segure 3 segundos** "GUARDAR UMA CÓPIA NESTE CELULAR E TIRAR". A BIA sai.
6. Desligue o modo avião. Na tela "Quem vai estudar hoje?" toque **🔄 ATUALIZAR AGORA** e depois na **🐰 TESTE BIA ☁️**: ela tem que voltar **com as 2 frases lidas sem internet** (a cópia da lixeira é juntada sozinha).

## 5. Mudar nome ou bichinho

1. ✏️ **ARRUMAR** → ✏️ na TESTE ANA → troque o bichinho para 🦋 → **PRONTO! ✅**.
2. No 2º celular, toque **🔄 ATUALIZAR AGORA** e depois abra o app de novo:
   - tem que aparecer o aviso **"🐼 TESTE ANA MUDOU PARA 🦋 TESTE ANA EM OUTRO APP. MUDAR AQUI TAMBÉM?"** → **MUDAR**.
3. Em **☁️ BUSCAR NA NUVEM**, não pode aparecer a TESTE ANA duas vezes.

## 6. Trava do adulto e famílias

1. ⚙️ → **☁️ FAMÍLIA E NUVEM** (a última seção) → **👁 MOSTRAR**: um toque só não mostra; **segurando 3 segundos** mostra `teste-pedro-2026`.
2. **🕘 CÓPIAS DE CADA DIA**: também precisa segurar 3 segundos.
3. Nas 2 primeiras semanas, **tirar a ÚLTIMA criança** não é permitido (de propósito: protege a volta para a versão anterior).

## 7. O que olhar com atenção (só o celular de verdade mostra)

- O **teclado** nunca cobre o campo do nome nem o do código, deitado e em pé.
- Os **8 bichinhos** ficam numa linha só, com o teclado aberto.
- A letra das telas novas dá para ler **na TV, a 3 metros**.
- O **botão voltar** do Android fecha primeiro o pop-up, depois a tela.
- O **chip com o bichinho** aparece ao lado da ⚙️ em Ler, Monta a Frase, Sílaba Perdida e Treinar Sílabas.
- A tela continua acesa e em tela cheia.

## 8. Quando terminar

Me diga **o que funcionou e o que estranhou** (prints ajudam). Só depois da sua aprovação eu entrego o zip do site de verdade, com a lista "conferir antes e depois de publicar".

Se quiser apagar os dados do teste: no celular, ⚙️ do navegador → Configurações do site `escolasaopedroalfabetizacao-teste.netlify.app` → Limpar dados. Isso **não** mexe no app de verdade. (A família `teste-pedro-2026` fica na nuvem, numa pasta própria, sem misturar com a de verdade.)
