/* Roda todos os teste_*.js desta pasta, um por vez (cada um sobe seu
   próprio JSDOM do zero — mais lento, mas isolado: um teste bagunçado
   não contamina o próximo), e mostra o resumo geral no final.
   Uso:  node rodar_testes.js */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const pasta = __dirname;
const arquivos = fs.readdirSync(pasta)
  .filter(f => /^teste_.*\.js$/.test(f))
  .sort();

if(arquivos.length === 0){
  console.log('Nenhum arquivo teste_*.js encontrado em ' + pasta);
  process.exit(1);
}

let totalOk = 0, totalFalha = 0, arquivosComFalha = [];

arquivos.forEach(f => {
  console.log('\n=== ' + f + ' ===');
  try{
    const saida = execFileSync('node', [path.join(pasta, f)], { encoding: 'utf-8' });
    process.stdout.write(saida);
    const m = saida.match(/(\d+)\/(\d+) passou/);
    if(m){ totalOk += parseInt(m[1], 10); totalFalha += (parseInt(m[2], 10) - parseInt(m[1], 10)); }
  }catch(e){
    // execFileSync joga erro quando o processo filho sai com código != 0
    // (ou seja, quando pelo menos um teste daquele arquivo falhou)
    if(e.stdout) process.stdout.write(e.stdout);
    if(e.stderr) process.stderr.write(e.stderr);
    arquivosComFalha.push(f);
    const m = (e.stdout || '').match(/(\d+)\/(\d+) passou/);
    if(m){ totalOk += parseInt(m[1], 10); totalFalha += (parseInt(m[2], 10) - parseInt(m[1], 10)); }
  }
});

console.log('\n' + '='.repeat(50));
console.log('RESULTADO GERAL: ' + totalOk + '/' + (totalOk + totalFalha) + ' testes passaram');
if(arquivosComFalha.length){
  console.log('Arquivos com pelo menos 1 falha: ' + arquivosComFalha.join(', '));
  process.exitCode = 1;
} else {
  console.log('Tudo passou. ✅');
  process.exitCode = 0;
}
