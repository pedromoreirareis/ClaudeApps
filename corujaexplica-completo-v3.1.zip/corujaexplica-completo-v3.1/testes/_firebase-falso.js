/* Firebase DE MENTIRA para os testes (nada sai para a internet).
   Imita o que o nuvem-sync.js usa:
   - identitytoolkit (login anônimo) e securetoken (renovar o login);
   - Firestore REST: GET documento, GET coleção (lista), PATCH com
     updateMask e com as travas currentDocument.exists / currentDocument.updateTime.
   Um mesmo "banco" (store) pode ser ligado a vários contextos do navegador,
   para simular dois celulares da mesma família. */
function criarBanco(){
  return {
    docs: {},            /* caminho → { fields, updateTime, createTime } */
    relogio: 0,
    pedidos: [],         /* histórico de chamadas: {metodo, caminho, qs} */
    modo: '',            /* '' | 'permissao' (regras bloqueando tudo) | 'semVersoes' */
    antesDoPatch: null   /* gancho: (caminho, banco) → roda antes de gravar (simula outro celular no meio) */
  };
}
function novoTempo(b){
  b.relogio++;
  const d = new Date(Date.UTC(2026, 8, 24, 12, 0, 0) + b.relogio * 1000);
  return d.toISOString().replace('Z', '123Z');   /* formato do Firestore: microssegundos */
}
function erro(route, code, status, message){
  return route.fulfill({ status: code, contentType: 'application/json',
    headers: { 'access-control-allow-origin': '*' },
    body: JSON.stringify({ error: { code, status, message: message || status } }) });
}
function ok(route, obj){
  return route.fulfill({ status: 200, contentType: 'application/json',
    headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(obj) });
}
function nomeCompleto(caminho){ return 'projects/escola-sao-pedro-5ee62/databases/(default)/documents/' + caminho; }
function docResposta(caminho, d){ return { name: nomeCompleto(caminho), fields: d.fields, createTime: d.createTime, updateTime: d.updateTime }; }

async function ligar(ctx, b){
  await ctx.route(/^https:\/\/(identitytoolkit|securetoken|firestore)\.googleapis\.com\//, async route => {
    const req = route.request();
    const url = new URL(req.url());
    const metodo = req.method();
    if (metodo === 'OPTIONS'){
      return route.fulfill({ status: 204, headers: {
        'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,POST,PATCH,OPTIONS',
        'access-control-allow-headers': 'authorization,content-type' } });
    }
    if (url.hostname === 'identitytoolkit.googleapis.com'){
      b.pedidos.push({ metodo, caminho: 'login' });
      return ok(route, { idToken: 'tk-' + Math.random().toString(36).slice(2), refreshToken: 'rf', expiresIn: '3600' });
    }
    if (url.hostname === 'securetoken.googleapis.com'){
      b.pedidos.push({ metodo, caminho: 'renovar' });
      return ok(route, { id_token: 'tk2', refresh_token: 'rf', expires_in: '3600' });
    }
    const marca = '/documents/';
    const i = url.pathname.indexOf(marca);
    const caminho = decodeURIComponent(url.pathname.slice(i + marca.length));
    const seg = caminho.split('/');
    b.pedidos.push({ metodo, caminho, qs: url.search });
    if (b.modo === 'permissao') return erro(route, 403, 'PERMISSION_DENIED', 'Missing or insufficient permissions.');
    if (b.modo === 'semVersoes' && /\/versoes(\/|$)/.test(caminho)) return erro(route, 403, 'PERMISSION_DENIED', 'Missing or insufficient permissions.');

    if (metodo === 'GET'){
      if (seg.length % 2 === 1){   /* coleção */
        const pre = caminho + '/';
        const lista = Object.keys(b.docs).filter(k => k.startsWith(pre) && k.slice(pre.length).indexOf('/') < 0)
          .map(k => docResposta(k, b.docs[k]));
        return ok(route, lista.length ? { documents: lista } : {});
      }
      const d = b.docs[caminho];
      if (!d) return erro(route, 404, 'NOT_FOUND', 'Document not found');
      return ok(route, docResposta(caminho, d));
    }
    if (metodo === 'PATCH'){
      if (b.antesDoPatch){ const g = b.antesDoPatch; await g(caminho, b); }
      const qs = url.searchParams;
      const atual = b.docs[caminho];
      if (qs.get('currentDocument.exists') === 'false' && atual)
        return erro(route, 400, 'FAILED_PRECONDITION', 'Document already exists');
      const ut = qs.get('currentDocument.updateTime');
      if (ut && (!atual || atual.updateTime !== ut))
        return erro(route, 400, 'FAILED_PRECONDITION', 'The document was modified');
      const corpo = JSON.parse(req.postData() || '{}');
      const mascara = qs.getAll('updateMask.fieldPaths');
      const agora = novoTempo(b);
      let fields;
      if (mascara.length){
        fields = JSON.parse(JSON.stringify((atual && atual.fields) || {}));
        mascara.forEach(mp => {
          const partes = mp.split('.');
          if (partes.length === 1){ if (corpo.fields && corpo.fields[mp]) fields[mp] = corpo.fields[mp]; }
          else {
            const [a, c] = partes;
            const novo = corpo.fields && corpo.fields[a] && corpo.fields[a].mapValue.fields[c];
            fields[a] = fields[a] || { mapValue: { fields: {} } };
            fields[a].mapValue.fields = fields[a].mapValue.fields || {};
            if (novo) fields[a].mapValue.fields[c] = novo;
          }
        });
      } else fields = corpo.fields || {};
      b.docs[caminho] = { fields, updateTime: agora, createTime: (atual && atual.createTime) || agora };
      return ok(route, docResposta(caminho, b.docs[caminho]));
    }
    return erro(route, 400, 'INVALID_ARGUMENT', 'método não previsto no teste');
  });
}
/* leitura direta do banco (para as conferências) */
function lerApp(b, familia, chave, app){
  const d = b.docs['familias/' + familia + '/usuarios/' + chave + '/apps/' + (app || 'corujaexplica')];
  if (!d) return null;
  const dados = JSON.parse(d.fields.dados.stringValue);
  return { dados, textos: JSON.parse(dados.textos || '[]'), excluidos: JSON.parse(dados.excluidos || '{}'),
           config: dados.config ? JSON.parse(dados.config) : null, dispositivo: d.fields.dispositivo.stringValue, updateTime: d.updateTime };
}
function gravarApp(b, familia, chave, nome, av, textos, extra){
  const dados = Object.assign({ textos: JSON.stringify(textos), excluidos: JSON.stringify({}) }, extra || {});
  const t = novoTempo(b);
  const base = 'familias/' + familia + '/usuarios/' + chave;
  b.docs[base + '/apps/corujaexplica'] = { updateTime: t, createTime: t, fields: {
    nome: { stringValue: nome }, av: { stringValue: av }, app: { stringValue: 'corujaexplica' },
    dados: { stringValue: JSON.stringify(dados) }, atualizadoEm: { integerValue: String(Date.now()) },
    dispositivo: { stringValue: 'outroCelular' }, versao: { stringValue: '3' } } };
  const u = b.docs[base] || { fields: {} };
  b.docs[base] = { updateTime: t, createTime: t, fields: Object.assign({}, u.fields, {
    nome: { stringValue: nome }, av: { stringValue: av },
    apps: { mapValue: { fields: { corujaexplica: { integerValue: String(Date.now()) } } } } }) };
}
module.exports = { criarBanco, ligar, lerApp, gravarApp, novoTempo };
