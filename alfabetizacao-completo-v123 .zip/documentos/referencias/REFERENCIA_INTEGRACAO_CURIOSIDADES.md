# REFERÊNCIA — integração no CURIOSIDADES v1.7
### Cadastro Nome + Bichinho · Nuvem (Firebase) com histórico · Tela sempre acesa · Tela cheia · Convite para instalar

> Modelo **para a IA (Claude ou ChatGPT)** repetir o mesmo padrão nos outros apps da Escola São Pedro.
> Nenhum app usa este arquivo. O Pedro não precisa ler.
> A **regra oficial** do cadastro está no `PADRAO_CADASTRO_NOME_BICHINHO.md`. Este arquivo mostra **como** ela foi implementada no Curiosidades.
> ⚠️ Os outros apps **não são iguais por dentro**: use isto como modelo e **adapte**, não copie às cegas.

## 0) Arquitetura em uma olhada

Três arquivos compartilhados, **idênticos em todos os 7 apps** (não reescrever):

| Arquivo | Papel | API usada pelo app |
|---|---|---|
| `nuvem-config.js` | configuração do Firebase (Pedro preenche uma vez) → `window.NUVEM_CONFIG` | — |
| `nuvem-sync.js` (**v3**) | local-first via REST (login anônimo + Firestore); fila offline (envio ~1,5 s após mudar, ao minimizar, a cada 60 s e ao voltar a internet); **envio seguro**: GET → junta se veio de outro dispositivo → PATCH com `currentDocument.updateTime`/`exists` → repete até 3× em conflito; **histórico de versões** (`versoes/AAAA-MM-DD`); `navigator.storage.persist()` | `NuvemSync.iniciar({app, usuarios, idDaChave, exportar, mesclar})`, `status()`, `aoMudar(fn)`, `sincronizar()`, `definirFamilia(c)`, `listarUsuarios()`, `recuperar(id,nome,av,restaurando)`, `listarVersoes(nome,av)`, `juntarVersao(id,nome,av,dia)`, `chaveUsuario(nome,av)`, `configurada()`, `pronta()`, `marcarPendente(id)` |
| `escola-pwa.js` (**v2**) | **lista oficial dos 8 bichinhos** (`EscolaPWA.BICHINHOS`); Wake Lock + modo reserva (vídeo mudo) + vigia 15 s; tela cheia a cada toque (fase de borbulha, ignora campos e o convite); convite para instalar | `EscolaPWA.BICHINHOS`, `EscolaPWA.iniciar({nome, icone, chaveTelaAcesa, aoEntrarTelaCheia})`, `estado()`, `aoMudar(fn)`, `telaAcesa.pedir()/alternar()/estado()`, `mostrarConvite()` |

O que **cada app** escreve (a "cola"):
- cadastro padrão (seção 1): lista de bichinhos a partir de `EscolaPWA.BICHINHOS`, tela, regras, acesso, troca de nome/bichinho;
- `usuarios()` → `[{id, nome, av}]`;
- `idDaChave(chaveLocalStorage)` → id do leitor dono daquela chave, ou `null`;
- `exportar(id)` → objeto {chave: valorString} com **todo** progresso/aprendizagem do leitor;
- `mesclar(id, dadosDaNuvem, restaurando)` → junta sem nunca perder progresso (feito = OU; listas = união; contadores/recordes/níveis/erros por item = máximo; onde parou e preferências = celular, exceto restaurando ou leitor vazio) e atualiza a tela se for o leitor atual;
- telas e botões (seções 3 e 4), incluindo **🕘 Versões guardadas**.

No Curiosidades os dados ficam assim no `localStorage`:
- `mundo_usuarios` = `{us:[{id,nome,av}], atual}`
- `mundo_<id>_<dado>` (ex.: `mundo_p1712345_lidas`)
Em outro app, **descubra o esquema real** e adapte.

Caminhos na nuvem:
- perfil: `familias/{codigo}/usuarios/{nome-normalizado}_{hex do emoji}` (`nome`, `av`, `apps.{ID}`)
- progresso: `.../apps/{ID}`
- histórico: `.../apps/{ID}/versoes/AAAA-MM-DD`

Regras do Firestore (o Pedro cola no console):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /familias/{familia}/usuarios/{usuario} {
      allow read, create, update: if request.auth != null;
      match /apps/{app} {
        allow read, create, update: if request.auth != null;
        match /versoes/{versao} {
          allow read, create, update: if request.auth != null;
        }
      }
    }
  }
}
```

**Limite honesto (dizer ao Pedro):** limpar **dados de sites** do Chrome apaga o localStorage. O que já subiu volta pela recuperação, mas alteração feita **sem internet** e ainda não enviada não tem como sobreviver. Mitigação: envio em ~1,5 s, envio ao minimizar, `storage.persist()`, pontinho laranja + aviso, Exportar backup.

## 1) Cadastro padrão Nome + Bichinho (v1.7)

Meta viewport (o teclado encolhe a página, e a tela se reorganiza acima dele):
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover, interactive-widget=resizes-content">
```
A tela de cadastro **saiu da rotação forçada** para paisagem (`#home,#reader,#users` continuam na regra `@media (max-aspect-ratio:1/1)`; `#novoUser` não).

CSS:
```css
/* =================== TELA: CADASTRO DE USUARIO (padrão Escola São Pedro) ===================
   Os 8 bichinhos oficiais ficam SEMPRE numa linha só. A ordem é:
   título → nome → bichinhos → botões, e tudo cabe na parte da tela que
   sobra quando o teclado do celular abre (em pé ou deitado). */
#novoUser{position:fixed;inset:0;display:flex;flex-direction:column;background:var(--bg);
  background-attachment:fixed;z-index:41;overflow:auto;-webkit-overflow-scrolling:touch}
#nuConteudo{display:flex;flex-direction:column;align-items:center;gap:clamp(4px,1.6vh,11px);
  text-align:center;margin:auto;padding:clamp(6px,2vh,16px) 8px clamp(8px,3vh,20px);width:100%}
.nuTitulo{font-size:clamp(16px,min(5.4vw,4.2vh),28px);font-weight:900;color:var(--ink);line-height:1.15}
#nuNome{font-family:var(--pfont);font-size:clamp(16px,min(5.4vw,4.2vh),26px);font-weight:900;text-align:center;
  padding:clamp(5px,1.6vh,12px) 14px;border-radius:16px;border:4px solid var(--accent);background:#fff;
  color:var(--ink);outline:none;width:min(360px,90vw);
  -webkit-user-select:text;user-select:text}
#nuNome:focus{border-color:var(--navnext)}
.nuSub{font-size:clamp(11.5px,min(3.6vw,2.6vh),16px);font-weight:800;color:var(--muted)}
/* UMA LINHA SÓ: nunca quebra, o tamanho se ajusta à largura e à altura livres */
#nuEmojis{display:flex;flex-wrap:nowrap;justify-content:center;align-items:center;
  gap:clamp(3px,1.2vw,9px);max-width:98vw}
.nuEmoji{--t:clamp(30px,min(10.4vw,15vh),62px);width:var(--t);height:var(--t);
  font-size:calc(var(--t)*.58);line-height:1;background:#fff;border:3px solid transparent;border-radius:14px;
  display:flex;align-items:center;justify-content:center;box-shadow:0 3px 8px #00000018;
  transition:transform .1s;cursor:pointer;flex:0 0 auto;padding:0}
.nuEmoji:active{transform:scale(.9)}
.nuEmoji.on{border-color:var(--navnext);background:#eaffef;transform:scale(1.08);box-shadow:0 0 0 3px #f0a03055}
.nuEscolhido{font-size:clamp(11px,min(3.4vw,2.4vh),15px);font-weight:900;color:var(--ink);min-height:1.2em}
.nuBotoes{display:flex;gap:9px;align-items:center;margin-top:clamp(0px,.8vh,8px);
  flex-wrap:wrap;justify-content:center}
.nuVoltar,.nuPronto{border:0;border-radius:20px;font-weight:900;cursor:pointer;
  font-size:clamp(13px,min(4vw,2.8vh),19px);padding:clamp(6px,1.8vh,13px) clamp(14px,4vw,28px);
  box-shadow:0 5px 13px #00000030;transition:transform .1s ease}
.nuVoltar{background:#ffffffe6;color:var(--ink)}
.nuPronto{background:var(--navnext);color:#fff;padding:clamp(6px,1.8vh,13px) clamp(22px,5vw,34px)}
.nuVoltar:active,.nuPronto:active{transform:translateY(3px)}
/* teclado aberto / tela baixinha: some o que é enfeite, ficam nome + bichinhos + botões */
@media (max-height:300px){
  .nuTitulo,.nuEscolhido{display:none}
  #nuConteudo{gap:4px;padding:4px 6px}
  .nuBotoes{gap:6px}
  .nuEmoji{--t:clamp(30px,min(10.4vw,22vh),62px)}
}
```

HTML do cadastro:
```html
<!-- ============ TELA: CADASTRO DE USUÁRIO ============ -->
<div id="novoUser" class="hidden">
  <div id="nuConteudo">
    <div class="nuTitulo" id="nuTitulo">🌟 Qual é o seu nome?</div>
    <input id="nuNome" type="text" maxlength="14" placeholder="Digite o seu nome..."
           autocomplete="off" autocorrect="off" spellcheck="false" enterkeyhint="done">
    <div class="nuSub">Escolha o seu bichinho:</div>
    <div id="nuEmojis" role="radiogroup" aria-label="Bichinhos"></div>
    <div class="nuEscolhido" id="nuEscolhido"></div>
    <div class="nuBotoes">
      <button class="nuVoltar" id="nuVoltar" onclick="abrirUsers()">← Voltar</button>
      <button class="nuPronto" onclick="confirmarUser()">Pronto! ✅</button>
      <button class="nuVoltar nuNuvem nuvemAcao" id="nuNuvem" onclick="abrirNuvemTela()">☁️ Já tenho cadastro</button>
    </div>
  </div>
</div>
```

HTML de "Quem vai estudar hoje?":
```html
<div id="users" class="hidden">
  <div id="usersTop">
    <span class="ow">🦉</span>
    <h1>Quem vai estudar hoje?</h1>
    <span class="sp"></span>
    <button class="cfgBtn" onclick="toggleFs()" title="Tela cheia">⛶</button>
  </div>
  <div id="usersBody">
    <div class="usersAviso">Cada criança tem o próprio progresso. Toque no seu nome e no seu
      bichinho para começar.</div>
    <div id="usersGrid"></div>
    <div id="usersAcoes">
      <button class="userAcao" onclick="editarUser()">✏️ Trocar nome ou bichinho</button>
      <button class="userAcao apagar" onclick="apagarUser()">🗑️ Apagar este usuário</button>
      <button class="userAcao nuvemAcao" onclick="abrirNuvemTela()">☁️ Recuperar da nuvem</button>
    </div>
  </div>
</div>
```

JavaScript do cadastro:
```js
/* ===== CADASTRO PADRÃO ESCOLA SÃO PEDRO: NOME + BICHINHO =====
   Os 8 bichinhos oficiais (iguais em todos os apps). A lista "de verdade"
   mora no escola-pwa.js; esta cópia só é usada se aquele arquivo faltar. */
const BICHINHOS_OFICIAIS=[
  {e:'🦉',nome:'Coruja'},{e:'🦊',nome:'Raposa'},{e:'🐰',nome:'Coelho'},{e:'🐼',nome:'Panda'},
  {e:'🦋',nome:'Borboleta'},{e:'🐨',nome:'Coala'},{e:'🐯',nome:'Tigre'},{e:'🐴',nome:'Pônei'}];
const BICHINHOS=(window.EscolaPWA && EscolaPWA.BICHINHOS && EscolaPWA.BICHINHOS.length===8) ? EscolaPWA.BICHINHOS : BICHINHOS_OFICIAIS;
const EMOJIS_USER=BICHINHOS.map(b=>b.e);
function nomeDoBichinho(e){ const b=BICHINHOS.find(x=>x.e===e); return b?b.nome:''; }
/* mesma regra da nuvem: "Renata" + 🦋 → renata_1f98b (sem acento, sem maiúscula) */
function chaveLeitor(nome, av){
  if(window.NuvemSync) return NuvemSync.chaveUsuario(nome, av);
  const n=(nome||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')||'leitor';
  const e=Array.from(av||'').map(c=>c.codePointAt(0).toString(16)).filter(h=>h!=='fe0f'&&h!=='200d').join('-')||'x';
  return n+'_'+e;
}
let nuEmoji=null, nuEditandoId=null;

function abrirNovoUser(){
  if(U.us.length>=MAX_USERS){ showToast('Já são '+MAX_USERS+' crianças — o máximo.'); return; }
  nuEditandoId=null;
  nuEmoji=null;                                   /* a criança escolhe de propósito */
  document.getElementById('nuTitulo').textContent='🌟 Qual é o seu nome?';
  document.getElementById('nuNome').value='';
  document.getElementById('nuVoltar').style.display=U.us.length?'inline-flex':'none';
  montarEmojisUser();
  mostrarTela('novoUser');
  focarNome();
}
function editarUser(){
  const u=userAtual(); if(!u.id) return;
  nuEditandoId=u.id;
  nuEmoji=EMOJIS_USER.includes(u.av)?u.av:null;  /* bichinho antigo fora da lista: escolher um dos 8 */
  document.getElementById('nuTitulo').textContent='✏️ Trocar nome ou bichinho';
  document.getElementById('nuNome').value=u.nome;
  document.getElementById('nuVoltar').style.display='inline-flex';
  montarEmojisUser();
  if(!nuEmoji) document.getElementById('nuEscolhido').textContent='O bichinho '+u.av+' mudou: escolha um dos 8 novos 🙂';
  mostrarTela('novoUser');
  focarNome();
}
/* deixa o nome e os bichinhos à vista quando o teclado do celular abre */
function focarNome(){
  const i=document.getElementById('nuNome'); if(!i) return;
  setTimeout(()=>{ try{ i.focus(); }catch(e){} },200);
  const mostrar=()=>{ try{ document.getElementById('nuEmojis').scrollIntoView({block:'nearest'}); i.scrollIntoView({block:'nearest'}); }catch(e){} };
  i.onfocus=()=>{ setTimeout(mostrar,350); };
  i.onkeydown=(ev)=>{
    if(ev.key!=='Enter') return;
    ev.preventDefault();
    if(nuEmoji) confirmarUser();
    else{ try{ i.blur(); }catch(e){} showToast('Agora escolha o seu bichinho 🙂'); }
  };
  if(window.visualViewport && !focarNome._vv){
    focarNome._vv=true;
    visualViewport.addEventListener('resize',()=>{
      if(document.activeElement===i && !document.getElementById('novoUser').classList.contains('hidden')) mostrar();
    });
  }
}
function montarEmojisUser(){
  const c=document.getElementById('nuEmojis'); c.innerHTML='';
  BICHINHOS.forEach(b=>{
    const bt=document.createElement('button');
    bt.className='nuEmoji'+(b.e===nuEmoji?' on':'');
    bt.textContent=b.e;
    bt.title=b.nome; bt.setAttribute('aria-label',b.nome);
    bt.setAttribute('role','radio'); bt.setAttribute('aria-checked', b.e===nuEmoji?'true':'false');
    bt.onclick=()=>{ nuEmoji=b.e; montarEmojisUser(); };
    c.appendChild(bt);
  });
  const esc=document.getElementById('nuEscolhido');
  if(esc) esc.textContent = nuEmoji ? ('Você escolheu: '+nuEmoji+' '+nomeDoBichinho(nuEmoji)) : '';
}
function confirmarUser(){
  const campo=document.getElementById('nuNome');
  const nome=(campo.value||'').trim().replace(/\s+/g,' ').slice(0,14);
  if(!nome){ showToast('Escreva o seu nome primeiro 🙂'); try{ campo.focus(); }catch(e){} return; }
  if(!nuEmoji || !EMOJIS_USER.includes(nuEmoji)){ try{ campo.blur(); }catch(e){} showToast('Escolha o seu bichinho 🙂'); return; }
  const chave=chaveLeitor(nome,nuEmoji);
  const igual=U.us.find(x=>chaveLeitor(x.nome,x.av)===chave);
  if(nuEditandoId){
    if(igual && igual.id!==nuEditandoId){ showToast(nuEmoji+' '+nome+' já existe neste celular. Escolha outro nome ou bichinho.'); return; }
    const u=U.us.find(x=>x.id===nuEditandoId);
    const antes={nome:u.nome, av:u.av};
    u.nome=nome; u.av=nuEmoji;
    salvarUsers(); nuEditandoId=null;
    atualizaChipUser(); abrirUsers();
    showToast(u.av+' Agora é '+u.nome+' ('+nomeDoBichinho(u.av)+')');
    /* mudou o nome ou o bichinho: a ficha nova na nuvem recebe tudo da antiga */
    if(chaveLeitor(antes.nome,antes.av)!==chave) nuvemLevarFichaAntiga(u.id, antes.nome, antes.av);
    return;
  }
  if(igual){
    /* já existe no celular: não cria repetido, só abre o dela */
    showToast(igual.av+' '+igual.nome+' já está neste celular — abrindo!');
    trocarUser(igual.id);
    return;
  }
  if(U.us.length) saveState();          /* guarda quem estava estudando */
  const id='p'+Date.now();
  U.us.push({id:id,nome:nome,av:nuEmoji});
  U.atual=id; salvarUsers();
  carregarDados();                       /* começa do zero, sem herdar nada */
  saveState();
  applyTheme(); applyFont(); updateCsBtn(); updateFsizeBtn();
  aplicaAjustes(); applyAudioUI(); atualizaMute();
  irParaEstante();
  showToast(nuEmoji+' Bem-vindo, '+nome+'!');
  nuvemTentarRecuperarNovo(id, nome, nuEmoji);
}
```
(`apagarUser`, `trocarUser`, `abrirUsers` já existiam no app e continuam iguais.)

## 2) `<head>` — scripts compartilhados (logo depois do `<link rel="apple-touch-icon" ...>`)
```html
<script>window.__nuvemCfgArq='carregando';</script>
<script src="nuvem-config.js" onload="window.__nuvemCfgArq='ok'" onerror="window.__nuvemCfgArq='falta'"></script>
<script src="nuvem-sync.js"></script>
<script src="escola-pwa.js"></script>
```

## 3) CSS da nuvem
```css
/* ===== NUVEM ===== */
#cfgGearHome{position:relative}
#nuvemPonto{position:absolute;right:1px;top:1px;width:13px;height:13px;border-radius:50%;
  border:2px solid #fff;display:none;box-shadow:0 1px 3px #0005}
#nuvemPonto.on{display:block}
#nuvemPonto.ok{background:#2fb35a} #nuvemPonto.espera{background:#f0a030} #nuvemPonto.erro{background:#e23b3b}
#nuvemTela{position:fixed;inset:0;display:flex;flex-direction:column;background:var(--bg);
  background-attachment:fixed;z-index:45}
#nuvemMsg{font-size:clamp(12px,2.1vh,15px);font-weight:800;color:var(--ink);text-align:center;
  line-height:1.45;margin:0 auto 12px;max-width:60ch;font-family:system-ui,'Segoe UI',Roboto,Arial,sans-serif}
.nuvemAcoes{display:flex;gap:9px;justify-content:center;margin-top:16px;flex-wrap:wrap}
#nuvemGrid{display:grid;gap:12px;grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}
.nuNuvem{font-size:clamp(12px,2.2vh,16px)!important}
```

## 4) HTML da nuvem
Botão ⚙️ da tela inicial (pontinho de status):
```html
<button class="cfgBtn" id="cfgGearHome" onclick="openCfg()" title="Configurações">⚙️<span id="nuvemPonto"></span></button>
```
Tela de recuperação (e versões):
```html
<div id="nuvemTela" class="hidden">
  <div id="nuvemTop" class="palavrasTopLike">
    <button onclick="fecharNuvemTela()" title="Voltar">🏠</button>
    <span class="ow">☁️</span>
    <h1>Recuperar cadastro</h1>
    <span class="sp"></span>
  </div>
  <div id="nuvemBody" class="palavrasBodyLike">
    <div id="nuvemMsg"></div>
    <div id="nuvemGrid"></div>
    <div class="nuvemAcoes">
      <button class="userAcao" onclick="pedirCodigoFamilia(true)">🔑 Código da família</button>
      <button class="userAcao" onclick="montarNuvemTela()">🔄 Procurar de novo</button>
      <button class="userAcao" id="nuvemVersoesBt" onclick="montarVersoesTela()">🕘 Versões guardadas</button>
    </div>
  </div>
</div>
```
Painel de Configurações (antes da seção Backup):
```html
      <div class="cfgSep">📺 Tela</div>

      <div class="cfgRow">
        <div class="lbl">Tela sempre acesa<small id="cfgTelaSt">A tela não apaga nem bloqueia enquanto o app estiver aberto (bom para espelhar na TV)</small></div>
        <div class="sw" id="cfgTela" onclick="alternaTelaAcesa()"><b></b></div>
      </div>
      <div class="cfgRow" id="cfgInstRow">
        <div class="lbl">Instalar o app<small id="cfgInstSt">Coloca o app na tela do celular (tela cheia e sem internet)</small></div>
        <button class="cfgBt" onclick="closeCfg();instalarApp()">📲 Instalar</button>
      </div>

      <div class="cfgSep">☁️ Nuvem (guarda o progresso na internet)</div>

      <div class="cfgRow">
        <div class="lbl">Situação<small id="cfgNuvemSt">—</small></div>
        <button class="cfgBt" id="cfgNuvemBt" onclick="nuvemSincronizarAgora()">🔄 Enviar agora</button>
      </div>
      <div class="cfgRow">
        <div class="lbl">Código da família<small id="cfgNuvemFam">—</small></div>
        <button class="cfgBt" onclick="pedirCodigoFamilia(false)">🔑 Digitar</button>
      </div>
      <div class="cfgRow">
        <div class="lbl">Recuperar leitores<small>Traz de volta o progresso guardado na nuvem (pelo nome + bichinho)</small></div>
        <button class="cfgBt" onclick="closeCfg();abrirNuvemTela()">☁️ Recuperar</button>
      </div>
```

## 5) Outras ligações
- `mostrarTela(...)` conhece `'nuvemTela'`.
- `syncCfgUI()` chama `atualizaTelaAcesaUI(); atualizaNuvemUI();`
- `confirmarUser()` chama `nuvemTentarRecuperarNovo(...)` (cadastro novo) e `nuvemLevarFichaAntiga(...)` (troca de nome/bichinho).
- O antigo `pointerdown` que tentava tela cheia **só no 1º toque** foi retirado.
- Na inicialização:
```js
if(window.EscolaPWA){
  EscolaPWA.iniciar({ nome:'Curiosidades', icone:'icon-192.png', chaveTelaAcesa:'mundo_telaAcesa',
                      aoEntrarTelaCheia: lockLandscape });
  EscolaPWA.aoMudar(()=>{ try{ atualizaTelaAcesaUI(); }catch(e){} });
}
try{ atualizaNuvemUI(); atualizaTelaAcesaUI(); }catch(e){}
```

## 6) JavaScript da tela acesa, do convite e da nuvem (antes do bloco de inicialização)
```js
/* ===================================================================
   📺 TELA SEMPRE ACESA · ⛶ TELA CHEIA · 📲 CONVITE PARA INSTALAR
   Tudo isso mora no escola-pwa.js (igual em todos os apps). Aqui só
   ligamos os botões das Configurações a ele.
   =================================================================== */
function pedirTelaAcesa(){ try{ if(window.EscolaPWA) EscolaPWA.telaAcesa.pedir(); }catch(e){} }
function alternaTelaAcesa(){
  if(!window.EscolaPWA){ showToast('⚠️ Falta o arquivo escola-pwa.js'); return; }
  const on=EscolaPWA.telaAcesa.alternar();
  showToast(on?'📺 Tela sempre acesa: LIGADO':'💤 A tela pode apagar sozinha');
  atualizaTelaAcesaUI();
}
function atualizaTelaAcesaUI(){
  const sw=document.getElementById('cfgTela'), st=document.getElementById('cfgTelaSt');
  const ir=document.getElementById('cfgInstRow'), is=document.getElementById('cfgInstSt');
  if(!window.EscolaPWA){
    if(sw) sw.classList.remove('on');
    if(st) st.textContent='⚠️ Falta o arquivo escola-pwa.js no site';
    if(ir) ir.style.display='none';
    return;
  }
  const e=EscolaPWA.estado(), t=e.telaAcesa;
  if(sw) sw.classList.toggle('on',t.ligada);
  if(st){
    if(!t.ligada) st.textContent='Desligado: a tela apaga sozinha no tempo normal do celular';
    else if(t.modo==='nativo') st.textContent='✅ Ligado: com o app aberto, a tela não apaga nem bloqueia (bom para a TV)';
    else if(t.modo==='reserva') st.textContent='✅ Ligado (modo reserva): com o app aberto, a tela não apaga nem bloqueia';
    else if(t.erro) st.textContent='⚠️ O celular recusou ('+t.erro+'). Desligue a "Economia de bateria" e toque na tela do app.';
    else st.textContent='Ligado: toque em qualquer lugar do app para ativar';
  }
  if(ir) ir.style.display = e.modoApp==='browser' ? '' : 'none';
  if(is) is.textContent = e.instalado ? 'Já está instalado — abra pelo ícone na tela do celular'
                                      : 'Coloca o app na tela do celular (tela cheia e sem internet)';
}
function instalarApp(){ if(window.EscolaPWA) EscolaPWA.mostrarConvite(); }

/* ===================================================================
   ☁️ NUVEM (Firebase) — ligação deste app com o nuvem-sync.js
   O celular continua sendo o dono dos dados. A nuvem é uma cópia de
   segurança que se atualiza sozinha quando há internet.
   =================================================================== */
const APP_NUVEM='curiosidades';
/* tudo que é de um leitor e vale guardar */
const CHAVES_NUVEM=CHAVES_DADOS.concat(['ultimoDia','seqDias']);
const CHAVES_OBJ_NUVEM=['favs','palavrasAprendidas','marcos'];
const CHAVES_SIMPLES_NUVEM=['theme','font','caps','fsize','cfgHi','cfgSyl','cfgAudio','voz','pais',
  'secAtual','ultPais','ultCur','ajustes','modoLinha','ultimoDia','seqDias'];

function nuvemIdDaChave(k){
  const m=/^mundo_(p\d+)_(.+)$/.exec(k||'');
  if(!m || CHAVES_NUVEM.indexOf(m[2])<0) return null;
  return U.us.some(u=>u.id===m[1]) ? m[1] : null;
}
function nuvemExportar(id){
  const o={};
  CHAVES_NUVEM.forEach(n=>{ try{ const v=localStorage.getItem('mundo_'+id+'_'+n); if(v!==null) o[n]=v; }catch(e){} });
  return o;
}
/* mistura o que veio da nuvem com o que já existe neste celular.
   Regra de ouro: NUNCA perder uma curiosidade lida. */
function nuvemMesclar(id, dn, restaurando){
  const P='mundo_'+id+'_';
  const get=n=>{ try{ return localStorage.getItem(P+n); }catch(e){ return null; } };
  const set=(n,v)=>{ try{ localStorage.setItem(P+n,v); }catch(e){} };
  const Jp=(t,d)=>{ try{ const v=JSON.parse(t); return (v===null||v===undefined||typeof v!=='object')?d:v; }catch(e){ return d; } };
  /* lidas: fica marcada se estiver marcada em QUALQUER um dos lados */
  const lL=Jp(get('lidas'),{}), lN=Jp(dn.lidas,{});
  /* leitor que ainda não leu nada neste celular (acabou de ser cadastrado
     ou os dados foram apagados) adota também as preferências da nuvem */
  if(!restaurando && !Object.keys(lL).some(c=>/1/.test(String(lL[c]||'')))) restaurando=true;
  for(const c in lN){
    const a=String(lL[c]||''), b=String(lN[c]||''); let r='';
    for(let i=0;i<Math.max(a.length,b.length);i++) r+=(a[i]==='1'||b[i]==='1')?'1':'0';
    lL[c]=r;
  }
  set('lidas',JSON.stringify(lL));
  /* favoritas, palavras aprendidas, festejos já vistos: junta os dois */
  CHAVES_OBJ_NUVEM.forEach(n=>{
    if(dn[n]===undefined) return;
    set(n, JSON.stringify(Object.assign({}, Jp(dn[n],{}), Jp(get(n),{}))));
  });
  /* onde parou em cada assunto */
  if(dn.posPais!==undefined){
    const a=Jp(get('posPais'),{}), b=Jp(dn.posPais,{});
    set('posPais', JSON.stringify(restaurando ? Object.assign({},a,b) : Object.assign({},b,a)));
  }
  /* últimas lidas: junta, sem repetir, só as que continuam marcadas */
  if(dn.ultimasLidas!==undefined){
    const a=Jp(get('ultimasLidas'),[]), b=Jp(dn.ultimasLidas,[]);
    const lista=(restaurando? b.concat(a) : a.concat(b)), vistos={}, fim=[];
    lista.forEach(x=>{ if(!x||!x.code) return; const k=x.code+':'+x.idx;
      if(vistos[k]) return; vistos[k]=1;
      if((lL[x.code]||'')[x.idx]==='1') fim.push({code:x.code,idx:x.idx}); });
    set('ultimasLidas', JSON.stringify(fim.slice(0,10)));
  }
  /* cores, letra, onde parou: numa recuperação vêm da nuvem;
     no dia a dia, o que está neste celular manda */
  CHAVES_SIMPLES_NUVEM.forEach(n=>{
    if(dn[n]===undefined || dn[n]===null) return;
    if(restaurando || get(n)===null) set(n, dn[n]);
  });
  /* se for quem está lendo agora, atualiza a tela */
  if(id===U.atual){
    try{
      if(restaurando){
        carregarDados();
        applyTheme(); applyFont(); updateCsBtn(); updateFsizeBtn();
        aplicaAjustes(); applyAudioUI(); atualizaMute();
      } else {
        resincronizarDoDisco();
      }
      if(!document.getElementById('home').classList.contains('hidden')) buildHome();
    }catch(e){}
  }
}

function nuvemAtiva(){ return !!(window.NuvemSync && NuvemSync.configurada()); }

function atualizaNuvemUI(){
  const ponto=document.getElementById('nuvemPonto');
  const stEl=document.getElementById('cfgNuvemSt'), famEl=document.getElementById('cfgNuvemFam');
  const bt=document.getElementById('cfgNuvemBt');
  document.querySelectorAll('.nuvemAcao').forEach(b=>{ b.style.display=nuvemAtiva()?'':'none'; });
  if(!window.NuvemSync){
    if(stEl) stEl.textContent='Desligada (arquivo nuvem-sync.js não encontrado)';
    if(famEl) famEl.textContent='—'; if(bt) bt.disabled=true;
    if(ponto) ponto.className=''; return;
  }
  const st=NuvemSync.status();
  let txt='', cor='';
  if(!st.configurada){
    txt = window.__nuvemCfgArq==='ok'
      ? 'Desligada: o arquivo nuvem-config.js está vazio ou com erro de digitação (Etapa 7 do guia)'
      : 'Desligada: falta o arquivo nuvem-config.js (Etapa 7 do guia)';
  }
  else if(st.estado==='sem-codigo'){ txt='Falta digitar o código da família (botão 🔑 abaixo)'; cor='erro'; }
  else if(st.estado==='offline'){ txt='📴 Sem internet. '+(st.pendentes?st.pendentes+' leitor(es) com progresso guardado só no celular, esperando para subir. ⚠️ Não limpe os dados do navegador até conectar na internet.':'Tudo em dia.'); cor=st.pendentes?'espera':'ok'; }
  else if(st.estado==='enviando'){ txt='⏳ Enviando para a nuvem...'; cor='espera'; }
  else if(st.estado==='erro'){ txt='❌ '+st.detalhe; cor='erro'; }
  else if(st.estado==='ok'){
    const h=st.ultimoOk?new Date(st.ultimoOk):null;
    txt='✅ Tudo guardado na nuvem'+(h?' (às '+String(h.getHours()).padStart(2,'0')+':'+String(h.getMinutes()).padStart(2,'0')+')':'')+
        (st.pendentes?' — '+st.pendentes+' alteração(ões) na fila':'');
    cor=st.pendentes?'espera':'ok';
  }
  else { txt='⏳ Preparando...'; cor='espera'; }
  if(st.configurada && st.avisoVersoes) txt+=' ⚠️ '+st.avisoVersoes+' (confira as Regras — Etapa 6 do guia)';
  if(stEl) stEl.textContent=txt;
  if(bt) bt.disabled=!st.configurada;
  if(famEl) famEl.textContent = !st.configurada ? '—' :
     (st.familia ? ('Em uso: '+st.familia.slice(0,3)+'•••'+(st.temFamiliaNoArquivo?' (vem do arquivo)':'')) : 'Ainda não digitado');
  if(ponto){ ponto.className = st.configurada ? ('on '+cor) : ''; ponto.title=txt; }
}
function nuvemSincronizarAgora(){
  if(!nuvemAtiva()){ showToast('☁️ A nuvem ainda não foi configurada'); return; }
  if(!NuvemSync.pronta()){ pedirCodigoFamilia(false); return; }
  showToast('☁️ Enviando...');
  NuvemSync.sincronizar().then(ok=>{
    atualizaNuvemUI();
    const st=NuvemSync.status();
    showToast(ok ? '✅ Tudo guardado na nuvem!' : (st.estado==='offline' ? '📴 Sem internet — fica guardado no celular' : '❌ '+(st.detalhe||'Não deu certo')));
  });
}
function pedirCodigoFamilia(voltarParaNuvem){
  if(!nuvemAtiva()){ showToast('☁️ A nuvem ainda não foi configurada'); return; }
  const st=NuvemSync.status();
  if(st.temFamiliaNoArquivo){ alert('O código da família já está escrito no arquivo nuvem-config.js. Para trocar, edite aquele arquivo.'); return; }
  const c=prompt('Digite o CÓDIGO DA FAMÍLIA.\n\nÉ o mesmo código em todos os aplicativos e em todos os celulares (pelo menos 6 letras ou números, sem espaço).', '');
  if(c===null) return;
  const ok=NuvemSync.definirFamilia(c);
  if(!ok){ alert('O código precisa ter pelo menos 6 letras ou números.'); return; }
  showToast('🔑 Código guardado!');
  atualizaNuvemUI();
  if(voltarParaNuvem) montarNuvemTela();
}

/* ----- tela: recuperar da nuvem ----- */
function abrirNuvemTela(){
  try{ speechSynthesis.cancel(); }catch(e){}
  mostrarTela('nuvemTela');
  montarNuvemTela();
}
function fecharNuvemTela(){
  if(!U.us.length) abrirNovoUser();
  else if(U.us.length===1) irParaEstante();
  else abrirUsers();
}
/* ----- histórico de versões (uma cópia por dia na nuvem) ----- */
function montarVersoesTela(){
  const msg=document.getElementById('nuvemMsg'), g=document.getElementById('nuvemGrid');
  g.innerHTML='';
  const u=userAtual();
  if(!u.id){ msg.textContent='Primeiro escolha ou recupere um leitor.'; return; }
  if(!nuvemAtiva() || !NuvemSync.pronta()){ msg.textContent='A nuvem ainda não está pronta (configuração ou código da família).'; return; }
  if(navigator.onLine===false){ msg.textContent='📴 Sem internet agora.'; return; }
  msg.textContent='⏳ Procurando as versões guardadas de '+u.nome+'...';
  NuvemSync.listarVersoes(u.nome,u.av).then(lista=>{
    if(!lista.length){ msg.textContent='Ainda não tem versões guardadas de '+u.nome+' (a primeira aparece depois do primeiro envio).'; return; }
    msg.textContent='🕘 Versões de '+u.av+' '+u.nome+' (uma por dia). Tocar numa versão JUNTA ela com o progresso atual — nada é apagado.';
    lista.forEach(v=>{
      let n=0; try{ const l=JSON.parse(v.dados.lidas||'{}'); for(const c in l) n+=((l[c]||'').match(/1/g)||[]).length; }catch(e){}
      const p=v.dia.split('-'), b=document.createElement('button');
      b.className='userCard';
      b.innerHTML='<span class="uAv">🗓️</span><span class="uNome"></span><span class="uProg"></span>';
      b.querySelector('.uNome').textContent=p[2]+'/'+p[1]+'/'+p[0];
      b.querySelector('.uProg').textContent=n+' curiosidade(s) lida(s)';
      b.onclick=()=>{
        if(!confirm('Juntar a versão de '+p[2]+'/'+p[1]+'/'+p[0]+' com o progresso atual de '+u.nome+'?\n\nNada é apagado: só volta o que estiver faltando.')) return;
        NuvemSync.juntarVersao(u.id,u.nome,u.av,v.dia).then(ok=>{
          if(u.id===U.atual){ resincronizarDoDisco(); }
          showToast(ok?'✅ Versão de '+p[2]+'/'+p[1]+' juntada!':'Não encontrei essa versão');
        }).catch(e=>showToast('❌ '+(e.message||'Não deu certo')));
      };
      g.appendChild(b);
    });
  }).catch(e=>{ msg.textContent='❌ '+(e.message||'Não foi possível falar com a nuvem.'); });
}
function montarNuvemTela(){
  const msg=document.getElementById('nuvemMsg'), g=document.getElementById('nuvemGrid');
  g.innerHTML='';
  if(!nuvemAtiva()){ msg.textContent='A nuvem ainda não foi configurada neste aplicativo (veja o guia do Firebase).'; return; }
  if(!NuvemSync.pronta()){ msg.textContent='Primeiro digite o código da família (botão 🔑 abaixo).'; return; }
  if(navigator.onLine===false){ msg.textContent='📴 Sem internet agora. Conecte no Wi-Fi e toque em "Procurar de novo".'; return; }
  msg.textContent='⏳ Procurando os leitores guardados na nuvem...';
  NuvemSync.listarUsuarios().then(lista=>{
    if(!lista.length){ msg.textContent='Ainda não tem nenhum leitor guardado na nuvem com este código da família.'; return; }
    msg.textContent='Toque no leitor para trazer o progresso dele para este celular. Nada que já está aqui é apagado.';
    lista.sort((a,b)=>(b.temAqui-a.temAqui)||a.nome.localeCompare(b.nome));
    lista.forEach(item=>{
      const local=U.us.find(u=>NuvemSync.chaveUsuario(u.nome,u.av)===item.chave);
      const b=document.createElement('button');
      b.className='userCard'+(local?' atual':'');
      b.innerHTML='<span class="uAv"></span><span class="uNome"></span><span class="uProg"></span>';
      b.querySelector('.uAv').textContent=item.av;
      b.querySelector('.uNome').textContent=item.nome+(nomeDoBichinho(item.av)?' · '+nomeDoBichinho(item.av):'');
      b.querySelector('.uProg').textContent= local ? 'já está neste celular — toque para juntar'
                                        : (item.temAqui ? 'tem progresso neste app' : 'veio de outro app');
      b.onclick=()=>nuvemRecuperarLeitor(item, local);
      g.appendChild(b);
    });
  }).catch(e=>{ msg.textContent='❌ '+(e.message||'Não foi possível falar com a nuvem.'); });
}
function nuvemRecuperarLeitor(item, local){
  let id;
  if(local){ id=local.id; }
  else{
    if(U.us.length>=MAX_USERS){ showToast('Já são '+MAX_USERS+' usuários — o máximo.'); return; }
    if(U.us.length) saveState();
    id='p'+Date.now();
    U.us.push({id:id,nome:item.nome,av:item.av});
    U.atual=id; salvarUsers();
    carregarDados(); saveState();
  }
  if(U.atual!==id){ saveState(); U.atual=id; salvarUsers(); carregarDados(); }
  showToast('☁️ Buscando o progresso de '+item.nome+'...');
  NuvemSync.recuperar(id, item.nome, item.av, !local).then(achou=>{
    carregarDados();
    applyTheme(); applyFont(); updateCsBtn(); updateFsizeBtn();
    aplicaAjustes(); applyAudioUI(); atualizaMute();
    irParaEstante();
    showToast(achou ? ('✅ '+item.av+' Progresso de '+item.nome+' recuperado!') : (item.av+' '+item.nome+' pronto! (ainda sem leituras neste app)'));
  }).catch(e=>{ irParaEstante(); showToast('❌ '+(e.message||'Não deu certo')); });
}
/* ao trocar o nome ou o bichinho, a ficha antiga da nuvem é juntada na nova
   (a antiga continua lá, nada é apagado) */
function nuvemLevarFichaAntiga(id, nomeAntigo, avAntigo){
  if(!nuvemAtiva() || !NuvemSync.pronta() || navigator.onLine===false){ try{ NuvemSync.marcarPendente(id); }catch(e){} return; }
  NuvemSync.recuperar(id, nomeAntigo, avAntigo, false).then(()=>{
    if(U.atual===id){ resincronizarDoDisco(); try{ buildHome(); }catch(e){} }
  }).catch(()=>{});
}
/* ao cadastrar alguém novo com o mesmo nome + bichinho que já existe na
   nuvem, o progresso dele volta sozinho */
function nuvemTentarRecuperarNovo(id, nome, av){
  if(!nuvemAtiva() || !NuvemSync.pronta() || navigator.onLine===false) return;
  NuvemSync.recuperar(id, nome, av, true).then(achou=>{
    if(achou && U.atual===id){ buildHome(); showToast('☁️ '+av+' Achei o progresso de '+nome+' na nuvem!'); }
  }).catch(()=>{});
}

if(window.NuvemSync){
  NuvemSync.aoMudar(()=>{ try{ atualizaNuvemUI(); }catch(e){} });
  NuvemSync.iniciar({
    app: APP_NUVEM,
    usuarios: ()=>U.us.map(u=>({id:u.id,nome:u.nome,av:u.av})),
    idDaChave: nuvemIdDaChave,
    exportar: nuvemExportar,
    mesclar: nuvemMesclar
  });
}
```

## 7) `sw.js` (modelo)
```js
/* Curiosidades do Mundo — versão 1.7 (cadastro padrão: nome + 8 bichinhos oficiais numa linha) */
const C='curiosidades-mundo-v1-7';
const FILES=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./nuvem-sync.js','./escola-pwa.js'];
/* nuvem-config.js é buscado sempre na internet primeiro (se o Pedro
   trocar a configuração, os celulares pegam a nova na hora) */
const REDE_PRIMEIRO=['nuvem-config.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>
  c.addAll(FILES).then(()=>c.add('./nuvem-config.js').catch(()=>{}))
).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  const url=new URL(e.request.url);
  /* conversa com o Firebase (outro endereço): nunca guardar, sempre direto na internet */
  if(url.origin!==self.location.origin) return;
  if(REDE_PRIMEIRO.some(n=>url.pathname.endsWith('/'+n))){
    e.respondWith(fetch(e.request).then(n=>{
      if(n&&n.ok){const cl=n.clone(); caches.open(C).then(c=>c.put(e.request,cl));}
      return n;
    }).catch(()=>caches.match(e.request,{ignoreSearch:true})));
    return;
  }
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(r=>r||fetch(e.request).then(n=>{
    if(n&&n.ok){const cl=n.clone(); caches.open(C).then(c=>c.put(e.request,cl));}
    return n;
  }).catch(()=>caches.match('./index.html'))));
});
```

## 8) `nuvem-config.js` — como deve voltar no pacote (VAZIO)
```js
/* =====================================================================
   nuvem-config.js — CONFIGURAÇÃO DA NUVEM (Firebase)
   Escola São Pedro — é o MESMO arquivo para todos os aplicativos.

   O QUE FAZER (veja o guia GUIA_FIREBASE_PASSO_A_PASSO.md, Etapa 7):
   1. Apague as 5 linhas de exemplo que estão entre as duas linhas de ===== abaixo.
   2. No lugar delas, cole o bloco que o Firebase mostrou, que começa com
         const firebaseConfig = {
      e termina com
         };
   3. Salve o arquivo. Não mexa em mais nada.

   Enquanto este arquivo estiver com os campos vazios, os aplicativos
   funcionam normalmente, só que SEM nuvem (tudo fica só no celular).
   ===================================================================== */

/* ======== COLE AQUI (apague daqui ...) ======== */
const firebaseConfig = {
  apiKey: "",
  projectId: "",
};
/* ======== (... até aqui) ======== */


/* ---------------------------------------------------------------------
   CÓDIGO DA FAMÍLIA (opcional)
   Se deixar vazio (""), cada aplicativo pergunta o código UMA vez em
   cada celular (Configurações → ☁️ Nuvem → Código da família).
   Isso é o mais seguro, porque o código não fica visível na internet.
   Se preferir não digitar nada nunca, escreva o código aqui entre as
   aspas (ex.: "saopedro-renata-2026"). Mais prático, porém menos privado.
   --------------------------------------------------------------------- */
const codigoDaFamilia = "";


/* ----- não mexa daqui para baixo ----- */
window.NUVEM_CONFIG = {
  apiKey: (typeof firebaseConfig !== 'undefined' && firebaseConfig.apiKey) || '',
  projectId: (typeof firebaseConfig !== 'undefined' && firebaseConfig.projectId) || '',
  familia: codigoDaFamilia || ''
};
```

## 9) `manifest.webmanifest` (requisitos para instalar)
```json
{
 "name": "Curiosidades do Mundo",
 "short_name": "Curiosidades",
 "description": "Aprender a ler descobrindo curiosidades do mundo, do Brasil, do espaço, da ciência e da nossa cidade. Offline. Escola São Pedro 🌍",
 "id": "./",
 "start_url": "./",
 "scope": "./",
 "display": "fullscreen",
 "display_override": ["fullscreen", "standalone", "minimal-ui"],
 "orientation": "landscape",
 "background_color": "#0e1226",
 "theme_color": "#0e1226",
 "lang": "pt-BR",
 "icons": [
  {"src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
  {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
  {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}
 ]
}

```
Para o convite "Instalar agora" do Chrome aparecer: `name`/`short_name`, `start_url`, `display` (fullscreen/standalone), ícones **192** e **512**, site em HTTPS e service worker com `fetch`.

## 10) Testes usados no Curiosidades v1.7
- **`teste_cadastro.py`: 41/41**
  - 1ª conferência (funcionamento): 16 itens;
  - 2ª conferência (celular): 12 tamanhos (deitado, em pé, tablet e 5 com teclado), medindo se os 8 ficam numa linha, inteiros na tela, sem encostar, com pelo menos 30 px, tocáveis, com o nome e o Pronto visíveis, e se tocar no 🐴 escolhe o Pônei;
  - cadastro em pé sem rotação.
- **`teste_nuvem.py`: 94/94**
  - A: sem configuração;
  - B: envio e fila;
  - C: recuperação em celular limpo;
  - D: recuperação automática por nome + bichinho;
  - E: mistura entre aparelhos ao abrir;
  - F: regressão;
  - G: erro de regras;
  - H: trava de versão e relógio atrasado;
  - P: instalação, tela cheia e tela acesa;
  - V: histórico de versões;
  - K: trocar nome ou bichinho leva a ficha da nuvem, e bichinho antigo continua funcionando.
- **`sw_test.py`:** o app abre offline com o service worker real.
- **`regressao.py`: 10/10.**
