/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Camada 2: navegador real (Chromium), medindo o que aparece na tela —
   não propriedades CSS de elementos que podem nem ser os certos. */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const ROOT = process.env.CORUJA_ROOT || require('path').join(__dirname, '..', 'pacote-netlify');
const PORT = Number(process.env.CORUJA_PORT || 8951);
const OUT = process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'); require('fs').mkdirSync(OUT, { recursive: true });
const MIME = { '.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };

function serve(){
  return http.createServer((req,res)=>{
    let p = req.url.split('?')[0]; if (p === '/') p = '/index.html';
    fs.readFile(path.join(ROOT,p),(e,d)=>{
      if (e){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200,{'Content-Type': MIME[path.extname(p)] || 'application/octet-stream'});
      res.end(d);
    });
  }).listen(PORT);
}

const TEXTO_SOL = `TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?
TAGS: sol, espaço, estrela, astronomia, céu

TEXTO:
Você já sentiu o calor do Sol no rosto durante uma brincadeira? Ele é uma estrela enorme, e a luz dele atravessa a atmosfera antes de chegar até você.

— Pai, será que eu poderia chegar perto do Sol?

— Não seria possível, porque o Sol é quente demais.

PALAVRAS NOVAS:
atmosfera = é a camada de ar que fica em volta de um planeta inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar que você respira e que faz as estrelas cadentes brilharem.

PERGUNTAS:
1) Por que a Lua parece brilhar?
a) Porque tem fogo dentro dela.
b) Porque devolve a luz que vem do Sol. *
c) Porque tem lâmpadas escondidas.
> A Lua não faz luz própria: ela devolve para nós a luz que vem do Sol.

2) O que a atmosfera faz pela gente?
a) Segura o ar que a gente respira. *
b) Faz o Sol girar mais devagar.
c) Deixa a Lua mais quente.
> A atmosfera é o cobertor de ar do planeta, e é ele que mantém o ar por perto.

3) O Sol é o quê?
a) Um planeta como a Terra.
b) Uma lua grande.
c) Uma estrela. *
> Estrela é um astro que fabrica a própria luz, e o Sol faz exatamente isso.

PARA PENSAR:
O que você acha mais incrível no céu?`;

const TEXTO_CORACAO = `TÍTULO: 🫁 Por que o coração acelera?

TAGS: coração, corpo humano, respiração, exercício, saúde

TEXTO:
Você já reparou no que acontece com o seu corpo quando corre bastante? Os músculos pedem mais oxigênio, e o coração acelera para entregar.

PALAVRAS NOVAS:
oxigênio = é um gás invisível do ar que o seu corpo precisa o tempo todo, como se fosse a comida dos músculos.

PERGUNTAS:
1) Por que o coração acelera quando você corre?
a) Para levar mais oxigênio aos músculos. *
b) Porque fica com medo.
c) Porque o ar fica mais pesado.
> Correndo, os músculos gastam mais oxigênio, e o coração acelera para entregar tudo a tempo.

2) O oxigênio vem de onde?
a) Da comida.
b) Do ar que você respira. *
c) Da água do copo.
> O oxigênio é um gás do ar: ele entra pelo nariz quando você respira.

PARA PENSAR:
Você já sentiu seu coração bater rápido?`;

(async () => {
  const server = serve();
  const erros = [];
  const resultados = [];
  function ok(nome, cond, detalhe){ resultados.push({ nome, ok: !!cond, detalhe: detalhe || '' }); }

  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  try {
    const ctx = await browser.newContext({ viewport: { width: 412, height: 915 } });
    await require('./_usuario-teste.js')(ctx);
    const page = await ctx.newPage();
    const benigno = s => /favicon\.ico/i.test(s || '');
    page.on('console', m => {
      if (m.type() !== 'error') return;
      const loc = m.location() || {};
      if (benigno(m.text()) || benigno(loc.url)) return;
      erros.push('console: ' + m.text() + (loc.url ? ' @ ' + loc.url : ''));
    });
    page.on('pageerror', e => erros.push('pageerror: ' + e.message));
    page.on('response', r => { if (r.status() >= 400 && !benigno(r.url())) erros.push('http ' + r.status() + ': ' + r.url()); });

    async function colar(texto){
      await page.evaluate((t) => {
        const c = document.getElementById('caixaTexto');
        c.focus();
        c.value = t;
        const dt = new DataTransfer(); dt.setData('text/plain', t);
        c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
        c.dispatchEvent(new Event('input', { bubbles: true }));
      }, texto);
      await page.waitForTimeout(350);
    }

    await page.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(300);
    ok('Tela inicial aparece', await page.isVisible('#telaInicio'));
    await page.click('.inicioMarca'); // toque neutro (o canto de cima agora é o chip da criança)
    await page.waitForTimeout(100);

    // ---------- PREPARAR TEXTO ----------
    await page.click('.btnInicioPreparar');
    await page.waitForTimeout(200);
    ok('Tela Preparar Texto abre', await page.isVisible('#telaEstudio'));
    ok('O botão Desfazer não existe mais', await page.$('#btnDesfazer') === null);
    ok('Com a caixa vazia, nenhuma linha de título aparece', await page.isVisible('#linhaTitulo') === false);
    const ordem = await page.evaluate(() => {
      const corpo = document.querySelector('.corpoEstudio');
      return Array.from(corpo.children).map(e => e.id || e.className);
    });
    ok('A caixa de texto vem antes da linha de título', ordem.indexOf('caixaTexto') < ordem.indexOf('linhaTitulo'), JSON.stringify(ordem));

    await colar(TEXTO_SOL);
    ok('Colar formata sozinho', /\nTEXTO:\n/.test(await page.inputValue('#caixaTexto')));
    ok('A linha de título aparece depois de colar', await page.isVisible('#linhaTitulo'));
    const chip = await page.textContent('#tituloDetectado');
    ok('O título é detectado com emoji colorido', /Você já imaginou/.test(chip) && /☀️/.test(chip), `"${chip}"`);
    const tst = () => page.evaluate(() => document.getElementById('toast').textContent);
    ok('Depois do formatar automático o botão vira "↩️ Desfazer" e o aviso diz o que foi feito',
      await page.textContent('#btnFormatar') === '↩️ Desfazer' && /Colado e formatado/.test(await tst()), await tst());
    const formatadoAuto = await page.inputValue('#caixaTexto');
    await page.click('#btnFormatar'); await page.waitForTimeout(80);
    ok('Desfazer volta o texto como foi colado (e avisa)', await page.inputValue('#caixaTexto') === TEXTO_SOL &&
      await page.textContent('#btnFormatar') === '🪄 Formatar' && /voltou/.test(await tst()));
    await page.click('#btnFormatar'); await page.waitForTimeout(80);
    ok('Formatar de novo: mesmo resultado e aviso "🪄 Formatado"', await page.inputValue('#caixaTexto') === formatadoAuto && /Formatado/.test(await tst()), await tst());
    await page.evaluate(() => esquecerFormatacao());
    await page.click('#btnFormatar'); await page.waitForTimeout(80);
    ok('Formatar um texto já formatado avisa "já está formatado" (não fica calado)', /já está formatado/.test(await tst()) && await page.inputValue('#caixaTexto') === formatadoAuto, await tst());
    ok('Nenhum botão da fileira fica apagado (todos respondem com um aviso)', await page.$$eval('.botoesLinha button', bs => bs.every(b => !b.disabled)));
    ok('Só restaram 3 botões na fileira', (await page.$$('.botoesLinha button')).length === 3);

    const valorFormatado = await page.inputValue('#caixaTexto');
    ok('O Formatar preserva as TAGS', /TAGS: sol, espaço/.test(valorFormatado));
    ok('O Formatar preserva as PERGUNTAS', /PERGUNTAS:/.test(valorFormatado) && /\*/.test(valorFormatado));

    await page.click('#btnSalvar');
    await page.waitForTimeout(350);
    ok('Salvar leva para a biblioteca', await page.isVisible('#telaBiblioteca'));

    await page.click('text=+ Novo');
    await page.waitForTimeout(200);
    await colar(TEXTO_CORACAO);
    await page.click('#btnSalvar');
    await page.waitForTimeout(350);
    ok('Os dois textos estão na biblioteca', (await page.$$('.cardTexto')).length === 2);

    const distancia = await page.evaluate(() => {
      const c = document.querySelectorAll('.cardTexto');
      return Math.round(c[1].getBoundingClientRect().top - c[0].getBoundingClientRect().bottom);
    });
    ok('Espaço real entre os cards (>= 18px medidos na tela)', distancia >= 18, `${distancia}px`);

    // ---------- BUSCA ----------
    ok('A caixa de busca aparece quando há textos', await page.isVisible('#linhaBusca'));
    await page.fill('#buscaTexto', 'co');
    await page.waitForTimeout(200);
    ok('Com 2 letras ainda mostra todos os textos', (await page.$$('.cardTexto')).length === 2);
    await page.fill('#buscaTexto', 'cora');
    await page.waitForTimeout(200);
    let achados = await page.$$eval('.cardTitulo', els => els.map(e => e.textContent));
    ok('Com 4 letras filtra pelo título', achados.length === 1 && /coração/i.test(achados[0]), JSON.stringify(achados));
    await page.fill('#buscaTexto', 'astronomia');
    await page.waitForTimeout(200);
    achados = await page.$$eval('.cardTitulo', els => els.map(e => e.textContent));
    ok('Acha pelas TAGS invisíveis (astronomia só está na tag)', achados.length === 1 && /Sol/i.test(achados[0]), JSON.stringify(achados));
    await page.fill('#buscaTexto', 'CORACAO');
    await page.waitForTimeout(200);
    ok('Busca ignora acento e maiúscula', (await page.$$('.cardTexto')).length === 1);
    await page.fill('#buscaTexto', 'dinossauro');
    await page.waitForTimeout(200);
    ok('Mostra recado quando não acha nada', await page.isVisible('.buscaSemResultado'));
    await page.click('#btnLimparBusca');
    await page.waitForTimeout(200);
    ok('O X limpa a busca e traz tudo de volta', (await page.$$('.cardTexto')).length === 2);
    await page.screenshot({ path: `${OUT}/v3-biblioteca.png` });

    // ---------- LEITURA + QUIZ ----------
    await page.click('.cardTexto .cardLer');   // primeiro card = coração (o mais novo)
    await page.waitForTimeout(450);
    ok('Popup de leitura abre', await page.evaluate(() => document.getElementById('detOv').classList.contains('open')));
    ok('O convite do quiz aparece no fim do texto', await page.isVisible('.conviteQuiz'));
    const rotuloConvite = await page.textContent('.conviteQuizBtn');
    ok('O convite diz quantas perguntas são', /2/.test(rotuloConvite), `"${rotuloConvite}"`);

    await page.click('.conviteQuizBtn');
    await page.waitForTimeout(350);
    ok('O quiz abre', await page.evaluate(() => document.getElementById('quizOv').classList.contains('open')));
    ok('Mostra o contador da pergunta', /1.*2/.test(await page.textContent('#quizContador')));
    ok('Mostra 3 alternativas', (await page.$$('.quizOpcao')).length === 3);
    ok('A resposta só aparece depois de responder', await page.isVisible('#quizResposta') === false);
    await page.screenshot({ path: `${OUT}/v3-quiz-pergunta.png` });

    // responde ERRADO de propósito (2ª alternativa desta pergunta é a errada)
    const opcoes = await page.$$('.quizOpcao');
    await opcoes[1].click();
    await page.waitForTimeout(300);
    ok('Depois de responder, aparece o veredito', await page.isVisible('#quizVeredito'));
    ok('Errar mostra a explicação carinhosa', (await page.textContent('#quizExplicacao')).length > 20);
    const classes = await page.$$eval('.quizOpcao', els => els.map(e => e.className));
    ok('A alternativa certa fica marcada em verde', classes.some(c => /certa/.test(c)), JSON.stringify(classes));
    ok('A alternativa escolhida errada fica marcada', classes.some(c => /errada/.test(c)));
    ok('As alternativas travam depois de responder', await page.$$eval('.quizOpcao', els => els.every(e => e.disabled)));
    await page.screenshot({ path: `${OUT}/v3-quiz-resposta.png` });

    // botão voltar do Android deve fechar o quiz, não a leitura
    await page.goBack();
    await page.waitForTimeout(300);
    const estado = await page.evaluate(() => ({
      quiz: document.getElementById('quizOv').classList.contains('open'),
      leitura: document.getElementById('detOv').classList.contains('open')
    }));
    ok('O botão voltar fecha o quiz e mantém a leitura aberta', !estado.quiz && estado.leitura, JSON.stringify(estado));

    // refaz o quiz até o fim, acertando tudo
    await page.click('.conviteQuizBtn');
    await page.waitForTimeout(300);
    for (let i = 0; i < 2; i++){
      const certa = await page.evaluate(() => {
        const q = quizPerguntas[quizIndice];
        return q.certa;
      });
      const alternativas = await page.$$('.quizOpcao');
      await alternativas[certa].click();
      await page.waitForTimeout(250);
      await page.click('#quizProxima');
      await page.waitForTimeout(250);
    }
    ok('No fim aparece o resultado', await page.isVisible('#quizFim'));
    const resultado = await page.textContent('#quizFimTitulo');
    ok('Acertando tudo, o resultado comemora', /acertou tudo/i.test(resultado), `"${resultado}"`);
    await page.screenshot({ path: `${OUT}/v3-quiz-fim.png` });
    await page.click('#quizFim .ok');
    await page.waitForTimeout(250);
    ok('O quiz fecha pelo botão', await page.evaluate(() => !document.getElementById('quizOv').classList.contains('open')));

    // ---------- DICIONÁRIO / FONTE / RECUO ----------
    const abriuGloss = await page.evaluate(() => {
      const g = document.querySelector('#detTexto .gloss');
      if (!g) return false; g.click(); return true;
    });
    await page.waitForTimeout(300);
    ok('Dicionário abre ao tocar numa palavra', abriuGloss && await page.evaluate(() => document.getElementById('glossOv').classList.contains('open')));
    if (abriuGloss){
      ok('Definição longa cabe sem rolar', await page.evaluate(() => {
        const c = document.querySelector('#glossOv .pcard');
        return c.scrollHeight <= c.clientHeight + 2;
      }));
      await page.click('#glossOv .ok');
      await page.waitForTimeout(200);
    }

    const fonteAntes = await page.$eval('#detTexto p', el => getComputedStyle(el).fontSize);
    await page.click('button[onclick="mudaFontSize(1)"]');
    await page.waitForTimeout(120);
    const fonteDepois = await page.$eval('#detTexto p', el => getComputedStyle(el).fontSize);
    ok('Botão A+ aumenta a fonte', parseFloat(fonteDepois) > parseFloat(fonteAntes), `${fonteAntes} → ${fonteDepois}`);
    const recuo = await page.evaluate(() => {
      const ps = Array.from(document.querySelectorAll('#detTexto p'));
      const n = ps.find(p => !p.classList.contains('exemploLinha') && !p.classList.contains('pensarLinha'));
      return n ? parseFloat(getComputedStyle(n).textIndent) : null;
    });
    ok('Parágrafo com recuo na primeira linha', recuo > 0, `${recuo}px`);

    await page.click('#detCard .detX');
    await page.waitForTimeout(300);
    ok('Leitura fecha', await page.evaluate(() => !document.getElementById('detOv').classList.contains('open')));

    // ---------- OS CINCO PEDIDOS ----------
    await page.click('#telaBiblioteca .btnVoltar');
    await page.waitForTimeout(200);
    await page.click('.btnInicioPreparar');
    await page.waitForTimeout(200);
    await page.click('.btnPromptMais');
    await page.waitForTimeout(300);
    ok('O menu dos pedidos abre', await page.evaluate(() => document.getElementById('promptOv').classList.contains('open')));
    const nomesPrompts = await page.$$eval('.promptOpcao b', els => els.map(e => e.textContent));
    ok('O menu tem os cinco pedidos', nomesPrompts.length === 5, JSON.stringify(nomesPrompts));
    ok('Os dois pedidos de geração têm nomes bem diferentes',
      nomesPrompts[0] === 'Leitura do dia' && nomesPrompts[1] === 'Entender de verdade',
      JSON.stringify(nomesPrompts.slice(0, 2)));
    ok('O botão grande PROMPT avisa que copia a Leitura do dia',
      (await page.getAttribute('.btnPrompt', 'title') || '').includes('Leitura do dia'));

    const textoLeitura = await page.evaluate(() => CorujaLogic.montarPrompt('leitura', {}));
    const textoEntender = await page.evaluate(() => CorujaLogic.montarPrompt('entender', {}));
    ok('"Leitura do dia" traz a faixa de 300 a 500 palavras', /entre 300 e 500 palavras/.test(textoLeitura));
    ok('"Entender de verdade" não impõe tamanho', /TAMANHO NÃO IMPORTA/.test(textoEntender) && !/650 e 950/.test(textoEntender));
    ok('Os dois pedidos de geração são mesmo diferentes', textoLeitura !== textoEntender);
    ok('O botão grande copia exatamente a Leitura do dia',
      await page.evaluate(() => CorujaLogic.montarPrompt('leitura', {}) === CorujaLogic.montarPrompt('explicar', {})));

    await page.click('text=Entender de verdade');
    await page.waitForTimeout(250);
    ok('"Entender de verdade" copia direto e fecha o menu', await page.evaluate(() => !document.getElementById('promptOv').classList.contains('open')));

    await page.click('.btnPromptMais');
    await page.waitForTimeout(250);
    await page.click('text=Adaptar um texto pronto');
    await page.waitForTimeout(200);
    ok('"Adaptar" pede o texto original antes de copiar', await page.isVisible('#promptPassoExtra'));
    await page.click('.promptVoltarBtn');
    await page.waitForTimeout(150);
    ok('O "Voltar às opções" funciona', await page.isVisible('#promptPassoLista'));
    await page.screenshot({ path: `${OUT}/v4-menu-cinco.png` });
    await page.click('#promptOv', { position: { x: 5, y: 5 } });
    await page.waitForTimeout(200);
    ok('O menu fecha ao tocar fora', await page.evaluate(() => !document.getElementById('promptOv').classList.contains('open')));

    await page.click('#telaEstudio .btnVoltar');
    await page.waitForTimeout(200);
    await page.click('text=LER');
    await page.waitForTimeout(250);

    // ---------- PAISAGEM ----------
    await page.setViewportSize({ width: 915, height: 412 });
    await page.waitForTimeout(250);
    await page.click('.cardTexto .cardLer');
    await page.waitForTimeout(450);
    const dims = await page.evaluate(() => {
      const r = document.getElementById('detCard').getBoundingClientRect();
      return { pw: r.width / innerWidth, ph: r.height / innerHeight };
    });
    ok('Paisagem: leitura usa ~97% da largura', dims.pw > 0.93 && dims.pw < 0.995, `${(dims.pw*100).toFixed(1)}%`);
    ok('Paisagem: leitura usa ~94% da altura', dims.ph > 0.90 && dims.ph < 0.995, `${(dims.ph*100).toFixed(1)}%`);

    await page.evaluate(() => { document.querySelector('.conviteQuizBtn').click(); });
    await page.waitForTimeout(350);
    const quizPaisagem = await page.evaluate(() => {
      const c = document.querySelector('#quizOv .pcard');
      const r = c.getBoundingClientRect();
      return { rolando: c.scrollHeight > c.clientHeight + 2, dentro: r.top >= -1 && r.bottom <= innerHeight + 1 };
    });
    ok('Paisagem: o quiz cabe na tela sem rolar', !quizPaisagem.rolando);
    ok('Paisagem: o quiz não vaza para fora da tela', quizPaisagem.dentro);
    await page.screenshot({ path: `${OUT}/v3-quiz-paisagem.png` });

    // ---------- OFFLINE ----------
    const ctxOff = await browser.newContext({ viewport: { width: 412, height: 915 } });
    await require('./_usuario-teste.js')(ctxOff);
    const pageOff = await ctxOff.newPage();
    await pageOff.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await pageOff.waitForFunction(() => navigator.serviceWorker.controller !== null, { timeout: 6000 }).catch(()=>{});
    await pageOff.waitForTimeout(600);
    await ctxOff.setOffline(true);
    await pageOff.reload({ waitUntil: 'load' }).catch(e => erros.push('recarga offline: ' + e.message));
    ok('O app abre sem internet', await pageOff.isVisible('#telaInicio').catch(() => false));
    await ctxOff.setOffline(false);

    await browser.close();
  } catch (e) {
    erros.push('FALHA GRAVE: ' + e.stack);
    try { await browser.close(); } catch(_) {}
  }
  server.close();

  console.log('\n===== RESULTADOS NO NAVEGADOR =====');
  let tudoOk = true, passaram = 0;
  for (const r of resultados){
    if (r.ok) passaram++; else tudoOk = false;
    console.log(r.ok ? '✅' : '❌', r.nome, r.detalhe ? '— ' + r.detalhe : '');
  }
  console.log('\n===== ERROS DE CONSOLE/REDE =====');
  if (!erros.length) console.log('(nenhum)');
  else { erros.forEach(e => console.log('❌', e)); tudoOk = false; }
  console.log(`\n${passaram}/${resultados.length} verificações — ` + (tudoOk ? '✅ TUDO OK' : '❌ HÁ FALHAS'));
  process.exit(tudoOk ? 0 : 1);
})();
