import os, hashlib, zipfile, sys, datetime
R='/home/claude/passagem/corujaexplica-completo-v3.1'
ZIP='/mnt/user-data/outputs/corujaexplica-completo-v3.1.zip'
FORA={'LEIA-ME.txt','documentos/RELATORIO_CONFERENCIA_PASSAGEM_corujaexplica.md'}
arqs=[]
for d,_,fs in os.walk(R):
    if '/testes/saida' in d: continue
    for f in fs:
        rel=os.path.relpath(os.path.join(d,f),R)
        if rel in FORA: continue
        arqs.append(rel)
arqs.sort()
def md5(p):
    h=hashlib.md5(); h.update(open(p,'rb').read()); return h.hexdigest()
agora=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3))).strftime('%d/%m/%Y %H:%M')
L=[]
L.append('Coruja Explica 🦉 — pacote completo da PASSAGEM · versão do app 3.1 (cache coruja-explica-v3-1) · gerado em '+agora+' (horário de Brasília)')
L.append('')
L.append('PASTAS')
L.append('  pacote-netlify/  = EXATAMENTE o que vai para o Netlify (8 arquivos, na raiz do zip do Netlify).')
L.append('                     nuvem-config.js = o do Pedro, byte a byte (md5 1d5f060a5ae8339921d3d58498807971).')
L.append('                     nuvem-sync.js = versão 3 (a que o app usa hoje). escola-pwa.js = versão 2.')
L.append('  documentos/      = HISTORICO_E_PLANO_corujaexplica.md, PROMPT_CONTINUACAO_corujaexplica.md, changelog, prompts da IA,')
L.append('                     relatório da conferência, historico/ e referencias/ (PLANO_CADASTRO_FAMILIA.md v3 etc.).')
L.append('  testes/          = 9 baterias (816 verificações), Firebase de mentira, COMO_RODAR.md, rodar_todos.sh. NUNCA publicar no Netlify.')
L.append('  trabalho/        = modelo do cadastro novo (NÃO usado pela v3.1), zips das versões anteriores, estudo dos espaços, scripts, capturas.')
L.append('')
L.append('TESTES/SCRIPTS PERDIDOS: nenhum. (Os testes antigos estão em testes/antigos/.)')
L.append('')
L.append('FICOU DE FORA DO ZIP (e por quê)')
L.append('  - _Tia_Irene_*.png / _Tia_Fabiana_*.png: arquivos do Projeto que estavam nos anexos; não são do Coruja Explica (relação: não sei).')
L.append('  - coruja-explica_v1_6 ... v3_0_teste.html (entregas antigas): cópias idênticas (md5 conferido) do index.html de cada versão, que já estão nos zips de trabalho/versoes-anteriores/.')
L.append('  - alfabetizacao-completo-v123.zip (anexo de 14/10, 5,3 MB): dele foram copiados só os documentos de referência (documentos/referencias/) e as cópias mestras (trabalho/modelo-cadastro-novo/).')
L.append('  - as versões v1.0 a v1.2 do app: não existem mais.')
L.append('OBS.: documentos/historico/capturas-do-pedro/ = as imagens que o Pedro mandou na conversa; o começo do nome é a data e a hora (Brasília) em que chegaram.')
L.append('Fora da lista abaixo (escritos por último): LEIA-ME.txt e documentos/RELATORIO_CONFERENCIA_PASSAGEM_corujaexplica.md')
L.append('')
L.append('arquivo | bytes | md5')
for a in arqs:
    p=os.path.join(R,a); L.append(f'{a} | {os.path.getsize(p)} | {md5(p)}')
open(os.path.join(R,'LEIA-ME.txt'),'w',encoding='utf8').write('\n'.join(L)+'\n')
if os.path.exists(ZIP): os.remove(ZIP)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for a in arqs+sorted(FORA):
        z.write(os.path.join(R,a),'corujaexplica-completo-v3.1/'+a)
print(len(arqs),'arquivos listados;', os.path.getsize(ZIP),'bytes no zip')
