import os, sys
# roda de qualquer lugar: usa a base dos testes (testes/testes_navegador) e abre o app de pacote-netlify/ (o nuvem-config.js é trocado por um vazio e o Firebase é de mentira: nunca fala com a nuvem real)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "testes", "testes_navegador"))
os.environ.setdefault("PASTA_PACOTE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "pacote-netlify"))
from base import *
import json, statistics, sys
servidor()
PF=json.dumps({"perfis":[{"id":"1","nome":"Teste","av":"🐧"}],"atual":"1"})
tam=[(int(a),int(b)) for a,b in (x.split('x') for x in sys.argv[1:])]
with sync_playwright() as pw:
    b=pw.chromium.launch()
    for w,h in tam:
        ctx,fb=novo_contexto(b,config='vazia',largura=w,altura=h,storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
        p=abrir(ctx)
        for fsi in (5,6,7,0):
            r=p.evaluate("""(fsi)=>{
              ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open'));
              trocarPagina('ler'); fsIdx=fsi; FSCALE=FSTEPS[fsi];
              const seq=construirOrdemDificuldade(); const out=[];
              const tia=seq.findIndex(i=>/^a ti·a \\{TIA/.test(DATA[i]));
              const lista=[]; for(let k=0;k<300;k+=3) lista.push(k); lista.push(tia);
              for(const k of lista){ idx=seq[k]; render();
                const cortada = phraseEl.scrollWidth>areaEl.clientWidth+1 || phraseEl.scrollHeight>areaEl.clientHeight+1;
                out.push([parseFloat(phraseEl.style.fontSize), cortada, fraseDe(idx).split('|')[0].trim()]); }
              return out; }""", fsi)
            fs=[x[0] for x in r]; cort=[x[2] for x in r if x[1]]
            mais=statistics.mode(fs); iguais=sum(1 for x in fs if x==mais)
            tia=r[-1]
            print('%dx%d tam %s: mais comum %.0fpx (%d de %d frases) min %.0f max %.0f | "%s"=%.0fpx | cortadas: %d' %
                  (w,h,p.evaluate("FSNOMES[fsIdx]"),mais,iguais,len(fs),min(fs),max(fs),tia[2],tia[0],len(cort)))
        ctx.close()
    b.close()
