# 🧭 Guia para implantar o NOVO CADASTRO DA FAMÍLIA num app da Escola São Pedro

Escrito em 15/10/2026, depois de implantar o cadastro no **🌍 Curiosidades do Mundo** (v2.0 → v2.0b → v2.1 → v2.2, publicado e aprovado pelo Pedro; a v2.3 só mexeu na leitura). O 1º app foi o **📚 Alfabetização v123**; o Curiosidades foi o 2º. **Próximo: 🦉 Coruja Explica**, depois Provinha → Historinhas → Matemática → Fluência.

Este guia junta o que deu certo e **os defeitos que só apareceram no teste do Pedro**, para o próximo app não repetir.

---

## 1. Antes de começar (regras do Pedro)
- **Não comece se faltar arquivo.** Peça: zip completo do app (com testes), histórico/prompt dele, `PLANO_CADASTRO_FAMILIA.md` (v3), os modelos (Alfabetização v123 e Curiosidades), as cópias mestras dos compartilhados, o `nuvem-config.js` verdadeiro, um backup exportado de agora, o nome do site de teste e do cache.
- Leia **tudo** antes de mexer. Explique o plano e **peça autorização**.
- **Nunca perder progresso** de nenhuma criança (nem no celular, nem na publicação, nem voltando à versão anterior).
- `nuvem-config.js` do Pedro **byte a byte** (md5 `1d5f060a5ae8339921d3d58498807971`). **Não mexer no Firebase.**
- `escola-familia.js`, `nuvem-sync.js`, `escola-pwa.js` **não se editam dentro de um app só** — usar as cópias mestras (md5 no `LEIA-ME_COMPARTILHADOS.md`). Se precisar mudar, **parar e perguntar**.
- Sem `alert()`, `confirm()`, `prompt()` — tudo com as telas/pop-ups do app.
- Testes **de verdade**, sempre com **Firebase de mentira**; dizer o que foi e o que não foi testado.
- Checagem em **3 etapas** (autochecagem + conferente independente + revisor-chefe).
- Cache novo a cada mudança; zip para o Netlify com os arquivos soltos na raiz; **zip completo** sempre; terminar com checklist ✅/⬜.

## 2. O que o `escola-familia.js` 1.2 espera do app
`EscolaFamilia.iniciar({ app, nomeApp, iconeApp, maxPorFamilia, criancas: ADAPTADOR, passoExtra, aoAbrirTelas, aoFecharTelas, abrirConfig(aoFechar), fecharConfig })` e depois `NuvemSync.iniciar({ app, usuarios: ()=>EscolaFamilia.paraNuvem(lista), idDaChave, exportar, mesclar })`. Depois: `montarChip(el)`, `montarPonto(el)`, `montarSecaoConfig(el)`.

**Adaptador** (ver `MODELO_LIGACAO_CURIOSIDADES_v2.2.js`, parte 4): `listar`, `atual`, `criar(nome, av)` (id novo nunca repetido; **não** troca a criança aberta), `mudar`, `exportar(id)`, `importar(id, dados)` (= juntar), `tirar(id)` (sai da lista; se era a aberta, fica "sem criança"; apaga **todas** as chaves dela), `completoNaNuvem`, `entrar(id, {naAbertura})`, `resumo(id)` → `{linha, barra}`, `resumoDados(d)`, `chavesDaCrianca(id)`.

## 3. Ordem da ligação (no fim do script do app)
1. `EscolaFamilia.iniciar(...)` (a migração só **acrescenta** a chave `escola_familia`).
2. `NuvemSync.iniciar(...)` (cada criança sobe para a pasta da família **dela**).
3. **Trava "sem criança"** de novo, por cima da vigia da nuvem.
4. Chip, bolinha e seção "☁️ FAMÍLIA E NUVEM".
5. Abertura (decisão D2): sempre "🦉 QUEM VAI ESTUDAR HOJE?" (ou as boas-vindas sem família).
6. **`sw.js`**: acrescentar `./escola-familia.js` na lista de arquivos guardados, manter o `nuvem-config.js` buscado na internet primeiro ("rede primeiro") e **subir o nome do cache**. Modelos: `compartilhados/modelos/sw_alfabetizacao_v123.js` e o `sw.js` do `pacote-netlify/` do Curiosidades.

## 4. Defeitos que apareceram no Curiosidades (e como evitar)
| O que aconteceu | Causa | Como evitar no próximo app |
|---|---|---|
| Chaves fantasmas `…_p0_…` | o app gravava com "criança 0" antes de ter criança | **trava "sem criança"** ligada **antes** de carregar os dados e de novo **depois** do `NuvemSync.iniciar` (a vigia troca o `setItem`) |
| "Leitor 1" fantasma reaparecia | com a lista **vazia**, o app recriava a criança a partir de uma chave antiga | respeitar a lista vazia existente |
| **Preferência mudada voltava sozinha** (achado do Pedro no site de teste: "destacar por sílaba" só valia depois de fechar e abrir) | o `mesclar` tratava a criança **sem progresso neste celular** como "celular vazio, acabou de chegar" e deixava as preferências da nuvem passarem por cima | "celular vazio" só se **não houver progresso E nenhuma preferência guardada aqui** (lista `PREFS_LOCAIS`). Quem traz a criança da nuvem já manda `restaurando=true` direto |
| **Escolher a criança não trazia o que ela fez no outro celular** (achado do conferente) | antes, a 1ª troca do dia gravava uma chave e essa gravação disparava, de carona, um envio que juntava com a nuvem; quando essa gravação deixou de existir, a carona sumiu | no `entrar()`, ao trocar de criança, chamar `NuvemSync.sincronizar()` (só se a nuvem estiver configurada) — não depender de efeito colateral |
| Junção parava no meio com dado estragado | um `JSON.parse` sem proteção | cada parte do `mesclar` num `try`; aceitar lista só onde espera lista; texto só onde espera texto; não gravar em criança que não está na lista |
| Backup apagava tudo antes de gravar | importar substituía | importar **junta** (acha a criança por nome + bichinho na família atual; se não existe, entra como nova: **primeiro na lista, depois junta**); pergunta no estilo do app |
| Barra de cima estourava no celular pequeno (568×320) | o chip ocupa espaço | compactar em 2 passos (chip só com o bichinho; depois só os espaços); **nunca** encolher os botões; testar vários tamanhos comparando com a versão anterior |
| Teste dependia da data | um `ultimoDia` fixo no teste | usar o dia de hoje no formato do app |
| Print com código de família no zip | print antigo de referência | conferir prints antes de empacotar; código só `pmrtestes` nos testes |

## 5. Testes que valeram a pena (Firebase de mentira — `fakefb.py`)
- **Migração com o backup REAL do Pedro**: abrir a versão antiga e a nova sobre o mesmo retrato → todas as chaves antigas **idênticas byte a byte**; a única chave nova é `escola_familia`.
- **Voltar à versão anterior** (republicar o zip antigo) e os dados continuam.
- **Dois celulares** na mesma criança (com o app aberto, sem recarregar): progresso chega dos dois lados.
- **Sem internet**: bolinha 🟡; tirar criança só com a nuvem confirmando ou cópia na lixeira (trava do adulto, 3 s); volta pela nuvem.
- Tirar a última criança nas 2 primeiras semanas → bloqueado (de propósito).
- Duas famílias; código novo acrescenta família; criança fica na família dela.
- Preferência mudada não volta; criança trazida da nuvem adota as preferências de lá.
- Desenho das telas em 984×432, 937×411, 740×360, 640×360, 568×320, tablet e em pé; teclado aberto no "QUAL É O SEU NOME?".
- **Prova de que os testes pegam o problema**: desfazer cada correção (ou usar a versão antiga) → o teste tem que falhar.

## 6. Site de teste e publicação
- Site de teste com **"teste" no nome** (o módulo mostra a faixa roxa e recusa código sem "teste"); família `pmrtestes`. **Nunca** o código verdadeiro no site de teste. Não instalar o app de teste no celular das meninas.
- Antes de publicar no site de verdade: bolinha 🟢 em todos os celulares, exportar backup, guardar o zip anterior. Depois: abrir o app **2 vezes** (o service worker troca na 2ª), conferir "QUEM VAI ESTUDAR HOJE?" com o mesmo número de progresso.
- Nunca importar backup numa versão **antiga** para "desfazer" (as antigas apagam antes de gravar).

## 7. Pontos específicos do 🦉 Coruja Explica (pelo prompt de continuação v3.1)
- ID na nuvem `corujaexplica`; chaves `explica_<id>_textos`, `explica_<id>_excluidos`, `explica_<id>_config`; `explica_usuarios`.
- Já tem cadastro e telas próprios (`telaUsuarios`, `telaCadastro`, `telaNuvem`, `codOv`, `confirmOv`), backup que **já junta** e `mesclarBibliotecas` com lápides — **manter** essa regra de juntar (é do app), só ligar no adaptador.
- `nuvem-sync.js` **v3 → 4.1** (como no Curiosidades). Atenção ao limite de ~850 KB por criança na nuvem (`montarExportacao`).
- Abertura hoje: 0 crianças → cadastro; 1 → início direto; 2+ → "Quem vai estudar hoje?". Pelo plano (D2), passa a ser sempre "Quem vai estudar hoje?" — **confirmar com o Pedro**.
- Testes do Coruja são em **JavaScript** (Node + Playwright, `_firebase-falso.js`); os do Curiosidades são em Python (`fakefb.py`) — servem de modelo do **que** testar.
- O "degrau de segurança no voltar" e o `popstate` do Coruja precisam conviver com as telas do `escola-familia.js` (o Curiosidades teve que tratar Esc/setas com `#efRaiz.ef-ativo`).
