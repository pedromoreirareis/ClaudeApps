/* Testes de regressão "gerais" — não são de nenhum item específico do
   pedido, mas cobrem coisas que já quebraram antes nesse projeto
   (segundo o histórico): ids duplicados no HTML, chaves de
   localStorage sem duplicata, e alguns fluxos centrais (Monta a Frase
   / Sílaba Perdida / Leitor de Palavra) ainda abrindo sem estourar
   erro depois de todas as mudanças de hoje. */
const fs = require('fs');
const path = require('path');
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_06_regressao_geral');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);

  t('Nenhum id duplicado no HTML inteiro', () => {
    const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf-8');
    const ids = html.match(/id="([^"]+)"/g).map(s => s.slice(4, -1));
    const contagem = {};
    ids.forEach(id => { contagem[id] = (contagem[id] || 0) + 1; });
    const duplicados = Object.keys(contagem).filter(id => contagem[id] > 1);
    assert(duplicados.length === 0, 'ids duplicados: ' + JSON.stringify(duplicados));
  });

  t('CHAVES_LEITORA não tem chave repetida', () => {
    const chaves = window.eval('CHAVES_LEITORA');
    const set = new Set(chaves);
    assertEq(set.size, chaves.length, 'CHAVES_LEITORA tem chaves repetidas');
  });

  t('Leitor de Palavra (Sílabas Simples): abrir uma família não estoura erro', () => {
    window.eval(`
      var fam = SILABAS_FASE1[0];
      abrirLeitorSimples(fam, fam.silabas[0].s);
    `);
    assert(doc.getElementById('lpPalavra'), 'estrutura do leitor não foi montada');
  });

  t('Leitor de Palavra (Sílabas Complexas): abrir um padrão não estoura erro', () => {
    window.eval(`
      var m0 = SILABAS_COMPLEXAS_MACRO[0];
      var grupo = SILABAS_COMPLEXAS_GRUPOS[m0.id];
      abrirComplexasPadrao(m0.id, grupo.padroes[0].id);
    `);
    assert(doc.getElementById('lpPalavra'), 'estrutura do leitor não foi montada (complexas)');
  });

  t('Monta a Frase: abrir uma frase qualquer monta os slots sem erro', () => {
    window.eval('openMonta(100);');
    const slots = doc.getElementById('mtSlots');
    assert(slots && slots.children.length > 0, 'slots do Monta a Frase não foram montados');
  });

  t('Sílaba Perdida: abrir uma frase qualquer monta as opções sem erro', () => {
    window.eval('openSilaba(100);');
    const ops = doc.getElementById('spOps');
    assert(ops && ops.children.length > 0, 'opções do Sílaba Perdida não foram montadas');
  });

  t('go(1)/go(-1) (navegação de Ler, ordem de dificuldade) não estoura erro', () => {
    window.eval("idx = 0; go(1); go(1); go(-1);");
    assert(true);
  });

  t('sw.js e index.html concordam sobre existir (não é teste de conteúdo, só existência dos arquivos de entrega)', () => {
    assert(fs.existsSync(path.join(__dirname, '..', 'index.html')), 'index.html não encontrado');
  });

  resumo();
})();
