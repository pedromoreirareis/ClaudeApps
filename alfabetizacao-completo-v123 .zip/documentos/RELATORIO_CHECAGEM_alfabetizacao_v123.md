# Relatório de checagem — 📚 Alfabetização v123 (VERSÃO FINAL, site de verdade)

**07/10/2026 · protocolo da parte 9-A, versão 3: autochecagem + 1 agente conferente independente + revisor-chefe**

> **Para que serve este zip:** publicar no site de verdade `https://escolasaopedroalfabetizacao.netlify.app/` (hoje na v121). Passo a passo e lista "conferir antes e depois": `INSTRUCOES_PUBLICAR_v123.md`.
> **Veredito do conferente (etapa 2):** ✅ Pode publicar (2 🟠 nos documentos, corrigidos).
> **Veredito do revisor-chefe (etapa 3):** ver a parte 5.

---

## 1. O que foi RODADO de verdade × só LIDO

**Rodado** (Chromium sem tela + Firebase de mentira; nunca o Firebase real), sobre o zip final:
- `node --check` em todo JavaScript.
- Todas as suítes, **uma de cada vez** (parte 3).
- **Provas de que os testes novos pegam os problemas:** o `teste_v123.py` rodado na v122b falha exatamente no que mudou — sem ⚙️ na T4; C1: as chaves `p2_hana_done` e `p2_hana_trilha_v2` da criança tirada **voltam** quando a resposta da nuvem chega depois (pelo `recuperar` e pelo `sincronizar`); C2: bolinha 🟢 com criança só na lixeira.
- Trilha de leitura: o JSON de `construirTrilha()` tem o **mesmo md5** na v122 e na v123 (`19235fa6…`).
- Abertura com o processador 6× mais lento (para parecer um celular): **3,6 s → 3,0 s** até "Quem vai estudar hoje?" aparecer (o conferente mediu 2,7 → 2,4 s na máquina dele).
- Capturas da ⚙️ na T4 e das Configurações abertas por cima, olhadas.

**Só lido:** o comportamento do Chrome do Android (tela cheia sem as barras, aviso do Chrome, tela preta ao abrir); o Firebase de verdade.

---

## 2. Etapa 1 — matriz "pedido → prova"

| Pedido do Pedro | O que mudou (onde) | Prova | |
|---|---|---|---|
| ⚙️ na "Quem vai estudar hoje?" | `escola-familia.js` 1.2: `botaoConfigT4`, `abrirConfigDoApp`, `mostrarRaiz`; `index.html`: `abrirConfig`/`fecharConfig` no `EscolaFamilia.iniciar` | `teste_v123` 1 (4 tamanhos: ⚙️ ≥ 48 px com bolinha, antes do ⛶; abre por cima; fecha e volta; Buscar e Arrumar de dentro das Configurações; voltar do Android; Cantinho dos pais; escolher criança depois; sem nenhuma criança, sem erro e sem criar chave) | ✅ |
| Tela cheia como antes (sem a "borda azul") | `index.html`: desfeitas as 3 mudanças da v122b (`toggleFs`, o pedido ao abrir, `telaCheia` do `EscolaPWA.iniciar`) | código igual ao da v122 (conferido com `diff`); `teste_desenho` 7 (app "instalado" volta a pedir a tela cheia; ⛶ real entra e sai) | ✅ · ⬜ no celular |
| Abertura lenta (tela preta de 5 s) | `index.html`: `categoriaSilaba` guarda cada resposta | medição acima; `teste_v123` 4 (trilha idêntica) | ✅ no que dava sem risco · explicado no `INSTRUCOES_PUBLICAR_v123.md` |
| "Desinstalei e limpei o cache e não voltou o cadastro" | — (é o comportamento certo) | explicado no `INSTRUCOES_PUBLICAR_v123.md`, parte 5 | ✅ |
| Versão final | `sw.js` `esforco-vence-v123`; C1 (`nuvem-sync.js` 4.1 + `nuvemMesclar`), C2 (`escola-familia.js` 1.2), C3 (aviso em destaque nas instruções) | `teste_v123` 2 e 3; `teste_pwa` (cache) | ✅ |
| Todo o material para os próximos apps | `compartilhados/` (4 arquivos + modelo do `sw.js` + `LEIA-ME_COMPARTILHADOS.md` com md5 gerado pelo `empacotar.py`) | md5 conferidos pelo `empacotar.py` e pelo conferente | ✅ |
| Plano e prompts de passagem com o protocolo novo, para o Sonnet 5.5 | `PLANO_CADASTRO_FAMILIA.md` v3 (parte 9-A, Apêndices A e B, partes 13 e 14, D17 e D18); `PROMPT_HANDOFF_APPS.md` e `_PROMPT_HANDOFF_APPS_COLAR.md` v3 | conferente: o texto de colar é igual ao bloco do arquivo completo; nenhuma sobra de "2 agentes" fora do histórico de mudanças | ✅ |
| Nada do que funcionava quebrou | — | todas as suítes antigas passando (parte 3) | ✅ |
| Revisão final | etapas 2 e 3 | partes 4 e 5 | ✅ |

---

## 3. Testes (rodados no zip final, uma suíte de cada vez)

| Suíte | Resultado |
|---|---|
| rápidos (Node + JSDOM) | **89/89** |
| `teste_cadastro.py` | **72/72** |
| `teste_nuvem.py` | **81/81** (1 teste antigo ajustado: ele juntava dados numa criança que **não estava na lista**; desde a v123 isso é bloqueado de propósito (C1), então o teste põe a criança na lista antes, como o app faz — o conferente conferiu que a mudança é legítima) |
| `teste_pwa.py` | **34/34** |
| `teste_fonte.py` | **57/58** (falha antiga desta máquina, sem as fontes Roboto/Arial; igual na v121 e na v122) |
| `teste_familia.py` | **130/130** |
| `teste_revisao.py` | **59/59** |
| `teste_desenho.py` | **127/127** |
| `teste_v123.py` (novo) | **41/41** |
| **Total** | **690/691** |

---

## 4. Etapa 2 — conferente independente (`revisao_independente/RELATORIO_CONFERENTE_v123_rodada1.md`)

**Veredito: ✅ Pode publicar.** Rodou todas as suítes (690/691) e testes próprios (resposta da nuvem segurada também no envio; lista de crianças dando erro no meio; cópia de um dia com a criança já tirada; v122b → v123 → v121 byte a byte; ⚙️ em 6 tamanhos com 0, 1, 2 e 6 crianças e 1 ou 2 famílias). Confirmou que a nova regra do `aplicar` continua juntando em todos os caminhos normais.

| Achado | O que foi feito |
|---|---|
| 🟠1 O plano não avisava os próximos apps da regra nova da 4.1 (a criança tem que estar na lista **antes** de juntar) | **Corrigido:** plano, parte 5.3, item 17 (hoje), e Apêndice A |
| 🟠2 O zip completo dado a ele não tinha os relatórios de checagem (v122, v122b, v123) | **De propósito** (protocolo: o conferente não vê os relatórios do autor). O zip final tem os 3 |
| 🟡3 Frases velhas no PROMPT (importar "substitui", C1 "a corrigir", `#codOv`) e no HISTORICO (tabela 5.2, capítulo 10 item 9) | **Corrigidas** |
| 🟡4 ⚙️ da T4 sem criança: "Nomes dos parentes" diz "salvos" mas não guarda | registrado no capítulo 11 (sem criança não há onde guardar) |
| 🟡5 Cópias antigas da lixeira (v122/v122b, só no site de teste) deixariam a bolinha 🟡; não há como descartar uma cópia | **Corrigido:** só contam as cópias com a marca nova; descartar fica registrado no capítulo 11 |
| 🟡6 Em pé, com a ⚙️, o "← VOLTAR" quebrava em 2 linhas | **Corrigido** (não quebra mais) |
| 🟡7 Instruções: "Continuar de onde parei" só aparece se a criança estava fora do Ler | **Corrigido** no texto |
| 🟡8 Prompt de passagem não dizia qual `nuvem-sync.js` anexar | **Corrigido:** o que aquele app usa hoje, não a 4.1 |
| 🟡9 Comentário dizia "poucas centenas" de combinações (são ≈ 2,6 mil) | **Corrigido** |
| (já existia) na aba do Chrome, em tela cheia, "📲 Instalar o app" some das Configurações | registrado no capítulo 11 |

Como o zip mudou depois do veredito dele (só os pontos acima), **todas as suítes rodaram de novo no zip final** (parte 3).

**Rodada 2 do conferente** (`revisao_independente/RELATORIO_CONFERENTE_v123_rodada2.md`): **✅ Pode publicar** — 🟠1 e 🟠2 corrigidos de verdade; todas as suítes de novo no zip final (todas passaram); migração v122b → v123 → v121 9/9; telas em 42 combinações sem problema. 2 sobras 🟡: o `#codOv` ainda citado no capítulo 7 do HISTORICO (**corrigido**) e, em pé, o título da T4 quebra em várias linhas (registrado no capítulo 11; o app é usado deitado).

---

## 5. Etapa 3 — revisor-chefe (`revisao_independente/RELATORIO_REVISOR_CHEFE_v123.md`)

**Veredito: ✅ Pode publicar.** Rodou todas as suítes no zip final, uma de cada vez (690/691, iguais aos documentos), conferiu os 107 md5 do `LEIA-ME.txt`, o `nuvem-config.js` (sem nada de teste), o `escola-pwa.js` igual ao da v121, o cache `esforco-vence-v123` e as cópias mestras. Fez 54 verificações próprias, todas OK: migração v121 → v123 com 2 celulares (Hana "1" sem prefixo e criança "p…"; chaves antigas byte a byte; só `escola_familia` nova; os dois celulares se juntam, inclusive com um ainda na v121); voltar à v121 e ir de novo à v123 sem "Hana fantasma"; celular sem código (caso B) sem duplicar; tirar criança sem internet (não tira) e com tudo guardado (sai e não volta); C1 com a lista dando erro no meio do envio (nada sobe, a fila fica, depois junta e sobe); ⚙️ logo na abertura com o voltar do Android (inclusive com o Cantinho dos pais aberto). Confirmou que o `teste_v123` falha na v122b exatamente na ⚙️, no C1 e no C2, e que o protocolo antigo de 2 agentes só aparece nos trechos de "o que mudou".

| Achado (só 🟡) | O que foi feito |
|---|---|
| A. As instruções não diziam o que fazer sem o zip da v121 | **Corrigido:** Download do deploy antigo no Netlify e "Publish deploy" para voltar |
| B. Apêndice A: o conferente também recebe o backup real, se houver | **Corrigido** |
| C. Prompt de passagem: a linha do modelo estava perdida no meio da lista | **Corrigido:** no item 1 |
| D. Plano 5.3: o `mesclar` do app nunca pode dar erro no meio | **Corrigido:** item 16 novo |

Depois do veredito mudaram **só documentos** (nenhum arquivo do app): o zip do Netlify é o mesmo que ele conferiu (md5 `6f26e783…`).

---

## 6. Pedro, confira no celular

1. Tela cheia **sem a borda azul** (as barras do Android), como era antes.
2. A ⚙️ em "Quem vai estudar hoje?": abre as Configurações e, ao fechar, volta.
3. O tempo da tela preta ao abrir (a 2ª abertura depois de publicar é a que vale).
4. Nos 2 celulares das meninas: as crianças com o progresso de antes, a bolinha verde e, no outro celular, o que foi lido aparecendo depois do 🔄.
5. O botão voltar do Android com as Configurações abertas por cima da "Quem vai estudar hoje?".

## 7. Pendências 🟡 (nenhuma bloqueia)

- Abertura: ≈ 3 s com processador de celular simulado; diminuir mais exige separar as frases do `index.html` (mudança grande, só com o seu OK).
- Sem botão para descartar uma cópia da lixeira (só trazer de volta).
- ⚙️ da T4 sem nenhuma criança: as opções que são da criança não guardam nada.
- 568×320 no site de teste: o texto da nuvem no rodapé passa um pouco da borda (a tela rola).
- C4: a migração foi testada com retratos inventados (33 chaves × 2 crianças, byte a byte) e na prática no seu celular (v122 → v122b); o seu backup de verdade não veio. Por isso, antes de publicar: bolinha verde, exportar o backup de cada celular e guardar o zip da v121.
