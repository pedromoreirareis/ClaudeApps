/* Telas que não foram mexidas nos últimos pedidos, mas que passam por
   cima de MUITO código compartilhado (LEVELS, DATA, PERF, karaoke) —
   uma tela auxiliar quebrando seria sinal de que alguma mudança de
   hoje afetou algo além do que pretendia. Também confere a consistência
   entre index.html, manifest.webmanifest e sw.js do pacote final. */
const fs = require('fs');
const path = require('path');
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_09_telas_auxiliares_e_pacote');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);

  t('Mapa de Níveis (openLvl) abre sem erro e monta a grade', () => {
    window.eval('openLvl();');
    assert(doc.getElementById('lvlOv').classList.contains('open'), 'overlay do Mapa de Níveis não abriu');
  });

  t('Calendário (openCal) abre sem erro', () => {
    window.eval('openCal(0);');
    assert(doc.getElementById('calOv').classList.contains('open'), 'overlay do Calendário não abriu');
  });

  t('Configurações (openConfig) abre sem erro', () => {
    window.eval('openConfig();');
    // openConfig não necessariamente usa a mesma convenção de overlay —
    // só confere que não estourou exceção (o eval acima já teria lançado)
    assert(true);
  });

  t('Quiz (openQuiz) abre sem erro e monta 3 opções', () => {
    window.eval('quizFor = 5; openQuiz();');
    const ops = doc.getElementById('qzOps').children;
    assert(ops.length === 3, 'esperava 3 opções no quiz, veio ' + ops.length);
  });

  t('karaoke() aceita container/seletor customizados (usado no Sílaba Perdida) sem estourar erro', () => {
    window.eval(`
      var fr = document.getElementById('spFrase');
      openSilaba(20);
      karaoke(fr, '.spS,.spGap');
    `);
    assert(true);
  });

  resumo();
})();
