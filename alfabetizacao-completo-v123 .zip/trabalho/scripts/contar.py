import os, sys
# roda de qualquer lugar: usa a base dos testes (testes/testes_navegador) e abre o app de pacote-netlify/ (o nuvem-config.js é trocado por um vazio e o Firebase é de mentira: nunca fala com a nuvem real)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "testes", "testes_navegador"))
os.environ.setdefault("PASTA_PACOTE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "pacote-netlify"))
import sys, json
import os; os.environ.setdefault('PORTA','8799')
from base import *
servidor()
PF=json.dumps({"perfis":[{"id":"1","nome":"Teste","av":"🦉"}],"atual":"1"})
with sync_playwright() as pw:
    b=pw.chromium.launch(); erros=[]
    ctx,fb=novo_contexto(b,config='vazia',largura=800,altura=360,storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
    p=abrir(ctx,erros)
    r=p.evaluate("""()=>{
      const o={};
      o.DATA=DATA.length; o.fam=SILABAS_FASE1.length; o.famSil=SILABAS_FASE1.reduce((a,f)=>a+f.silabas.length,0);
      o.palSimples=SILABAS_FASE1.reduce((a,f)=>a+f.silabas.reduce((b,s)=>b+s.palavras.length,0),0);
      o.grupos=Object.keys(SILABAS_COMPLEXAS_GRUPOS).length;
      o.padroes=Object.values(SILABAS_COMPLEXAS_GRUPOS).reduce((a,g)=>a+g.padroes.length,0);
      o.palCompl=Object.values(SILABAS_COMPLEXAS_GRUPOS).reduce((a,g)=>a+g.padroes.reduce((b,p)=>b+p.palavras.length,0),0);
      o.macro=(typeof SILABAS_COMPLEXAS_MACRO!=='undefined')?(Array.isArray(SILABAS_COMPLEXAS_MACRO)?SILABAS_COMPLEXAS_MACRO.length:Object.keys(SILABAS_COMPLEXAS_MACRO).length):null;
      o.LEVELS=LEVELS.length; o.etapas=ETAPAS_TRILHA.map(e=>e.id+': '+(e.nome||e.titulo||'')); 
      o.fontes=FONTS.map(f=>f.name+(f.mode?(' ['+f.mode+']'):'')); o.temas=THEMES.map(t=>t.name);
      o.FSNOMES=FSNOMES; o.FSTEPS=FSTEPS; o.fontPadrao=fontIdx; o.fsPadrao=fsIdx;
      o.rates=(typeof RATES!=='undefined')?RATES:null; o.META_DIA=META_DIA; o.SUPER_META=(typeof SUPER_META!=='undefined')?SUPER_META:null;
      o.blocos=(typeof BLOCOS_CONTEUDO!=='undefined')?BLOCOS_CONTEUDO.length:null;
      o.chaves=CHAVES_LEITORA.length; o.chavesNuvem=CHAVES_NUVEM.length;
      o.famOrdem=SILABAS_FASE1.map(f=>f.letra||f.l||f.nome||'?').join(',');
      o.grupNomes=Object.entries(SILABAS_COMPLEXAS_GRUPOS).map(([k,g])=>k+'='+(g.nome||g.titulo||'')+'('+g.padroes.length+')');
      o.semEmojiDATA=DATA.filter(x=>!x.split('|')[1]).length;
      return o; }""")
    print(json.dumps(r,ensure_ascii=False,indent=1)); print('ERROS',erros)
