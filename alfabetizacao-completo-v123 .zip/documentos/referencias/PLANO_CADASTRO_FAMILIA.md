# 🔑 Plano: cadastro da família e das crianças igual nos 7 apps

**Escola São Pedro · versão 3 (07/10/2026) · ✅ APROVADO pelo Pedro: decisões D1 a D18 · 📚 Alfabetização já implantado (v123)**

> **O que mudou da versão 2 para a 3 (07/10/2026), depois de implantar no 📚 Alfabetização:**
> - **o Alfabetização está pronto e aprovado** (v122 e v122b testadas pelo Pedro em 2 celulares no site de teste; v123 = versão final). Ele é o **app de referência**: o código dele (adaptador, testes, Firebase de mentira) serve de modelo para os outros 6 (parte 7 e parte 14);
> - **cópias mestras prontas:** `escola-familia.js` **1.2** e `nuvem-sync.js` **4.1** (parte 5.1). Os outros 6 apps usam **essas**, sem mudar;
> - **protocolo de checagem mais leve (parte 9-A):** autochecagem + **1 agente conferente independente** + revisor-chefe (antes eram 2 agentes na camada 2). Modelo indicado: **Sonnet 5.5, esforço alto**;
> - **desenho deitado com respiro** (parte 4.12, itens 7 a 10), pedido do Pedro depois do teste nos celulares: pop-ups largos, botões numa linha, caixa do código **no meio** entre o topo e o teclado;
> - **⚙️ na "Quem vai estudar hoje?"** (T4) e **tela cheia de verdade** também no app instalado (decisões D17 e D18);
> - **site de teste:** reconhecido por qualquer endereço com "teste"; o código de teste precisa **conter** "teste" (o do Pedro é `pmrtestes`);
> - **aprendizados da implantação** (parte 13): o que deu trabalho no Alfabetização e como evitar nos outros apps.
>
> **O que mudou da versão 1 para a 2:**
> - todas as decisões da parte 10 foram aprovadas: D1 a D13 e as novas D14 a D16;
> - 🌍 Curiosidades: o novo cadastro entra na versão **publicada (v1.8)**. As novidades da v1.9 ficam guardadas e só são aplicadas **depois** que o novo cadastro estiver publicado (parte 7);
> - entrou a **parte 9-A, o protocolo de checagem**: autochecagem, dupla checagem por 2 agentes independentes e especialistas, e uma revisão final por um 3º agente, antes de qualquer entrega;
> - entrou o **Apêndice B**: o prompt de revisão independente para colar numa conversa nova, se a ferramenta de agentes não estiver disponível;
> - **este plano passou por 2 revisores independentes** (dados e nuvem; telas e prompts). Eles acharam 3 riscos graves de perda de dados que a versão 1 não cobria, e todos foram conferidos no código e corrigidos aqui:
>   - o backup do Alfabetização e o da Matemática também substituem tudo;
>   - "tirar todas as crianças" no Alfabetização recria uma "Hana" fantasma;
>   - no Coruja Explica, "nada na fila" não quer dizer "tudo na nuvem".
>
>   Também entraram a **tabela única de textos (parte 3-A)** e **3 decisões novas, D14 a D16, também aprovadas pelo Pedro** (parte 10).

Este plano vale para os 7 apps: 📚 Alfabetização (Esforço Vence), 🔢 Matemática, 📖 Fluência, 🦉 Coruja Explica, 📝 Provinha, 📕 Historinhas e 🌍 Curiosidades.

Ele foi feito a partir do código das últimas versões que você mandou:

| App | Versão analisada |
|---|---|
| 📚 Alfabetização | v121 |
| 🔢 Matemática | cache v12 |
| 📖 Fluência | v1.4 |
| 🦉 Coruja Explica | v3.1 |
| 📝 Provinha | v30 |
| 📕 Historinhas | v68 |
| 🌍 Curiosidades | v1.8 (a publicada e a do GitHub: **base do novo cadastro**) e v1.9 (novidades guardadas para depois do cadastro) |

Também usei os arquivos compartilhados (`nuvem-sync.js` v3, `escola-pwa.js` v2, `nuvem-config.js`), o guia do Firebase, a referência do Curiosidades, as documentações e os prompts de continuação do projeto, e as conversas de desenvolvimento.

> **Como ler:** as partes 0 a 4 são para você (o que muda e como vai ficar). As partes 5 a 9-A são para o Claude que vai programar. A parte 10 traz as **decisões, todas aprovadas (D1 a D18)**. As partes 13 e 14 trazem o que o 📚 Alfabetização ensinou e como usá-lo de modelo.

---

## 0. Resumo em 1 minuto

1. **Uma tela só, igual em todos os apps.** As telas de família e de crianças passam a morar num **4º arquivo compartilhado**, o `escola-familia.js`. Ele é igual nos 7 apps, como já acontece com o `nuvem-sync.js` e o `escola-pwa.js`. Cada app só "liga" esse arquivo ao seu jeito de guardar o progresso. Assim, as telas e as palavras não têm como ficar diferentes de um app para outro.
2. **Primeira vez no celular:** dois botões grandes, **🔑 Já tenho cadastro** e **🌱 Sou novo por aqui**.
   - Em "Já tenho cadastro", o app **confere na nuvem** se o código existe e mostra as crianças da família.
   - Se o código não existir, o app avisa para conferir a digitação. Hoje nenhum app confere.
3. **Com a família no celular:** sempre abre em **🦉 Quem vai estudar hoje?**.
   - Lá aparecem as crianças do celular e também as crianças da família que estão na nuvem (com uma nuvenzinha; tocar traz a criança).
   - Lá também ficam: ➕ Nova criança, ☁️ Buscar na nuvem, 🔄 Atualizar agora e ✏️ Arrumar (mudar nome ou bichinho, tirar do celular).
4. **Em todos os apps:** o **bichinho da criança na barra de cima** (tocar troca de criança) e a **⚙️ com a bolinha 🟢🟡🔴**.
   - Nas Configurações, a última seção é sempre **☁️ Família e nuvem**, com as mesmas linhas, na mesma ordem.
5. **Mais de uma família no mesmo celular:** passa a ser possível. Cada criança fica ligada à família dela.
6. **Nada se perde:**
   - A mudança só **acrescenta** informação no celular e não apaga nada antigo. Se precisar, dá para voltar à versão anterior.
   - A nuvem **não precisa de nenhuma mudança** no Firebase (nem nas regras, nem no console).
   - Tirar uma criança do celular só é feito depois de confirmar que tudo dela está guardado na nuvem, ou com uma cópia de segurança no próprio celular.
7. **Ordem:** primeiro o 📚 Alfabetização. Antes de publicar, os testes de sincronização são feitos num **site de teste separado**, sem encostar no app que as meninas usam. Só depois de publicado e conferido, o próximo app.
8. **Nada é entregue sem checagem em 3 etapas** (parte 9-A): quem fez confere tudo, **1 agente conferente independente** tenta achar erros, e um **revisor-chefe** (outro agente) dá o veredito. Só sai entrega com **zero problema 🔴 grave e zero 🟠 importante** em aberto.
9. **Já pronto no 📚 Alfabetização (v123):** é o modelo para os outros 6 apps.

---

## 1. Como está hoje (diagnóstico)

### 1.1 Cada app faz de um jeito

| | 📚 Alfab. | 🔢 Matem. | 📖 Fluência | 🦉 Explica | 📝 Provinha | 📕 Historinhas | 🌍 Curios. |
|---|---|---|---|---|---|---|---|
| ID na nuvem | `alfabetizacao` | `matematica` | `fluencia` | `corujaexplica` | `provinha` | `historinhas` | `curiosidades` |
| Título da tela de escolher | Quem vai estudar hoje? | **Quem vai jogar?** | **Quem vai ler hoje?** | Quem vai estudar hoje? | Quem vai estudar hoje? | **Quem vai ler?** + tela "Olá!" | Quem vai estudar hoje? |
| Botão de cadastrar | ➕ Novo usuário | **Novo Perfil** | **Novo leitor** | ➕ Novo usuário | ➕ Novo usuário | **➕ Nova** / 🌟 Nova leitora | **+ NOVO USUÁRIO** |
| Cadastro | Nome + bichinho | Nome + bichinho + **turma** | Nome + **idade + ano** + bichinho | Nome + bichinho | Nome + bichinho | Nome + bichinho | Nome + bichinho |
| Bichinho já vem marcado? | não | não | **sim (🦉)** | não | não | não | não |
| Trazer da nuvem na 1ª abertura | ☁️ Já tenho cadastro | **só um link pequeno** "☁️ Recuperar perfil de outro celular" | **não tem** | ☁️ Já tenho cadastro | ☁️ Já tenho cadastro | ☁️ Já tenho cadastro | ☁️ Já tenho cadastro |
| Tela de recuperar | Recuperar cadastro | Recuperar cadastro | **não existe** | Recuperar cadastro | Recuperar cadastro | Recuperar cadastro | Recuperar cadastro |
| Nome nas Configurações | Recuperar da nuvem | **Recuperar leitores** | — | **Recuperar crianças** | **Recuperar crianças** | **Recuperar leitoras** | **Recuperar leitores** |
| Enviar agora | 🔄 Enviar agora | 🔄 Enviar agora | **🔄 Sincronizar agora** | 🔄 Enviar agora | 🔄 Enviar agora | (tocar em "Situação") | 🔄 Enviar agora |
| Botão do pop-up do código | 🔑 Guardar código | 🔑 Guardar código | **Confirmar ✅** | 🔑 Guardar código | 🔑 Guardar código | **Pronto! ✅** | **Confirmar ✅** |
| Onde troca de criança | chip pequeno embaixo da 🦉 + ⚙️ "Trocar leitora" | **"🔄 Trocar Jogador" no fim do mapa** | **"↔ Trocar leitor" no menu** | chip só na tela inicial | **chip "⬅ 🦊 Nome" que parece botão de voltar** | **sem chip** (pela tela "Olá!") | chip só na tela inicial |
| Bolinha na ⚙️ | sim | **não tem bolinha** (o botão é 👪) | sim | só na tela inicial | só em "Escolha o Ano" | **só dentro das Configurações** | só na tela inicial |
| Apagar | 🗑️ Apagar este usuário | 🗑️ em cima do cartão | **não existe** | 🗑️ Apagar este usuário | 🗑️ Apagar este usuário | 🗑️ Apagar esta leitora | 🗑️ Apagar este usuário |
| Apagar a última criança | bloqueia | deixa | — | bloqueia | deixa e pede cadastro | bloqueia | bloqueia |
| Pop-up do navegador | não | não | não | não | não | **sim (confirm)** | **sim (confirm/alert)** |
| Máximo de crianças | 6 | **sem limite** | **sem limite** | 6 | 6 | 6 | 6 |
| Tela | deitado | **em pé** | deitado (gira tudo) | livre (leitura deitada) | deitado | deitado | deitado |

Para a **mesma coisa**, os apps usam hoje 6 palavras: *usuário, leitor, leitora, criança, jogador, perfil*.

Para "trazer da nuvem", são 7 nomes diferentes:
- *Já tenho cadastro*
- *Recuperar da nuvem*
- *Recuperar cadastro*
- *Recuperar leitores*
- *Recuperar leitoras*
- *Recuperar crianças*
- *Recuperar perfil de outro celular*

A palavra **"Trocar"** serve para duas coisas diferentes: *Trocar nome ou bichinho* (mudar) e *Trocar leitora / Trocar Jogador* (escolher outra criança).

### 1.2 Problemas encontrados (do mais grave para o mais leve)

🔴 = pode **perder histórico** · 🟠 = confunde ou separa a criança · 🟡 = só diferença entre apps

| # | Problema | Onde | Por quê (causa) |
|---|---|---|---|
| 🔴 1 | **Apagar uma criança com progresso que ainda não subiu perde esse progresso para sempre.** | todos | O `nuvem-sync.js` tira da fila de envio quem foi apagado do celular ("leitor apagado: nada a enviar"). Sem internet, ou nos 1,5 s antes do envio, o que estava na fila some. |
| 🔴 2 | **Código digitado errado cria uma "família nova" vazia, sem aviso.** As crianças do celular sobem para lá e ficam separadas da família de verdade. | todos | O app aceita qualquer código com 6 ou mais letras e não confere se ele existe. |
| 🔴 3 | **"Família nova" com um código que outra família já usa junta as duas famílias.** | todos | Ninguém confere se o código está livre. Um código como `saopedro2026` é fácil de repetir. |
| 🔴 4 | **Trocar o código num celular manda todas as crianças daquele app para a outra família.** | todos | Cada app guarda **um único** código por celular (`nuvem_familia`). Não existe "duas famílias". |
| 🔴 5 | **Apagar uma leitora no Historinhas apaga as gravações de voz dela.** Elas nunca vão para a nuvem, então somem de vez. | Historinhas | As gravações ficam numa memória separada do celular (IndexedDB), e `apagarRecontosDoPerfil` apaga essa memória junto. |
| 🔴 6 | **Importar backup substitui tudo** (não junta). Um backup antigo apaga o progresso novo **e depois sobe por cima da nuvem**: como foi o mesmo celular que gravou, o `nuvem-sync.js` não junta, e a ficha da nuvem e a cópia do dia ficam com o backup velho. | **Alfabetização** (`aplicarBackup`), **Matemática** (`confirmImportBackup`), Historinhas, Curiosidades | O código do backup apaga as chaves e grava por cima. O Coruja Explica já foi corrigido para juntar. *Fora do cadastro, mas é perda de histórico, por isso está aqui.* |
| 🟠 7 | **Na 1ª abertura é difícil (Matemática: só um link pequeno e cinza) ou impossível (Fluência) trazer a criança da nuvem.** O Fluência não tem nem a tela de recuperar, nem mudar nome, nem apagar. | Matemática, Fluência | O cadastro dos dois foi feito antes do padrão e só recebeu a "recuperação automática" (mesmo nome + bichinho). |
| 🟠 8 | **O 🦉 já vem marcado no cadastro.** A criança aperta "Pronto" e fica com 🦉, uma ficha diferente da dos outros apps. Também não impede nome repetido. | Fluência | `pegarEmoji(primeiro)` no formulário. |
| 🟠 9 | **Mudar nome ou bichinho deixa a ficha antiga aparecendo** em "Recuperar" (duas "Hana"). Nos outros apps a criança continua com o nome antigo, numa ficha separada. | todos | A ficha antiga não pode ser apagada (regra do Firebase) e nada marca que ela "mudou para" a nova. |
| 🟠 10 | **A mesma criança tem bichinhos diferentes em apps diferentes** (ex.: a Hana com 👧 no Alfabetização antigo e outro bichinho em outro app). O progresso dela fica em fichas separadas na nuvem. | entre apps | A identidade na nuvem é nome + bichinho. Bichinhos antigos continuam valendo, e cada app foi cadastrado separado. |
| 🟠 11 | **A bolinha da nuvem falta ou está escondida.** | Matemática (não tem), Historinhas (só dentro das Configurações), Explica / Curiosidades / Provinha (só numa tela) | Cada app colocou a bolinha num lugar. |
| 🟠 12 | **Trocar de criança fica em lugares diferentes.** No Provinha, o chip "⬅" parece um botão de voltar. | todos | Cada app colocou num lugar. |
| 🟠 13 | **Teclado pode desarrumar a tela.** No Fluência, o cadastro está dentro da área que gira quando o celular está em pé (`#giro`). No Historinhas, o pop-up do código fica dentro da área girada (`#app`). *A confirmar no seu celular.* | Fluência, Historinhas | Com o teclado aberto, a altura da tela muda e a regra de girar liga e desliga no meio da digitação. |
| 🟡 14 | Pop-ups do navegador (`confirm`/`alert`) para apagar, juntar versão e backup. | Historinhas, Curiosidades | Ficaram de antes do padrão. |
| 🟡 15 | Regras diferentes para apagar a última criança; limites diferentes (6 ou sem limite). | vários | Cada app decidiu. |
| 🟡 16 | O código só aparece escondido (`sao•••`). Se o adulto esquecer o código, não tem como ver no celular. | todos | Por privacidade. |
| 🟡 17 | O código é digitado **uma vez em cada app, em cada celular** (7 apps × 2 celulares = 14 vezes). | todos | Cada site tem a sua memória separada no celular. É do navegador, não tem como evitar. Há uma ideia de atalho na decisão D8. |
| 🟡 18 | No Alfabetização, "👨‍👩‍👧‍👦 Nomes da família" (os parentes das frases) usa a mesma palavra "família" do "Código da família". | Alfabetização | Nomes parecidos para coisas diferentes. |
| 🟡 19 | A Matemática ainda tem código de uma nuvem antiga ("Código Mágico", Realtime Database), desligado com `COLE_AQUI`. Não faz nada, mas confunde quem for mexer. | Matemática | Ficou de antes. |
| 🟡 20 | Abrir com 1 criança: cada app faz uma coisa. O Alfabetização mostra "continuar / menu", Explica e Curiosidades entram direto, Matemática e Fluência sempre mostram a lista. | todos | Cada app decidiu. |

> **O que está bom e fica:**
> - o "motor" da nuvem: fila sem internet, envio seguro com trava de versão, cópias de cada dia;
> - a identidade **nome + bichinho** e os **8 bichinhos oficiais**;
> - o jeito de **juntar sem perder** de cada app (`mesclar`);
> - o pop-up do código que encolhe com o teclado, no estilo do Alfabetização (o melhor hoje, como você disse).

---

## 2. Regras de ouro (valem para todos os apps, sem exceção)

1. **Nenhum histórico se perde.** Pode mudar de lugar, pode mudar de formato, mas não pode sumir.
2. **A mudança no celular só acrescenta.** As chaves antigas (`ev_perfis`, `mundo_usuarios`, `nuvem_familia`…) **não são apagadas nem renomeadas**: a versão nova grava ao lado. Se algo der errado, publica-se o zip anterior e tudo volta como estava.
3. **Firebase sem nenhuma mudança.** Nada de regras novas, nada no console.
   - Os caminhos continuam `familias/{código}/usuarios/{nome_bichinho}/apps/{app}` e `…/versoes/{dia}`.
   - O formato do documento não muda.
   - Campos novos e opcionais (ex.: `movidoPara`) entram em documentos que as regras atuais já deixam atualizar. Apps que ainda não mudaram simplesmente ignoram esses campos.
4. **Os apps nunca apagam nada da nuvem** (as regras nem deixam). "Tirar a criança" é sempre só do celular.
5. **Nada destrutivo sem garantia.** Tirar uma criança do celular só acontece se:
   - a nuvem confirmou que **tudo dela foi guardado**, ou
   - o app guardou antes uma **cópia na lixeira do celular**.
6. **A identidade não muda:** nome + bichinho, com a mesma conta de hoje (`hana_1f98a`). Bichinhos antigos (👧, 🌸, 🐧…) continuam funcionando. Só ao **mudar** é que se escolhe um dos 8.
7. **Mesmas telas, mesmas palavras, mesma ordem** nos 7 apps, garantido por um arquivo único (`escola-familia.js`).
8. **Sem pop-up do navegador** (`alert`, `confirm`, `prompt`) em nenhuma dessas telas.
9. **Funciona sem internet.** Cadastrar, escolher e trocar de criança funcionam offline. O que depende da nuvem avisa e espera.
10. **O teclado nunca cobre o que está sendo digitado**, deitado ou em pé.

---

## 3. Palavras padrão (para crianças de 3 a 10 anos)

Princípio: **frases curtas, verbo de ação, um desenho (emoji) por ideia.** A criança reconhece o **próprio bichinho** antes de ler o nome. As palavras técnicas ficam só nas explicações pequenas, para o adulto.

| O que é | Nome padrão (em todos os apps) | Substitui |
|---|---|---|
| O grupo da família | **Família** · **🔑 Código da família** | (já é assim) |
| Cada pessoa que usa | **criança** (nos textos para o adulto). Na tela das crianças aparece só o **bichinho + nome** | usuário, leitor, leitora, jogador, perfil |
| Primeira vez no celular | **🔑 Já tenho cadastro** · **🌱 Sou novo por aqui** | — |
| Tela de escolher | **🦉 Quem vai estudar hoje?** | Quem vai jogar? / Quem vai ler hoje? / Quem vai ler? |
| Cadastrar | **➕ Nova criança** → tela **🌟 Qual é o seu nome?** | Novo usuário, Novo Perfil, Novo leitor, Nova leitora |
| Mudar nome/bichinho | **✏️ Mudar nome ou bichinho** | ✏️ Trocar nome ou bichinho |
| Escolher outra criança | **👥 Trocar de criança** (e o chip com o bichinho na barra de cima). O 🔄 fica só para "Atualizar agora": a criança se guia pelo desenho, então cada desenho tem um sentido só | Trocar leitora, Trocar Jogador, Trocar leitor, ⬅ Voltar |
| Tirar do celular | **🗑️ Tirar deste celular** | Apagar este usuário, Apagar esta leitora |
| Modo de mexer na lista | **✏️ Arrumar** / **✅ Terminei de arrumar** | — |
| Trazer da nuvem | **☁️ Buscar na nuvem** | Recuperar da nuvem / cadastro / leitores / leitoras / crianças / perfil… |
| Enviar e receber agora | **🔄 Atualizar agora** | Enviar agora, Sincronizar agora |
| Situação da nuvem | **☁️ Nuvem** + bolinha **🟢 / 🟡 / 🔴** + frase curta | Situação |
| Cópias diárias (só adulto) | **🕘 Cópias de cada dia** | 🕘 Versões guardadas |
| Várias famílias | **👨‍👩‍👧 Famílias neste celular** | — |
| Botão do pop-up do código | **🔑 Procurar a família** (ao entrar) · **✅ Criar a família** (ao criar) | Guardar código, Confirmar, Pronto |

**Palavras que não aparecem mais nessas telas:** usuário, perfil, leitor(a), jogador, aluno, sincronizar, recuperar, versões, ficha.

**"Trocar"** passa a ter um sentido só: **escolher outra criança**. Para editar, a palavra é **"Mudar"**.

### 3-A. Tabela única de textos (a fonte para o teste de textos)

Os desenhos da parte 4 e a tabela da parte 3 mostram onde cada texto fica. **Quando houver diferença, vale esta tabela 3-A.** O que não estiver nela segue a parte 4. O `escola-familia.js` guarda todos os textos num objeto só (`TEXTOS`), e o teste da parte 9 compara as telas com ele.

| Onde | Texto exato |
|---|---|
| T1 título | 🦉 OLÁ! VAMOS COMEÇAR? |
| T1 botões | 🔑 JÁ TENHO CADASTRO · 🌱 SOU NOVO POR AQUI · AGORA NÃO › |
| T2 título | 🔑 CÓDIGO DA FAMÍLIA |
| T2 botão (com e sem teclado) | 🔑 PROCURAR A FAMÍLIA |
| T3 título / botões | 🌱 CRIAR O CÓDIGO DA FAMÍLIA · ✅ CRIAR A FAMÍLIA · 📝 ANOTE NUM PAPEL · ✅ JÁ ANOTEI |
| Pop-ups (T2, T3, perguntas) | ✕ CANCELAR (fechar sem fazer nada) |
| Telas inteiras (T5, T6, T8) | ← VOLTAR |
| T4 título | 🦉 QUEM VAI ESTUDAR HOJE? |
| T4 botões | ➕ NOVA CRIANÇA · ☁️ BUSCAR NA NUVEM · 🔄 ATUALIZAR AGORA · ✏️ ARRUMAR |
| T5 título / campo / botão | 🌟 QUAL É O SEU NOME? · DIGITE O SEU NOME · PRONTO! ✅ |
| T5 ao mudar | ✏️ MUDAR NOME OU BICHINHO |
| T7 título / sair do modo | ✏️ ARRUMANDO · ✅ TERMINEI DE ARRUMAR |
| T7 tirar | 🗑️ TIRAR DESTE CELULAR |
| Chip / trocar | 👥 TROCAR DE CRIANÇA |
| T8 título | 👨‍👩‍👧 FAMÍLIAS NESTE CELULAR |
| Bolinha 🟢 | TUDO GUARDADO NA NUVEM (ÀS 14:32) |
| Bolinha 🟡 | GUARDANDO… · 📴 SEM INTERNET: 2 CRIANÇAS ESPERANDO. NÃO LIMPE OS DADOS DO NAVEGADOR. |
| Bolinha 🔴 | FALTA O CÓDIGO DA FAMÍLIA · A NUVEM DEU ERRO: (motivo) · NUVEM DESLIGADA (FALTA O ARQUIVO NUVEM-CONFIG.JS) |
| Configurações | ☁️ FAMÍLIA E NUVEM · 🕘 CÓPIAS DE CADA DIA |
| Trava do adulto | 👨 PEÇA PARA UM ADULTO (veja a D15) |

- Os avisos para o adulto (ex.: "🦊 HANA MUDOU PARA 🐰 HANA EM OUTRO APP. MUDAR AQUI TAMBÉM?") também ficam em CAIXA ALTA. As explicações pequenas embaixo dos títulos podem ficar em letra normal.
- A frase **"Sou novo por aqui"** foi escrita pelo Pedro no pedido e fica assim.

**Letra:** as telas de família e crianças usam **CAIXA ALTA** em todos os apps, para quem ainda está aprendendo a ler (decisão D4). Os nomes digitados aparecem em caixa alta também. **A caixa alta é só na tela (CSS `text-transform`)**: o nome é guardado como foi digitado, porque o Alfabetização usa o nome dentro das frases e a identidade na nuvem não pode mudar.

---

## 4. Como o app vai ficar (telas e caminhos)

### 4.0 O caminho todo

```
Abrir o app
   │
   ├─ Este celular NÃO tem família neste app ──► [T1] Boas-vindas
   │        ├─ 🔑 Já tenho cadastro ──► [T2] Código ──► confere na nuvem ──► [T4] Quem vai estudar hoje?
   │        └─ 🌱 Sou novo por aqui  ──► [T3] Criar código ──► anotar ──► [T5] Nova criança (obrigatória)
   │
   └─ Este celular JÁ TEM família ──► [T4] Quem vai estudar hoje?
            ├─ toca no bichinho de uma criança ──► (passo próprio do app, ex.: "continuar de onde parei") ──► app
            ├─ toca numa criança ☁️ (está na nuvem, não neste celular) ──► traz ──► app
            ├─ ➕ Nova criança ──► [T5]
            ├─ ☁️ Buscar na nuvem ──► [T6]
            ├─ 🔄 Atualizar agora
            └─ ✏️ Arrumar ──► [T7] (mudar nome/bichinho · tirar deste celular)

Dentro do app:  [chip 🦊 HANA] ──► [T4]      [⚙️●] ──► Configurações ──► seção "☁️ Família e nuvem" (fim)
```

**Ao abrir o app, sempre aparece a T4**, mesmo com uma criança só (decisão D2). Assim:
- a criança sempre vê quem está entrando;
- o adulto sempre vê a bolinha;
- nunca se marca nada na criança errada.

Depois de escolher, cada app segue o seu caminho de sempre. Por exemplo, o Alfabetização continua perguntando "▶ Continuar de onde parei / 🏠 Menu".

### [T1] Boas-vindas (o celular não tem família neste app)

```
┌──────────────────────────── DEITADO ────────────────────────────┐
│                       🦉  OLÁ! VAMOS COMEÇAR?                    │
│                                                                  │
│   ┌──────────────────────────┐    ┌──────────────────────────┐   │
│   │  🔑  JÁ TENHO CADASTRO    │    │  🌱  SOU NOVO POR AQUI    │   │
│   │  tenho o código da        │    │  criar o código da        │   │
│   │  família                  │    │  família                  │   │
│   └──────────────────────────┘    └──────────────────────────┘   │
│                                                                  │
│  (só se o celular já tiver crianças de antes)                    │
│  Este celular já tem: 🦊 HANA · 🌸 HINATA — elas não vão sumir.   │
│                                              [Agora não ›]        │
└──────────────────────────────────────────────────────────────────┘
EM PÉ: os dois botões ficam um embaixo do outro, do mesmo tamanho.
```

- Os dois botões são grandes (pelo menos 64 px de altura), com o emoji grande.
- **"Agora não ›"** só aparece se o celular **já tiver crianças de antes** (atualização de um app antigo). Ele leva à T4 com a bolinha 🔴, e nada fica escondido (decisão D7).
- Numa instalação nova não tem "Agora não". Os dois caminhos funcionam **sem internet**, então ninguém fica preso.

### [T2] Código da família — "Já tenho cadastro"

```
SEM TECLADO                                   COM TECLADO (deitado, ~170 px livres)
┌──────────────────────────────────────┐      ┌────────────────────────────────────────────────┐
│        🔑 CÓDIGO DA FAMÍLIA           │      │🔑 CÓDIGO  [ saopedro2026         ] [🔑 PROCURAR] ✕│
│  É O MESMO CÓDIGO EM TODOS OS APPS    │      └────────────────────────────────────────────────┘
│  E EM TODOS OS CELULARES DA FAMÍLIA.  │      ██████████████████ TECLADO ██████████████████████
│  ┌────────────────────────────────┐   │
│  │ ex.: panda-4827                 │   │
│  └────────────────────────────────┘   │
│     [CANCELAR]   [🔑 PROCURAR A FAMÍLIA] │
└──────────────────────────────────────┘
```

O que acontece ao tocar **🔑 Procurar a família**:

| Situação | O que o app mostra |
|---|---|
| Achou (tem crianças) | **"🎉 Achei a sua família!"** e os cartões das crianças (bichinho + nome + 📚🌍📕 dos apps onde cada uma aparece). Botões **[Trazer todas]** e **[Escolher]**. Depois vai para a T4. |
| Não achou | **"🤔 Não achei nenhuma criança com esse código."** Confira letra por letra (tracinho conta). Se é a primeira vez da família, toque em **🌱 Sou novo por aqui**. Se o código sem tracinho existir, o app pergunta: *"Você quis dizer `saopedro2026`?"* |
| Sem internet | **"📴 Sem internet agora."** Botões **[Guardar e conferir depois]** e **[Tentar de novo]**. Se guardar, a família fica como "a conferir": o app funciona e confere sozinho quando a internet voltar. Se não existir, avisa antes de subir qualquer coisa. |
| Código curto | **"O código precisa ter pelo menos 6 letras ou números 🙂"** (embaixo do campo, sem fechar o pop-up). |

### [T3] Criar o código — "Sou novo por aqui"

```
┌────────────────────────────────────────────┐
│          🌱 CRIAR O CÓDIGO DA FAMÍLIA        │
│  O app sugeriu um código. Pode usar ou       │
│  escrever outro (6 letras ou números ou mais).│
│  ┌──────────────────────────────────────┐   │
│  │ tigre-5183                            │   │
│  └──────────────────────────────────────┘   │
│      [CANCELAR]       [✅ CRIAR A FAMÍLIA]    │
└────────────────────────────────────────────┘
          ↓ (depois de criar)
┌────────────────────────────────────────────┐
│  📝 ANOTE NUM PAPEL:     TIGRE-5183          │
│  É com ele que os outros celulares e os      │
│  outros apps encontram as crianças.          │
│                 [✅ JÁ ANOTEI]                │
└────────────────────────────────────────────┘
          ↓
[T5] Nova criança (obrigatória: precisa de pelo menos uma)
```

- **Sugestão automática:** um bichinho + 4 números (`tigre-5183`, `panda-4827`). É fácil de anotar e quase impossível de repetir sem querer. O adulto pode trocar pelo que quiser.
- **Com internet:** confere se o código está livre. Se já existir, mostra **"Esse código já tem crianças. Se é da sua família, use 🔑 Já tenho cadastro. Se não é, escolha outro."**
- **Sem internet:** cria assim mesmo (a sugestão automática praticamente não se repete) e confere quando a internet voltar.

### [T4] 🦉 Quem vai estudar hoje? (tela principal das crianças)

```
┌───────────────────────────────────── DEITADO ─────────────────────────────────────┐
│ 🦉 QUEM VAI ESTUDAR HOJE?                                              ⚙️●   ⛶ │
│                                                                                   │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌ ─ ─ ─ ─ ┐  ┌────────┐                      │
│  │   🦊   │  │   🌸   │  │   🐰   │     🐼 ☁️     │   ➕   │                      │
│  │  HANA  │  │ HINATA │  │  PAPAI │  │   ANA   │  │  NOVA  │                      │
│  │📖 120  │  │📖 860  │  │📖 3    │   toque para  │ CRIANÇA│                      │
│  │▓▓▓░░░░ │  │▓▓▓▓▓▓░ │  │░░░░░░░ │  │  trazer │  └────────┘                      │
│  └────────┘  └────────┘  └────────┘  └ ─ ─ ─ ─ ┘                                  │
│                                                                                   │
│ [☁️ BUSCAR NA NUVEM] [🔄 ATUALIZAR AGORA] [✏️ ARRUMAR]        ☁️🟢 Tudo guardado   │
│ 🔑 Família tig••••                                                                │
└───────────────────────────────────────────────────────────────────────────────────┘
EM PÉ: 2 cartões por linha; a barra de botões fica embaixo, em 2 linhas se precisar.
```

**Cartões**
- **Crianças deste celular:** bichinho bem grande, nome e **uma linha de progresso do app** (cada app diz qual).
  - Exemplos: 📚 frases lidas · 🌍 curiosidades lidas · 📝 provas feitas · 📕 histórias · 🦉 textos lidos · 🔢 estrelas · 📖 último teste.
- **Crianças da família que estão na nuvem e não neste celular:** cartão com borda tracejada e ☁️ ("toque para trazer").
  - Só aparecem com internet. Tocar traz a criança com todo o progresso e entra.
  - Cartões de fichas antigas que mudaram de nome não aparecem (veja a T7).

**Botões**
- **➕ Nova criança** é o último cartão.
- **☁️ Buscar na nuvem:** lista completa da família, inclusive de outros apps (T6).
- **🔄 Atualizar agora:** envia o que está na fila e traz o que outro celular fez. Mostra "⏳ Atualizando…" e depois o resultado.
- **✏️ Arrumar:** liga o modo de arrumar (T7).
- No rodapé ficam a **bolinha com a frase** e a **família** (escondida: `tig••••`). Tocar na família abre **👨‍👩‍👧 Famílias neste celular** (T8).
- **⚙️ com a bolinha** no alto, antes do ⛶ (D17): abre as **Configurações do app** por cima (a T4 fica escondida, sem fechar, e volta quando elas fecham). O app informa `abrirConfig(aoFechar)` e `fecharConfig()` no adaptador (parte 5.2). Se o app não informar, a ⚙️ não aparece.
- Os cartões ficam **no meio** da tela (não grudados à esquerda), com o nome em até 2 linhas.

**Sem nenhuma criança** (família nova, ou todas foram tiradas):
- a tela mostra só **➕ Nova criança** (grande) e **☁️ Buscar na nuvem**;
- não dá para entrar no app sem ter pelo menos uma criança.

**Com 2 ou mais famílias** no celular, os cartões ficam em grupos, um título por família ("👨‍👩‍👧 Família tig••••"), e cada grupo tem o seu ➕.

### [T5] 🌟 Qual é o seu nome? (nova criança)

```
SEM TECLADO (deitado)                              COM TECLADO (deitado, ~170 px livres)
┌────────────────────────────────────────────┐     ┌───────────────────────────────────────────────┐
│          🌟 QUAL É O SEU NOME?               │     │ ← [ HANA                     ] [PRONTO! ✅]    │
│        ┌──────────────────────────┐          │     │  🦉  🦊  🐰  🐼  🦋  🐨  🐯  🐴               │
│        │ Digite o seu nome...      │          │     └───────────────────────────────────────────────┘
│        └──────────────────────────┘          │     ███████████████████ TECLADO █████████████████████
│          ESCOLHA O SEU BICHINHO:              │
│  🦉   🦊   🐰   🐼   🦋   🐨   🐯   🐴         │
│          VOCÊ ESCOLHEU: 🦊 RAPOSA             │
│     [← VOLTAR]        [PRONTO! ✅]            │
└────────────────────────────────────────────┘
```

As regras de hoje continuam:
- os 8 bichinhos numa linha só, nenhum já marcado;
- nome com até 14 letras, espaços sobrando são limpos;
- Enter só confirma se já tem bichinho.

O que muda:
- Sem o botão ☁️ nesta tela: a nuvem já está na T4. Isso deixa a tela mais limpa para a criança.
- **Mesmo nome + bichinho que já existe na nuvem:** o progresso volta sozinho (como hoje).
- **Mesmo nome com outro bichinho na família:** o app pergunta **"Já existe 🦊 HANA na família. É você?"** com **[🦊 Sou eu!]** e **[Não, sou outra criança]**. Isso evita duas fichas da mesma criança.
- **Passo próprio do app** (só depois do "Pronto ✅", no **mesmo estilo de cartão**):
  - 🔢 Matemática: "Qual é a sua turma?" (Tia Fabiana / Tia Irene);
  - 📖 Fluência: "Quantos anos você tem?" e "Em que ano da escola você está?".
  - Os outros apps não têm passo extra.

### [T6] ☁️ Buscar na nuvem

- Lista todas as crianças da família na nuvem. Para cada uma:
  - **bichinho + nome**, e os **apps onde ela aparece** (📚🔢📖🦉📝📕🌍);
  - se ela já está neste celular: "já está aqui — toque para juntar".
- Tocar **traz** a criança ou **junta** a nuvem com o celular. Nunca apaga o que está no celular.
- Embaixo fica **🗑️ Tiradas deste celular**: as crianças guardadas na lixeira do celular (veja a T7), com o botão **[↩️ Trazer de volta]**.
- Fichas antigas de quem mudou de nome aparecem só num cantinho "📦 Nomes antigos", para o adulto juntar se quiser.

### [T7] ✏️ Arrumar (mudar e tirar)

```
│ ✏️ ARRUMANDO — toque em ✏️ para mudar, 🗑️ para tirar deste celular      [✅ TERMINEI DE ARRUMAR] │
│  ┌────────┐✏️🗑️ ┌────────┐✏️🗑️ ┌────────┐✏️🗑️                                    │
│  │   🦊   │     │   🌸   │     │   🐰   │                                          │
```

**✏️ Mudar nome ou bichinho**
- Abre a T5 com o título "✏️ MUDAR NOME OU BICHINHO".
- Como hoje, a ficha nova recebe todo o progresso da antiga.
- O que muda:
  - a ficha antiga ganha o aviso `movidoPara` e para de aparecer duplicada;
  - nos **outros apps** (já atualizados), ao abrir, o adulto vê: **"🦊 Hana mudou para 🐰 Hana em outro app. Mudar aqui também?"** com **[Mudar]** e **[Agora não]**.

**🗑️ Tirar deste celular**
1. Pergunta: **"Tirar 🦊 HANA deste celular? O progresso dela continua guardado na nuvem e pode voltar em ☁️ Buscar na nuvem."** com **[Cancelar]** e **[🗑️ Tirar]**.
2. Antes de tirar, o app **atualiza a nuvem** e confere duas coisas: se não sobrou nada na fila daquela criança e se **tudo dela cabe na nuvem** (`completoNaNuvem`, parte 5.2).
   - **Tudo guardado e completo:** tira.
   - **Guardado, mas incompleto** (ex.: no Coruja Explica, os textos lidos mais antigos sobem sem o texto inteiro, por causa do limite de tamanho): tira **só com a cópia na lixeira do celular**.
   - **Sem internet ou erro:** **"⚠️ Ainda não dá para garantir: o progresso de HANA ainda não foi guardado na nuvem. Conecte na internet e espere a bolinha ficar 🟢."**
     - Só para o adulto (com a trava da D15), aparece **[Guardar uma cópia neste celular e tirar]**. A cópia vai para a lixeira do celular e pode voltar pela T6.
3. **Gravações de voz (Historinhas)** e qualquer outra coisa que não vai para a nuvem **não são apagadas**. Ficam guardadas e voltam se a criança voltar. Para isso, o app guarda a ligação "id antigo → nome + bichinho" (veja a ficha do Historinhas).
4. **Pode tirar todas.** Quando sai a última, a T4 mostra só "➕ Nova criança / ☁️ Buscar na nuvem". Não dá para entrar no app sem uma criança.

### [T8] 👨‍👩‍👧 Famílias neste celular (mais de uma família no mesmo celular)

```
┌──────────────────────── 👨‍👩‍👧 FAMÍLIAS NESTE CELULAR ────────────────────────┐
│  🔑 tig••••  (👁 mostrar)   🦊 HANA · 🌸 HINATA          🟢                     │
│  🔑 moreira•• (👁 mostrar)  🐯 JOÃO                      🟡 1 esperando          │
│                                                                                │
│  [➕ ENTRAR EM OUTRA FAMÍLIA]  [🌱 CRIAR OUTRA FAMÍLIA]  [🚪 TIRAR UMA FAMÍLIA]   │
└────────────────────────────────────────────────────────────────────────────────┘
```

- Cada criança pertence a **uma** família. A nuvem de cada uma vai para a pasta da família dela.
- Um código novo **acrescenta** uma família. Ele não troca a família das crianças que já estão no celular (resolve o problema 🔴 4).
- **👁 Mostrar:** mostra o código inteiro, depois da trava do adulto (D15). Resolve "esqueci o código".
- **🚪 Tirar uma família:** só do celular, com a mesma garantia da T7 para cada criança dela. A nuvem fica intacta. Se for a família "atual", o `nuvem_familia` passa a ser a próxima família que ficou.
- **Entrar ou criar outra família fica bloqueado nas primeiras 2 semanas** depois de publicar cada app (só libera com a trava do adulto e o aviso "depois disso, voltar à versão anterior do app não é mais seguro"). Veja a parte 6.
- Limite: **6 crianças por família** e **até 4 famílias** por celular (decisão D5). Crianças que já existem acima do limite (Matemática e Fluência não tinham limite) **continuam**; o limite só vale para cadastrar novas.

### [T9] Barra de cima: chip da criança + ⚙️ com bolinha (em todos os apps)

```
… barra do app …                      [ 🦊 HANA ] [⚙️●]  (⛶ e outros botões do app ficam onde já estão)
```

- **Chip da criança:** um círculo com o bichinho e o nome curto ao lado. Fica **sempre colado à esquerda da ⚙️** e aparece em **todas** as telas principais do app. Tocar leva para a **T4**.
  - Alfabetização: o chip pequeno embaixo da 🦉 vira o chip padrão.
  - Provinha: sai o "⬅".
  - Matemática: sai o "Trocar Jogador" do fim do mapa (pode continuar lá também).
  - Fluência: sai o "↔ Trocar leitor".
  - Historinhas: ganha chip.
- **⚙️ com bolinha:** em **todas** as telas que têm ⚙️, e a ⚙️ existe em todas as telas principais.
  - Matemática: o botão 👪 vira ⚙️. A "Área dos Pais" continua sendo o que abre.
- A **bolinha** sempre aparece (veja 4.11).

### 4.10 Configurações: a última seção é sempre "☁️ Família e nuvem"

As seções de cada app (aparência, som, tela, backup…) continuam em cima. **No fim**, igual em todos:

```
☁️ FAMÍLIA E NUVEM
[🟢]  Nuvem: Tudo guardado (às 14:32)                    [🔄 Atualizar agora]
👧   Crianças deste celular: 🦊 HANA · 🌸 HINATA          [👥 Trocar de criança] [✏️ Arrumar]
☁️   Buscar crianças na nuvem                             [▶]
🕘   Cópias de cada dia (de 🦊 HANA)                       [▶]
🔑   Família: tig•••• (👁 mostrar)                         [👨‍👩‍👧 Famílias ▶]
```

- As linhas antigas espalhadas são retiradas, para não ficarem em dobro: "Trocar leitora", "👧 Criança/Quem está usando", "Código da família", "Recuperar…", "Situação".
- **🕘 Cópias de cada dia** é a tela de hoje ("juntar um dia antigo com o atual, nada é apagado"), com o novo nome e só para o adulto.

### 4.11 A bolinha (regras iguais em todos)

| Bolinha | Quando | Frase (curta) |
|---|---|---|
| 🟢 verde | não tem nada esperando (inclusive sem internet, se tudo já subiu) | **Tudo guardado na nuvem (às 14:32)** |
| 🟡 amarela | tem coisa esperando para subir: enviando, preparando, ou sem internet com fila | **Guardando…** / **📴 Sem internet: 2 crianças esperando. Não limpe os dados do navegador.** |
| 🔴 vermelha | a nuvem **não está guardando** | **Falta o código da família** / **A nuvem deu erro: (motivo em português)** / **Nuvem desligada (falta o arquivo nuvem-config.js)** |

- A cor amarela é a mesma em todos os apps (hoje um diz "laranja" e outro "amarela").
- A bolinha é grande o suficiente para ver de longe: 14 px, com borda branca.

### 4.12 Teclado e tela deitada (regras de desenho)

1. **As telas de família e crianças nunca ficam dentro da área que gira.** Elas são colocadas direto na página, por cima de tudo. Funcionam deitado e em pé, sem girar à força (como já é a exceção do cadastro hoje).
2. **Pop-up do código e T5 com teclado aberto:**
   - o cartão fica **no meio** da parte visível da tela, entre o topo e o teclado (o app mede o espaço livre acima do teclado; versão 3 — antes ficava grudado no topo);
   - somem a explicação e o título grande;
   - campo e botão ficam **na mesma linha**;
   - o ✕ de cancelar fica no canto.
   - É o comportamento do Alfabetização, levado para todos.
3. **Medidas:** botões com pelo menos 48 px de altura; nenhuma letra abaixo de 14 px; bichinhos entre 30 e 62 px, sempre os 8 numa linha.
4. **Meta viewport** com `interactive-widget=resizes-content` em todos (já está nos 7), mais a medida do espaço livre para celulares que ignoram essa instrução.
5. **Matemática e Coruja Explica (usados em pé):** as mesmas telas funcionam em pé. A trava "Vire o celular!" da Matemática **não cobre** essas telas (hoje ela já não cobre o campo do nome; vale também para o código).
6. **Testes de tela:** 12 tamanhos (deitado, em pé, tablet e 5 com teclado aberto), conferindo que o campo, o botão e os 8 bichinhos ficam visíveis e tocáveis.
7. **Respiro e largura deitado (pedido do Pedro, 07/10/2026):** a maioria dos apps fica deitada. Pop-ups largos (o do código 560 px; perguntas 640 px; "🎉 Achei a sua família" até 960 px), 14 px ou mais entre botões, nada grudado no topo. **Já está no `escola-familia.js` 1.2** — os outros apps só precisam cuidar das telas **deles** (ex.: o pop-up de Configurações do app, que no Alfabetização ficou com até 980 px e 2 colunas deitado).
8. **Teclado aberto (corrige o item 2):** o cartão do código fica **no meio** da área entre o topo e o teclado (não grudado em cima), sem espaço vazio dentro dele. O campo **nunca muda de lugar** (mudar de lugar fecha o teclado); com a tela baixa só aparecem os botões pequenos ao lado dele.
9. **"🎉 Achei a sua família":** o pop-up cresce, esconde o campo e a explicação, mostra o código procurado, as crianças em grade (até 4 numa fileira; 5 ou 6 em 3 + 3; nomes compridos em 2 linhas, nunca cortados) e, embaixo e sempre à vista, **← OUTRO CÓDIGO · ESCOLHER · TRAZER TODAS**, com ✕ no canto.
10. **Tamanhos de referência:** o Motorola do Pedro deitado tem cerca de **984×432** (e 937×411) px de CSS. Testar sempre também 740×360, 640×360 e 568×320.

---

## 5. Como funciona por dentro (para o Claude que vai programar)

### 5.1 Arquivos compartilhados (iguais nos 7 apps)

| Arquivo | Versão | Muda? |
|---|---|---|
| `nuvem-config.js` | — | **Não.** É o do Pedro, byte a byte. |
| `escola-pwa.js` | v2 | **Não.** (A lista dos 8 bichinhos continua aqui.) |
| `nuvem-sync.js` | v3 → **4.1** (pronto, 07/10/2026) | **Já mudou** (5.3). Compatível com os apps que ainda estão na v3. Os outros 6 apps usam a **4.1 sem mudar**. |
| **`escola-familia.js`** | **1.2** (pronto, 07/10/2026) | Telas T1–T8, chip, bolinha, seção das Configurações, migração, regras de segurança, ⚙️ na T4. Os outros 6 apps usam a **1.2 sem mudar**. |

As cópias mestras e o md5 de cada uma estão em `compartilhados/` (com o `LEIA-ME_COMPARTILHADOS.md`) no zip do Alfabetização v123. **Antes de usar, confira o md5.**

As **cópias mestras** desses arquivos devem ficar numa pasta `compartilhados/` no GitHub e nos documentos do projeto. Quem mudar um deles sobe a versão, e o Pedro leva a cópia nova para os outros apps quando chegar a vez de cada um.

### 5.2 `escola-familia.js`: o que o app informa (adaptador)

```js
EscolaFamilia.iniciar({
  app: 'alfabetizacao',              // mesmo ID da nuvem
  nomeApp: 'Esforço Vence',
  iconeApp: '📚',
  maxPorFamilia: 6,
  criancas: {                         // o app traduz para o jeito dele de guardar
    listar()            { return [{id, nome, av}] },         // crianças deste celular
    atual()             { return id|null },
    criar(nome, av)     { return id },                       // cria sem herdar nada
    mudar(id, nome, av) { /* troca nome/bichinho */ },
    exportar(id)        { return {chave: valor} },           // para a lixeira local (igual ao da nuvem)
    importar(id, dados) { /* devolve da lixeira (junta, não substitui) */ },
    tirar(id)           { /* apaga SÓ as chaves de progresso deste app; nunca gravações locais sem cópia
                              ORDEM OBRIGATÓRIA (senão a vigia do nuvem-sync marca pendência ou sobe {} por cima da nuvem):
                              1) garantirGuardado(id) deu true, ou a cópia já está na lixeira;
                              2) no mesmo passo: tira da lista PRIMEIRO, depois apaga as chaves com a vigia desligada;
                              3) limpa a pendência e o meta daquele id; exportar() de criança que não existe lança erro */ },
    completoNaNuvem(id) { return true /* Coruja Explica: false se algum texto lido subiu cortado */ },
    entrar(id)          { /* troca e abre o app (pode recarregar a página, ex.: Alfabetização) */ },
    resumo(id)          { return {linha:'📖 120 frases', barra:0.35} },
    chavesDaCrianca(id) { return [/* TODAS as chaves deste id: as da nuvem E as do backup (ex.: Curiosidades ultimoDia/seqDias) */] }
  },
  passoExtra: null | function(id){ return Promise },   // Matemática: turma; Fluência: idade e ano
  aoAbrirTelas() { /* pausa voz, timers etc. */ },
  aoFecharTelas() {},
  fonte: () => '…',                    // opcional: a letra do app (só a fonte; cores e tamanhos não mudam)
  abrirConfig(aoFechar) { /* 1.2, opcional: abre as Configurações do app e chama aoFechar() quando elas
                             (e o que foi aberto a partir delas) fecharem → aparece a ⚙️ na T4 */ },
  fecharConfig() { /* 1.2, opcional: fecha as Configurações (o adulto tocou numa opção que abre tela do módulo) */ }
});
EscolaFamilia.montarChip(elementoNaBarra);      // chip padrão
EscolaFamilia.montarPonto(botaoEngrenagem);     // bolinha padrão na ⚙️
EscolaFamilia.montarSecaoConfig(elementoFimDasConfiguracoes);
EscolaFamilia.abrir('quem');                    // abre a T4 (também: 'inicio', 'nova', 'mudar', 'nuvem', 'familias', 'copias', 'codigo', 'boasvindas')
EscolaFamilia.familiaDe(id) / .estaAberto() / .fecharTopo()  // para o botão voltar do Android
// também existem (1.2): versao, TEXTOS, abrirInicio(), paraNuvem(lista), familiaAtual(), familias(),
// atualizar(tudo), situacao() → {cor, txt}, fecharTudo(), toast(msg)
```

**Como ficou no Alfabetização (modelo):** veja `ADAPTADOR_CRIANCAS` e o bloco "liga o cadastro da família, a nuvem e o escola-pwa.js" no fim do `index.html` da v123. O `usuarios()` do `NuvemSync.iniciar` usa `EscolaFamilia.paraNuvem(lista)` (põe `fam` e `segurar` em cada criança).

A ligação com a nuvem continua sendo do app (`idDaChave`, `exportar`, `mesclar` não mudam). A única diferença é que `usuarios()` passa a dizer a família de cada criança:

```js
NuvemSync.iniciar({ app, idDaChave, exportar, mesclar,
  usuarios: () => adaptador.listar().map(u => ({...u, fam: EscolaFamilia.familiaDe(u.id)})) });
```

**Estilo:**
- O módulo traz o próprio CSS (com prefixo `ef-`, para não brigar com o app) e uma paleta única: cartão creme `#fffdf7`, tinta `#123a63`, verde `#2fb35a`, amarelo `#f0a030`, vermelho `#e23b3b`.
- O app pode passar **só** a fonte (`fonte:'…'`). Cores, tamanhos, textos e ordem não mudam de app para app.
- Telas presas direto no `<body>`, `z-index` acima do app e abaixo do convite de instalar do `escola-pwa.js`.

### 5.3 `nuvem-sync.js` v4 (hoje 4.1): só o necessário

**O que NÃO muda:**
- caminhos;
- formato do documento;
- `chaveUsuario`;
- `normalizaFamilia`;
- envio seguro com trava de versão;
- cópias diárias;
- fila;
- `mesclar`.

**O que muda:**
1. **Família por criança:** `usuarios()` pode trazer `fam`. Se não trouxer, usa a família do celular, como na v3. `pastaUsuarios(fam)` e `docApp(uk, fam)` recebem a família.
2. `existeFamilia(codigo)` → `{existe, criancas:[…]}`. Lê `familias/{c}/usuarios?pageSize=300`. As regras atuais já permitem: é o mesmo que o `listarUsuarios` faz hoje.
3. `listarUsuarios(fam)` devolve também `apps` (já devolve), `movidoPara` e `oculta` (se existirem).
4. `garantirGuardado(id)` → Promise\<boolean>. Sincroniza agora e só devolve `true` se a criança **não tem nada na fila** e o último envio dela deu certo. É usado antes de tirar do celular.
5. `pendente(id)` → boolean.
6. `marcarMovido(fam, chaveAntiga, chaveNova)`. Usa `PATCH` com `updateMask.fieldPaths=movidoPara` **e `currentDocument.exists=true`** no documento da ficha antiga (sem isso, o PATCH criaria uma ficha vazia, e os apps na v3 mostrariam uma criança "? 🙂"). As regras atuais já permitem (`update`). Apps na v3 nunca mexem nesse campo. Regras:
   - **só marca depois** que a ficha antiga foi juntada com sucesso na nova. Sem internet, a mudança fica pendente e o `movidoPara` só é gravado quando a junção der certo;
   - a mudança de nome é feita **num app**, mas a ficha antiga tem dados de **outros apps** (`apps/X`). Por isso, ao trazer a criança para o app X, se a ficha antiga tiver `apps/X`, ele é **juntado automaticamente** na ficha nova. A ficha antiga só some da lista quando os apps da nova cobrem todos os da antiga;
   - **sem ciclo:** ao marcar A → B, a ficha B recebe `movidoPara:""` (vazio). Quem segue a cadeia para numa ficha já visitada.
7. `normalizaFamilia` exportada, para o módulo usar a mesma regra.
8. A fila de quem foi tirado do celular **não é descartada em silêncio**. Se ainda tiver pendência, o módulo não deixa tirar (veja a T7). Nada se perde.
9. `status()` ganha `porFamilia` (pendências por família) para a T8.
10. **Família não conferida não recebe nada.** Enquanto a família estiver com `conferida:false` (T2 ou T3 feitas sem internet), a fila espera. Quando a internet volta, o `existeFamilia` roda primeiro:
    - T2 e o código **não existe**: pergunta ao adulto antes do primeiro envio ("Não achei essa família. Conferir o código ou criar uma família nova com ele?");
    - T3 e o código **já existe**: pergunta ao adulto antes do primeiro envio ("Esse código já tem crianças. É da sua família?").
11. **Todas as funções que hoje usam a família global recebem a família:** `recuperar`, `listarVersoes`, `juntarVersao`, `checarNuvem`, `baixarDoc`, `listarUsuarios`. O `definirFamilia` da v3 (que muda a família de todas as crianças) **não é usado** pelo módulo.
12. **Prioridade da família:** família da criança (`escola_familia`) > `nuvem_familia`. O `codigoDaFamilia` do `nuvem-config.js` (hoje vazio) só vale para criança sem família. Se um dia ele for preenchido, ele **não** passa por cima da família de cada criança.
13. **Mesmo nome + bichinho duas vezes no mesmo celular e na mesma família** (caso D da parte 6): a segunda **não envia** (fica 🟡) até o adulto resolver, porque as duas iriam para a mesma ficha e uma gravaria por cima da outra.
14. **(4.1, 07/10/2026) Resposta da nuvem atrasada:** antes de juntar (`mesclar`) o que veio da nuvem, confere **na hora** se a criança ainda está na lista do app. Se ela saiu do celular enquanto a nuvem respondia, não junta e não envia (`recuperar` e `juntarVersao` devolvem `false`). Sem isso, as chaves de uma criança tirada voltavam a ser gravadas — e, nos apps em que o id é o nome (Matemática, Fluência), a próxima criança com o mesmo nome herdaria o progresso dela. **Recomendado também no app:** o `mesclar` não grava nada para um id que não está na lista (no Alfabetização: `nuvemMesclar`).
15. **Se a lista de crianças do app der erro**, o envio para e **não mexe na fila** (`usuariosParaEnviar`).
16. ⚠️ **O `mesclar` do app nunca pode dar erro no meio:** se ele lançar um erro, o `nuvem-sync.js` engole e segue — e o envio pode subir os dados deste celular sem a junção. Proteja cada campo (no Alfabetização, o `nuvemMesclar` trata cada chave com `try/catch` e leitura segura de JSON) e teste o `mesclar` com dados estragados.
17. ⚠️ **Regra nova para quem liga um app na 4.1:** a criança tem que estar na lista do app (`usuarios()` / `listar()`) **ANTES** de qualquer junção que passe pelo `nuvem-sync.js` (`recuperar`, `juntarVersao`, envio) — e, se o `mesclar` do app também conferir a lista (recomendado), antes de **qualquer** junção (backup que junta, lixeira, trazer da nuvem). Ou seja: **primeiro cria/acrescenta a criança na lista, depois junta.** Se a ordem for a contrária, a junção não grava nada e não avisa. No Alfabetização é assim: `criar()` põe a criança em `PERF.perfis` antes do `recuperar`; o `aplicarBackup` acrescenta a criança antes do `nuvemMesclar`; o `importar()` da lixeira é chamado com a criança já criada.

**Compatibilidade:**
- Cada app leva a sua cópia no próprio zip. Enquanto um app não for migrado, ele continua com a v3 e funciona igual.
- O documento na nuvem é idêntico, então v3 e v4 leem e gravam a mesma coisa.

### 5.4 Onde as coisas ficam guardadas (no celular, por app)

- **Novo:** `escola_familia` = `{v:1, familias:[{c, desde, conferida:true|false}], criancas:{<id do app>: <código>}, atual:<código>, ultimoNuvemFamilia:<código>, primeiraAberturaEm:<data>, liberouSegundaFamilia:false, mudancasPendentes:[{fam, chaveAntiga, chaveNova}]}`.
  - `ultimoNuvemFamilia`: o último `nuvem_familia` visto pela versão nova (caso H da parte 6);
  - `primeiraAberturaEm`: a data da primeira abertura da versão nova, para o bloqueio de 2 semanas da 2ª família;
  - `mudancasPendentes`: mudanças de nome ou bichinho que ainda vão marcar o `movidoPara` (parte 5.3, item 6).
- **Novo, só no Historinhas:** `escola_gravacoes_historinhas` = `{<id antigo>: <chave nome_bichinho>}`, a ligação das gravações de voz de quem foi tirado do celular.
- **Novo:** `escola_lixeira_<app>` = lista de `{id, nome, av, fam, quando, dados}`. Fica até a criança voltar ou o adulto esvaziar. Se não couber na memória, **não tira** a criança.
- **Mantido e atualizado:** `nuvem_familia` = a família "atual". Assim, se for preciso voltar ao zip antigo, ele continua funcionando.
- **Não mexe (na migração):** as listas de cada app (`ev_perfis`, `corujasProfiles`, `corujaFluenciaPerfis`, `explica_usuarios`, `provinha_usuarios`, `coruja_perfis`, `mundo_usuarios`) e todas as chaves de progresso.

### 5.5 Campos novos na nuvem (opcionais; nenhuma regra muda)

| Documento | Campo | Para quê |
|---|---|---|
| `familias/{c}/usuarios/{chaveAntiga}` | `movidoPara: "hana_1f430"` | Esconde a ficha antiga duplicada e avisa os outros apps da mudança de nome ou bichinho |
| `familias/{c}/usuarios/{chave}` | `oculta: true` (**NÃO implementar agora**: a D3 aprovou só a opção (a). Fica reservado para o futuro) | "Tirar da família": esconde da lista sem apagar nada |

---

## 6. Migração sem perder nada (o que acontece na primeira abertura da versão nova)

| Situação no celular | O que a versão nova faz | Tela |
|---|---|---|
| **A)** Tem `nuvem_familia` e crianças (é o seu caso nos apps com nuvem) | Cria `escola_familia` com essa família, liga todas as crianças a ela e confere na nuvem em segundo plano | T4 direto, com aviso "🔑 Família tig•••• — tudo certo ✅" |
| **B)** Tem crianças, mas nunca digitou o código neste app | Mantém tudo. A bolinha fica 🔴. Quando o adulto entra (T2) ou cria (T3) uma família, **as crianças que já estavam no celular passam a ser dessa família** (a tela diz isso antes de confirmar) | T1 com a lista "Este celular já tem…" e "Agora não ›" |
| **C)** Não tem nada (instalação nova) | — | T1 |
| **D)** Duas crianças com o mesmo nome + bichinho na mesma família (pode acontecer no Fluência) | **Não junta sozinho.** As duas continuam, a segunda **não envia** (🟡) e o adulto vê o aviso "HÁ DUAS 🦉 HINATA: JUNTAR?" | aviso no "Arrumar" |
| **E)** Criança com bichinho antigo (👧 🌸 🐧 …) | Continua igual, mesma ficha na nuvem | — |
| **F)** A nuvem tem `movidoPara` para uma criança deste celular | Pergunta se quer seguir a mudança (T7) | aviso para o adulto |
| **G)** Tem `nuvem_familia`, mas nenhuma criança (o Provinha e a Matemática deixam apagar todas) | Cria `escola_familia` com essa família, sem crianças | T4 só com "➕ Nova criança / ☁️ Buscar na nuvem" |
| **H)** Voltou ao zip anterior e depois à versão nova (crianças criadas na versão antiga ficaram sem família; o código pode ter sido trocado lá) | **A reconciliação roda em toda abertura e pode rodar quantas vezes for preciso sem estragar nada:** criança sem família ganha a família do `nuvem_familia`; se o `nuvem_familia` mudou desde a última abertura da versão nova, ele vence | T4 |

O que fica garantido:
- Nada é apagado ou renomeado no celular.
- A primeira atualização sobe tudo o que já existe, como a v3 já faz.
- **Voltar ao zip anterior:** como `nuvem_familia` e as listas antigas continuam, o app antigo abre como antes.
  - ⚠️ Se nesse meio-tempo uma **segunda família** tiver sido colocada no celular, o app antigo mandaria todas as crianças para uma família só. Por isso, **o próprio app bloqueia** "entrar ou criar outra família" nas primeiras 2 semanas depois de publicar (T8). Não é só um conselho.

---

## 7. Ficha de cada app (o que muda em cada um)

### 📚 Alfabetização (Esforço Vence) v121: **o primeiro** — ✅ IMPLANTADO (v122 → v122b → **v123**, 07/10/2026)

> **Estado:** pronto e aprovado pelo Pedro. Site de teste `escolasaopedrotestes.netlify.app` (família de teste `pmrtestes`); v123 entregue para o site de verdade. Tudo o que está abaixo foi feito e testado (651 verificações na v122b; ver o `HISTORICO_E_PLANO_alfabetizacao.md`, capítulos 3.10 a 3.12). Use este app como **modelo**: o `ADAPTADOR_CRIANCAS`, a ligação no fim do `index.html` e os testes `testes/testes_navegador/` (`fakefb.py`, `ef.py`, `teste_familia.py`, `teste_revisao.py`, `teste_desenho.py`, `teste_v123.py`).

- **Troca:**
  - `#homeOv`, `#npOv`, `#nuvemOv` e `#codOv` saem; entram as telas do módulo;
  - "👯 Trocar leitora" e as 3 linhas de nuvem saem das Configurações; no fim entra a seção padrão;
  - o chip `#curName` (embaixo da 🦉, 64 px) vira o chip padrão ao lado da ⚙️.
- **Fica:**
  - o pop-up "▶ Continuar de onde parei / 🏠 Menu" depois de escolher a criança;
  - "Nomes da família" (parentes), pedido logo depois de cadastrar criança nova (decisão D9 sobre o nome);
  - o backup, que **passa a juntar** em vez de substituir (`aplicarBackup` hoje apaga tudo; D14).
- **Cuidados:**
  - o prefixo por criança (`hana_*` para a leitora "1", `<id>_hana_*` para as outras) **recolocado por cima** da vigia do `nuvem-sync.js` (a ordem não pode mudar);
  - `entrar(id)` usa `location.reload()` como hoje;
  - `tirar(id)` apaga só as `CHAVES_LEITORA` com o prefixo certo, usando `_rawRemove`;
  - testar com a Hana (id "1", chaves sem prefixo) e com uma criança "p…";
  - **"Hana fantasma":** hoje, se o `ev_perfis` tiver a lista vazia, o `carregarPerfis` acha que é a primeira vez e recria a criança "1" a partir da chave `hana_idx`. Sem criança atual, a vigia usa o prefixo vazio, e o `saveState` volta a gravar `hana_*`. Essa "Hana 👧" sobe pelo mesmo celular e grava por cima da ficha antiga dela na nuvem. Hoje não acontece porque o app não deixa apagar a última; o plano deixa ("pode tirar todas"). Corrigir:
    - o `carregarPerfis` respeita um `ev_perfis` que existe com a lista vazia;
    - sem criança atual, nada grava em chaves `hana_*` sem prefixo;
    - teste: tirar todas, abrir o app 2 vezes, e nenhuma criança aparece;
  - **marca `hana_abrirhub`:** o `trocarPerfil` grava essa marca antes de recarregar, para pular a tela inicial. Com a D2 ("sempre abre na T4"), o módulo **tem que respeitar essa marca** depois do `entrar(id)`. Senão entra num laço: T4 → recarrega → T4.
- **Testes de hoje:** os 310 continuam passando.

### 🌍 Curiosidades: base **v1.8** (a publicada). A v1.9 entra **depois**
- **Decisão do Pedro:** o novo cadastro é implantado em cima da **v1.8, a versão publicada hoje**. As novidades da v1.9 só são aplicadas **depois** que o novo cadastro estiver publicado e conferido, numa entrega separada.
- **O que a v1.9 traz** (lido no código; a conversa do Curiosidades confirma a lista completa no histórico):
  - "▶️ continuar de onde parei", numa faixa no topo dos Cantinhos Especiais;
  - placar e dica no desafio;
  - 🔥 dias seguidos contando só os dias em que a criança **leu** (mesmas chaves `ultimoDia`/`seqDias`);
  - "ler ao tocar" (🔊) lembrado por criança: **chave nova `sayTap`**, que entra na lista de chaves por criança;
  - arrastar o dedo e setas do teclado para passar de curiosidade;
  - karaokê sincronizado com a voz (`speak(texto, opts)` com `onboundary`);
  - marcos e selos novos (a chave `marcos` **já sobe** para a nuvem desde a v1.8; muda só o conteúdo);
  - busca mais rápida (indexada) e as "últimas lidas" montadas com `textContent`;
  - a tecla **Esc** chama `fecharCodigoFamilia()`, que **sai** com o novo cadastro: na v1.9 aplicada depois, ela vira `EscolaFamilia.fecharTopo()`;
  - o backup confere o arquivo inteiro antes de importar: exige pelo menos 1 criança e ids `p…`. Isso **choca** com "pode tirar todas" e com a regra de juntar, e precisa ser ajustado quando a v1.9 for aplicada.
- **Ao aplicar a v1.9 depois do cadastro:**
  - a chave `sayTap`: a v1.9 **já** a coloca nas listas `CHAVES_DADOS` e da nuvem. Conferir que o adaptador (`chavesDaCrianca`, `exportar`, `tirar`) e a lixeira também a incluem;
  - **já na v1.8:** `ultimoDia` e `seqDias` estão na lista da nuvem (`CHAVES_NUVEM`), mas não na do backup (`CHAVES_DADOS`). O `chavesDaCrianca` do adaptador usa as **duas** listas juntas, senão tirar, a lixeira e o backup perdem os dias seguidos;
  - a validação de backup da v1.9 tem que respeitar a regra nova de **juntar**, sem `alert`;
  - os testes do cadastro precisam continuar passando, e a entrega passa pelo mesmo protocolo da parte 9-A.
- **No cadastro (em cima da v1.8):**
  - troca as telas `#users`, `#novoUser`, `#nuvemTela` e `#codigoOv`, o chip e a seção de nuvem das Configurações;
  - `apagarUser` com `confirm()` sai, e a regra "pelo menos 1" sai;
  - o backup passa a **juntar** em vez de substituir (problema 🔴 6, decisão D13 aprovada), sem `alert`/`confirm`.

### 🦉 Coruja Explica v3.1
- Troca as telas `telaUsuarios`, `telaCadastro`, `telaNuvem` e `codOv`.
- A seção "👧 Quem está usando" sai do **topo** das Configurações; tudo vai para o fim.
- **Cuidado:** a navegação pelo botão voltar (`popstate`, "duas vezes no histórico") precisa chamar `EscolaFamilia.fecharTopo()` antes.
- Hoje a ⚙️ e o chip só existem na tela inicial; precisam ir para as outras telas principais.
- **Textos cortados na nuvem:** o `montarExportacao` (limite `LIMITE_NUVEM_BYTES = 850000`) sobe os textos lidos mais antigos sem o texto inteiro. O `completoNaNuvem(id)` devolve `false` quando algum texto subiu cortado, e aí tirar a criança só acontece com a cópia na lixeira (T7).

### 📝 Provinha v30
- Troca `#screen-profile`, `#novoUser`, `#screen-nuvem` e `#codOv`.
- O chip "⬅ 🦊 Nome" vira o chip padrão. O pop-up próprio `pergunta()` continua para o resto do app.
- **Cuidado:**
  - tudo que é do módulo fica **fora** do `#app-rot`;
  - a migração do histórico antigo `provinha:history` (por nome) continua funcionando ao criar ou trazer uma criança.
- Histórico grande (perto de 1 MB por criança) já tem aviso: manter.

### 📕 Historinhas v68
- Troca `perfisTela`, `novoPerfilTela`, `nuvemTela` e `familiaVeu`. A tela "Olá! Vamos começar a ler?" (`boasVindas`) **continua** como o passo do app depois de escolher a criança.
- **Precisa de ⚙️ com bolinha** (hoje a bolinha está só dentro das Configurações) e do chip.
- **Cuidados:**
  - **as gravações de voz (IndexedDB) nunca são apagadas ao tirar uma criança.** Hoje elas ficam presas ao **id local** da leitora (`chaveReconto(perfilId, …)` e o índice "perfil"). Uma criança trazida de volta ganha outro id, então "religar pela nuvem" não funciona sozinho. Correção: ao tirar, guardar `{id antigo → nome + bichinho}`; ao trazer de volta a mesma criança, **reusar o id antigo** (ou mudar a chave das gravações para o id novo, sem apagar nada);
  - os `confirm()` de apagar, juntar versão e backup saem;
  - o pop-up do código não pode ficar dentro do `#app` girado;
  - bichinhos antigos (fora dos 8 oficiais) continuam valendo.
- **Obrigatório (D13 aprovada):** o backup passa a juntar, sem `confirm`.

### 🔢 Matemática (cache v12) — usada **em pé**
- Troca `showProfilePicker`, `showNewProfileForm`, a tela de nuvem e o modal do código, todos dentro do `#start-overlay`.
- O botão 👪 vira ⚙️ com bolinha.
- O chip entra no cabeçalho.
- O "Qual é a sua turma?" vira o **passo extra** no estilo do módulo.
- **Cuidados:**
  - o id da criança é o nome sem acento (`hinata`), e o progresso fica em `corujasMathDataV4_<id>`;
  - `selectProfile` reinicia o estado do jogo (o `entrar(id)` usa ela);
  - a trava "Vire o celular!" não pode cobrir as telas do módulo;
  - o código da nuvem antiga ("Código Mágico", `COLE_AQUI`) pode sair numa limpeza à parte. Não é obrigatório, porque não faz nada.
- Hoje não tem limite de crianças: as que existem continuam.
- **Backup:** o `confirmImportBackup` apaga todas as chaves `corujas*` e grava o arquivo por cima. Passa a juntar (D14).
- **"Modo Brincar 🎈":** esse perfil especial sobe para a nuvem e apareceria como criança nos outros apps e contaria no limite. Ele **fica fora** da lista do módulo, da nuvem e do limite.
- A conferência "mesmo nome + bichinho" hoje é só no celular; passa a ser **na família** (T5).

### 📖 Fluência v1.4 — o que mais muda
- **Ganha o que não tinha:** trazer da nuvem na 1ª abertura, buscar na nuvem, mudar nome/bichinho, tirar do celular, cópias de cada dia.
- **Cadastro:**
  - deixa de marcar 🦉 sozinho;
  - passa a impedir nome + bichinho repetido;
  - idade e ano viram o **passo extra**.
- O "👤 Perfil" do leitor continua para idade, ano e nível.
- **Cuidados:**
  - o módulo fica **fora** do `#giro` (que gira tudo quando o celular está em pé);
  - o "perfil ativo" hoje não é lembrado ao fechar o app, então o `atual()` precisa ser guardado;
  - os ids são o nome sem acento, e há chaves `corujaFluenciaTestes_`, `…PseudoTestes_`, `…FrasesTestes_` e `…TextosUsados_` por criança.

---

## 8. Ordem de implantação e como testar sem arriscar o app das meninas

### 8.1 Antes de tudo: as conversas novas (passagem)
Você cola o **PROMPT_HANDOFF_APPS.md** em cada conversa atual. Cada uma devolve:
- o histórico e plano;
- o prompt de continuação;
- o zip completo.

Cada passagem também passa pela **checagem em 3 etapas** (está no próprio prompt de passagem, versão 3): autochecagem, 1 agente conferente independente (pacote e histórico) e um revisor-chefe.

Depois disso, cada app passa a ser trabalhado numa **conversa nova**.

### 8.2 Ordem sugerida

| Etapa | App | Por quê |
|---|---|---|
| 1 | 📚 **Alfabetização** ✅ (v123) | você pediu; é a referência do teclado; e é onde nasceram o `escola-familia.js` (hoje 1.2) e o `nuvem-sync.js` v4 (hoje 4.1) |
| 2 | 🌍 Curiosidades | é o modelo do padrão atual, o mais parecido com o Alfabetização |
| 3 | 🦉 Coruja Explica | já tem as mesmas telas do modelo |
| 4 | 📝 Provinha | mesmas telas, com o cuidado da rotação |
| 5 | 📕 Historinhas | gravações de voz e `confirm()` a tirar |
| 6 | 🔢 Matemática | em pé, turma, cabeçalho diferente |
| 7 | 📖 Fluência | é o que mais muda (decisão D10) |

Cada app **só começa depois** que o anterior estiver publicado e conferido por você.

### 8.3 Como testar a sincronização **sem publicar por cima do app que funciona**

1. **Testes automáticos** com um "Firebase de mentira" (como já é feito), com dois e três "celulares", duas famílias, sem internet, conflitos e tirar ou trazer criança.
2. **Site de teste no Netlify.** Um site separado. O app reconhece como site de teste **qualquer endereço com a palavra "teste"** (o do Pedro para o Alfabetização foi `escolasaopedrotestes.netlify.app`); lá aparece a faixa roxa "🧪 SITE DE TESTE" nas telas da família e só são aceitos códigos que **contenham** "teste". Cada app pode usar o seu site de teste (ex.: `escolasaopedrocuriosidadestestes.netlify.app`) ou o Pedro pode publicar no mesmo site de teste, um app de cada vez.
   - É outro endereço, então o celular guarda os dados dele **separados** do app de verdade. O app das meninas não é tocado.
   - Usa o **mesmo Firebase**, sem mudar nada nele.
   - Os testes usam uma **família de teste** (a do Pedro: **`pmrtestes`**), que fica numa pasta própria e não se mistura com a família de verdade.
   - ⚠️ **NUNCA digite o código da família de verdade no site de teste.** A versão nova do app ainda não foi aprovada e poderia gravar na família das meninas. Use só o código de teste.
   - ⚠️ **A cada zip novo, suba o nome do cache do `sw.js`** (ex.: `-v122`, `-v122b`, `-v123`). Com o mesmo nome, o celular continua mostrando a versão anterior.
   - Dá para testar com 2 celulares de verdade: "Já tenho cadastro", trazer criança, tirar do celular, duas famílias, sem internet etc.
3. **Teste da migração com os dados reais**, sem risco: você exporta o backup do app atual, e o Claude roda a migração nesse retrato nos testes automáticos. Opcionalmente, também no site de teste. O backup de hoje **não leva** `nuvem_familia` nem os dados da nuvem (e o Fluência nem tem backup). Por isso, o Claude completa o retrato com esses dados (casos A, B e G) ou entrega uma página simples que copia **todas** as chaves daquele app.
4. **No dia de publicar:**
   - **só publique** se o `RELATORIO_CHECAGEM` disser **"✅ Pode publicar"** (parte 9-A);
   - em cada celular, abra o app atual e espere a **bolinha verde**: tudo está na nuvem;
   - **exporte o backup** e guarde o **zip anterior**;
   - publique;
   - abra e confira a lista "Conferir depois de publicar" que virá na entrega.
   - ⚠️ **Nunca use "Importar backup" das versões de hoje como "desfazer"**: elas substituem tudo e sobem por cima da nuvem (problema 🔴 6). O backup é só uma garantia guardada.
5. **Se algo der errado:** publique de novo o zip anterior. A migração não apagou nada, então volta como estava (com o cuidado da 2ª família, parte 6).

---

## 9. Testes obrigatórios (para cada app)

- ⬜ Todos os testes antigos do app continuam passando (nada do que funcionava quebrou).
- ⬜ T1 a T9: textos **exatamente** iguais aos da tabela única (parte 3-A), nos 7 apps. Um teste compara o texto das telas com o objeto `TEXTOS`.
- ⬜ 12 tamanhos de tela (deitado, em pé, tablet e 5 com teclado):
  - campo e botão visíveis;
  - 8 bichinhos numa linha, inteiros e tocáveis;
  - nenhuma letra abaixo de 14 px.
- ⬜ Nenhum `alert` / `confirm` / `prompt` do navegador (o teste falha se aparecer).
- ⬜ Código que existe: acha e mostra as crianças. Código errado: avisa. Variante sem tracinho: sugere. Sem internet: guarda "a conferir".
- ⬜ Código já usado ao criar: avisa. Código livre: cria e pede "anote".
- ⬜ Duas famílias no mesmo celular: cada criança sobe para a pasta da sua família. Trocar de família não move ninguém.
- ⬜ Tirar criança:
  - com nuvem em dia, tira;
  - com fila, não tira (ou só com a cópia na lixeira);
  - a lixeira devolve tudo;
  - tirar a última obriga a cadastrar.
- ⬜ Mudar nome/bichinho:
  - a ficha nova recebe tudo;
  - a antiga ganha `movidoPara` e some da lista;
  - o outro app pergunta se quer seguir a mudança.
- ⬜ Migração (casos A a H da parte 6) com retratos dos dados reais: as listas de crianças e **todas** as chaves de progresso continuam idênticas, byte a byte. **Exceções** (chaves que mudam sozinhas e ficam fora dessa comparação): `nuvem_familia` (atualizada de propósito), as filas `nuvem_*_pendentes` e os `_meta`/`dispositivo` do `nuvem-sync.js`.
- ⬜ Tirar todas as crianças e abrir o app 2 vezes: nenhuma criança aparece ("Hana fantasma" do Alfabetização).
- ⬜ Alfabetização: tirar todas na versão nova → voltar ao zip anterior (v121) → abrir 2 vezes → nenhuma "Hana 👧" aparece e nada sobe para a ficha `hana_👧`. Se aparecer, a versão nova não pode deixar "tirar todas" antes de o risco de voltar ao v121 acabar (as 2 semanas).
- ⬜ Importar backup **junta** (não apaga o progresso mais novo) nos apps da D13 e da D14.
- ⬜ Voltar ao zip anterior depois da migração: abre com tudo.
- ⬜ Bolinha: verde, amarela e vermelha nas situações da tabela 4.11, em todas as telas com ⚙️.
- ⬜ Botão voltar do Android fecha primeiro o pop-up, depois a tela do módulo.
- ⬜ App abre sem internet (service worker com o `escola-familia.js` na lista de arquivos).
- ⬜ `nuvem-config.js` igual, byte a byte; `escola-pwa.js` v2 igual; `nuvem-sync.js` **4.1** e `escola-familia.js` **1.2** iguais às cópias mestras (md5).
- ⬜ **Desenho deitado** (parte 4.12, itens 7 a 10): teclado com o cartão no meio; "Achei" com 1, 3 e 6 crianças e nomes compridos; Configurações do app usando a largura; nos tamanhos 984×432, 937×411, 740×360, 640×360, 568×320 (modelo: `teste_desenho.py` do Alfabetização).
- ⬜ ⚙️ na T4 abre e fecha as Configurações do app (modelo: `teste_v123.py`, parte 1).
- ⬜ Resposta atrasada da nuvem depois de tirar a criança não regrava nada (modelo: `teste_v123.py`, parte 2).
- ⬜ Protocolo de checagem da parte 9-A completo, com o relatório dentro do zip.

---

## 9-A. Protocolo de checagem: nada é entregue sem passar por aqui

**Versão 3 (07/10/2026, pedido do Pedro):** 3 etapas — **autochecagem**, **1 agente conferente independente** e **revisor-chefe**. Vale para **toda** entrega deste plano: cada app, o site de teste, o zip final, e também a aplicação da v1.9 do Curiosidades. **Modelo indicado:** Sonnet 5.5, esforço **alto** (para revisar a migração ou o `nuvem-sync.js`, o esforço mais alto disponível).

### Etapa 1: autochecagem (feita por quem programou)

1. **Matriz "pedido → prova".** Uma tabela com cada item deste plano que vale para o app (telas T1–T9, palavras da parte 3, regras de ouro, ficha do app na parte 7, testes da parte 9, decisões D1–D18). Para cada item: **onde está no código** (arquivo e função), **qual teste prova** e o **resultado**. Item sem prova fica ⬜, nunca ✅.
2. **Rodar de verdade:**
   - `node --check` em todo JavaScript;
   - todos os testes antigos e os novos;
   - os tamanhos de tela com o navegador sem tela (Playwright/Chromium), **olhando as capturas**;
   - a migração nos retratos dos dados (backup do Pedro, se ele mandou), conferindo byte a byte as chaves antigas.
   - **Prova de que o teste novo pega o problema:** rodar o teste novo também na versão **anterior** e ver que ele falha lá.
3. **Conferir o zip:** abrir o zip pronto e listar tudo; `nuvem-config.js` byte a byte igual ao do Pedro; `sw.js` com o cache novo e com `escola-familia.js` na lista; cópias mestras com o md5 certo.
4. Escrever o que foi **rodado** e o que foi só **lido**. O que só o celular de verdade mostra (teclado real, TV espelhada) vai para a lista do Pedro.

### Etapa 2: 1 agente conferente independente

Um agente novo, que **não participou e não viu o trabalho sendo feito**.

> **O que é um "agente" aqui:** outra instância do Claude **criada por uma ferramenta** (por exemplo, a ferramenta Agent/Task), com contexto próprio e vazio. **Fazer o papel de agente na mesma conversa NÃO vale**, porque quem fez o trabalho estaria corrigindo a própria prova. Sem a ferramenta, siga "Se a ferramenta de agentes não estiver disponível", no fim desta parte.

- **O que ele recebe:** este plano; o zip **anterior** (o publicado); o zip **novo**; os testes; o **backup real** (se o Pedro mandou); e o pedido do Pedro.
- **O que ele NÃO recebe:** a conversa, as explicações de quem programou, nem a matriz da etapa 1 (se estiverem no zip, avise: "não abra `documentos/RELATORIO_*`").
- **A missão dele é tentar quebrar**, não confirmar. Ele cobre as **duas** áreas, nesta ordem de prioridade:
  1. **Dados e nuvem:** qualquer caminho que perca histórico — tirar criança com fila, migração (casos A–H), voltar ao zip anterior, 2 famílias, sem internet, conflito entre 2 celulares, `mesclar`, prefixo por criança, chaves antigas intactas byte a byte, compatibilidade v3 ↔ 4.1, nada apagado na nuvem, Firebase sem mudança;
  2. **Telas, crianças e celular:** textos idênticos aos da tabela 3-A, CAIXA ALTA, teclado nunca cobrindo o campo (cartão no meio), 8 bichinhos numa linha, letras ≥ 14 px, botões ≥ 48 px, desenho deitado com respiro (parte 4.12), chip e ⚙️ com bolinha, botão voltar do Android, nenhum `alert`/`confirm`/`prompt`, nada do app antigo quebrado.
- Ele escreve e roda os **seus próprios testes**, além dos que já existem, e **olha capturas de tela** nos tamanhos da parte 4.12.

Cada achado tem gravidade:

| Gravidade | Significado |
|---|---|
| 🔴 **Grave** | pode perder histórico, quebra o app ou contraria uma regra de ouro. **Bloqueia a entrega.** |
| 🟠 **Importante** | confunde a criança, difere do plano ou do pedido do Pedro, ou quebra algo secundário. **Bloqueia a entrega.** |
| 🟡 **Leve** | detalhe. Pode ir para as "pendências", com o OK do Pedro. |

e também **onde** (arquivo e linha), **como reproduzir**, o **que deveria acontecer** e a **sugestão de correção**.

**Depois da etapa 2:**
- quem programou corrige os 🔴 e 🟠;
- **o mesmo agente confere a correção** (continuando o mesmo agente; se a ferramenta não deixar, um agente novo com o relatório anterior e o zip corrigido);
- repete até **zero 🔴 e zero 🟠**; se depois de **3 rodadas** ainda houver 🔴 ou 🟠, **parar e avisar o Pedro**. Nada de entregar "quase pronto".

### Etapa 3: revisor-chefe

Um outro agente, que também **não viu nada antes**, recebe o plano, os 2 zips, o relatório do conferente, as correções e a matriz da etapa 1. Ele:
1. confere se **cada** achado 🔴/🟠 foi corrigido de verdade, **rodando** o teste de novo;
2. faz uma **passada própria** pelos pontos de maior risco (tirar criança, migração, 2 famílias, voltar ao zip anterior) e pelo pedido do Pedro;
3. confere a matriz da etapa 1 contra o zip final: cada ✅ tem prova;
4. dá o veredito: **✅ Pode publicar** ou **❌ Não pode publicar**, com o motivo.

Se o zip mudar **depois** do veredito (correção de 🟡), quem programou roda **todos** os testes de novo no zip final e diz isso no relatório.

### O que vai para o Pedro (dentro do zip, em `documentos/`)

`RELATORIO_CHECAGEM_<app>_v<versão>.md`, com:
- a matriz "pedido → prova" (etapa 1);
- os achados do conferente, com o que foi corrigido;
- o veredito do revisor-chefe;
- **o que foi rodado e o que foi só lido**;
- a lista **"Pedro, confira no celular"**;
- os pontos 🟡 que ficaram para depois.

Os relatórios do conferente e do revisor-chefe vão em `documentos/revisao_independente/`.

### Se a ferramenta de agentes não estiver disponível

- quem programou **avisa claramente** que as etapas 2 e 3 não rodaram;
- entrega o zip marcado como **"NÃO REVISADO, não publicar"**;
- o Pedro abre **uma conversa nova para o conferente** e depois **uma para o revisor-chefe**, e cola o prompt do **Apêndice B**.

Uma conversa nova não sabe nada da conversa que programou, então ela é um revisor independente de verdade.

### Cuidados que o Alfabetização ensinou (para quem programa e para os agentes)

- O ambiente de trabalho da conversa **pode ser apagado** depois de um tempo parado. Entregue **sempre o zip completo** (com testes e documentos) a cada rodada; se perder tudo, o pacote publicado pode ser baixado do próprio site, e as edições podem ser refeitas a partir do que foi registrado na conversa — conferindo por md5.
- Ao matar processos de teste, **nunca** use `pkill -f`/`pgrep -f` com um texto que também apareça no próprio comando (mata o próprio terminal).
- Nos testes com Playwright, `page.evaluate("algo.then(...)")` **espera** a promessa; para não esperar, embrulhe em `(()=>{ …; })()`.
- Rodar várias suítes ao mesmo tempo deixa a máquina lenta e pode fazer um teste de tempo falhar à toa: no fim, rode **tudo de novo, uma suíte de cada vez**.

---

## 10. Decisões: ✅ todas aprovadas pelo Pedro (06 e 07/10/2026), de D1 a D18

A coluna "Decidido" é o que vale. Quem for programar segue exatamente isto. D14 a D16 vieram da revisão independente e também foram aprovadas.

| # | Pergunta | Decidido | Status |
|---|---|---|---|
| **D1** | Telas num arquivo compartilhado novo (`escola-familia.js`) em vez de copiar as telas para dentro de cada app? | **Sim.** É o único jeito de garantir que fique tudo igual para sempre. | ✅ Aprovada |
| **D2** | Mostrar "Quem vai estudar hoje?" **toda vez** que abre, mesmo com 1 criança? | **Sim** (é o que você descreveu). Depois de escolher, o Alfabetização continua com o "continuar de onde parei". | ✅ Aprovada |
| **D3** | "Excluir": **(a)** só **tirar deste celular** (a nuvem guarda, dá para trazer de volta) ou **(b)** também **"tirar da família"**, que esconde a criança da lista em todos os celulares sem apagar nada? | **(a) agora**; (b) depois, se fizer falta. A (b) não apaga nada, mas pode confundir ("sumiu de todos os celulares"). | ✅ Aprovada |
| **D4** | CAIXA ALTA nas telas de família e crianças em todos os apps? | **Sim** (como no pop-up do Alfabetização da sua imagem). | ✅ Aprovada |
| **D5** | Limites: 6 crianças por família, até 4 famílias por celular? | **Sim.** As que já existem acima do limite continuam. | ✅ Aprovada |
| **D6** | As crianças da família que estão na nuvem (e não no celular) aparecem **direto** em "Quem vai estudar hoje?" com uma ☁️? | **Sim.** A criança se acha sozinha, sem precisar entender "recuperar". | ✅ Aprovada |
| **D7** | Na tela "Já tenho cadastro / Sou novo", deixar **"Agora não"** quando o celular já tem crianças de antes? | **Sim, só nesse caso.** Ninguém fica sem acesso ao que já tem. Instalação nova não tem "Agora não". | ✅ Aprovada |
| **D8** | Atalho **"📲 Levar a família para os outros apps"**: abre cada app com o código já preenchido (o código vai no link), e o adulto só confirma. Evita digitar 7 vezes. | **Sim, opcional**, depois que os 7 apps estiverem no padrão. O código fica no histórico do navegador daquele celular. | ✅ Aprovada |
| **D9** | No Alfabetização, renomear "👨‍👩‍👧‍👦 Nomes da família" para **"👨‍👩‍👧 Nomes dos parentes"**, para não confundir com "Código da família"? | **Sim.** Muda só o texto. | ✅ Aprovada |
| **D10** | A ordem depois do Alfabetização: Curiosidades → Explica → Provinha → Historinhas → Matemática → Fluência? | **Sim.** | ✅ Aprovada |
| **D11** | Usar um **site de teste** no Netlify com uma família de teste, para testar a sincronização antes de publicar? | **Sim.** É o jeito seguro de testar sem tocar no app das meninas. | ✅ Aprovada |
| **D12** | Matemática: o botão 👪 vira ⚙️ (mesma "Área dos Pais")? | **Sim.** | ✅ Aprovada |
| **D13** | Junto com cada app, corrigir o **backup que substitui** (Historinhas e Curiosidades) para **juntar**? | **Sim.** É perda de histórico, mesmo estando fora do cadastro. | ✅ Aprovada |
| **D14** | A revisão independente achou que o backup do **Alfabetização** e o da **Matemática** também substituem tudo e sobem por cima da nuvem. Estender a D13 a esses dois? | **Sim.** É o mesmo risco da D13. | ✅ Aprovada |
| **D15** | **Trava do adulto** (para "guardar cópia e tirar", "👁 mostrar o código", "entrar em outra família" e as cópias de cada dia). A Hinata faz conta de 3º ano, então uma conta simples não segura. | **Segurar o botão por 3 segundos**, com a frase "👨 PEÇA PARA UM ADULTO" e um círculo enchendo. É igual nos 7 apps e funciona mesmo se o adulto esqueceu o código. | ✅ Aprovada |
| **D16** | Trocar o desenho de "Trocar de criança" de 🔄 para **👥**, porque o 🔄 já é "Atualizar agora"? | **Sim.** Cada desenho com um sentido só (já aplicado neste plano). | ✅ Aprovada |
| **D17** | (07/10/2026, depois do teste no celular) **⚙️ na "Quem vai estudar hoje?"**, para o adulto mexer nas Configurações sem escolher uma criança? | **Sim** (pedido do Pedro). As Configurações do app abrem por cima da T4. | ✅ Aprovada |
| **D18** | (07/10/2026) No app instalado, **parar de pedir a tela cheia** do navegador para o Chrome não mostrar o aviso "Para sair da tela cheia, arraste…"? | **Não.** Testado na v122b: aparecem as barras do Android e o aviso continua. O Pedro prefere a **tela cheia de verdade**; o aviso do Chrome é aceito (nenhum site consegue escondê-lo). | ✅ Decidida |

---

## 11. Limites honestos

- **Cada app tem a sua memória no celular.** O código da família é digitado uma vez em cada app, em cada celular. É do navegador, não tem como evitar (o D8 só facilita).
- **Limpar os dados do navegador sem internet** apaga o que ainda não subiu. Continua valendo o aviso "⚠️ Não limpe os dados do navegador até conectar na internet", e a bolinha 🟡 mostra quando há risco.
- **A nuvem guarda cerca de 1 MB por criança por app.** O Provinha e o Explica já têm aviso e tratamento.
- **Gravações de voz do Historinhas não vão para a nuvem** (são grandes). O plano garante que elas não sejam apagadas ao tirar a criança, mas, se o celular for trocado, elas não vêm junto. Para levar, seria preciso exportar à parte. Fica como ideia futura.
- **Quem tiver o código vê os nomes e bichinhos da família** (não vê mais nada pessoal). Por isso a sugestão de código com números e o "👁 mostrar" só para o adulto.
- **O que foi conferido aqui:** li o código das 8 versões (7 apps; o Curiosidades em duas). **Não** rodei os apps no celular. Os pontos marcados "a confirmar no seu celular" (teclado no Fluência e no pop-up do Historinhas) precisam do seu teste ou dos testes de tela da implementação.

---

## Apêndice A: pedido pronto para os outros 6 apps (na ordem da D10)

> O 📚 Alfabetização **já foi feito** (v123, 07/10/2026). O pedido original dele fica no histórico do Alfabetização.
>
> **Modelo:** Sonnet 5.5, esforço **alto**.
>
> **Anexe na conversa nova de cada app:**
> - o zip completo que a conversa de passagem daquele app gerou e o `HISTORICO_E_PLANO_<id>.md`;
> - este `PLANO_CADASTRO_FAMILIA.md` (versão 3);
> - as **cópias mestras** da pasta `compartilhados/` do zip do Alfabetização v123: `escola-familia.js` (1.2), `nuvem-sync.js` (4.1), `escola-pwa.js` (v2), `nuvem-config.js` (o seu) e o `LEIA-ME_COMPARTILHADOS.md` (com os md5);
> - **como modelo:** o `alfabetizacao-completo-v123.zip` (o `index.html` dele mostra o adaptador e a ligação; a pasta `testes/` tem o Firebase de mentira e os testes que podem ser adaptados);
> - se puder, o **backup exportado** do app de hoje (para testar a migração com os dados reais).
>
> Cole o prompt de continuação do app e, no lugar de "O que eu quero agora", cole o bloco abaixo, trocando `<APP>` (ex.: 🌍 Curiosidades) e `<id>` (ex.: `curiosidades`).

```
Vamos implantar no <APP> o novo cadastro da família e das crianças, seguindo o
PLANO_CADASTRO_FAMILIA.md anexado (versão 3, aprovado; minhas decisões estão na parte 10, D1 a D18).
Leia a ficha deste app na parte 7 com atenção.

O 📚 Alfabetização JÁ FOI FEITO e aprovado (v123): ele é o MODELO. O escola-familia.js (1.2) e o
nuvem-sync.js (4.1) JÁ EXISTEM: são as cópias mestras anexadas (compartilhados/). Use-as SEM MUDAR,
conferindo o md5 (LEIA-ME_COMPARTILHADOS.md). Se precisar mudar algo nelas, PARE e me pergunte,
porque isso afeta os apps já publicados. Veja no zip do Alfabetização como ficaram o adaptador
(ADAPTADOR_CRIANCAS), a ligação no fim do index.html (EscolaFamilia.iniciar com abrirConfig e
fecharConfig para a ⚙️ na "Quem vai estudar hoje?"; NuvemSync.iniciar com EscolaFamilia.paraNuvem),
as regras da 4.1 (parte 5.3, itens 16 e 17: o mesclar nunca dá erro no meio; a criança entra na lista ANTES de qualquer junção),
e os testes (testes/testes_navegador: fakefb.py, ef.py, teste_familia.py, teste_desenho.py,
teste_v123.py), que podem ser adaptados para este app.

Antes de mexer: leia o HISTORICO_E_PLANO e o PLANO_CADASTRO_FAMILIA inteiros e me mande em
poucas linhas o seu entendimento e qualquer contradição entre o plano e o código. Se a
contradição mudar o plano, PARE e me pergunte.

Regras: nenhuma perda de histórico; migração só acrescenta; Firebase sem nenhuma mudança;
edições cirúrgicas no resto do app; os testes antigos continuam passando; testes novos da parte 9;
desenho deitado com respiro (parte 4.12, itens 7 a 10), testado nos tamanhos 984x432, 937x411,
740x360, 640x360 e 568x320, olhando as capturas; tela cheia como o app já faz hoje (D18).
A cada zip novo, suba o nome do cache do sw.js.

CHECAGEM OBRIGATÓRIA (parte 9-A, versão 3), antes de me entregar qualquer zip:
1) Autochecagem: matriz "pedido → prova" de TODOS os itens do plano que valem para este app,
   com o teste que prova cada um (item sem prova fica ⬜, nunca ✅). Rode o teste novo também na
   versão anterior, para provar que ele pega o problema.
2) 1 agente conferente NOVO e independente, criado por ferramenta (Agent/Task) — fazer o papel
   de agente nesta mesma conversa NÃO vale. Ele recebe só o plano, o zip anterior, o zip novo,
   os testes e o meu pedido (e o backup, se eu mandar), e tenta QUEBRAR (primeiro dados e nuvem, depois telas, crianças e
   celular). Corrija todo 🔴 e 🟠; o mesmo agente confere a correção; repita até zero 🔴 e zero
   🟠 (no máximo 3 rodadas; se não acabar, PARE e me avise). Se eu mandar o backup do app,
   o conferente também recebe (para testar a migração com os dados reais).
3) Revisor-chefe: outro agente novo confere as correções rodando os testes de novo e dá o
   veredito "✅ Pode publicar" ou "❌ Não pode publicar". Se o zip mudar depois do veredito,
   rode todos os testes de novo e diga isso.
Sem a ferramenta de agentes: AVISE, marque o zip "NÃO REVISADO, não publicar" e me diga para
usar o Apêndice B do plano em conversas novas.

Eu NÃO consigo testar sincronização antes de publicar. Então:
1) primeiro um zip para o SITE DE TESTE (um endereço com a palavra "teste"; ex.:
   escolasaopedro<id>testes.netlify.app), com instruções passo a passo para eu testar com
   2 celulares e a família de teste pmrtestes. Em destaque: "NUNCA digite o código da família
   de verdade no site de teste";
2) depois da minha aprovação, o zip final para o site de verdade, com a lista "conferir antes e
   depois de publicar".
Junto de cada zip: RELATORIO_CHECAGEM_<id>_v<versão>.md (parte 9-A), dizendo o que foi RODADO e o
que foi só LIDO, e a lista "Pedro, confira no celular". Escreva o veredito também aqui no chat.
Entregue SEMPRE o zip completo (com testes e documentos), porque o ambiente da conversa pode ser
apagado. Termine com o checklist ✅/⬜.
```

> **Só no 🌍 Curiosidades**, acrescente ao pedido: "a base é a **v1.8 publicada**. **Não** aplique as novidades da v1.9 agora: elas vêm numa entrega separada, depois que o cadastro estiver publicado e conferido. Siga os cuidados da ficha do Curiosidades na parte 7 (`ultimoDia`/`seqDias` e, depois, `sayTap`)."
>
> **Para aplicar a v1.9 depois:** peça "aplique as novidades da v1.9 (em `trabalho/v1.9-pendente/`) em cima do Curiosidades com o novo cadastro, seguindo os cuidados da parte 7 e a checagem da parte 9-A".
>
> **Matemática e Coruja Explica (usados em pé):** acrescente "teste também em pé (360×740 e 412×915), que é como este app é usado".

---

## Apêndice B: prompt de revisão independente (para colar numa conversa nova)

> Use quando a conversa que programou **não conseguiu** criar os agentes, ou quando você quiser uma revisão extra.
>
> **Abra uma conversa nova para cada papel** e troque `<PAPEL>` por:
> - **Conferente** (primeiro);
> - **Revisor-chefe** (por último, anexando também o relatório do conferente e o zip corrigido).
>
> **Modelo:** Sonnet 5.5, esforço alto.
>
> **Anexe:**
> - este `PLANO_CADASTRO_FAMILIA.md`;
> - o zip **anterior** (o que está publicado);
> - o zip **novo**;
> - (só para o conferente) o **backup exportado** do app, se tiver;
> - (só para o revisor-chefe) o relatório do conferente, a matriz "pedido → prova" e o `RELATORIO_CHECAGEM` de quem programou.
>
> **Para o conferente, não anexe** a conversa de quem programou, as explicações dela nem o `RELATORIO_CHECAGEM` (se ele estiver dentro do zip novo, avise: "não abra `documentos/RELATORIO_*`").
>
> **Roteiro para você (Pedro):**
> 1. Abra a conversa do **Conferente**.
> 2. Leve o relatório dele para a conversa que programou e peça: "corrija todos os 🔴 e 🟠 deste relatório e me mande o zip corrigido".
> 3. Volte à **mesma conversa do conferente**, anexe o zip corrigido e peça: "confira se os seus achados foram corrigidos".
> 4. Repita os passos 2 e 3 até zero 🔴 e zero 🟠 (no máximo 3 voltas; se não acabar, pare e me chame numa conversa nova).
> 5. Por último, abra a conversa do **Revisor-chefe** com o plano, os 2 zips (anterior e corrigido) e o relatório final do conferente.
> 6. Só publique com **"✅ Pode publicar"**.

```
Você é o <PAPEL> independente de uma mudança num aplicativo educativo (PWA de arquivo único,
offline, publicado no Netlify, com nuvem no Firestore) usado por duas crianças de 4 e 6 anos,
quase sempre com o celular DEITADO e espelhado numa TV. Você NÃO participou do trabalho e não deve
confiar em nada que o autor disse: confie só nos arquivos.

Anexos: o plano aprovado (PLANO_CADASTRO_FAMILIA.md, versão 3), o zip ANTERIOR (publicado hoje) e o
zip NOVO. Leia o plano inteiro antes de começar. As regras de ouro (parte 2) e a parte 9-A valem
acima de tudo.

Sua missão é TENTAR QUEBRAR, não confirmar:
- Conferente: (1) Dados e nuvem: procure qualquer caminho que perca histórico — tirar criança com
  fila, migração (casos A–H da parte 6), voltar ao zip anterior, 2 famílias, sem internet,
  conflito entre 2 celulares, mesclar, chaves antigas intactas byte a byte, compatibilidade do
  nuvem-sync v3 com a 4.1, nada apagado na nuvem, Firebase sem mudança. (2) Telas, crianças e
  celular: textos idênticos aos da tabela 3-A, CAIXA ALTA, teclado nunca cobrindo o campo (o
  cartão fica no meio entre o topo e o teclado), 8 bichinhos numa linha, letras ≥ 14 px, botões
  ≥ 48 px, desenho deitado com respiro (parte 4.12) nos tamanhos 984x432, 937x411, 740x360,
  640x360 e 568x320, chip e ⚙️ com bolinha, botão voltar do Android, nenhum alert/confirm/prompt,
  nada do app antigo quebrado.
- Revisor-chefe: confira, RODANDO os testes de novo, se cada achado 🔴/🟠 do conferente foi
  corrigido; faça uma passada própria nos pontos de maior risco (tirar criança, migração,
  2 famílias, voltar ao zip anterior) e no pedido do dono; confira se cada ✅ da matriz tem prova;
  dê o veredito.

Como trabalhar:
1) Descompacte os dois zips em pastas separadas. Rode node --check, os testes que vierem no zip
   e ESCREVA E RODE OS SEUS PRÓPRIOS testes (navegador sem tela com Playwright/Chromium, um
   "Firebase de mentira", 2 "celulares", sem internet), e OLHE capturas de tela. Compare o novo
   com o anterior.
2) Para cada problema: gravidade (🔴 grave = perde histórico, quebra o app ou contraria regra de
   ouro; 🟠 importante = confunde a criança ou difere do plano/pedido; 🟡 leve), onde (arquivo e
   linha), como reproduzir, o que deveria acontecer e a sugestão de correção.
3) Não corrija o código: só aponte.
4) Diga claramente o que você RODOU de verdade e o que só LEU.

Entregue RELATORIO_<PAPEL>.md com:
- a lista de achados;
- o que foi rodado e o que foi só lido;
- o que só um celular de verdade pode confirmar;
- e, no fim, UMA linha de veredito:
  - "✅ Pode publicar" (só se houver zero 🔴 e zero 🟠);
  - ou "❌ Não pode publicar: <motivo>".
Escreva em português do Brasil, simples (o dono do app não é programador).
```

---

## 13. Aprendizados da implantação no 📚 Alfabetização (para os outros 6 apps)

| O que aconteceu | Causa | Como evitar |
|---|---|---|
| O campo do código perdia o foco e às vezes sumia com o teclado (achado 🔴 do revisor) | o app **mudava o campo de lugar** quando a tela ficava baixa | o campo nunca muda de lugar; só aparecem botões pequenos ao lado (já no `escola-familia.js`) |
| A barra de cima escondia a pílula de estrelas ao ganhar o chip, e depois encolhia os botões | conferência de "cabe?" olhando só a caixa de fora; compactação que diminuía os botões | medir o conteúdo de verdade; **nunca** diminuir botões abaixo de 48 px; esconder primeiro o que é enfeite |
| A ficha antiga virava uma 2ª criança ☁️ depois de mudar o bichinho | a regra "some quando a nova cobre todos os apps" valia também na T4 | já corrigido no módulo (ficha com `movidoPara` nunca aparece na T4) |
| Progresso guardado só na lixeira ficava "esquecido" | trazer pela nuvem não olhava a lixeira | já corrigido (`juntarLixeira`) e, na 1.2, a bolinha fica 🟡 enquanto houver criança só na lixeira |
| A fila era jogada fora se a lista de crianças desse erro | `usuarios()` engolia o erro | já corrigido no `nuvem-sync.js` 4 |
| Chaves de criança tirada voltavam a ser gravadas (C1) | resposta da nuvem chegando depois de tirar | já corrigido no `nuvem-sync.js` 4.1; no app, o `mesclar` também ignora id que não está na lista |
| Site de teste sem a faixa roxa | o app só reconhecia `-teste.` no endereço; o Pedro escolheu `escolasaopedrotestes` | qualquer endereço com "teste" (1.1) |
| Caixa do código grudada no topo com o teclado; "Achei" apertado; Configurações estreitas | desenho pensado para cartão de 480 px | parte 4.12, itens 7 a 10 (já no módulo; as Configurações do app são de cada app) |
| Aviso do Chrome "arraste para sair da tela cheia" | é do Chrome, aparece sempre que um site entra em tela cheia | **aceito** (D18); não tentar esconder |
| "Desinstalei e limpei o cache e não voltou o cadastro" | o app instalado e o Chrome usam o mesmo armazenamento | é o certo; começar do zero = Configurações do site › Limpar e redefinir |
| A cada zip do site de teste, o celular mostrava a versão anterior | `sw.js` com o mesmo nome de cache | subir o cache a cada zip |
| O ambiente da conversa foi apagado durante uma pausa | ambiente temporário | zip completo a cada rodada; o pacote publicado pode ser baixado do site |

---

## 14. Como usar o 📚 Alfabetização como modelo (para quem programa)

1. **Adaptador:** `ADAPTADOR_CRIANCAS` no `index.html` do Alfabetização v123 (listar, atual, criar, mudar, exportar, importar, tirar, completoNaNuvem, entrar, resumo, chavesDaCrianca).
2. **Ligação** (fim do `index.html`): `EscolaFamilia.iniciar({...})` → `NuvemSync.iniciar({..., usuarios: () => EscolaFamilia.paraNuvem(lista)})` → o prefixo por criança recolocado por cima da vigia → `EscolaFamilia.montarChip`, `montarPonto`, `montarSecaoConfig` → abrir a T4 ao começar.
3. **Guarda de "sem criança"** (`SEM_CRIANCA`): sem criança escolhida, o app não lê nem grava nenhuma chave de progresso (evita a "criança fantasma").
4. **Backup que junta** (`aplicarBackup`): acha cada criança por nome + bichinho na família atual e junta com a mesma regra da nuvem.
5. **Testes:** `testes/testes_navegador/fakefb.py` (Firebase de mentira, sem internet, erros, `currentDocument`), `ef.py` (ajudantes das telas do módulo), `teste_familia.py` (parte 9), `teste_desenho.py` (tamanhos e respiro), `teste_v123.py` (⚙️ na T4, C1, C2).

---

## 12. Checklist

- ✅ Plano aprovado (D1 a D16 em 06/10/2026; D17 e D18 em 07/10/2026)
- ✅ 📚 Alfabetização: implantado (v122), testado pelo Pedro em 2 celulares no site de teste (v122 e v122b), aprovado, versão final v123 entregue com as cópias mestras `escola-familia.js` 1.2 e `nuvem-sync.js` 4.1
- ✅ Protocolo de checagem versão 3 (autochecagem + 1 agente conferente + revisor-chefe), indicado para o Sonnet 5.5
- ⬜ Pedro: publicar a v123 no site de verdade do Alfabetização (`INSTRUCOES_PUBLICAR_v123.md`) e conferir
- ⬜ Próximo app: 🌍 Curiosidades (Apêndice A), depois Coruja Explica → Provinha → Historinhas → Matemática → Fluência (D10), um de cada vez, cada um só depois do anterior publicado e conferido
- ⬜ Curiosidades: depois do cadastro publicado, aplicar as novidades da v1.9 (com a checagem da parte 9-A)
- ⬜ Depois dos 7: atalho "📲 Levar a família para os outros apps" (D8)
