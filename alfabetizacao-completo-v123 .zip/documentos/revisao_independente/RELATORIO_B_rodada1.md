# Relatório do Revisor B: Telas, crianças e celular (rodada 1)

**App:** 📚 Esforço Vence (Alfabetização) · **v121 (publicada) → v122 (site de teste)**
**Data:** 07/10/2026 · **Revisor:** B (independente; não participou do trabalho; não abri `documentos/RELATORIO_*`)

Pastas, scripts e capturas deste revisor: `/home/claude/revB/` (scripts em `scripts/`, 259 capturas em `capturas/`, registros em `log_*.txt`).

---

## Resumo em 1 minuto

O cadastro novo está, na maior parte, **bem feito**: os textos batem com a tabela 3-A, tudo aparece em CAIXA ALTA, os 8 bichinhos ficam numa linha em todos os tamanhos, nenhuma caixinha do navegador (`alert`/`confirm`/`prompt`) aparece, o botão voltar do Android fecha primeiro o pop-up e depois a tela, a trava do adulto funciona com o dedo (1,5 s não abre; 3 s abre), "Quem vai estudar hoje?" aparece toda vez que o app abre e o "Continuar de onde parei" continua funcionando depois. Nada do app antigo quebrou no meu teste (Ler, Monta a Frase, Sílaba Perdida, Treinar Sílabas, Configurações, Cantinho dos pais, Nomes dos parentes, mapa, calendário, tipo e tamanho da letra, áudio).

Mesmo assim, achei **1 problema 🔴 e 2 🟠** que bloqueiam a publicação:

1. 🔴 **O campo do código da família pode SUMIR com o teclado aberto** (e o campo perde o foco toda vez que o teclado abre).
2. 🟠 **A barra de cima passou a esconder a pílula "☀️ 0/10 · 🌱 Nível 1 de 52"** nos tamanhos de celular mais comuns deitado (640 a 760 px de largura).
3. 🟠 **No modo ✏️ Arrumar, os botões ✏️ e 🗑️ cobrem o bichinho da criança** (87% a 100% dele).

Também há 12 pontos 🟡 (leves).

---

## Achados

### 🔴 B1. Com o teclado aberto, o campo do código da família pode sumir; e ele sempre perde o foco por um instante

- **Onde:** `escola-familia.js`
  - T2: função `posicionar()`, linhas 946–963;
  - T3: `posicionar()`, linhas 1057–1066;
  - regra de tela baixa: `CSS_COMPACTO`, linhas 349–359, e `@media (max-height:300px)`, linha 434;
  - `ajustarTeclado()`, linhas 559–574.
- **O que acontece (explicação simples):** quando o teclado abre e a tela fica baixa, o app **tira o campo de um lugar e coloca em outro** (da caixa "sozinho" para a linha compacta). Para o navegador, mudar um campo de lugar é o mesmo que tirar o dedo dele: o campo **perde o foco** e depois o app devolve o foco.
  - Medi isso em **todos** os 24 casos que testei (T2, T3 e T5; 740x360→170, 640x360→150, 568x320→140, 915x412→170, e o teclado abrindo aos poucos). Em todos aparece `focusout` seguido de `focusin`.
  - Num celular de verdade, perder o foco **costuma fechar o teclado**.
  - Às vezes a devolução do foco falha. Aconteceu em 1 de 5 repetições na T2 em 915x412→170, e também na T2 em 568x320→140 e na T3 em 915x412→170. Quando falha, o cartão fica no modo "compacto", mas o campo continua na caixa que esse modo esconde. **Resultado: na tela só ficam "🔑 [🔑 PROCURAR A FAMÍLIA] [✕]", sem campo nenhum** (captura `capturas/kb_t2_k568x140.png`).
  - O sumiço acontece **sempre** que a tela fica com 300 px de altura ou menos sem o campo estar focado. A T2 e a T3, ao contrário da T5, não escutam a mudança de tamanho da tela, então o campo não volta sozinho (capturas `sumico_t2_740x170.png` e `sumico_t3_740x170.png`; o campo mede 0×0).
- **Como reproduzir:**
  - Script `scripts/b3_sumico.py`: abre a T2 em 740x360 sem o campo focado e reduz a tela para 740x170. O campo fica com 0×0 px.
  - Script `scripts/b2_foco.py`: foca o campo e reduz a tela, mostrando o `focusout`/`focusin`.
  - Script `scripts/b2b_repete.py`: repete 5 vezes cada caso e mostra as falhas intermitentes.
- **Por que os testes do zip não pegam:** o teste de 12 tamanhos (`teste_cadastro.py`, linhas 157–173) já **abre** a tela pequena e só depois foca o campo. Ele nunca simula o teclado abrindo **depois** do toque, que é o que acontece no celular. E ele aceita botões a partir de 30 px.
- **O que deveria acontecer:** regra de ouro 10, "O teclado nunca cobre o que está sendo digitado". O campo tem que continuar visível e focado enquanto o teclado abre.
- **Sugestão:**
  - Não mover o `<input>` de lugar. Deixar o campo sempre no mesmo lugar e trocar só a arrumação com CSS (por exemplo, a linha compacta usa `order`/`grid`, ou se movem os botões em volta do campo, nunca o campo).
  - Se continuar movendo, chamar o `posicionar()` também no `resize` na T2 e na T3 (como a T5 já faz) e nunca esconder, pela regra `max-height:300px`, a caixa onde o campo está.
  - Acrescentar um teste que foca primeiro e só depois encolhe a tela, conferindo que o foco não sai do campo e que o campo continua visível.

### 🟠 B2. A barra de cima esconde a pílula de progresso "☀️ 0/10 · 🌱 Nível 1 de 52" (regressão)

- **Onde:**
  - `index.html`, CSS do chip, linhas 76–87 (o chip fica com 52 px de altura e até 150 px de largura);
  - a conferência `_barraTransborda()`, linha 5872, e o `ajustarBarraDeCima()`, linha 5885.
- **O que acontece:** o chip "🦊 HANA" ocupa cerca de 100 px a mais na barra do **Ler**, e os botões 🏠 📅 🗺️ passam por cima da pílula de estrelas e de nível.
  - A conferência `_barraTransborda()` não percebe, porque ela mede só a caixa da esquerda (que encolhe) e não o texto que sai dela.
  - Medi o lado direito da pílula contra o primeiro botão em 14 larguras (script `scripts/b6_meta.py`):

    | Largura (deitado) | v121 | v122 |
    |---|---|---|
    | 640 | sobrepõe 13 px | **sobrepõe 73 px** |
    | 660 a 760 | não sobrepõe | **sobrepõe** |
    | 780 ou mais | não sobrepõe | não sobrepõe |

  - Capturas: `PAG_ler_d740x360.png` (o "52" some debaixo do 🏠) e `PAG_ler_d640x360.png` (o 🏠 e o 📅 por cima de "Nível 1 de 52"). Para comparar com a versão anterior: `v121_PAG_ler_d740x360.png` e `v121_PAG_ler_d640x360.png`.
  - 740x360 é um tamanho muito comum de celular Android deitado. Numa TV a 3 metros, a criança perde de vista as estrelas do dia e o nível.
- **O que deveria acontecer:** "a barra de cima não pode esconder" nada (pedido desta revisão). A v121 mostrava a pílula inteira de 660 px para cima.
- **Sugestão:**
  - Medir a sobreposição pelo conteúdo (`#meta`/`#prog`) e não pela caixa `#lgrp`, e ligar o `efChipCurto` (chip só com o bichinho) já quando a pílula encosta nos botões;
  - ou tirar o nome do chip na barra do Ler deitado em larguras abaixo de cerca de 780 px.
  - Acrescentar um teste que confira "a pílula não fica debaixo de nenhum botão" de 640 a 915 px.

### 🟠 B3. No "✏️ Arrumar", o ✏️ e o 🗑️ cobrem o bichinho da criança

- **Onde:** `escola-familia.js`:
  - `.ef-acoes-card{position:absolute;top:4px;right:4px…}`, linhas 410–411;
  - `cardCrianca()`, linhas 1129–1133.
- **O que acontece:** os dois botões (48×48 cada) ficam por cima do cartão, bem onde está o bichinho. Medi quanto do bichinho fica coberto (script `scripts/b8_dobras.py`):
  - **90%** em 740x360;
  - **100%** em 640x360;
  - **87%** em 568x320;
  - 42% em 915x412.

  Capturas: `T7_d740x360.png` e `T7_p360x740.png`. O 🦊 e o 🦋 quase não aparecem.
- **Por que importa:** a parte 3 do plano diz que "a criança reconhece o **próprio bichinho** antes de ler o nome". E é justamente nesta tela que o adulto (ou a criança) escolhe **quem tirar do celular**. Sem o bichinho, é mais fácil tocar no 🗑️ da criança errada. O desenho da T7 no plano põe o "✏️🗑️" **ao lado** do cartão, não por cima.
- **Sugestão:** no modo Arrumar, colocar o ✏️ e o 🗑️ **embaixo** do nome (uma linha própria no cartão) ou ao lado do cartão, deixando o bichinho inteiro à vista. Como o `escola-familia.js` vai para os 7 apps, isso vale para todos.

### 🟡 Leves

| # | O quê | Onde | Como ver | Sugestão |
|---|---|---|---|---|
| B4 | Na barra de cima, em **568x320 deitado** os botões 🏠📅🗺️⚙️⛶ e o chip encolhem para **42 px** (na v121 eram 52 px). O plano pede pelo menos 48 px. | `index.html`, linha 84 (`efBarraApertada`) | `scripts/b4_t4.py` (log `log_b4.txt`) | Em vez de encolher os botões, esconder o nome do chip e, se precisar, a pílula de nível em tela pequena; ou aceitar 46 px como em pé. |
| B5 | **Em pé, 320 px:** no Monta a Frase e na Sílaba Perdida, a **⚙️ sai da tela** (lado direito em 324 px). Na v121, só o ⛶ saía. Em 360 px, o ⛶ sai mais do que antes. | `index.html` (barra `htmlTopo`) | `log_b4.txt` / `scripts/b5_barra_v121.py` | O Alfabetização é usado deitado, por isso é leve. Mesmo assim, nunca deixar a ⚙️ sair da tela. |
| B6 | **T4 com 4 ou mais cartões** (crianças + ☁️ + ➕) em 740x360: a bolinha, "BUSCAR NA NUVEM", "ATUALIZAR" e "ARRUMAR" ficam **abaixo da tela** (precisa rolar). O desenho do plano mostra 5 cartões numa linha e os botões à vista. Isso vai acontecer quando a nuvem mostrar fichas de outros apps (problema 🟠 10 do plano: a mesma criança com bichinhos diferentes). | `escola-familia.js`, linha 398 (largura mínima do cartão `clamp(130px,19vw,170px)`) | `scripts/b8_dobras.py`; captura `F8_T4_4_740x360.png` | Cartões um pouco menores deitado (5 por linha em 740 px), ou a barra de botões e o rodapé fixos embaixo. |
| B7 | **"🎉 ACHEI A SUA FAMÍLIA!"**: com 3 ou 4 crianças ou mais, os botões **TRAZER TODAS / ESCOLHER** ficam fora do pop-up (precisa rolar dentro dele). Em 568x320 isso acontece já com 2 crianças. | `escola-familia.js`, linhas 988–1010 | `b8_dobras.py`; capturas `F2_achei_740x360.png` e `F8_achei4_740x360.png` | Pôr os botões antes dos cartões ou deixá-los fixos embaixo do cartão. |
| B8 | A **T4 não tem ⚙️**. O desenho do plano mostra "⛶ ⚙️●" no topo. Na abertura não dá para chegar às Configurações sem escolher uma criança. (A bolinha aparece no rodapé.) | `escola-familia.js`, linhas 1143–1147 | captura `T4_d740x360.png` | Pôr a ⚙️ com a bolinha ao lado do ⛶, abrindo as Configurações do app. |
| B9 | **T4 sem nenhuma criança** mostra também "🔄 ATUALIZAR AGORA". O plano diz "só ➕ Nova criança e ☁️ Buscar na nuvem". | `escola-familia.js`, linha 1207 | `scripts/b7_fluxos.py`, parte 1 | Esconder o "Atualizar agora" quando não há crianças. |
| B10 | Escolher a **mesma** criança pelo chip, de dentro do Monta a Frase, mostra "👋 BEM-VINDO DE VOLTA! VOCÊ ESTAVA EM MONTA A FRASE". Ela nem saiu de lá, o que confunde. | `index.html`, `trocarPerfil()` (linha 5043) e `passoDoApp()` (linha 6652) | `b7_fluxos.py`; captura `F1_mesma_crianca_chip.png` | Se a criança tocada já é a atual e o app já está aberto, só fechar a T4 (sem o pop-up). |
| B11 | Na **T8**, o código aparece em minúsculas ("🔑 fam••••"); na T4 e nas Configurações aparece em CAIXA ALTA ("FAM••••"). | `escola-familia.js`, linha 1534 (`ef-normal`) | captura `T8_d740x360.png` | Usar a mesma forma em todas as telas. |
| B12 | **T4 aberta na abertura do app, em modo ✏️ Arrumar:** o botão voltar do Android não sai do modo Arrumar (só o "✅ TERMINEI DE ARRUMAR" sai). *Só lido no código, não rodado.* | `escola-familia.js`, linhas 1104–1107 | ler o código | No voltar, se estiver arrumando, sair do modo Arrumar. |
| B13 | **Site de teste:** a faixa roxa "🧪 SITE DE TESTE…" (23 px) fica **por cima da metade de cima do campo** e dos botões quando o teclado está aberto (T2 e T5 compactas grudam no topo). Só no site de teste, mas é lá que o Pedro vai testar o teclado. | `escola-familia.js`, linha 472 (`.ef-teste`) | `scripts/b12_siteteste.py`; captura `siteteste_t5_740x170.png` | Com o teclado aberto, esconder a faixa ou empurrar o cartão 24 px para baixo. |
| B14 | Pensando nos **outros 6 apps**: o chip padrão do módulo tem **46 px** de altura (`.ef-chip{height:46px}`, linha 452). Só o Alfabetização aumenta para 52 px no próprio CSS. Os outros apps vão herdar um chip abaixo de 48 px. Também há textos fora do objeto `TEXTOS` (ex.: `sim:'JUNTAR'` na linha 1491, "Tela cheia"), e o teste de textos não os pega. | `escola-familia.js` | ler o código | Chip padrão com 48 px ou mais; todos os textos dentro de `TEXTOS`. |
| B15 | O teste `teste_fonte.py` do zip tem **1 falha** ("Ler 412x915 em pé, tamanho 24: 86% em vez de 90%"). **A mesma falha acontece na v121**, então não foi esta mudança que causou. Mas não é verdade que "todos os testes passam". | `testes/testes_navegador/teste_fonte.py`, linha 40 | rodei nas duas versões | Registrar como pendência antiga ou ajustar o teste. |

*(Observação, sem gravidade: com o celular espelhado na TV, o título "🦉 QUEM VAI ESTUDAR HOJE?" fica com 18 px em 740x360. Está dentro da regra de 14 px, mas é pequeno a 3 metros. O bichinho do cartão, com 40 a 62 px, compensa.)*

---

## O que eu RODEI de verdade

**Conferências e testes do zip**
- `node --check` nos 5 arquivos `.js` do pacote e nos 2 blocos de script do `index.html`: todos OK.
- O zip do Netlify (9 arquivos) é **idêntico, byte a byte,** à pasta `pacote-netlify/` do zip completo. As cópias em `compartilhados/` e `testes/` também são iguais (md5). `sw.js` está na v122, com `escola-familia.js` na lista de arquivos.
- Testes do zip, em Node (`npm install` + `node testes/rodar_testes.js`): **89/89** na v122. Os mesmos 89/89 na v121.
- Testes do zip, com navegador (Chromium + Firebase de mentira, portas 8851/8852):

  | Teste | Resultado |
  |---|---|
  | `teste_familia.py` | **127/127** |
  | `teste_cadastro.py` | **72/72** |
  | `teste_nuvem.py` | **81/81** |
  | `teste_pwa.py` | **34/34** |
  | `teste_fonte.py` | **57/58** (a mesma falha da v121, que também rodei: 57/58) |

**Meus próprios testes** (Playwright/Chromium sem tela, com o `fakefb.py`, nunca o Firebase real; em `/home/claude/revB/scripts/`):
- `b1_telas.py`: T1, T2, T3 (com o "anote"), T5 em 8 tamanhos: deitado 740x360, 640x360, 568x320, 915x412; tablet 1024x600; em pé 360x740, 320x568, 412x915. Mais o **teclado abrindo depois do toque** em 6 tamanhos: 740→170, 640→150, 568→140, 915→170 (deitado) e 360→420, 320→300 (em pé), na T2, na T3 e na T5. Medi letras, botões, campo, os 8 bichinhos e o foco.
- `b2_foco.py`, `b2b_repete.py`, `b3_sumico.py`: o achado B1 (foco perdido e campo que some).
- `b4_t4.py`: T4, T7 (Arrumar e a pergunta de tirar), T5 "mudar", T6, T8 e a seção "☁️ Família e nuvem" em 7 tamanhos. Também o chip e a ⚙️ com bolinha nas 4 telas principais (Ler, Monta a Frase, Sílaba Perdida, Treinar Sílabas).
  - **Chip colado à esquerda da ⚙️ e ⚙️ com bolinha: OK** em todas as telas e tamanhos.
  - **"☁️ Família e nuvem" é a última seção das Configurações: OK.**
  - **Letras de 14 px ou mais e botões de 48 px ou mais** nas telas do módulo: OK, menos os bichinhos em pé (30 a 37 px, que o plano permite: de 30 a 62 px).
- `b5_barra_v121.py` e `b6_meta.py`: a mesma barra de cima na v121 e na v122, lado a lado (achados B2, B4 e B5).
- `b7_fluxos.py`:
  - primeira abertura T1→T3→anotar→T5→"Cadastrar os parentes?" (D9)→menu;
  - D2: ao abrir de novo, a T4 aparece sem "Voltar"; depois de escolher, "Continuar de onde parei" (estava no Monta a Frase) leva de volta ao Monta;
  - T1→T2: código com espaço e maiúsculas acha a família → "Trazer todas" → T4 com as 2 crianças;
  - código errado: avisa e sugere "VOCÊ QUIS DIZER saopedro2026?";
  - caso B: "Este celular já tem…" + "AGORA NÃO ›" → T4 com a bolinha 🔴;
  - **botão voltar do Android:** fecha o pop-up T2 e mantém a T1; fecha só a pergunta (a T4 fica); fecha a T5 e depois a T4; fecha a T6 e mantém as Configurações; na abertura, não deixa entrar no app sem criança;
  - **trava do adulto com o DEDO** (eventos de toque reais): toque rápido só mostra "👨 PEÇA PARA UM ADULTO SEGURAR…"; 1,5 s não abre; 3 s abre as "Cópias de cada dia"; 3 s em "👁 MOSTRAR" mostra o código;
  - tirar uma criança com a nuvem em dia funciona;
  - **nenhum alert/confirm/prompt** em nenhum dos fluxos.
- `b8_dobras.py`: o que fica fora da tela com 2, 4 ou 6 crianças (achados B6 e B7) e quanto do bichinho fica coberto no Arrumar (achado B3).
- `b9_smoke.py`: o app antigo, na **v121 e na v122**: próxima/anterior frase, áudio da frase, tipo de letra, tamanho da letra, calendário, mapa de níveis, Configurações, Cantinho dos pais, Nomes dos parentes, Monta a Frase, Sílaba Perdida, Treinar Sílabas, menu. **Zero erros de JavaScript nas duas versões.** Olhei as capturas: o texto "👨‍👩‍👧 Nomes dos parentes" (D9) aparece certo.
- `b10_cfg.py`, `b11_2fam.py` (2 famílias: um título por família e um ➕ por grupo, OK), `b12_siteteste.py` (faixa do site de teste).
- **Olhei de verdade** (com a ferramenta de ler imagens) as capturas de T1, T2, T2 "Achei" e "Não achei", T3 "Anote", T5 (deitado, em pé e com teclado), T4, T4 com 4 crianças, T4 com 2 famílias, T6, T7, T8, Configurações e as barras do Ler, Monta a Frase, Sílaba Perdida e Treinar Sílabas, em v121 e v122.

## O que eu só LI (não rodei)

- O código inteiro do `escola-familia.js` (1.736 linhas) e o diff completo do `index.html` (v121 → v122).
- B12 (voltar no modo Arrumar na abertura) foi só lido.
- A busca por `alert(`, `confirm(` e `prompt(` no código: não há nenhum. O único `prompt()` é o do convite de instalação do navegador, que não é caixinha de texto.
- Não conferi a fundo a parte de dados e nuvem (migração, fila, `mesclar`, voltar ao zip anterior): é a missão do Revisor A. Os testes do zip sobre isso passaram.

## O que só um celular de verdade pode confirmar (Pedro, confira no celular)

1. **Teclado de verdade (o mais importante):** na T2 ("🔑 Já tenho cadastro") e na T3 ("🌱 Sou novo"), deitado, toque no campo. O teclado abre e **fica aberto**? O campo **continua aparecendo**? Repita umas 5 vezes (o achado B1 é intermitente). Faça o mesmo na T5 ("Qual é o seu nome?").
2. Celulares que **ignoram** o `interactive-widget=resizes-content` (o teclado cobre a página em vez de encolher): o cartão gruda em cima do teclado?
3. **Trava do adulto:** segurar 3 s com o dedo no Android não abre o menu de "copiar/selecionar" nem é cancelado pelo próprio Android?
4. **Botão voltar do Android** no app instalado (PWA): fecha o pop-up, depois a tela, e na "Quem vai estudar hoje?" de abertura não sai do app sem querer.
5. **Na TV a 3 m:** as crianças conseguem achar o próprio bichinho na T4? A pílula "☀️ … · 🌱 Nível …" aparece inteira no seu celular (achado B2)?
6. A largura do seu celular deitado. Se for de 780 px ou mais, o B2 não aparece nele, mas aparece em celulares de 640 a 760 px.

---

## Veredito

❌ Não pode publicar: 1 problema 🔴 (B1: com o teclado aberto, o campo do código da família perde o foco e às vezes some, contrariando a regra de ouro 10) e 2 problemas 🟠 (B2: a barra de cima esconde a pílula de estrelas e nível de 640 a 760 px; B3: no "Arrumar", o ✏️🗑️ cobre o bichinho da criança).
