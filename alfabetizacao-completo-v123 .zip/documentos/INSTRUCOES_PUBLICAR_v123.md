# 🚀 Publicar a v123 no site de verdade — conferir ANTES e DEPOIS

**App:** 📚 Esforço Vence — Alfabetização · **Site:** https://escolasaopedroalfabetizacao.netlify.app/ · **Versão:** v123 (cache `esforco-vence-v123`)
**Arquivo para o Netlify:** `alfabetizacao-v123-netlify.zip` (9 arquivos na raiz)
**Data:** 07/10/2026

Hoje o site de verdade está na **v121** (o cadastro antigo). A v123 traz o cadastro novo da família, que você testou no site de teste (v122 e v122b), mais: ⚙️ na "Quem vai estudar hoje?", a tela cheia como era antes (sem as barras do Android) e 2 correções de segurança (C1 e C2).

---

## 1. ANTES de publicar (10 minutos, uma vez)

1. **(Recomendado, 2 minutos) Publique o mesmo zip primeiro no site de teste** `escolasaopedrotestes` (Deploys → arrastar o zip). Abra 2 vezes no celular e confira só:
   - a **⚙️ com a bolinha** ao lado do ⛶ em "Quem vai estudar hoje?": toque, veja as Configurações e feche;
   - a tela cheia, **sem as barras do Android** (como era antes).
2. **Em cada celular das meninas, no app de verdade (o de hoje, v121):**
   - abra o app e espere a **bolinha verde** na ⚙️ (tudo guardado na nuvem). Se não ficar verde, ligue a internet e espere;
   - ⚙️ → **⬆️ Exportar backup** → guarde o arquivo (ex.: no Google Drive). Só **exporte**: **não importe** backup na v121 (lá o importar substitui tudo).
3. **Guarde o zip de hoje do site de verdade** (o da v121, `esforco-vence-netlify.zip`). Ele é o "desfazer" (parte 4). Se não achar esse zip: no Netlify, site **escolasaopedroalfabetizacao** → **Deploys** → toque no deploy que está publicado hoje → **Download** (guarda uma cópia). O Netlify também guarda os deploys antigos: na parte 4 dá para voltar com **Publish deploy**.
4. Confira que você está no site certo: no Netlify, o site **escolasaopedroalfabetizacao** (não o de teste).

## 2. Publicar

1. Netlify → site **escolasaopedroalfabetizacao** → aba **Deploys**.
2. Arraste **`alfabetizacao-v123-netlify.zip`** na área "Drag and drop".
3. Espere **Published**.

## 3. DEPOIS de publicar (em cada celular)

1. Abra o app **2 vezes** (na 1ª o celular baixa a versão nova; na 2ª ela já abre). Se ainda aparecer o cadastro antigo, feche o app por completo e abra de novo.
2. Tem que aparecer **🦉 QUEM VAI ESTUDAR HOJE?** com as crianças daquele celular, **com o progresso de antes** (frases e sílabas no cartão de cada uma), e um aviso rápido **"🔑 FAMÍLIA xxx•••• — TUDO CERTO ✅"**.
   - Se aparecer **"🔑 Já tenho cadastro / 🌱 Sou novo por aqui"** com a lista "Este celular já tem…": esse celular nunca recebeu o código da família. Toque **🔑 JÁ TENHO CADASTRO** e digite o código **de verdade** da família (é aqui, no site de verdade, que ele vai). As crianças do celular passam a ser dessa família.
3. Toque numa criança → se ela estava no Monta a Frase, na Sílaba Perdida ou no Treinar Sílabas, aparece **👋 Bem-vindo de volta!** com **▶ Continuar de onde parei**; se estava no Ler, abre o menu (e o Ler continua na frase em que ela parou).
4. Leia uma frase e confira a **bolinha verde** na ⚙️ (tudo guardado na nuvem).
5. Confira a **⚙️ na "Quem vai estudar hoje?"** (toque no bichinho ao lado da ⚙️ para voltar a ela).
6. No **outro celular**, depois de abrir a v123, toque **🔄 ATUALIZAR AGORA**: o que uma criança leu no 1º celular aparece no 2º.

## 4. Se algo der errado

- **Nas 2 primeiras semanas:** volte para a v121: no Netlify, **Deploys** → toque no deploy antigo (o da v121) → **Publish deploy** (volta na hora); ou arraste de novo o zip da v121. A v123 **não apagou nada** do jeito antigo, então a v121 abre como antes. Depois me mande prints.
- ⚠️ **Depois das 2 primeiras semanas, se alguma vez TODAS as crianças forem tiradas de um celular, NUNCA publique de novo o zip v121.** A v121 recriaria a "Hana 👧" vazia e ela gravaria por cima da ficha dela na nuvem (é por isso que, nas 2 primeiras semanas, a v123 não deixa tirar a última criança).
- **Nas 2 primeiras semanas não dá para entrar numa 2ª família** sem um adulto liberar (segurando 3 s). É de propósito: protege a volta para a v121.
- **Nunca digite o código da família de verdade no site de teste.** O site de teste só aceita códigos com a palavra "teste".

## 5. Duas perguntas que você fez

- **"Desinstalei o app e limpei o cache, mas não voltou a tela 'Já tenho cadastro'."** É o esperado. No Android, o app instalado e o site no Chrome guardam os dados **no mesmo lugar (o Chrome)**. Desinstalar o ícone e limpar o cache não apagam esses dados, e isso protege o progresso das meninas. Para começar do zero de verdade: Chrome → ⋮ → Configurações → Configurações do site → Todos os sites → (o endereço do app) → **Limpar e redefinir**. ⚠️ No site de verdade, só faça isso com a **bolinha verde** (senão o que ainda não subiu se perde).
- **"O app parece travar uns 5 segundos ao abrir (tela preta)."** A tela preta é o Android abrindo a janela do app e o Chrome começando a rodar; o app é um arquivo grande (≈ 1 MB, com as 2039 frases) e o celular precisa ler tudo antes de mostrar a primeira tela. Medi a abertura com o processador "freado" para parecer o de um celular: cerca de 3,6 s antes e **3,0 s na v123** (a classificação das frases agora é feita sem repetir contas). O resto é do Chrome e do tamanho do arquivo; diminuir mais exigiria separar as frases em outro arquivo, uma mudança grande que eu só faço com o seu OK. A 1ª abertura depois de publicar é sempre a mais lenta (o celular baixa a versão nova).

## 6. O aviso do Chrome "Para sair da tela cheia, arraste…"

É do Chrome e aparece toda vez que o app entra em tela cheia. Nenhum site consegue esconder ou encurtar. Na v122b eu tirei o pedido de tela cheia no app instalado para o aviso sumir, mas aí apareceram as barras do Android (a "borda azul" com os 3 botões), e você preferiu sem elas. Na v123 voltou como era: tela cheia de verdade, e o aviso aparece por alguns segundos quando ela começa.
