/* Item (a): pop-ups devem seguir a fonte e o modo (caixa alta/baixa)
   escolhidos nas Configurações.
   Item (b): botão "Próxima sílaba" deve estar na MESMA barra e MESMA
   altura do botão "▶" normal, não mais flutuando por cima da tela. */
const { carregarApp, t, tAsync, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_03_popups_e_botao');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);

  t('#lpProximaSilaba existe e não tem mais style inline "display:none" fixo', () => {
    const btn = doc.getElementById('lpProximaSilaba');
    assert(!!btn, 'botão não encontrado');
    const style = btn.getAttribute('style');
    assert(!style, 'botão ainda tem style inline (' + style + ') — isso sobrescreve a classe .mostra e o deixa invisível pra sempre');
  });

  t('#lpProximaSilaba está DENTRO da #lpBar (mesma barra do botão ▶)', () => {
    const btn = doc.getElementById('lpProximaSilaba');
    const bar = doc.getElementById('lpBar');
    assert(bar.contains(btn), 'botão não está mais dentro de #lpBar');
  });

  t('#lpProximaSilaba está no MESMO grupo flex que o #lpNext (grudado nele, não solto na barra)', () => {
    const btn = doc.getElementById('lpProximaSilaba');
    const next = doc.getElementById('lpNext');
    assertEq(btn.parentElement, next.parentElement, 'botão e "▶" não compartilham mais o mesmo container — voltam a ficar separados pelo justify-content:space-between da barra');
  });

  t('#lpProximaSilaba fica logo antes do #lpNext (mesma linha, lado a lado)', () => {
    const btn = doc.getElementById('lpProximaSilaba');
    const next = doc.getElementById('lpNext');
    assertEq(btn.nextElementSibling, next, 'botão não está mais imediatamente antes do "▶"');
  });

  t('O grupo que junta #lpProximaSilaba + #lpNext usa align-items:stretch (garante MESMA altura entre os dois, calculada pelo navegador)', () => {
    const grupo = doc.getElementById('lpNextGrupo');
    assert(grupo, '#lpNextGrupo não encontrado — o botão deveria estar dentro de um wrapper junto com #lpNext');
    assert(grupo.contains(doc.getElementById('lpProximaSilaba')) && grupo.contains(doc.getElementById('lpNext')),
      '#lpNextGrupo não contém os dois botões');
    const styleAttr = grupo.getAttribute('style') || '';
    assert(/align-items:\s*stretch/.test(styleAttr), '#lpNextGrupo não tem align-items:stretch — sem isso a altura não é garantida igual à do "▶"');
  });

  t('CSS de #lpProximaSilaba não usa mais position:fixed (agora é item normal da barra)', () => {
    const css = window.eval(`
      Array.from(document.styleSheets).map(function(ss){
        try{ return Array.from(ss.cssRules).map(function(r){ return r.cssText||''; }).join('\\n'); }
        catch(e){ return ''; }
      }).join('\\n')
    `);
    const regra = css.split('\n').find(l => l.indexOf('#lpProximaSilaba') === 0 || l.indexOf('#lpProximaSilaba{') >= 0);
    assert(regra, 'regra CSS de #lpProximaSilaba não encontrada');
    assert(regra.indexOf('position: fixed') < 0 && regra.indexOf('position:fixed') < 0, 'CSS ainda tem position:fixed: ' + regra);
  });

  await tAsync('confirmModal aplica a fonte escolhida (FONTS[fontIdx].css) no card do pop-up', async () => {
    window.eval('fontIdx = 1;'); // uma fonte qualquer com mode:'caps'
    const p = window.confirmModal({titulo:'Teste', linhas:['linha'], simTxt:'Sim', naoTxt:'Não'});
    await esperar(50);
    const card = doc.getElementById('cfmCard');
    const fonteEsperada = window.eval('FONTS[1].css');
    assert(card.style.fontFamily && card.style.fontFamily.length > 0, 'cfmCard não recebeu font-family nenhuma');
    // resolve o modal pra não deixar a Promise pendurada
    doc.getElementById('cfmSim').click();
    await p;
  });

  await tAsync('confirmModal aplica caixa alta (.caps) quando capsOn() é verdadeiro', async () => {
    window.eval('capsMode = true; fontIdx = 2;'); // fonte sem mode fixo -> usa capsMode
    const p = window.confirmModal({titulo:'Teste2', linhas:['linha'], simTxt:'Sim', naoTxt:'Não'});
    await esperar(50);
    const card = doc.getElementById('cfmCard');
    assert(card.classList.contains('caps'), 'cfmCard devia ter a classe .caps com capsMode=true');
    doc.getElementById('cfmNao').click();
    await p;
  });

  t('CSS #cfmCard.caps existe e usa text-transform:uppercase', () => {
    const css = window.eval(`
      Array.from(document.styleSheets).map(function(ss){
        try{ return Array.from(ss.cssRules).map(function(r){ return r.cssText||''; }).join('\\n'); }
        catch(e){ return ''; }
      }).join('\\n')
    `);
    const regra = css.split('\n').find(l => l.indexOf('#cfmCard.caps') >= 0);
    assert(regra, 'regra #cfmCard.caps não encontrada no CSS');
    assert(/text-transform:\s*uppercase/.test(regra), 'regra não aplica text-transform:uppercase: ' + regra);
  });

  resumo();
})();
