> ⚠️ **DOCUMENTO ANTIGO, guardado só como histórico.** Onde ele contradisser o `documentos/HISTORICO_E_PLANO_alfabetizacao.md`, vale o HISTORICO_E_PLANO (por exemplo: o zip do Netlify leva os 8 arquivos **na raiz**, sem pasta; os testes precisam de `npm install`; hoje são 310 testes; `CHAVES_LEITORA` tem 33 chaves).

# Continuar o 📚 Esforço Vence — Alfabetização numa conversa nova

**Como usar (Pedro):** abra uma conversa nova, anexe os arquivos abaixo, cole o texto entre **COPIE DAQUI** e **ATÉ AQUI** e escreva o que quer mudar.

Anexar:
- `index.html` **mais recente** (o que está publicado — de dentro do `esforco-vence-netlify.zip`);
- `ESFORCO-VENCE-DOCUMENTACAO.md` (explica tudo do app);
- `nuvem-sync.js` e `escola-pwa.js` (os mesmos de todos os apps);
- se for mexer em cadastro/nuvem: `PADRAO_CADASTRO_NOME_BICHINHO.md` e `REFERENCIA_INTEGRACAO_CURIOSIDADES.md`;
- se quiser rodar os testes: `esforco-vence-testes.zip`.
- **Não precisa anexar** o seu `nuvem-config.js` (ele fica com você; é o mesmo em todos os apps).

`========== COPIE DAQUI ==========`

Olá! Vamos continuar o app **📚 Esforço Vence — Alfabetização** da Escola São Pedro (https://escolasaopedroalfabetizacao.netlify.app/, ID na nuvem `alfabetizacao`). Anexei o `index.html` mais recente e a `ESFORCO-VENCE-DOCUMENTACAO.md`: **leia a documentação inteira antes de mexer**, principalmente as seções 3, 4b a 4f e 5 (aprendizados difíceis).

Estado atual: **v121** (cache `esforco-vence-v121`), 310 testes passando (89 em `testes/` com Node+JSDOM, 221 em `testes_navegador/` com Playwright e Firebase simulado).

Regras deste app que não podem ser quebradas:
1. **Edições cirúrgicas.** Não reescreva o que funciona. Explique a causa de cada problema em português simples.
2. **Nunca inserir frase no meio do array `DATA`** — só no fim (o progresso é um mapa de posições).
3. **A ordem de leitura é calculada** (`construirTrilha`): primeiro só sílabas simples com frases curtas, depois as complexas começando pelo R. Não voltar a ordenar à mão.
4. **Áudio:** no Ler, só toca se a criança ligar. No Monta a Frase e na Sílaba Perdida, fala a frase sozinho, mas só com a página aberta na tela.
5. **Pop-ups sempre no estilo do app** (`confirmModal`, `#codOv`), seguindo a fonte e a caixa alta das Configurações. **Nunca** `alert()`, `confirm()` ou `prompt()` do navegador.
6. **Cada criança grava com prefixo** (`hana_*` para a leitora "1", `<id>_hana_*` para as outras). Toda chave nova de progresso começa com `hana_` e entra em `CHAVES_LEITORA` (backup, apagar, nuvem). **Cuidado:** o `nuvem-sync.js` troca o `localStorage.setItem`; o app recoloca o prefixo por cima logo depois do `NuvemSync.iniciar` — não mexa nessa ordem sem testar com duas crianças.
7. **Não altere** `nuvem-sync.js`, `escola-pwa.js` nem `nuvem-config.js` (são iguais nos 7 apps). Cadastro segue o `PADRAO_CADASTRO_NOME_BICHINHO.md` (8 bichinhos numa linha, Nome + Bichinho).
8. **A cada entrega:** subir a versão do cache no `sw.js` (próxima: `esforco-vence-v122`), rodar todos os testes, conferir o zip extraído, e entregar o zip do Netlify com: `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`, `nuvem-sync.js`, `escola-pwa.js` e o `nuvem-config.js` (o Pedro troca pelo dele se vier vazio).
9. **Tamanho da letra:** o número das Configurações vale um tamanho fixo medido numa frase-padrão (`fitCaixa` com `REF_LER`/`REF_MONTA`/`REF_SILABA`). Nunca voltar a "esticar até encher o quadro".
10. Se não conseguir rodar algum teste, diga claramente o que foi testado de verdade e o que só foi conferido lendo o código. Termine sempre com um checklist ✅/⬜ em português.

O que eu quero agora: **(escreva aqui)**

`========== ATÉ AQUI ==========`
