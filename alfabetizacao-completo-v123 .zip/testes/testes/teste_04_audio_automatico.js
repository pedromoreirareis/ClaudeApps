/* Item (d): no Monta a Frase e no Sílaba Perdida, a frase tem que ser
   falada SEMPRE que aparece na tela (entrada, Próxima e Anterior),
   independente do interruptor de áudio (🔇/🔊).
   Como o JSDOM não tem Web Speech API de verdade, aqui a gente
   substitui speak() por um espião e dispara os fluxos reais do app
   (abrir a página, clicar ▶/◀) pra confirmar que ela É CHAMADA — não
   dá pra "ouvir", mas dá pra provar que a chamada acontece sempre,
   mesmo com o áudio manual desligado (audioOn=false). */
const { carregarApp, t, tAsync, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_04_audio_automatico');
  const dom = carregarApp();
  const { window } = dom;
  await esperar(300);

  // espiona speak() sem precisar que ela realmente fale nada
  // desde a v117 a fala automática só acontece com a página ABERTA na tela
  window.eval("document.getElementById('pgMonta').classList.add('open'); document.getElementById('pgSilaba').classList.add('open');");
  window.eval(`
    window._faladas = [];
    window._speakOriginal = window.speak;
    window.speak = function(txt){ window._faladas.push(txt); };
  `);

  await tAsync('Monta a Frase fala a frase ao ABRIR, mesmo com audioOn=false', async () => {
    window.eval('audioOn = false; window._faladas = [];');
    window.eval('openMonta(5);');
    await esperar(1200); // o app agenda a fala com setTimeout(...,1000)
    const faladas = window.eval('window._faladas');
    assert(faladas.length > 0, 'speak() não foi chamada ao abrir Monta a Frase com áudio desligado');
  });

  await tAsync('Monta a Frase fala a frase de novo ao clicar em "▶" (irMonta)', async () => {
    window.eval('audioOn = false; window._faladas = [];');
    window.eval("document.getElementById('mtNext').onclick();");
    await esperar(1200);
    const faladas = window.eval('window._faladas');
    assert(faladas.length > 0, 'speak() não foi chamada ao clicar em "▶" no Monta a Frase');
  });

  await tAsync('Sílaba Perdida fala a frase ao ABRIR, mesmo com audioOn=false', async () => {
    window.eval('audioOn = false; window._faladas = [];');
    window.eval('openSilaba(5);');
    await esperar(1200);
    const faladas = window.eval('window._faladas');
    assert(faladas.length > 0, 'speak() não foi chamada ao abrir Sílaba Perdida com áudio desligado');
  });

  await tAsync('Sílaba Perdida fala a frase de novo ao clicar em "▶" (irSilaba)', async () => {
    window.eval('audioOn = false; window._faladas = [];');
    window.eval("document.getElementById('spNext').onclick();");
    await esperar(1200);
    const faladas = window.eval('window._faladas');
    assert(faladas.length > 0, 'speak() não foi chamada ao clicar em "▶" no Sílaba Perdida');
  });

  t('Código-fonte: nenhuma das duas falas automáticas de entrada ainda está condicionada a audioOn', () => {
    const fs = require('fs');
    const path = require('path');
    const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf-8');
    // procura em TODOS os <script> da página (desde a v120 o 1º é o do nuvem-config)
    const js = (html.match(/<script[^>]*>([\s\S]*?)<\/script>/g) || []).join('\n');
    // as 2 chamadas de "fala ao entrar" (window._mtTxt / window._spTxt)
    // não podem mais ter "audioOn" na mesma linha do setTimeout que fala
    const linhaMt = js.split('\n').find(l => l.includes('speak(window._mtTxt)') && l.includes('setTimeout'));
    const linhaSp = js.split('\n').find(l => l.includes('speak(window._spTxt)') && l.includes('setTimeout') && l.includes('1000'));
    assert(linhaMt, 'não encontrei a linha do setTimeout que fala window._mtTxt');
    assert(linhaSp, 'não encontrei a linha do setTimeout que fala window._spTxt');
    assert(!/audioOn/.test(linhaMt), 'a fala automática do Monta a Frase ainda está condicionada a audioOn: ' + linhaMt.trim());
    assert(!/audioOn/.test(linhaSp), 'a fala automática do Sílaba Perdida ainda está condicionada a audioOn: ' + linhaSp.trim());
  });

  resumo();
})();
