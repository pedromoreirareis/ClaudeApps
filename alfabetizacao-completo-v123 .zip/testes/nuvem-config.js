/* ==================================================================
   ⚠️ ARQUIVO SÓ PARA OS TESTES AUTOMÁTICOS — NÃO PUBLICAR ⚠️
   Chaves FALSAS: os testes nunca falam com o Firebase de verdade
   (usam um Firebase simulado). O arquivo de verdade, com as suas
   chaves, está em pacote-netlify/ (é o que vai para o Netlify).
   O teste_pwa.py precisa deste arquivo aqui (o service worker guarda ele).
   ================================================================== */
window.NUVEM_CONFIG = { apiKey: 'chave-de-teste', projectId: 'projeto-teste', familia: '' };
