/* Item (e): ao acertar uma frase no Monta a Frase ou no Sílaba Perdida,
   ela fica marcada — e ao passar de novo por ela (Próxima/Anterior),
   o visual de "já concluída" tem que aparecer sozinho, sem precisar
   acertar de novo. */
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_05_frases_concluidas');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);

  t('marcarConcluida + estaConcluida: guarda e recupera corretamente por módulo e índice', () => {
    window.marcarConcluida('monta', 7);
    assertEq(window.estaConcluida('monta', 7), true, 'índice 7 devia estar marcado em "monta"');
    assertEq(window.estaConcluida('monta', 8), false, 'índice 8 não devia estar marcado');
    assertEq(window.estaConcluida('silaba', 7), false, '"monta" e "silaba" precisam ser namespaces separados');
  });

  t('marcarConcluida persiste em localStorage sob a chave hana_<modulo>_ok', () => {
    window.marcarConcluida('silaba', 99);
    const bruto = window.eval("localStorage.getItem('hana_silaba_ok')");
    assert(bruto, 'nada foi salvo em hana_silaba_ok');
    const lista = JSON.parse(bruto);
    assert(lista.indexOf(99) >= 0, 'índice 99 não está na lista salva: ' + bruto);
  });

  t('aplicarVisualConcluida liga a classe .jaConcluida quando a frase já foi concluída', () => {
    window.marcarConcluida('monta', 123);
    window.aplicarVisualConcluida('mtWrap', 'monta', 123);
    assert(doc.getElementById('mtWrap').classList.contains('jaConcluida'), '#mtWrap devia ter a classe .jaConcluida');
  });

  t('aplicarVisualConcluida DESLIGA a classe ao entrar numa frase ainda não concluída (não fica "grudada")', () => {
    window.aplicarVisualConcluida('mtWrap', 'monta', 123); // deixa ligada
    assert(doc.getElementById('mtWrap').classList.contains('jaConcluida'), 'pré-condição falhou');
    window.aplicarVisualConcluida('mtWrap', 'monta', 456); // índice nunca marcado
    assert(!doc.getElementById('mtWrap').classList.contains('jaConcluida'), '.jaConcluida não devia continuar ligada numa frase nova');
  });

  t('openMonta() aplica o visual de concluída sozinho, sem precisar responder de novo', () => {
    window.eval("try{ localStorage.removeItem('hana_monta_ok'); }catch(e){}");
    window.marcarConcluida('monta', 42);
    window.eval('openMonta(42);');
    assert(doc.getElementById('mtWrap').classList.contains('jaConcluida'), 'reabrir uma frase já concluída no Monta a Frase devia mostrar o selo sozinho');
    window.eval('openMonta(43);'); // frase não concluída
    assert(!doc.getElementById('mtWrap').classList.contains('jaConcluida'), 'uma frase NÃO concluída não devia mostrar o selo');
  });

  t('openSilaba() aplica o visual de concluída sozinho, sem precisar responder de novo', () => {
    window.eval("try{ localStorage.removeItem('hana_silaba_ok'); }catch(e){}");
    // openSilaba pode "andar pra frente" se a frase pedida não tiver
    // sílaba múltipla — por isso lê o índice REAL de volta (jReal).
    const jReal = window.eval('openSilaba(10);');
    window.marcarConcluida('silaba', jReal);
    window.eval('openSilaba(' + jReal + ');');
    assert(doc.getElementById('spWrap').classList.contains('jaConcluida'), 'reabrir uma frase já concluída no Sílaba Perdida devia mostrar o selo sozinho');
  });

  t('CSS .jaConcluida existe pros dois wraps (#mtWrap e #spWrap) e dá efeito visual de "feito"', () => {
    const css = window.eval(`
      Array.from(document.styleSheets).map(function(ss){
        try{ return Array.from(ss.cssRules).map(function(r){ return r.cssText||''; }).join('\\n'); }
        catch(e){ return ''; }
      }).join('\\n')
    `);
    assert(/#mtWrap\.jaConcluida/.test(css), 'CSS não tem regra pra #mtWrap.jaConcluida');
    assert(/#spWrap\.jaConcluida/.test(css), 'CSS não tem regra pra #spWrap.jaConcluida');
  });

  t('hana_monta_ok e hana_silaba_ok estão em CHAVES_LEITORA (senão não são salvas/restauradas ao trocar de leitora)', () => {
    const chaves = window.eval('CHAVES_LEITORA');
    assert(chaves.indexOf('hana_monta_ok') >= 0, 'hana_monta_ok não está em CHAVES_LEITORA');
    assert(chaves.indexOf('hana_silaba_ok') >= 0, 'hana_silaba_ok não está em CHAVES_LEITORA');
  });

  resumo();
})();
