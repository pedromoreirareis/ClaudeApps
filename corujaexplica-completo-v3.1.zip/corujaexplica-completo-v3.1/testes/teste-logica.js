/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Camada 1: lógica de texto (CorujaLogic) direto no Node, sem navegador.
   O módulo é extraído de dentro do index.html para garantir que o que está
   sendo testado é exatamente o que vai ser publicado. */
const fs = require('fs');

const INDEX = process.env.CORUJA_INDEX || require('path').join(__dirname, '..', 'pacote-netlify', 'index.html');
const TMP = require('path').join(process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'), '_logic.js'); require('fs').mkdirSync(require('path').dirname(TMP), { recursive: true });

const html = fs.readFileSync(INDEX, 'utf8');
const script = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m => m[1]).find(t => t.includes('(function(root)'));
const linhas = script.split('\n');
const ini = linhas.findIndex(l => l.startsWith('(function(root)'));
const fim = linhas.findIndex(l => l.startsWith('})(typeof window'));
if (ini < 0 || fim < 0) { console.error('Não achei o módulo CorujaLogic'); process.exit(1); }
fs.writeFileSync(TMP, linhas.slice(ini, fim + 1).join('\n'));
delete require.cache[TMP];
const C = require(TMP);

let falhas = 0, total = 0;
function ok(nome, cond, detalhe) {
  total++;
  if (cond) console.log('✅', nome, detalhe ? '— ' + detalhe : '');
  else { console.log('❌', nome, detalhe ? '— ' + detalhe : ''); falhas++; }
}

const TEXTO_COMPLETO = `PARA O PAI:
Aparecem travessão, aspas e reticências.

TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?

TAGS: sol, espaço, estrela, sistema solar, astronomia, céu

TEXTO:
Você já sentiu o calor do Sol no rosto? Ele é uma estrela enorme, e a luz dele atravessa a atmosfera antes de chegar até você.

— Pai, será que eu poderia chegar perto do Sol?

— Não seria possível, porque o Sol é quente demais.

Você pode observar algumas fases da Lua:

• Lua nova: a parte iluminada fica do outro lado.

• Lua cheia: vemos quase toda a face iluminada.

PALAVRAS NOVAS:
atmosfera = é a camada de ar que fica em volta de um planeta inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar que você respira.
alerta = quando o corpo fica ligado e pronto para agir.

PERGUNTAS:
1) Por que a Lua parece brilhar?
a) Porque tem fogo dentro dela.
b) Porque devolve a luz que vem do Sol. *
c) Porque tem lâmpadas escondidas.
> A Lua não faz luz própria: ela devolve para nós a luz que vem do Sol.

2) O que a atmosfera faz pela gente?
a) Segura o ar que a gente respira. *
b) Faz o Sol girar mais devagar.
c) Deixa a Lua mais quente.
> A atmosfera é o cobertor de ar do planeta, e é ele que mantém o ar por perto.

3) O Sol é o quê?
a) Um planeta como a Terra.
b) Uma lua grande.
c) Uma estrela. *
> Estrela é um astro que fabrica a própria luz, e o Sol faz exatamente isso.

PARA PENSAR:
O que você acha mais incrível no céu?`;

console.log('\n### 1. Formato Coruja completo\n');

const r = C.interpretarTexto(TEXTO_COMPLETO);
ok('Título lido', r.titulo === 'Você já imaginou uma viagem até o Sol?', `"${r.titulo}"`);
ok('Emoji colorido preservado (com seletor de variação)',
  r.emoji === '☀️' && Array.from(r.emoji).length === 2, `${r.emoji} (${Array.from(r.emoji).map(c => c.codePointAt(0).toString(16)).join(',')})`);
ok('Bloco PARA O PAI é ignorado', !r.paragrafos.some(p => /Aparecem travessão/.test(p.texto)));
ok('Tags lidas', r.tags.length === 6 && r.tags[0] === 'sol', JSON.stringify(r.tags));
ok('Tags não viram parágrafo lido', !r.paragrafos.some(p => /astronomia/i.test(p.texto)));
ok('Falas com travessão viram parágrafos próprios', r.paragrafos.filter(p => /^—/.test(p.texto)).length === 2);
ok('Itens de lista viram tipo "exemplo"', r.paragrafos.filter(p => p.tipo === 'exemplo').length === 2);
ok('Dicionário com definição longa preservada', (r.palavrasNovas['atmosfera'] || '').length > 100, `${(r.palavrasNovas['atmosfera'] || '').length} caracteres`);
ok('Dicionário com definição curta preservada', (r.palavrasNovas['alerta'] || '').length < 70, `${(r.palavrasNovas['alerta'] || '').length} caracteres`);
ok('Perguntas não viram parágrafo lido', !r.paragrafos.some(p => /lâmpadas escondidas/i.test(p.texto)));
ok('Para pensar lido', /incrível no céu/.test(r.paraPensar || ''));

console.log('\n### 2. O quiz\n');

ok('As 3 perguntas foram lidas', r.perguntas.length === 3, `${r.perguntas.length}`);
if (r.perguntas.length === 3) {
  ok('Cada pergunta tem 3 alternativas', r.perguntas.every(q => q.opcoes.length === 3));
  ok('Cada pergunta tem uma alternativa certa marcada', r.perguntas.every(q => q.certa >= 0));
  ok('A alternativa certa da 1ª é a do reflexo do Sol', /devolve a luz/i.test(r.perguntas[0].opcoes[r.perguntas[0].certa]));
  ok('A alternativa certa da 3ª é "uma estrela"', /estrela/i.test(r.perguntas[2].opcoes[r.perguntas[2].certa]));
  ok('O asterisco não sobra no texto da alternativa', r.perguntas.every(q => q.opcoes.every(o => !o.includes('*'))));
  ok('Cada pergunta tem a explicação do porquê', r.perguntas.every(q => q.explicacao && q.explicacao.length > 20));
  ok('A explicação não começa com o sinal de maior', r.perguntas.every(q => !q.explicacao.startsWith('>')));
}

// tolerância: outros jeitos que a IA pode escrever
const variantes = [
  ['ponto em vez de parêntese', '1. Pergunta assim?\na. Errada.\nb. Certa. *\nc. Outra errada.\n> Porque sim.'],
  ['asterisco antes do texto', '1) Pergunta?\na) Errada.\nb) * Certa.\nc) Outra.\n> Porque sim.'],
  ['marcação (correta)', '1) Pergunta?\na) Errada.\nb) Certa. (correta)\nc) Outra.\n> Porque sim.'],
  ['negrito markdown em volta', '**1) Pergunta?**\na) Errada.\n**b) Certa. ***\nc) Outra.\n> Porque sim.'],
  ['explicação em duas linhas', '1) Pergunta?\na) Errada.\nb) Certa. *\nc) Outra.\n> Porque sim,\ne também por isso.']
];
variantes.forEach(([nome, txt]) => {
  const qs = C.parsePerguntas(txt.split('\n'));
  ok(`Quiz entende a variação: ${nome}`, qs.length === 1 && qs[0].certa === 1, qs.length ? `certa=${qs[0].certa} "${qs[0].opcoes[qs[0].certa]}"` : 'nenhuma pergunta lida');
});

const incompleta = C.parsePerguntas('1) Pergunta sem alternativa certa?\na) Uma.\nb) Outra.'.split('\n'));
ok('Pergunta sem resposta certa é descartada (não entra no quiz quebrada)', incompleta.length === 0);

console.log('\n### 3. O Formatar não pode destruir nada\n');

const arrumado = C.arrumarParaCaixa(TEXTO_COMPLETO);
const r2 = C.interpretarTexto(arrumado);
ok('Título sobrevive ao Formatar', r2.titulo === r.titulo);
ok('Emoji sobrevive ao Formatar', r2.emoji === r.emoji);
ok('Parágrafos sobrevivem ao Formatar', r2.paragrafos.length === r.paragrafos.length, `${r2.paragrafos.length}`);
ok('TAGS sobrevivem ao Formatar', JSON.stringify(r2.tags) === JSON.stringify(r.tags), JSON.stringify(r2.tags));
ok('PERGUNTAS sobrevivem ao Formatar', r2.perguntas.length === 3 && r2.perguntas.every(q => q.certa >= 0));
ok('Explicações do quiz sobrevivem ao Formatar', r2.perguntas.every(q => q.explicacao.length > 20));
ok('Dicionário sobrevive ao Formatar', Object.keys(r2.palavrasNovas).length === 2);
ok('Para pensar sobrevive ao Formatar', r2.paraPensar === r.paraPensar);
ok('Formatar duas vezes dá o mesmo texto (idempotente)', C.arrumarParaCaixa(arrumado) === arrumado);

// o caso que já quebrou antes: rótulos colados, sem linha em branco
const colado = TEXTO_COMPLETO.replace(/\n\n(TAGS|TEXTO|PALAVRAS NOVAS|PERGUNTAS|PARA PENSAR):/g, '\n$1:');
const r3 = C.interpretarTexto(C.arrumarParaCaixa(colado));
ok('Rótulos colados sem linha em branco continuam funcionando',
  r3.titulo === r.titulo && r3.tags.length === 6 && r3.perguntas.length === 3,
  `título ok, ${r3.tags.length} tags, ${r3.perguntas.length} perguntas`);

console.log('\n### 4. Texto livre e pontuação\n');

const livre = 'Isso é uma frase solta sem formato nenhum. Aqui vem outra frase.\n\nE aqui um parágrafo novo, com mais conteúdo.';
const arrLivre = C.arrumarParaCaixa(livre);
ok('Texto livre não ganha rótulos indevidos', !/TÍTULO:|TAGS:|PERGUNTAS:/.test(arrLivre));
const rLivre = C.interpretarTexto(livre);
ok('Texto livre devolve tags e perguntas vazias (sem quebrar)',
  Array.isArray(rLivre.tags) && rLivre.tags.length === 0 && Array.isArray(rLivre.perguntas) && rLivre.perguntas.length === 0);

const tricky = 'O Dr. Silva mediu 3.5 metros. Ele pensou: "Eu consigo." Depois foi embora...';
const junto = C.limparEDividirEmParagrafos(tricky).map(p => p.texto).join(' ');
ok('Número decimal não vira fim de frase', /3\.5/.test(junto));
ok('Abreviação "Dr." não vira fim de frase', /Dr\. Silva/.test(junto));
ok('Aspas de fechamento ficam na mesma frase', /"Eu consigo\."/.test(junto));
ok('Reticências preservadas', /\.\.\.|…/.test(junto));

console.log('\n### 5. Emojis de todos os tipos\n');
[['☀️ Sol', '☀️'], ['🫁 Pulmão', '🫁'], ['👩‍🚀 Astronauta', '👩‍🚀'], ['👍🏽 Joia', '👍🏽'], ['Sem emoji', null]]
  .forEach(([entrada, esperado]) => {
    const e = C.extraiEmoji(entrada);
    ok(`Emoji lido inteiro: ${JSON.stringify(entrada)}`, e.emoji === esperado, JSON.stringify(e.emoji));
  });

console.log('\n### 6. Os cinco pedidos (o cérebro do aplicativo)\n');

const pLeitura = C.montarPrompt('leitura', {});
const pEntender = C.montarPrompt('entender', {});

ok('Existe o pedido "Leitura do dia"', pLeitura.length > 1000);
ok('Existe o pedido "Entender de verdade"', pEntender.length > 1000);
ok('São dois pedidos diferentes', pLeitura !== pEntender);
ok('O nome antigo "explicar" ainda funciona e aponta para a Leitura do dia', C.montarPrompt('explicar', {}) === pLeitura);
ok('Um tipo inexistente devolve vazio, sem quebrar', C.montarPrompt('nao-existe', {}) === '');

// Leitura do dia (v2.0): curto, para ler, reler e recontar
ok('Leitura do dia pede de 300 a 500 palavras', /entre 300 e 500 palavras/.test(pLeitura));
ok('Leitura do dia diz que o número não é regra rígida', /não é uma regra rígida/.test(pLeitura));
ok('Leitura do dia fala em ler, reler e recontar em uns vinte minutos', /ler, reler e recontar/.test(pLeitura) && /vinte minutos/.test(pLeitura));
ok('Leitura do dia dá a ordem de prioridade compreensão → retenção → reconto → quantidade',
  /1º COMPREENSÃO[\s\S]*2º RETENÇÃO[\s\S]*3º RECONTO[\s\S]*4º[\s\S]*QUANTIDADE/.test(pLeitura));
ok('Leitura do dia proíbe tentar colocar o máximo de informação', /NÃO tente colocar o máximo de informação/.test(pLeitura));
ok('Leitura do dia manda escolher as 3 ou 4 ideias principais', /3 ou 4\s+ideias mais importantes/.test(pLeitura));
ok('Leitura do dia manda reduzir escolhendo, não cortando no meio', /Reduza escolhendo e resumindo/.test(pLeitura));
ok('Leitura do dia pede o fecho que a criança consiga repetir', /retome a ideia principal/.test(pLeitura));
ok('Leitura do dia mantém diálogo, destaques, perguntas mesmo curto', /Mesmo curto, o texto mantém tudo/.test(pLeitura));
ok('Leitura do dia manda contar as palavras antes de enviar', /Conte as palavras antes de enviar/.test(pLeitura));
ok('Leitura do dia pede exatamente 3 perguntas', /exatamente 3 perguntas/.test(pLeitura));
ok('Leitura do dia confere o tamanho na conferência final', /entre 300 e 500 palavras\? Conte de verdade/.test(pLeitura));
ok('Leitura do dia não fala mais em 650–950', !/650|950/.test(pLeitura));

// Entender de verdade: o entendimento manda
ok('Entender de verdade diz que o tamanho não importa', /O TAMANHO NÃO IMPORTA/.test(pEntender));
ok('Entender de verdade aceita textos de duas mil palavras', /duas mil/.test(pEntender));
ok('Entender de verdade proíbe pular etapa', /pular etapa/.test(pEntender));
ok('Entender de verdade manda começar do zero', /Comece do zero/.test(pEntender));
ok('Entender de verdade pede degraus pequenos', /degraus pequenos/i.test(pEntender));
ok('Entender de verdade pede recapitulações', /recapitulando/i.test(pEntender));
ok('Entender de verdade pede explicar duas vezes as ideias difíceis', /explique DUAS vezes/.test(pEntender));
ok('Entender de verdade ainda proíbe encher linguiça', /Encher linguiça continua/.test(pEntender));
ok('Entender de verdade pede de 3 a 6 perguntas', /de 3 a 6 perguntas/.test(pEntender));
ok('Entender de verdade NÃO impõe a faixa da Leitura do dia', !/entre 300 e 500 palavras/.test(pEntender));
ok('Entender de verdade dá só uma referência (700 a 1.000) para não cansar', /700 a 1\.000 palavras/.test(pEntender) && /nunca para encher/.test(pEntender));

console.log('\n### 6a. Revisão tripla, destaques, diálogo e parágrafos curtos\n');
['leitura', 'entender', 'adaptar', 'continuar'].forEach(tipo => {
  const p = C.montarPrompt(tipo, { texto: 'X', pergunta: 'Y' });
  ok(`Pedido "${tipo}" tem a REVISÃO TRIPLA OBRIGATÓRIA`, /REVISÃO TRIPLA OBRIGATÓRIA/.test(p));
  ok(`Pedido "${tipo}" traz as três revisões na ordem`, /1ª REVISÃO — LEITURA[\s\S]*2ª REVISÃO — COMPREENSÃO E ENVOLVIMENTO[\s\S]*3ª REVISÃO — CONHECIMENTO/.test(p));
  ok(`Pedido "${tipo}" faz a revisão tripla ANTES da conferência final`, p.indexOf('REVISÃO TRIPLA') < p.indexOf('CONFERÊNCIA FINAL'));
  ok(`Pedido "${tipo}" diz que gramática correta não basta`, /NÃO está pronto só porque está gramaticalmente correto/.test(p));
  ok(`Pedido "${tipo}" limita o parágrafo a quatro linhas`, /quatro linhas/.test(p));
  ok(`Pedido "${tipo}" pede um diálogo`, /diálogo/.test(p));
  ok(`Pedido "${tipo}" NÃO obriga o diálogo a ser entre a filha e o pai`, !/diálogo[^.]{0,20}entre a filha e o pai/.test(p) && !/entre a filha e o pai, (usando|com) travessão/.test(p));
  ok(`Pedido "${tipo}" pede a lista com nome em destaque e dois-pontos`, /•[^\n]*(Nome|nome em destaque|NOME EM)/.test(p) || /nomes em destaque/.test(p));
  ok(`Pedido "${tipo}" pede recontar com as próprias palavras`, /recontar o assunto com as próprias/.test(p));
});
ok('Leitura do dia: diálogo com personagens do assunto (ex.: marinheiro e capitão)', /personagens que\s+combinem com o assunto/.test(pLeitura) && /marinheiro e o\s+capitão/.test(pLeitura));
ok('Leitura do dia: pai e filha continua sendo uma possibilidade, não obrigação', /também pode ser a filha\s+e o pai/.test(pLeitura) && /O importante é TER o diálogo/.test(pLeitura));
ok('Leitura do dia: parágrafos de três a quatro linhas', /Parágrafos de três a quatro linhas/.test(pLeitura));
ok('Leitura do dia: cinco linhas só quando não houver outro jeito', /Cinco linhas, só quando não houver mesmo outro jeito/.test(pLeitura));
ok('Leitura do dia: revisão tripla confere os 3 a 4 linhas', /Cada parágrafo tem de três a quatro linhas/.test(pLeitura));
ok('Leitura do dia: conferência final pergunta dos 3 a 4 linhas', /Os parágrafos ficaram com três a quatro linhas \(fora as falas do diálogo\s+e os itens da lista\)\?/.test(pLeitura));
ok('Leitura do dia não traz mais a regra antiga de "no máximo quatro"', !/no máximo quatro linhas/.test(pLeitura));
['entender', 'adaptar'].forEach(t => {
  const q = C.montarPrompt(t, { texto: 'X', pergunta: 'Y' });
  ok(`"${t}" mantém a regra de parágrafo como estava (só a Leitura do dia mudou)`, /no máximo quatro linhas/.test(q) && !/três a quatro linhas/.test(q));
});
ok('Continuar segue o tamanho de parágrafo do texto anterior (3 a 4 linhas)', /parágrafos do mesmo tamanho dos do texto anterior \(de três a\s+quatro linhas/.test(C.montarPrompt('continuar', { pergunta: 'Y' })));
ok('Diálogo é sempre obrigatório (a regra "deixe de fora" não vale para ele)', /deixe de fora — menos o\s+diálogo, que sempre aparece/.test(pLeitura));
ok('Sem personagens no assunto, o prompt manda criar uma cena curta de pergunta e resposta', /crie uma cena curta em que alguém\s+pergunta e outro responde/.test(pLeitura));
ok('Não há mais "nunca colocado só para cumprir a regra" (contradizia o diálogo obrigatório)', !/só para cumprir a regra/.test(pLeitura));
ok('Fecho do texto sem "uma ou duas frases" (não briga com os 3 a 4 linhas)', !/uma ou duas frases simples/.test(pLeitura));
ok('Exceções dos 3 a 4 linhas: diálogo, itens da lista e a frase que apresenta a lista', /as falas do diálogo, os itens da lista e a frase\s+que apresenta a lista/.test(pLeitura));
ok('Adaptar: personagens do diálogo não trazem fatos novos', /sem trazer fatos novos/.test(C.montarPrompt('adaptar', { texto: 'X' })));
ok('Adaptar: diálogo não precisa ser pai e filha', /não precisa\s+ser pai e filha/.test(C.montarPrompt('adaptar', { texto: 'X' })));
ok('Consertar NÃO recebe revisão tripla (ele só arruma formato)', !/REVISÃO TRIPLA/.test(C.montarPrompt('consertar', {})));
ok('Revisão tripla da Leitura usa a idade (sem "de  anos")', /Leia como uma criança de 6 anos leria/.test(pLeitura));
ok('Exemplo de destaque do prompt é o formato Nome: explicação', /• Acrux: a estrela mais brilhante/.test(pLeitura));
ok('Prompt pede que a frase antes da lista termine em dois-pontos', /termina com\s+dois-pontos, sem ponto depois/.test(pLeitura));

// as regras comuns não podem sair de sincronia entre os dois
[
  ['dicionário proporcional', 'O tamanho da explicação acompanha a DIFICULDADE'],
  ['exemplo de palavra fácil', 'alerta = quando o corpo fica ligado'],
  ['exemplo de palavra difícil', 'atmosfera = é a camada de ar'],
  ['todas as palavras difíceis', 'Inclua TODAS as palavras'],
  ['tags para a busca', 'As tags não aparecem para a criança'],
  ['alternativas erradas plausíveis', 'enganos que uma criança'],
  ['gancho no começo', 'Comece com um gancho'],
  ['proibição de negrito', 'Não use negrito'],
  ['asterisco só na resposta certa', 'único asterisco permitido'],
  ['travessão no diálogo', 'usando travessão'],
  ['crase', 'crase'],
  ['segurança: cientistas continuam estudando', 'cientistas continuam estudando'],
  ['segurança: quem cuida é o médico', 'quem cuida disso é o médico']
].forEach(([nome, trecho]) => {
  ok(`Regra comum nos DOIS pedidos de geração: ${nome}`,
    pLeitura.includes(trecho) && pEntender.includes(trecho));
});

const prompt = pLeitura;
[
  ['exige que a criança consiga explicar para outra pessoa', /explicar o\s+assunto para outra pessoa/i],
  ['exige gancho no começo', /gancho/i],
  ['proíbe começar com "vamos aprender sobre"', /vamos aprender sobre/i],
  ['pede momentos de surpresa', /não sabia disso/i],
  ['manda incluir TODAS as palavras difíceis', /TODAS as palavras/],
  ['faz a explicação do dicionário ser proporcional à dificuldade', /acompanha a DIFICULDADE|acompanha a dificuldade/],
  ['dá exemplo de palavra fácil com uma frase só', /alerta = quando o corpo fica ligado/],
  ['dá exemplo de palavra difícil com comparação', /atmosfera = é a camada de ar/],
  ['avisa que explicação longa em palavra fácil cansa', /cansa/i],
  ['pede as TAGS para busca', /TAGS/],
  ['diz que as tags não aparecem para a criança', /não aparecem para a criança/],
  ['pede exatamente 3 perguntas', /exatamente 3 perguntas/i],
  ['exige alternativas erradas plausíveis', /enganos que uma criança/i],
  ['proíbe alternativa boba', /alternativa boba/i],
  ['pede a linha de explicação do quiz', /começando com >/],
  ['exige uma pergunta que junte duas partes do texto', /juntar duas partes/i],
  ['mantém o travessão no diálogo', /travess/i],
  ['mantém a crase', /crase/i],
  ['mantém a lista com bolinha', /•/],
  ['mantém as regras de segurança', /cientistas|médico|adulto/i],
  ['proíbe negrito', /negrito/i],
  ['libera o asterisco só para marcar a resposta certa', /único asterisco permitido/i],
  ['traz o formato de resposta com todos os rótulos', /TÍTULO:[\s\S]*TAGS:[\s\S]*TEXTO:[\s\S]*PALAVRAS NOVAS:[\s\S]*PERGUNTAS:[\s\S]*PARA PENSAR:/]
].forEach(([nome, re]) => ok('Prompt ' + nome, re.test(prompt)));
ok('Prompt não deixa {{ }} sem preencher', !/\{\{/.test(prompt));
ok('Prompt não traz mais o campo TAMANHO fixo', !/^TAMANHO: /m.test(prompt));

const pAdaptar = C.montarPrompt('adaptar', { texto: 'MEU TEXTO ORIGINAL' });
ok('Adaptar inclui o texto do pai', /MEU TEXTO ORIGINAL/.test(pAdaptar));
ok('Adaptar pede TAGS e PERGUNTAS', /TAGS/.test(pAdaptar) && /PERGUNTAS/.test(pAdaptar));
ok('Adaptar tem o dicionário proporcional', /dificuldade da palavra/i.test(pAdaptar));
ok('Adaptar não deixa {{ }} sobrando', !/\{\{/.test(pAdaptar));

const pContinuar = C.montarPrompt('continuar', { pergunta: 'MINHA PERGUNTA' });
ok('Continuar inclui a pergunta', /MINHA PERGUNTA/.test(pContinuar));
ok('Continuar lembra das TAGS e PERGUNTAS', /TAGS/.test(pContinuar) && /PERGUNTAS/.test(pContinuar));

console.log('\n### 6b. A conferência final em todos os pedidos\n');
['leitura', 'entender', 'adaptar', 'continuar', 'consertar'].forEach(tipo => {
  const p = C.montarPrompt(tipo, { texto: 'X', pergunta: 'Y' });
  ok(`Pedido "${tipo}" tem a conferência final`, /CONFERÊNCIA FINAL/.test(p));
  ok(`Pedido "${tipo}" manda conferir antes de enviar`, /ANTES DE ENVIAR|antes de responder/i.test(p));
  ok(`Pedido "${tipo}" manda não comentar a conferência`, /não comente a conferência|não escreva sobre a conferência|Não comente a conferência/i.test(p));
  ok(`Pedido "${tipo}" fecha com "só então envie"`, /Só então envie a resposta/.test(p));
  ok(`Pedido "${tipo}" confere a ortografia`, /ortografia/i.test(p) || tipo === 'consertar');
  ok(`Pedido "${tipo}" confere o formato dos rótulos`, /rótulos/i.test(p));
  ok(`Pedido "${tipo}" não deixa {{ }} sobrando`, !/\{\{/.test(p));
});
const pExplicar = C.montarPrompt('leitura', {});
ok('A conferência do pedido principal checa os fatos inventados', /inventad/i.test(pExplicar));
ok('A conferência do pedido principal checa o tamanho do dicionário', /tamanho certo para a dificuldade/i.test(pExplicar));
ok('A conferência do pedido principal checa as alternativas do quiz', /engano possível/i.test(pExplicar));
ok('A conferência do pedido principal manda cortar repetição', /repetiu alguma ideia/i.test(pExplicar));

const pConsertar = C.montarPrompt('consertar', {});
ok('Consertar cita o formato completo', /TAGS/.test(pConsertar) && /PERGUNTAS/.test(pConsertar));
ok('Consertar mostra o formato das perguntas', /alternativa certa \*/.test(pConsertar));

console.log('\n### 6c. Silabador (separar sílabas no fim da linha)\n');
const SH = '\u00AD';
const vis = t => t.split(SH).join('-');
// separação conferida à mão
[
  ['constelação','cons·te·la·ção'], ['navegadores','na·ve·ga·do·res'], ['hemisfério','he·mis·fé·rio'],
  ['referência','re·fe·rên·cia'], ['pássaro','pás·sa·ro'], ['carro','car·ro'], ['queijo','quei·jo'],
  ['guerreiro','guer·rei·ro'], ['história','his·tó·ria'], ['saída','sa·í·da'], ['país','pa·ís'],
  ['coração','co·ra·ção'], ['Gabriel','Ga·bri·el'], ['psicólogo','psi·có·lo·go'], ['advogado','ad·vo·ga·do'],
  ['ritmo','rit·mo'], ['oxigênio','o·xi·gê·nio'], ['técnica','téc·ni·ca'], ['transporte','trans·por·te'],
  ['exceção','ex·ce·ção'], ['piscina','pis·ci·na'], ['nascer','nas·cer'], ['bisavô','bi·sa·vô']
].forEach(([p, esp]) => ok(`Sílabas de "${p}"`, C.silabasDe(p).join('·') === esp, C.silabasDe(p).join('·')));
ok('Hífen invisível nas sílabas de CONSTELAÇÃO', vis(C.hifenizarPalavra('constelação', true)) === 'cons-te-la-ção');
ok('Nunca deixa uma letra sozinha no começo (amigo → ami-go)', vis(C.hifenizarPalavra('amigo', true)) === 'ami-go');
ok('Nunca deixa uma letra sozinha no fim (rádio não quebra no "o")', vis(C.hifenizarPalavra('rádio', true)) === 'rá-dio');
ok('Palavra curta (3 letras) fica inteira', C.hifenizarPalavra('céu', true) === 'céu');
ok('Pontuação grudada é preservada', vis(C.hifenizarPalavra('constelação.', true)) === 'cons-te-la-ção.');
ok('Aspas e parênteses são preservados', vis(C.hifenizarPalavra('“Estou', true)) === '“Es-tou' && C.hifenizarPalavra('(que', true) === '(que');
ok('Palavra com hífen: o hífen fica e cada parte é separada', vis(C.hifenizarPalavra('guarda-chuva', true)) === 'guar-da-chu-va');
ok('Pronome com hífen (encontrá-lo)', vis(C.hifenizarPalavra('encontrá-lo', true)) === 'en-con-trá-lo');
ok('Sigla não é cortada (GPS, ONU, DNA)', ['GPS','ONU','DNA','IBGE'].every(x => C.hifenizarPalavra(x, true) === x));
ok('Número não é cortado', C.hifenizarPalavra('2024', true) === '2024' && C.hifenizarPalavra('1,4', true) === '1,4');
ok('Palavra estrangeira (k, w, y, sh) não é cortada', ['playground','show','kiwi','Wagner'].every(x => C.hifenizarPalavra(x, true) === x));
ok('Travessão sozinho fica intacto', C.hifenizarPalavra('—', true) === '—');
ok('Texto inteiro: espaços e quebras preservados', C.hifenizarTexto('Oi,  tudo\nbem?').split(SH).join('') === 'Oi,  tudo\nbem?');
ok('Texto normal: sigla fica, palavras separam',
  vis(C.hifenizarTexto('O GPS ajuda a encontrar o hemisfério.')) === 'O GPS aju-da a en-con-trar o he-mis-fé-rio.');
ok('Texto todo em MAIÚSCULAS: aí toda palavra pode separar',
  vis(C.hifenizarTexto('SARA E O SAPO FORAM PASSEAR NA FLORESTA.')) === 'SA-RA E O SA-PO FO-RAM PAS-SE-AR NA FLO-RES-TA.');
ok('Tirando os hífens invisíveis, o texto volta exatamente igual', (() => {
  const t = C.interpretarTexto(TEXTO_COMPLETO).paragrafos.map(p => p.texto).join('\n');
  return C.hifenizarTexto(t).split(SH).join('') === t;
})());
ok('Silabador aguenta texto grande rápido', (() => {
  const t0 = Date.now(); C.hifenizarTexto(Array(300).fill('A constelação do Cruzeiro do Sul ajudava os navegadores.').join(' '));
  return Date.now() - t0 < 1500;
})());
ok('Entrada vazia/nula não quebra', C.hifenizarTexto('') === '' && C.hifenizarTexto(null) === '');

console.log('\n### 6d. Nome em destaque na lista\n');
ok('"Acrux: ..." destaca 1 palavra', C.palavrasDoTermo('Acrux: a estrela mais brilhante.') === 1);
ok('"Alfa Crucis: ..." destaca 2 palavras', C.palavrasDoTermo('Alfa Crucis: outra estrela.') === 2);
ok('"Acrux, também chamada..." (formato antigo) destaca 1', C.palavrasDoTermo('Acrux, também chamada Alfa Crucis, é a estrela.') === 1);
ok('"Nome — explicação" destaca o nome', C.palavrasDoTermo('Mimosa — outra estrela.') === 1);
ok('Frase comum sem nome em destaque → 0', C.palavrasDoTermo('Quando chove muito forte, a água sobe.') === 0);
ok('Item de uma palavra só → 0', C.palavrasDoTermo('Pão') === 0);
const rLista = C.interpretarTexto('TÍTULO: Estrelas\n\nTEXTO:\nAs mais fáceis de achar são:\n\n• Acrux: a mais brilhante.\n\n• Mimosa: outra muito brilhante.\n\n• Gacrux: fica em cima da cruz.\n\nFim.');
ok('Itens "• Nome: explicação" continuam virando cartão (tipo exemplo)',
  rLista.paragrafos.filter(p => p.tipo === 'exemplo').length === 3, rLista.paragrafos.map(p => p.tipo).join(','));
ok('O nome com dois-pontos não é confundido com rótulo do formato',
  rLista.paragrafos.some(p => /Acrux: a mais brilhante/.test(p.texto)));

const fLista = C.arrumarParaCaixa('TÍTULO: ⭐ Estrelas\n\nTEXTO:\nElas são:\n• Acrux: a mais brilhante.\n• Mimosa: outra muito brilhante.');
ok('Formatar NÃO põe ponto depois de dois-pontos ("são:" e não "são:.")', /Elas são:\n/.test(fLista) && !/:\./.test(fLista), JSON.stringify(fLista.split('\n')[4]));
ok('Formatar mantém "• Nome: explicação" e é idempotente', /• Acrux: a mais brilhante\./.test(fLista) && C.arrumarParaCaixa(fLista) === fLista);
ok('Texto antigo com "Elas são:." não piora ao formatar', !/:\.\./.test(C.arrumarParaCaixa('Elas são:.')));

console.log('\n### 7. Robustez\n');
const grande = Array(400).fill('Esta é uma frase de teste com algumas palavras dentro dela.').join(' ');
const t0 = Date.now();
const rGrande = C.interpretarTexto(grande);
const ms = Date.now() - t0;
ok('Texto de ~4.000 palavras processado rápido', rGrande.paragrafos.length > 0 && ms < 2000, `${rGrande.paragrafos.length} parágrafos em ${ms}ms`);
ok('Texto vazio não quebra', (() => { try { C.interpretarTexto(''); C.arrumarParaCaixa(''); C.parsePerguntas([]); return true; } catch (e) { return false; } })());
ok('Seção PERGUNTAS vazia não quebra', (() => {
  try { return C.interpretarTexto('TÍTULO: X\n\nTEXTO:\nOi.\n\nPERGUNTAS:\n\nPARA PENSAR:\nE aí?').perguntas.length === 0; }
  catch (e) { return false; }
})());

console.log(`\n===== ${total - falhas}/${total} testes de lógica passaram =====`);
process.exit(falhas === 0 ? 0 : 1);
