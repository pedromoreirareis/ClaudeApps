import os, sys
# roda de qualquer lugar: usa a base dos testes (testes/testes_navegador) e abre o app de pacote-netlify/ (o nuvem-config.js é trocado por um vazio e o Firebase é de mentira: nunca fala com a nuvem real)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "testes", "testes_navegador"))
os.environ.setdefault("PASTA_PACOTE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "pacote-netlify"))
from base import *
import json, statistics, sys
servidor()
PF=json.dumps({"perfis":[{"id":"1","nome":"Teste","av":"🐧"}],"atual":"1"})
with sync_playwright() as pw:
    b=pw.chromium.launch()
    for w,h in [(800,360),(1024,600),(412,915)]:
        ctx,fb=novo_contexto(b,config='vazia',largura=w,altura=h,storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
        p=abrir(ctx)
        for fsi in (5,6,7):
            r=p.evaluate("""(fsi)=>{
              ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open'));
              fsIdx=fsi; FSCALE=FSTEPS[fsi]; window._testeSemAnimacao=true;
              const seq=construirOrdemDificuldade(); const res={};
              const medir=(nome, abrir, el, area, n)=>{ const fs=[]; let cort=0;
                for(let k=0;k<n;k++){ abrir(k); const e=el(), a=area();
                  fs.push(parseFloat(e.style.fontSize));
                  if(e.scrollWidth>a.clientWidth+1||e.scrollHeight>a.clientHeight+1) cort++; }
                const cont={}; fs.forEach(x=>cont[x]=(cont[x]||0)+1); const moda=+Object.keys(cont).sort((a,b)=>cont[b]-cont[a])[0];
                res[nome]=[moda, cont[moda], fs.length, Math.min(...fs), Math.max(...fs), cort]; };
              trocarPagina('monta');
              medir('monta', k=>{ idxMonta=seq[k*3]; renderMontaPagina(); fitMonta(); }, ()=>document.getElementById('mtWrap'), ()=>document.querySelector('#pgMonta .pgConteudo'), 60);
              trocarPagina('silaba');
              medir('silaba', k=>{ idxSilaba=seq[k*3]; renderSilabaPagina(); fitSilaba(); }, ()=>document.getElementById('spWrap'), ()=>document.querySelector('#pgSilaba .pgConteudo'), 60);
              trocarPagina('treino'); const f=SILABAS_FASE1[0]; abrirLeitorSimples(f, f.silabas[0].s);
              medir('palavra', k=>{ _lpIdx=Math.min(k,_lpLista.length-1); renderLeitorPalavraAtual(); }, ()=>document.getElementById('lpPalavra'), ()=>document.getElementById('lpFrow'), 25);
              return res; }""", fsi)
            for m,(moda,n,tot,mn,mx,cort) in r.items():
                print('%dx%d tam %s %-7s: %dpx em %d de %d  (min %d max %d)  cortadas %d' % (w,h,['20','22','24'][fsi-5],m,moda,n,tot,mn,mx,cort))
        ctx.close()
    b.close()
