"""Testes dos achados da revisão independente (rodada 1) da v122:
A1–A4 (dados e nuvem), B1–B3 (telas e celular) e alguns 🟡.
Cada teste reproduz o problema achado e confere que ele não acontece mais."""
from base import *
from ef import *
import json

def nc(*a, **k):
    ctx, fb = novo_contexto(*a, **k)
    instalar_offline(ctx)
    return ctx, fb

def pf_json(lista, atual):
    return json.dumps({"perfis":[{"id":i,"nome":n,"av":a} for i,n,a in lista],"atual":atual})

def esperar_ok(p, ms=9000):
    for _ in range(ms//250):
        st = p.evaluate("NuvemSync.status()")
        if st['estado']=='ok' and st['pendentes']==0: return True
        p.wait_for_timeout(250)
    return False

def visivel_focado(p, sel):
    return p.evaluate("""s=>{ const el=document.querySelector(s); if(!el) return {ok:false};
      const r=el.getBoundingClientRect(), vh=(window.visualViewport?visualViewport.height:innerHeight), vw=innerWidth;
      return {ok: r.width>40 && r.height>20 && r.top>=-1 && r.bottom<=vh+1 && r.left>=-1 && r.right<=vw+1, foco: document.activeElement===el, r:[r.left,r.top,r.width,r.height], vh:vh}; }""", sel)

def main():
    servidor()
    res = []
    with sync_playwright() as pw:
        b = pw.chromium.launch()

        # ---------- B1: teclado abrindo DEPOIS do toque ----------
        r = R('B1) Teclado abre depois do toque: o campo nunca some nem perde o foco')
        for (w,h,wk,hk) in [(740,360,740,170),(568,320,568,140),(640,360,640,150),(360,740,360,420),(320,568,320,300)]:
            for qual in ('T2','T3','T5'):
                ctx, fb = nc(b, largura=w, altura=h, familia=('familiateste' if qual=='T5' else None))
                p = abrir(ctx)
                if qual=='T2': p.click('.ef-t1-ja'); sel='.ef-t2 .ef-codigo'
                elif qual=='T3': p.click('.ef-t1-novo'); sel='.ef-t3 .ef-codigo'
                else: p.evaluate("EscolaFamilia.abrir('nova')"); sel='.ef-t5 .ef-nome-campo'
                p.wait_for_timeout(300); p.click(sel); p.wait_for_timeout(200)
                ok = True; det = []
                for _ in range(5):
                    p.set_viewport_size({'width':wk,'height':hk}); p.wait_for_timeout(250)
                    v = visivel_focado(p, sel); det.append(v); ok = ok and v['ok'] and v['foco']
                    p.set_viewport_size({'width':w,'height':h}); p.wait_for_timeout(250)
                    v2 = visivel_focado(p, sel); ok = ok and v2['ok'] and v2['foco']
                r.t('%s %dx%d → %dx%d (5 vezes): o campo continua visível e com o foco' % (qual,w,h,wk,hk), ok, det[-1])
                ctx.close()
        # tela baixa SEM foco: o campo continua lá
        ctx, fb = nc(b, largura=568, altura=140)
        p = abrir(ctx); p.click('.ef-t1-ja'); p.wait_for_timeout(300); p.evaluate("document.activeElement.blur()"); p.wait_for_timeout(200)
        r.t('Tela de 140 px de altura sem foco: o campo do código continua visível', visivel_focado(p,'.ef-t2 .ef-codigo')['ok'])
        ctx.close()
        res.append(r.fim())

        # ---------- B2: a pílula de estrelas/nível não fica embaixo dos botões ----------
        r = R('B2) Barra de cima: a pílula "☀️ 0/10 · 🌱 Nível…" não fica embaixo dos botões')
        PF = pf_json([('1','Hinata','🐰')],'1')
        for (w,h) in [(915,412),(800,360),(760,360),(740,360),(700,360),(640,360)]:
            ctx, fb = nc(b, largura=w, altura=h, familia='familiateste', storage={'ev_perfis':PF,'hana_abrirhub':'1','hana_trilha_v2':'1'})
            p = abrir(ctx); p.wait_for_timeout(500); fechar_app_popups(p); fechar_tudo(p); p.evaluate("fecharHub(); trocarPagina('ler'); ajustarBarraDeCima()"); p.wait_for_timeout(300)
            m = p.evaluate("""()=>{ const meta=document.getElementById('meta').getBoundingClientRect(); const bt=document.querySelector('#rgrp').getBoundingClientRect();
                 const ult=Array.from(document.querySelectorAll('#rgrp button')).pop().getBoundingClientRect();
                 return {metaDir:meta.right, botoesEsq:bt.left, ultDir:ult.right, vw:innerWidth, chipNome: getComputedStyle(document.querySelector('#efChip .ef-chip-nome')).display}; }""")
            r.t('Ler %dx%d: pílula inteira à esquerda dos botões e ⛶ dentro da tela' % (w,h), m['metaDir'] <= m['botoesEsq']+1 and m['ultDir'] <= m['vw'], m)
            ctx.close()
        # N1 (rodada 2): os botões da barra de cima NUNCA ficam menores que na v121
        for (w,h,minimo) in [(568,320,52),(640,360,52),(700,360,52),(740,360,52),(360,740,46),(320,568,46)]:
            ctx, fb = nc(b, largura=w, altura=h, familia='familiateste', storage={'ev_perfis':PF,'hana_abrirhub':'1','hana_trilha_v2':'1'})
            p = abrir(ctx); p.wait_for_timeout(500); fechar_app_popups(p); fechar_tudo(p); p.evaluate("fecharHub()")
            ok = True; det = {}
            for pg in ('ler','monta','silaba','treino'):
                p.evaluate("n=>{ trocarPagina(n); ajustarBarraDeCima(); }", pg); p.wait_for_timeout(250)
                m = p.evaluate("""pg=>{ const barra = pg==='ler' ? document.getElementById('top') : document.getElementById('pgTop'+pg.charAt(0).toUpperCase()+pg.slice(1));
                   const bs=Array.from(barra.querySelectorAll('button')).filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect());
                   const menor=Math.min(...bs.map(r=>Math.min(r.width,r.height)));
                   const dentro=bs.every(r=>r.left>=0 && r.right<=innerWidth+0.5);
                   let sobre=false; for(let i=1;i<bs.length;i++) if(bs[i].left < bs[i-1].right-0.5) sobre=true;
                   return {menor:Math.round(menor), dentro, sobre}; }""", pg)
                det[pg] = m
                ok = ok and m['menor']>=minimo and m['dentro'] and not m['sobre']
            r.t('%dx%d: nas 4 telas os botões da barra têm pelo menos %d px (como na v121), todos dentro da tela, sem encostar' % (w,h,minimo), ok, det)
            if w>=568 and h<=360:
                p.evaluate("trocarPagina('ler'); ajustarBarraDeCima()"); p.wait_for_timeout(200)
                m2 = p.evaluate("({coruja: !!document.getElementById('owl').offsetParent, letra: parseFloat(getComputedStyle(document.getElementById('meta')).fontSize)})")
                r.t('%dx%d: a 🦉 continua na barra (ela pula quando a criança acerta) e a pílula tem letra ≥ 14 px' % (w,h), m2['coruja'] and m2['letra']>=14, m2)
            ctx.close()
        res.append(r.fim())

        # ---------- B3: ✏️ 🗑️ não cobrem o bichinho ----------
        r = R('B3) "✏️ Arrumar": os botões ✏️ 🗑️ não cobrem o bichinho')
        for (w,h) in [(740,360),(568,320),(360,740)]:
            ctx, fb = nc(b, largura=w, altura=h, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊'),('p2','Bia','🐰')],'1')})
            p = abrir(ctx); p.click('.ef-arrumar'); p.wait_for_timeout(300)
            cob = p.evaluate("""()=>Array.from(document.querySelectorAll('.ef-t4 .ef-crianca[data-id]')).map(c=>{ const a=c.querySelector('.ef-av').getBoundingClientRect();
               return Array.from(c.querySelectorAll('.ef-acoes-card .ef-btn')).some(b=>{ const q=b.getBoundingClientRect(); return !(q.right<=a.left||q.left>=a.right||q.bottom<=a.top||q.top>=a.bottom); }); })""")
            r.t('%dx%d: nenhum botão por cima do bichinho' % (w,h), cob and not any(cob), cob)
            alt = p.evaluate("document.querySelector('.ef-t4 .ef-meio').getBoundingClientRect().height")
            r.t('%dx%d: a parte que rola da T4 tem pelo menos 130 px (dá para ver um cartão inteiro)' % (w,h), alt>=129, alt)
            ctx.close()
        res.append(r.fim())

        # ---------- A1/A3: mudou o bichinho e a criança também está em outro app ----------
        r = R('A1/A3) Mudou o bichinho; a ficha antiga (que tem outro app) não vira outra criança e fica em "📦 Nomes antigos"')
        fb = FakeFirebase()
        fb.gravar_app('hana_1f98a','Hana','🦊',{'x':'1'}, app='curiosidades')
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'111','hana_trilha_v2':'1'})
        p = abrir(ctx); esperar_ok(p)
        p.evaluate("EscolaFamilia.abrir('mudar','1')"); p.wait_for_timeout(300)
        p.locator('#efRaiz .ef-bicho').nth(2).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(500)
        r.t('Logo depois de mudar (antes da nuvem marcar): a 🦊 antiga não aparece como ☁️', p.locator('.ef-t4 .ef-nuvemcard[data-chave="hana_1f98a"]').count()==0)
        esperar_ok(p); p.wait_for_timeout(2500)
        r.t('A nuvem marcou movidoPara na ficha antiga', (fb.ficha('hana_1f98a') or {}).get('movidoPara',{}).get('stringValue')=='hana_1f430')
        p.reload(); p.wait_for_timeout(2500)
        r.t('Reabrindo: "Quem vai estudar hoje?" NÃO mostra a 🦊 antiga como ☁️ (mesmo ela tendo outro app)', p.locator('.ef-t4 .ef-nuvemcard').count()==0)
        p.click('.ef-t4 .ef-buscar'); p.wait_for_timeout(1500)
        r.t('"☁️ Buscar na nuvem" mostra a 🦊 em "📦 NOMES ANTIGOS" (para o adulto juntar)', '📦 NOMES ANTIGOS' in p.text_content('.ef-t6') and p.locator('.ef-t6 .ef-antigo').count()==1)
        r.t('...e a 🐰 aparece uma vez só', p.locator('.ef-t6 .ef-mini[data-chave="hana_1f430"]').count()==1)
        p.locator('.ef-t6 .ef-antigo').click(); p.wait_for_timeout(1500)
        r.t('Tocar no nome antigo junta na 🐰 (nenhuma criança nova)', len(perfis(p)['perfis'])==1 and perfis(p)['perfis'][0]['av']=='🐰')
        ctx.close()
        # outro celular continua com o nome antigo: o celular dele vê o aviso e a 🐰 não aparece como outra criança
        fb = FakeFirebase()
        fb.gravar_app('hana_1f98a','Hana','🦊',{'hana_done':'1'}, dispositivo='este')
        fb.gravar_app('hana_1f430','Hana','🐰',{'hana_done':'01'})
        fb.docs['familias/familiateste/usuarios/hana_1f98a']['fields']['movidoPara'] = {'stringValue':'hana_1f430'}
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1','hana_trilha_v2':'1'})
        p = abrir(ctx); p.wait_for_timeout(2500)
        r.t('Celular com a 🦊: aparece o aviso "MUDOU PARA 🐰" e a 🐰 NÃO aparece como outra criança ☁️', 'MUDOU PARA' in p.text_content('.ef-t4') and p.locator('.ef-t4 .ef-nuvemcard').count()==0)
        p.locator('.ef-aviso-mudou .ef-leve').click(); p.wait_for_timeout(300)
        r.t('"AGORA NÃO" guarda a data (volta a perguntar depois de 1 dia)', isinstance(estado_familia(p)['recusas'].get('familiateste/hana_1f98a'), int))
        ctx.close()
        res.append(r.fim())

        # ---------- A2: lixeira volta junto ----------
        r = R('A2) A criança volta por outro caminho: o que estava na lixeira do celular é juntado sozinho')
        for caminho in ('nuvem','cadastro'):
            fb = FakeFirebase()
            ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊'),('p2','Bia','🐰')],'1'),'p2_hana_done':'11','p2_hana_trilha_v2':'1','hana_trilha_v2':'1',
                         'escola_familia':familia_json(['familiateste'],{'1':'familiateste','p2':'familiateste'},'familiateste')})
            p = abrir(ctx); esperar_ok(p)
            offline(p, fb, True)
            p.evaluate("_rawSet('p2_hana_done','11111')")      # a Bia leu mais 3 sem internet
            p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-crianca[data-id="p2"] .ef-tirar').click(); p.wait_for_timeout(200)
            p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(500); segurar(p, '.ef-pergunta .ef-sim'); p.wait_for_timeout(500)
            offline(p, fb, False); p.wait_for_timeout(1500)
            if caminho=='nuvem':
                p.click('.ef-terminei'); p.evaluate("EscolaFamilia.fecharTudo(); EscolaFamilia.abrir('quem')"); p.wait_for_timeout(2000)
                p.locator('.ef-t4 .ef-nuvemcard[data-chave="bia_1f430"]').click()
            else:
                p.evaluate("EscolaFamilia.fecharTudo(); EscolaFamilia.abrir('nova')"); p.wait_for_timeout(300)
                p.fill('.ef-nome-campo','Bia'); p.locator('#efRaiz .ef-bicho').nth(2).click(); p.click('#efRaiz .ef-pronto')
            esperar_recarga(p, 4500); fechar_app_popups(p)
            bid = [x['id'] for x in perfis(p)['perfis'] if x['nome']=='Bia'][0]
            r.t('Pelo caminho "%s": a Bia volta com as 5 frases (2 da nuvem + 3 da lixeira)' % caminho, p.evaluate("id=>progressoDe(id)", bid)==5, p.evaluate("id=>progressoDe(id)", bid))
            r.t('...a lixeira ficou vazia e tudo sobe para a nuvem', json.loads(ls(p,'escola_lixeira_alfabetizacao') or '[]')==[] and esperar_ok(p) and fb.dados_app('bia_1f430')['hana_done'].count('1')==5)
            ctx.close()
        res.append(r.fim())

        # ---------- A4: a lista de crianças do app dá erro ----------
        r = R('A4) nuvem-sync v4: se a lista de crianças der erro, a fila NÃO é jogada fora')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1','hana_trilha_v2':'1'})
        p = abrir(ctx); esperar_ok(p)
        offline(p, fb, True)
        p.evaluate("trocarPagina('ler'); markDone(construirOrdemDificuldade().find(i=>!isDone(i)))"); p.wait_for_timeout(1800)
        p.evaluate("""()=>{ const orig=EscolaFamilia.paraNuvem; window.__falha=true; EscolaFamilia.paraNuvem=function(l){ if(window.__falha) throw new Error('falha de teste'); return orig(l); }; }""")
        offline(p, fb, False); p.wait_for_timeout(2000)
        r.t('Com a lista dando erro: a fila continua (a Hana espera) e a bolinha não fica 🟢', '1' in json.loads(ls(p,'nuvem_alfabetizacao_pendentes') or '{}') and status_txt(p)['cor']!='verde', (ls(p,'nuvem_alfabetizacao_pendentes'), status_txt(p)))
        p.evaluate("window.__falha=false; NuvemSync.sincronizar()"); p.wait_for_timeout(500); esperar_ok(p)
        r.t('Quando a lista volta, a frase sobe (nuvem com 2)', fb.dados_app('hana_1f98a')['hana_done'].count('1')==2)
        ctx.close()
        res.append(r.fim())

        # ---------- 🟡: nuvem_familia, backup "1", mudar para outra da nuvem ----------
        r = R('Leves da revisão: código não conferido, backup da Hana "1", mudar para outra criança da nuvem')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1'})
        p = abrir(ctx); offline(p, fb, True)
        p.click('.ef-t1-ja'); p.fill('.ef-t2 .ef-codigo','familia-nao-conferida'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(300); p.click('.ef-guardar-depois'); p.wait_for_timeout(300)
        r.t('"Guardar e conferir depois": o código NÃO conferido não vai para nuvem_familia (o app antigo não sobe para ele)', not ls(p,'nuvem_familia'))
        p.reload(); p.wait_for_timeout(800)
        r.t('...e reabrir não confunde com "código trocado no app antigo"', [f['c'] for f in estado_familia(p)['familias']]==['familia-nao-conferida'])
        ctx.close()
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1100','hana_trilha_v2':'1','hana_abrirhub':'1'})
        p = abrir(ctx); esperar_ok(p); fechar_app_popups(p); fechar_tudo(p)
        backup = {'appId':'esforco-vence','dados':{'ev_perfis':pf_json([('1','Hana','👧')],'1'),'hana_done':'0011'}}
        p.evaluate("o=>{ window.location.reload=function(){}; aplicarBackup(o); }", backup); p.wait_for_timeout(400)
        r.t('Backup antigo da "Hana 👧" (leitora 1) junta na Hana 🦊 deste celular (não cria outra)', len(perfis(p)['perfis'])==1 and ls(p,'hana_done')=='1111')
        ctx.close()
        fb = FakeFirebase(); fb.gravar_app('ana_1f430','Ana','🐰',{'hana_done':'1'})
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Ana','🦊')],'1'),'hana_done':'11','hana_trilha_v2':'1'})
        p = abrir(ctx); p.wait_for_timeout(2500)
        p.evaluate("EscolaFamilia.abrir('mudar','1')"); p.wait_for_timeout(300)
        p.locator('#efRaiz .ef-bicho').nth(2).click(); p.click('#efRaiz .ef-pronto'); p.wait_for_timeout(400)
        r.t('Mudar para nome + bichinho de OUTRA criança da nuvem pergunta "JUNTAR AS DUAS?"', aberta(p,'ef-pergunta') and 'JUNTAR AS DUAS' in p.text_content('.ef-pergunta'))
        p.click('.ef-pergunta .ef-nao'); p.wait_for_timeout(300)
        r.t('...e "cancelar" não muda nada', perfis(p)['perfis'][0]['av']=='🦊')
        ctx.close()
        # escolher a mesma criança pelo chip no meio do uso não mostra "Bem-vindo de volta"
        ctx, fb = nc(b, familia='familiateste', storage={'ev_perfis':pf_json([('1','Ana','🦊')],'1'),'hana_trilha_v2':'1','hana_abrirhub':'1','hana_pagina_atual':'ler'})
        p = abrir(ctx); fechar_app_popups(p); fechar_tudo(p)
        p.evaluate("fecharHub(); trocarPagina('monta')"); p.wait_for_timeout(300)
        p.click('#efChip_monta .ef-chip'); p.wait_for_timeout(300); p.click('.ef-t4 .ef-crianca[data-id="1"]'); p.wait_for_timeout(1200)
        r.t('B10: escolher a mesma criança pelo chip, no Monta a Frase, só volta para o Monta (sem "Bem-vindo de volta")',
            not p.evaluate("document.getElementById('cfmOv').classList.contains('open')") and p.evaluate("document.getElementById('pgMonta').classList.contains('open')"))
        p.click('#efChip_monta .ef-chip'); p.wait_for_timeout(300); p.click('.ef-arrumar'); p.go_back(); p.wait_for_timeout(400)
        r.t('B12: o voltar do Android sai primeiro do "Arrumar"', aberta(p,'ef-t4') and 'QUEM VAI ESTUDAR HOJE' in p.text_content('.ef-t4'))
        ctx.close()
        b.close()
        res.append(r.fim())
    return res

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nREVISAO: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
