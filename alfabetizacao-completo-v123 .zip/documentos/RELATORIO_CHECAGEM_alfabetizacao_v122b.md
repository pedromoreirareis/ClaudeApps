# Relatório de checagem — 📚 Alfabetização v122b (SITE DE TESTE)

**07/10/2026 · v122b = v122 + desenho (pedido do Pedro depois do teste nos 2 Motorolas) · protocolo da parte 9-A em 3 camadas**

> **Para que serve este zip:** atualizar o **site de teste** `https://escolasaopedrotestes.netlify.app/` (família de teste `pmrtestes`). O site de verdade continua na v121.
> **Veredito do revisor-chefe:** ver a parte 5.

---

## 0. Antes de tudo: a máquina de trabalho foi reciclada (e como recuperei)

Durante a pausa, o ambiente onde eu trabalhava foi apagado (pastas da v122, testes e documentos). Recuperei assim, e conferi:

| O quê | Como | Conferência |
|---|---|---|
| Os 9 arquivos da v122 | baixados do **seu site de teste** | md5 iguais aos que entreguei: `escola-familia.js` `8872b010…`, `nuvem-sync.js` `c953cfd3…`, `nuvem-config.js` `1d5f060a…`, `sw.js` `490e29fb…`; o `index.html` difere **só** pela linha `<script … netlify … hud>` que o próprio Netlify injeta no site publicado |
| Testes, scripts e documentos da v122 | repetindo, em ordem, as edições registradas na conversa, a partir do zip da v121 que você anexou | o `index.html` reconstruído é idêntico ao do site (tirando a linha do Netlify); os testes da v122 reconstruída deram **os mesmos números de antes**: 89 · cadastro 72 · nuvem 81 · PWA 34 · fonte 57/58 · família 130 · revisão 59 |
| Relatórios dos revisores da v122 | os que você baixou e anexou (A1, A2, B1, B2, B3, chefe) | copiados para `documentos/revisao_independente/` |

Também descobri que o `PROMPT_CONTINUACAO` da v122 citava um md5 do `index.html` (`2242a7b3…`) de antes das últimas mudanças da barra de cima; o certo da v122 é `c0e7f845…` (agora o PROMPT manda conferir pelo `LEIA-ME.txt`).

---

## 1. O que foi RODADO de verdade × só LIDO

**Rodado de verdade** (nesta máquina, Chromium sem tela + Firebase de mentira; nunca o Firebase real):
- `node --check` em todo JavaScript (os 2 `<script>` do `index.html`, `sw.js`, `nuvem-sync.js`, `escola-familia.js`, `escola-pwa.js`).
- Todos os testes (parte 3).
- Capturas em 984×432 e 937×411 (os seus Motorolas deitados), 740×360, 640×360, 568×320, 1280×800 (tablet) e 360×740 (em pé), olhadas uma a uma: Configurações, "Família e nuvem", T2 com teclado (2 alturas), "Achei" com 1, 3 e 6 crianças e com nomes compridos (MARIA EDUARDA, PEDRO HENRIQUE), T4, T6, T8, pergunta de tirar, T5 com teclado.
- **Prova de que o teste novo pega o problema:** o `teste_desenho.py` rodado contra a **v122 publicada** falha exatamente no que você reclamou (ex.: cartão do código com 4 px em cima e 82 px embaixo com o teclado; "Achei" com 480 px de largura e 6 crianças em 3 fileiras).

**Só lido no código:** nada da parte de dados mudou (conferido com `diff`: `nuvem-sync.js` idêntico; no `escola-familia.js` só CSS, a forma "curta" do botão do adulto, a ordem dos botões do "Achei", o ✕, a regra do site de teste e a constante `VERSAO`; no `index.html` só o CSS das Configurações e 3 pontos da tela cheia).

**Só o celular de verdade mostra:** parte 6.

---

## 2. Camada 1 — matriz "pedido → prova"

| Pedido do Pedro | O que mudou (onde) | Prova | |
|---|---|---|---|
| Teclado aberto: caixa do código **no meio** entre o topo e o teclado | `escola-familia.js`: regra compacta com `align-items:center`; erro e resultados vazios somem (`:empty`); T5 também no meio | `teste_desenho` 1 (T2 em 3 tamanhos × 2 alturas de teclado, T3, T5: sobra em cima = sobra embaixo ±12 px, campo com foco, cartão sem sobra); `teste_cadastro` (12 tamanhos + teclado depois do toque) | ✅ |
| Configurações: usar a largura | `index.html`: `#cfgCard` até 980 px deitado; 2 colunas a partir de 700 px | `teste_desenho` 3 (≥ 90% da largura esperada; 2 colunas) em 7 tamanhos | ✅ |
| "Família e nuvem": botões apertados, um em cima do outro | `renderSecao`: texto à esquerda + `.ef-cfg-acoes` à direita; botões do adulto "curtos" numa linha | `teste_desenho` 3 (botões dentro da linha, ≥ 48 px, ≥ 8 px entre eles; cada linha numa linha só a partir de 740 px; nada sai para o lado); trava do adulto: toque rápido não abre, 3 s abre (MOSTRAR e ABRIR) | ✅ |
| "Achei a sua família": pop-up pequeno, apertado, ilegível com 3–4 crianças | `abrirT2`: classe `ef-achou` (até 960 px); só título, código, crianças em grade e botões embaixo; ✕ no canto | `teste_desenho` 2 (1, 3 e 6 crianças em 6 tamanhos: largura, botões inteiros e separados, cartões sem encostar nos botões, nomes inteiros, até 2 fileiras para 6 crianças a partir de 740 px; nomes compridos em 4 tamanhos; ✕); `teste_familia` 2 ("← OUTRO CÓDIGO") | ✅ |
| Aviso do Chrome "Para sair da tela cheia, arraste…" | `index.html`: com o app instalado em tela cheia (`display-mode: fullscreen`) não pede a tela cheia do navegador (ao abrir, a cada toque e no ⛶) | `teste_desenho` 7 (instalado: 0 pedidos, também pelos ⛶; no navegador continua pedindo; e, com a tela cheia **de verdade**, o ⛶ da aba entra e sai como na v122) | ✅ no que dá para fazer · ⬜ no celular (parte 6) |
| Todas as telas com respiro, usando a largura deitado | pop-ups 560/640 px; 14 px entre botões; T4 com cartões no meio e rodapé numa faixa; T6/Cópias com cartões maiores; T8 numa linha | `teste_desenho` 4 (T4 no meio em 6 tamanhos; 5 cartões numa fileira em 937 e 984; rodapé inteiro; T8 numa linha) + capturas | ✅ |
| (achado meu) o site de teste do Pedro não era reconhecido | `siteDeTeste()`: qualquer endereço com "teste"; código precisa **conter** "teste"; faixa só nas telas da família | `teste_familia` 2 (endereço `escolasaopedrotestes`, `pmrtestes` aceito, código sem "teste" recusado); `teste_desenho` 6 (faixa no site de teste, sem cobrir nada, some com a criança estudando; nunca no site de verdade) | ✅ |
| Nada do funcionamento muda | — | todas as suítes da v122 continuam passando (parte 3) | ✅ |
| Cache novo | `sw.js` `esforco-vence-v122b` | `teste_pwa` (nome do cache e arquivos guardados) | ✅ |
| Arquivos compartilhados | `escola-familia.js` → **1.1** (mestra em `compartilhados/`); `nuvem-sync.js`, `escola-pwa.js`, `nuvem-config.js` iguais | md5 (parte 4) | ✅ |

---

## 3. Testes (rodados de verdade, 07/10/2026, sobre o zip final)

| Suíte | Resultado |
|---|---|
| rápidos (Node + JSDOM) | **89/89** |
| `teste_cadastro.py` | **72/72** |
| `teste_nuvem.py` | **81/81** |
| `teste_pwa.py` | **34/34** |
| `teste_fonte.py` | **57/58** — a falha (Ler 412×915 em pé, tamanho 24: 86% em vez de 90%) é desta máquina, que não tem as fontes Roboto/Arial; acontece **igual** na v121 e na v122 aqui |
| `teste_familia.py` | **130/130** |
| `teste_revisao.py` | **59/59** |
| `teste_desenho.py` (novo) | **128/128** |
| **Total** | **650/651** |

⚠️ **Honestidade sobre 1 item instável:** numa das rodadas, com 3 suítes rodando ao mesmo tempo (máquina carregada), o item "Com a nuvem em dia: tira (… as chaves dela somem do celular)" do `teste_familia.py` falhou 1 vez (as chaves `p2_hana_*` voltaram) e passou sozinho. É o 🟡 **C1** que o revisor-chefe da v122 já tinha achado: uma leitura da nuvem que **já estava a caminho** quando a criança é tirada regrava as chaves dela. Neste app não perde nada (são os dados que já estão na nuvem, e nenhuma criança aparece). Não tem relação com o desenho. A correção (no `nuvem-sync.js`) continua marcada para a v123, antes de o módulo ir para a Matemática e o Fluência.

---

## 4. Pacote

| Item | Resultado |
|---|---|
| Zip do Netlify só com os 9 arquivos na raiz | ✅ (o `empacotar.py` confere a lista) |
| `nuvem-config.js` md5 `1d5f060a5ae8339921d3d58498807971` | ✅ |
| `escola-pwa.js` e `nuvem-sync.js` iguais aos da v122 | ✅ `ec31bf4a…` e `c953cfd3…` |
| `escola-familia.js` 1.1 igual em `pacote-netlify/`, `compartilhados/` e `testes/` | ✅ (o `empacotar.py` confere) |
| `sw.js` com `esforco-vence-v122b` | ✅ (o `empacotar.py` confere) |
| `testes/` = `pacote-netlify/` (arquivos do app) | ✅ (o `empacotar.py` confere) |

Os md5 de todos os arquivos estão no `LEIA-ME.txt` do zip completo.

---

## 5. Camadas 2 e 3 — revisão independente

**Camada 2 — revisor de telas (B), independente** (`revisao_independente/RELATORIO_B_v122b_rodada1.md` e `…rodada2.md`):
- **Rodada 1:** ❌ — 2 🟠: (1) nomes cortados no "Achei" ("MARIA …", "JOÃO P…"); (2) a faixa roxa nova do site de teste cobria a barra de cima do app e a bolinha da nuvem. E 5 🟡: cartões estreitos na T4, "Achei" sem cancelar, ⛶ no app instalado, 568×320 sem internet (3 px), 6 crianças em 5 + 1.
- **Correções:** nomes em até 2 linhas (quebram entre palavras) e cartões de 200 px; colunas pelo número de crianças; faixa só nas telas da família e 30 px a mais em cima delas; T4 com cartões de 136 px ou mais e nome em 2 linhas; ✕ no canto do "Achei"; `toggleFs` sem pedido no app instalado.
- **Rodada 2:** ✅ **Pode publicar** — todos corrigidos; 3 🟡 novos: 4 crianças em 3 + 1 em 937 px (**corrigido depois**: espaço entre cartões fixo em 14 px → as 4 numa fileira em 937 e 984); ✕ encostando no título em pé (**corrigido**: título com 54 px de margem dos lados); faixa + 568×320 no rodapé da T4 (deixado: só no site de teste e num tamanho pequeno).

**Camada 3 — revisor-chefe** (`revisao_independente/RELATORIO_REVISOR_CHEFE_v122b.md`): **✅ Pode publicar** (no site de teste). Conferiu a reconstrução (os 9 arquivos da v122 iguais aos do seu site), rodou tudo de novo (mesmos números) e confirmou que o item instável é o C1 (acontece também na v122 publicada, com a máquina carregada). 4 🟡, todos tratados **depois** do veredito:
- **A.** Na aba do Chrome, o ⛶ deixou de **tirar** da tela cheia (a conferência "é app instalado?" era feita na hora do toque, quando a própria página já estava em tela cheia) → **corrigido**: usa o valor medido ao abrir; teste novo com a tela cheia de verdade (entra e sai), que falha no zip que ele revisou e passa no final.
- **B.** Depois da lupa do teclado, o foco podia ficar no campo → **corrigido**: o campo perde o foco quando aparece o "Achei" (teste novo).
- **C.** Faltavam testes para "4 numa fileira em 937/984" e "✕ em pé", e as chaves dos nomes compridos no teste estavam fora do formato → **feitos/corrigidos**.
- **D.** Frases velhas nos documentos (números da v121 no capítulo 9.2, "8 arquivos", "310 testes", `package-lock.json`) → **corrigidas**.
Como o zip final mudou depois do veredito (só estes 4 pontos), **rodei de novo todas as suítes no zip final** (parte 3).

---

## 6. Pedro, confira no celular (só o celular de verdade mostra)

1. Teclado de verdade (com a barra de senhas do Chrome em cima dele): a caixa do código fica no meio do espaço que sobra.
2. O aviso do Chrome **com o app instalado** (ícone na tela inicial): não deve aparecer mais. Se aparecer, apague o ícone e instale de novo. **Na aba do Chrome ele continua** — é regra do Chrome, nenhum site consegue esconder.
3. "Achei a sua família" com 3 ou 4 crianças de teste: dá para ler tudo, com espaço.
4. Configurações › "☁️ Família e nuvem": nada encostado.
5. Na TV a 3 m: as letras das telas da família dão para ler.

---

## 7. Pendências (🟡, para o OK do Pedro) — nenhuma bloqueia o site de teste

- **C1** (`nuvem-sync.js`): leitura da nuvem a caminho regrava chaves de criança tirada → corrigir **antes** da Matemática e do Fluência (v123).
- **C2**: bolinha 🟢 com progresso só na lixeira do celular (v123).
- **C3**: aviso escrito "depois de tirar todas as crianças, nunca volte ao zip antigo" no zip do site de verdade.
- **C4**: migração testada com o **seu backup de verdade** antes do site de verdade (ainda não recebi o backup).
- **C5**: o passo "guardar uma cópia e tirar sem internet" no roteiro (está no roteiro da v122, em `documentos/historico/`).
- Desenho: 568×320 só no site de teste, o texto da nuvem passa um pouco da borda (a tela rola).
