"""Cadastro da FAMÍLIA e das crianças (v122) — os testes obrigatórios da
parte 9 do PLANO_CADASTRO_FAMILIA.md, num Chromium de verdade e com o
Firebase de mentira (nunca fala com o Firebase real)."""
from base import *
from ef import *
import json, os, re, hashlib

V121 = os.environ.get('PASTA_V121', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'versao_anterior_v121'))   # o app anterior (v121), para os testes de migração e de voltar ao zip anterior
DIALOGOS = []
def abrir_v(ctx, erros=None):
    e = erros if erros is not None else []
    p = abrir(ctx, e)
    p.on('dialog', lambda d: DIALOGOS.append(d.message))
    return p

def esperar_ok(p, ms=8000):
    for _ in range(ms//250):
        st = p.evaluate("NuvemSync.status()")
        if st['estado']=='ok' and st['pendentes']==0: return True
        p.wait_for_timeout(250)
    return False

def pf_json(lista, atual):
    return json.dumps({"perfis":[{"id":i,"nome":n,"av":a} for i,n,a in lista],"atual":atual})

def servir_pasta(ctx, pasta, host_url):
    """serve uma pasta inteira num endereço (ex.: o app anterior, ou o site de teste)"""
    def h(route):
        u = route.request.url.split('?')[0]
        caminho = u[len(host_url):] or 'index.html'
        if caminho.endswith('/'): caminho += 'index.html'
        if caminho=='nuvem-config.js': return route.fallback()
        arq = os.path.join(pasta, caminho)
        if not os.path.isfile(arq): return route.fulfill(status=404, body='')
        tipo = 'text/html' if arq.endswith('.html') else ('application/javascript' if arq.endswith('.js') else 'application/octet-stream')
        route.fulfill(status=200, content_type=tipo+'; charset=utf-8', body=open(arq,'rb').read(), headers={'Cache-Control':'no-store'})
    ctx.route(host_url+'**', h)

def nc(*a, **k):
    ctx, fb = novo_contexto(*a, **k)
    instalar_offline(ctx)
    return ctx, fb

def chaves_brutas(p):
    return p.evaluate("()=>{ const g=Storage.prototype.getItem; const o={}; for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); o[k]=(window._rawGet?_rawGet(k):g.call(localStorage,k)); } return o; }")

def main():
    servidor()
    res = []
    with sync_playwright() as pw:
        b = pw.chromium.launch()

        # ================= 1) textos da tabela 3-A =================
        r = R('1) Textos exatamente iguais aos da tabela 3-A (objeto TEXTOS), em CAIXA ALTA')
        ctx, fb = nc(b, storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'11'})
        p = abrir_v(ctx); T = textos(p)
        def tem(sel, chaves, nome):
            txt = p.text_content(sel) or ''
            falta = [k for k in chaves if T[k] not in txt]
            r.t('%s: %s' % (nome, ', '.join(T[k] for k in chaves)), not falta, falta)
        tem('.ef-t1', ['t1Titulo','t1Ja','t1Novo','t1AgoraNao'], 'T1')
        p.click('.ef-t1-ja'); p.wait_for_timeout(300)
        tem('.ef-t2', ['t2Titulo','t2Botao','cancelar'], 'T2')
        r.t('T2: a explicação "É O MESMO CÓDIGO EM TODOS OS APPS..." e o aviso do caso B', T['t2Texto'] in p.text_content('.ef-t2') and 'VÃO FICAR NESTA FAMÍLIA' in p.text_content('.ef-t2'))
        p.click('.ef-t2 .ef-cancelar'); p.wait_for_timeout(200)
        r.t('"✕ CANCELAR" fecha sem fazer nada', not aberta(p,'ef-t2') and estado_familia(p)['familias']==[])
        p.click('.ef-t1-novo'); p.wait_for_timeout(300)
        tem('.ef-t3', ['t3Titulo','t3Botao','cancelar'], 'T3')
        p.fill('.ef-t3 .ef-codigo','familia-nova-1'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200)
        tem('.ef-t3', ['t3Anote','t3JaAnotei'], 'T3 depois de criar')
        p.click('.ef-ja-anotei'); p.wait_for_timeout(400)
        tem('.ef-t4', ['t4Titulo','t4Buscar','t4Atualizar','t4Arrumar'], 'T4')
        r.t('T4: o cartão ➕ NOVA CRIANÇA', 'NOVA CRIANÇA' in p.text_content('.ef-t4 .ef-novo'))
        r.t('T4: a criança que já estava no celular (caso B) entrou na família nova', estado_familia(p)['criancas'].get('1')=='familia-nova-1')
        esperar_ok(p)
        p.click('.ef-atualizar'); p.wait_for_timeout(1500)
        s = status_txt(p)
        r.t('Bolinha 🟢 "TUDO GUARDADO NA NUVEM (ÀS hh:mm)"', s['cor']=='verde' and re.match(r'^TUDO GUARDADO NA NUVEM \(ÀS \d\d:\d\d\)$', s['txt']), s)
        p.click('.ef-arrumar'); p.wait_for_timeout(200)
        tem('.ef-t4', ['t7Titulo','t7Terminei'], 'T7')
        p.locator('.ef-t4 .ef-mudar').first.click(); p.wait_for_timeout(300)
        tem('.ef-t5', ['t5Mudar','t5Pronto','voltar'], 'T5 ao mudar')
        p.click('.ef-t5 .ef-voltar'); p.wait_for_timeout(200)
        p.click('.ef-terminei'); p.wait_for_timeout(200)
        p.click('.ef-familia-link'); p.wait_for_timeout(300)
        tem('.ef-t8', ['t8Titulo','t8Entrar','t8Criar','t8Tirar','adulto','voltar'], 'T8')
        p.click('.ef-t8 .ef-voltar'); p.wait_for_timeout(200)
        p.click('.ef-t4 .ef-crianca[data-id="1"]'); p.wait_for_timeout(1500); fechar_app_popups(p); fechar_tudo(p)
        p.evaluate("openConfig()"); p.wait_for_timeout(200)
        tem('#cfgFamilia', ['cfgSecao','trocar','t4Atualizar','t4Arrumar'], 'Configurações')
        r.t('Configurações: "🕘 CÓPIAS DE CADA DIA (DE 🦊 Hana)" e "🔑 FAMÍLIA: fam••••"', 'CÓPIAS DE CADA DIA (DE 🦊 Hana)' in p.text_content('#cfgFamilia') and 'FAMÍLIA: fam••••' in p.text_content('#cfgFamilia'))
        r.t('"☁️ Família e nuvem" é a ÚLTIMA seção das Configurações', p.evaluate("document.getElementById('cfgBody').lastElementChild.id")=='cfgFamilia')
        r.t('As linhas antigas saíram das Configurações (Trocar leitora, Situação, Código, Recuperar)', not p.evaluate("!!(document.getElementById('cfgProf')||document.getElementById('cfgNuvemEnviar')||document.getElementById('cfgNuvemCodigo')||document.getElementById('cfgNuvemRecuperar'))"))
        r.t('As telas do módulo são CAIXA ALTA (CSS) e o nome fica guardado como foi digitado', p.evaluate("getComputedStyle(document.getElementById('efRaiz')).textTransform")=='uppercase' and perfis(p)['perfis'][0]['nome']=='Hana')
        proib = ['usuário','perfil','leitor','jogador','aluno','sincroniz','recuper','versões','ficha']
        ruins = [(k,v) for k,v in T.items() if any(x in v.lower() for x in proib)]
        r.t('Nenhuma palavra proibida pela parte 3 (usuário, perfil, leitor(a), jogador, aluno, sincronizar, recuperar, versões, ficha)', not ruins, ruins)
        ctx.close()
        res.append(r.fim())

        # ================= 2) código da família (T2) =================
        r = R('2) Código da família: existe, errado, sem tracinho, sem internet, site de teste')
        fb = FakeFirebase()
        fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'1'*12,'hana_trilha_v2':'1'}, familia='familia-real')
        fb.gravar_app('bia_1f430','Bia','🐰',{'hana_done':'1'*4,'hana_trilha_v2':'1'}, familia='familia-real')
        fb.gravar_app('caio_1f42f','Caio','🐯',{'x':'1'}, app='matematica', familia='familia-real')
        fb.gravar_app('lu_1f43c','Lu','🐼',{'hana_done':'1'}, familia='saopedro2026')
        ctx, _ = nc(b, fb=fb)
        p = abrir_v(ctx)
        p.click('.ef-t1-ja'); p.wait_for_timeout(200)
        p.fill('.ef-t2 .ef-codigo','abc'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(200)
        r.t('Código curto: "O CÓDIGO PRECISA TER PELO MENOS 6 LETRAS OU NÚMEROS 🙂" sem fechar', p.text_content('.ef-t2 .ef-erro')==T['codigoCurto'] and aberta(p,'ef-t2'))
        p.fill('.ef-t2 .ef-codigo','familia errada'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1200)
        r.t('Código errado: "🤔 NÃO ACHEI NENHUMA CRIANÇA COM ESSE CÓDIGO." e nada é guardado', T['t2NaoAchei'] in p.text_content('.ef-t2') and estado_familia(p)['familias']==[])
        p.fill('.ef-t2 .ef-codigo','sao-pedro-2026'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1500)
        r.t('Variante sem tracinho existe: "VOCÊ QUIS DIZER saopedro2026?"', p.is_visible('.ef-quisdizer') and 'saopedro2026' in p.text_content('.ef-quisdizer'))
        p.click('.ef-quisdizer'); p.wait_for_timeout(1200)
        r.t('...tocando, procura o código certo e acha a família', T['t2Achei'] in p.text_content('.ef-t2') and p.input_value('.ef-t2 .ef-codigo')=='saopedro2026')
        p.click('.ef-t2 .ef-outro-codigo'); p.wait_for_timeout(300)
        r.t('v122b: "← OUTRO CÓDIGO" volta para o campo (com o código para corrigir)', p.is_visible('.ef-t2 .ef-codigo') and not p.is_visible('.ef-t2 .ef-trazer-todas'))
        p.fill('.ef-t2 .ef-codigo','Família Real'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1500)
        cards = p.evaluate("Array.from(document.querySelectorAll('.ef-t2 .ef-mini')).map(c=>c.textContent)")
        r.t('Código que existe: "🎉 ACHEI A SUA FAMÍLIA!" com os cartões e os apps de cada criança', T['t2Achei'] in p.text_content('.ef-t2') and len(cards)==3 and any('Caio' in c and '🔢' in c for c in cards), cards)
        r.t('...com [TRAZER TODAS] e [ESCOLHER]', p.is_visible('.ef-trazer-todas') and p.is_visible('.ef-escolher'))
        p.click('.ef-trazer-todas'); p.wait_for_timeout(5000)
        pf = perfis(p)['perfis']
        r.t('"TRAZER TODAS" traz as 3 crianças da família (inclusive a do outro app)', sorted(x['nome'] for x in pf)==['Bia','Caio','Renata'], pf)
        rid = [x['id'] for x in pf if x['nome']=='Renata'][0]
        r.t('...com o progresso de cada uma (Renata: 12 frases)', p.evaluate("id=>progressoDe(id)", rid)==12)
        r.t('...e vai para "Quem vai estudar hoje?" com as 3', aberta(p,'ef-t4') and p.locator('.ef-t4 .ef-crianca[data-id]').count()==3)
        r.t('A família fica conferida e é a atual (nuvem_familia mantido para o app antigo)', estado_familia(p)['familias'][0]['conferida'] and ls(p,'nuvem_familia')=='familia-real')
        ctx.close()
        # sem internet: código que NÃO existe → pergunta antes de subir
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb)
        p = abrir_v(ctx)
        offline(p, fb, True)
        p.click('.ef-t1-ja'); p.fill('.ef-t2 .ef-codigo','familia-digitada'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(500)
        r.t('Sem internet: "📴 SEM INTERNET AGORA." com [GUARDAR E CONFERIR DEPOIS] e [TENTAR DE NOVO]', T['semInternet'] in p.text_content('.ef-t2') and p.is_visible('.ef-guardar-depois') and p.is_visible('.ef-tentar'))
        p.click('.ef-guardar-depois'); p.wait_for_timeout(400)
        ef0 = estado_familia(p)
        r.t('Guardar: a família fica "a conferir" e o app funciona', ef0['familias'][0]['conferida']==False and aberta(p,'ef-t4'))
        nova_crianca(p, 'Dudu', 5)
        p.evaluate("trocarPagina('ler'); go(1);"); p.wait_for_timeout(1500)
        r.t('Bolinha 🟡 "FAMÍLIA ... A CONFERIR" (nada sobe enquanto não confere)', status_txt(p)['cor']=='amarelo')
        offline(p, fb, False); p.wait_for_timeout(5000)
        r.t('Internet voltou: o código não existe → NADA subiu ainda', not [k for k in fb.docs if 'familia-digitada' in k])
        p.evaluate("EscolaFamilia.abrir('quem')"); p.wait_for_timeout(400)
        r.t('...e o adulto vê "NÃO ACHEI A FAMÍLIA familia-digitada. CONFERIR O CÓDIGO OU CRIAR UMA FAMÍLIA NOVA COM ELE?"', 'NÃO ACHEI A FAMÍLIA familia-digitada' in p.text_content('.ef-t4'))
        r.t('...com a bolinha 🔴 "CONFIRA O CÓDIGO DA FAMÍLIA"', status_txt(p)['cor']=='vermelho' and 'CONFIRA O CÓDIGO' in status_txt(p)['txt'])
        p.locator('.ef-aviso-familia .ef-verde').click(); p.wait_for_timeout(4000)
        r.t('"🌱 CRIAR COM ELE": a família fica conferida e o Dudu sobe', fb.dados_app('dudu_1f428', familia='familia-digitada') is not None)
        ctx.close()
        # sem internet: código que EXISTE → confere sozinho e sobe
        fb = FakeFirebase(); fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'1'}, familia='familia-real')
        ctx, _ = nc(b, fb=fb, storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'111','hana_trilha_v2':'1'})
        p = abrir_v(ctx)
        offline(p, fb, True)
        p.click('.ef-t1-ja'); p.fill('.ef-t2 .ef-codigo','familia-real'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(300); p.click('.ef-guardar-depois'); p.wait_for_timeout(300)
        offline(p, fb, False); p.wait_for_timeout(6000)
        r.t('Código que existe, guardado sem internet: confere sozinho quando a internet volta', estado_familia(p)['familias'][0]['conferida']==True)
        r.t('...e só então a criança do celular sobe para essa família', (fb.dados_app('hana_1f98a', familia='familia-real') or {}).get('hana_done')=='111')
        ctx.close()
        # site de teste
        HOST = 'https://escolasaopedrotestes.netlify.app/'      # o site de teste do Pedro (07/10/2026)
        ctx, fb = nc(b)
        servir_pasta(ctx, PASTA, HOST)
        p = ctx.new_page(); p.goto(HOST, wait_until='load'); p.wait_for_timeout(700)
        r.t('Site de teste: faixa "🧪 SITE DE TESTE — USE SÓ O CÓDIGO DE TESTE"', p.is_visible('.ef-teste'))
        p.click('.ef-t1-ja'); p.fill('.ef-t2 .ef-codigo','saopedro2026'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(300)
        r.t('Site de teste: um código sem "teste" é recusado (protege a família de verdade)', 'SITE DE TESTE' in p.text_content('.ef-t2 .ef-erro'))
        p.fill('.ef-t2 .ef-codigo','pmrtestes'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1200)
        r.t('Site de teste: um código com "teste" no meio (pmrtestes, o do Pedro) é aceito', 'SITE DE TESTE' not in (p.text_content('.ef-t2 .ef-erro') or '') and T['t2NaoAchei'] in p.text_content('.ef-t2'))
        p.click('.ef-t2 .ef-cancelar'); p.click('.ef-t1-novo'); p.wait_for_timeout(200)
        r.t('Site de teste: a sugestão de código já começa com "teste-"', p.input_value('.ef-t3 .ef-codigo').startswith('teste-'))
        p.fill('.ef-t3 .ef-codigo','teste-pedro-2026'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200)
        r.t('Site de teste: "teste-pedro-2026" é aceito', p.text_content('.ef-codigo-anotar')=='teste-pedro-2026')
        ctx.close()
        res.append(r.fim())

        # ================= 3) criar código (T3) =================
        r = R('3) Criar o código: já usado avisa; sem internet cria e confere depois')
        fb = FakeFirebase(); fb.gravar_app('ana_1f43c','Ana','🐼',{'hana_done':'1'}, familia='tigre-1234')
        ctx, _ = nc(b, fb=fb)
        p = abrir_v(ctx)
        p.click('.ef-t1-novo'); p.fill('.ef-t3 .ef-codigo','tigre-1234'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200)
        r.t('Código que já tem crianças: "ESSE CÓDIGO JÁ TEM CRIANÇAS. SE É DA SUA FAMÍLIA, USE 🔑 JÁ TENHO CADASTRO..."', p.text_content('.ef-t3 .ef-erro')==T['t3JaExiste'] and estado_familia(p)['familias']==[])
        offline(p, fb, True)
        p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(500)
        r.t('Sem internet: cria assim mesmo ("a conferir") e pede para anotar', p.text_content('.ef-codigo-anotar')=='tigre-1234' and estado_familia(p)['familias'][0]['conferida']==False)
        p.click('.ef-ja-anotei'); p.wait_for_timeout(300)
        cadastrar_t5(p, 'Leo', 6); fechar_app_popups(p)
        offline(p, fb, False); p.wait_for_timeout(5000)
        r.t('Internet voltou e o código já existia: NADA do Leo subiu para a outra família', fb.dados_app('leo_1f42f', familia='tigre-1234') is None)
        p.evaluate("EscolaFamilia.abrir('quem')"); p.wait_for_timeout(400)
        r.t('...e o adulto vê "O CÓDIGO tigre-1234 JÁ TEM CRIANÇAS. É DA SUA FAMÍLIA?"', 'O CÓDIGO tigre-1234 JÁ TEM CRIANÇAS' in p.text_content('.ef-t4'))
        p.locator('.ef-aviso-familia .ef-amarelo').click(); p.wait_for_timeout(300)
        p.fill('.ef-t3 .ef-codigo','leao-7777'); p.click('.ef-t3 .ef-criar'); p.wait_for_timeout(1200); p.click('.ef-ja-anotei'); p.wait_for_timeout(4000)
        ef3 = estado_familia(p)
        r.t('"🔑 ESCOLHER OUTRO CÓDIGO": a família troca de código e o Leo sobe para a nova', [f['c'] for f in ef3['familias']]==['leao-7777'] and fb.dados_app('leo_1f42f', familia='leao-7777') is not None, ef3)
        r.t('...e a família tigre-1234 de outra pessoa ficou intacta (só a Ana)', [k for k in fb.docs if k.startswith('familias/tigre-1234/usuarios/') and k.count('/')==3]==['familias/tigre-1234/usuarios/ana_1f43c'])
        ctx.close()
        res.append(r.fim())

        # ================= 4) duas famílias =================
        r = R('4) Duas famílias no mesmo celular: cada criança na pasta da sua família')
        fb = FakeFirebase()
        fb.gravar_app('bia_1f430','Bia','🐰',{'hana_done':'1'*5,'hana_trilha_v2':'1'}, familia='familia-bbb')
        ctx, _ = nc(b, fb=fb, familia='familia-aaa', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'11','hana_trilha_v2':'1'})
        p = abrir_v(ctx); esperar_ok(p)
        p.click('.ef-familia-link'); p.wait_for_timeout(300)
        r.t('Tocar na família abre "👨‍👩‍👧 FAMÍLIAS NESTE CELULAR" com o código escondido', aberta(p,'ef-t8') and 'fam••••' in p.text_content('.ef-t8') and 'familia-aaa' not in p.text_content('.ef-t8'))
        segurar(p, '.ef-t8 .ef-mostrar')
        r.t('"👁 MOSTRAR" (segurando 3 s) mostra o código inteiro', 'familia-aaa' in p.text_content('.ef-t8'))
        r.t('Nas 2 primeiras semanas: aviso de que é melhor ter só uma família', '2 PRIMEIRAS SEMANAS' in p.text_content('.ef-t8'))
        p.click('.ef-entrar-outra'); p.wait_for_timeout(300)
        r.t('"➕ ENTRAR EM OUTRA FAMÍLIA" com um toque só não faz nada (trava do adulto)', not aberta(p,'ef-pergunta') and not aberta(p,'ef-t2'))
        segurar(p, '.ef-entrar-outra')
        r.t('Segurando: nas 2 semanas pergunta de novo, avisando que voltar à versão anterior não é mais seguro', aberta(p,'ef-pergunta') and 'VERSÃO ANTERIOR' in p.text_content('.ef-pergunta'))
        segurar(p, '.ef-pergunta .ef-sim'); p.wait_for_timeout(300)
        p.fill('.ef-t2 .ef-codigo','familia-bbb'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1200); p.click('.ef-t2 .ef-escolher'); p.wait_for_timeout(1500)
        ef4 = estado_familia(p)
        r.t('A 2ª família entra no celular; a Hana continua na 1ª (código novo NÃO move ninguém)', [f['c'] for f in ef4['familias']]==['familia-aaa','familia-bbb'] and ef4['criancas']['1']=='familia-aaa' and ef4['atual']=='familia-aaa' and ef4['liberouSegundaFamilia'])
        p.click('.ef-t8 .ef-voltar'); p.wait_for_timeout(1500)
        r.t('"Quem vai estudar hoje?" mostra um título por família', p.locator('.ef-t4 .ef-grupo-tit').count()==2)
        r.t('A Bia (da 2ª família) aparece com ☁️ no grupo dela', p.locator('.ef-t4 .ef-grade[data-familia="familia-bbb"] .ef-nuvemcard').count()==1)
        p.locator('.ef-t4 .ef-grade[data-familia="familia-bbb"] .ef-nuvemcard').click(); esperar_recarga(p, 4500); fechar_app_popups(p); fechar_tudo(p)
        bid = perfis(p)['atual']
        r.t('Tocar traz a Bia para a família dela, com o progresso (5 frases)', estado_familia(p)['criancas'].get(bid)=='familia-bbb' and p.evaluate("doneN")==5)
        p.evaluate("trocarPagina('ler'); idx=construirOrdemDificuldade().find(i=>!isDone(i)); go(1);"); esperar_ok(p)
        r.t('O que a Bia lê sobe para familias/familia-bbb', fb.dados_app('bia_1f430', familia='familia-bbb')['hana_done'].count('1')==6)
        r.t('...e NADA da Bia aparece na familia-aaa', not [k for k in fb.docs if k.startswith('familias/familia-aaa/usuarios/bia')])
        r.t('...e a Hana continua só na familia-aaa', fb.dados_app('hana_1f98a', familia='familia-aaa') is not None and fb.dados_app('hana_1f98a', familia='familia-bbb') is None)
        st = p.evaluate("NuvemSync.status()")
        r.t('status() da nuvem v4 informa as pendências por família', 'porFamilia' in st)
        ctx.close()
        res.append(r.fim())

        # ================= 5) tirar criança =================
        r = R('5) Tirar deste celular: só com tudo guardado; lixeira; última; Hana fantasma')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊'),('p2','Bia','🐰')],'1'),
                 'hana_done':'1111','p2_hana_done':'11','p2_hana_fav':'[4]','p2_hana_trilha_v2':'1','hana_trilha_v2':'1'})
        p = abrir_v(ctx); esperar_ok(p)
        p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-crianca[data-id="p2"] .ef-tirar').click(); p.wait_for_timeout(300)
        r.t('Pergunta "TIRAR 🐰 Bia DESTE CELULAR?" explicando que a nuvem guarda', aberta(p,'ef-pergunta') and 'TIRAR 🐰 Bia DESTE CELULAR?' in p.text_content('.ef-pergunta') and 'NUVEM' in p.text_content('.ef-pergunta'))
        p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(3500)
        brutas = chaves_brutas(p)
        r.t('Com a nuvem em dia: tira (sai da lista e as chaves dela somem do celular)', [x['id'] for x in perfis(p)['perfis']]==['1'] and not [k for k in brutas if k.startswith('p2_')], [k for k in brutas if k.startswith('p2_')])
        r.t('...a nuvem continua com a Bia (nada apagado na nuvem)', fb.dados_app('bia_1f430')['hana_done']=='11')
        r.t('...e a Hana não foi tocada', brutas.get('hana_done')=='1111')
        # com fila e sem internet
        offline(p, fb, True)
        nova_crianca(p, 'Caio', 6); fechar_tudo(p)
        cid = perfis(p)['atual']
        p.evaluate("trocarPagina('ler'); markDone(construirOrdemDificuldade()[0]); markDone(construirOrdemDificuldade()[1]);"); p.wait_for_timeout(1800)
        p.evaluate("EscolaFamilia.abrir('quem')"); p.wait_for_timeout(300)
        p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-crianca[data-id="%s"] .ef-tirar' % cid).click(); p.wait_for_timeout(200)
        p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(800)
        r.t('Com fila e sem internet: "⚠️ AINDA NÃO DÁ PARA GARANTIR" (não tira)', aberta(p,'ef-pergunta') and T['t7NaoGarante'] in p.text_content('.ef-pergunta') and len(perfis(p)['perfis'])==2)
        p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(400)
        r.t('...um toque em "GUARDAR UMA CÓPIA..." não tira (trava do adulto)', len(perfis(p)['perfis'])==2)
        caio_antes = p.evaluate("id=>({done:_rawGet(prefixoDe(id)+'hana_done')})", cid)
        segurar(p, '.ef-pergunta .ef-sim'); p.wait_for_timeout(2000); p.wait_for_load_state('load'); p.wait_for_timeout(800)
        lix = json.loads(ls(p,'escola_lixeira_alfabetizacao') or '[]')
        r.t('Segurando 3 s: guarda a cópia na lixeira do celular e tira', len(perfis(p)['perfis'])==1 and len(lix)==1 and lix[0]['dados'].get('hana_done')==caio_antes['done'])
        r.t('...e a fila da criança tirada foi limpa (não fica 🟡 para sempre)', cid not in json.loads(ls(p,'nuvem_alfabetizacao_pendentes') or '{}'))
        fechar_tudo(p); p.evaluate("EscolaFamilia.abrir('nuvem')"); p.wait_for_timeout(500)
        r.t('"☁️ BUSCAR NA NUVEM" mostra "🗑️ TIRADAS DESTE CELULAR" com ↩️ TRAZER DE VOLTA', T['t6Lixeira'] in p.text_content('.ef-t6') and p.locator('.ef-lixeira .ef-mini').count()==1)
        p.locator('.ef-lixeira .ef-mini').click(); p.wait_for_timeout(600)
        pf = perfis(p)['perfis']; nid = [x['id'] for x in pf if x['nome']=='Caio']
        r.t('A lixeira devolve TUDO (mesmas frases lidas)', nid and p.evaluate("id=>_rawGet(prefixoDe(id)+'hana_done')", nid[0])==caio_antes['done'] and ls(p,'escola_lixeira_alfabetizacao')=='[]')
        offline(p, fb, False)
        r.t('...e, com internet, sobe para a nuvem', esperar_ok(p, 10000) and fb.dados_app('caio_1f42f') is not None)
        ctx.close()
        # última criança nas 2 primeiras semanas
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1','hana_trilha_v2':'1'})
        p = abrir_v(ctx); esperar_ok(p)
        p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-tirar').click(); p.wait_for_timeout(300)
        r.t('Nas 2 primeiras semanas a ÚLTIMA criança não sai ("⏳ AINDA NÃO DÁ PARA TIRAR A ÚLTIMA CRIANÇA")', T['t7Ultima'] in p.text_content('.ef-pergunta') and not p.locator('.ef-pergunta .ef-adulto').count())
        p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(300)
        r.t('...e ela continua no celular', len(perfis(p)['perfis'])==1)
        ctx.close()
        # depois das 2 semanas: pode tirar todas; a "Hana fantasma" nunca volta
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1','hana_idx':'5','hana_trilha_v2':'1',
                 'escola_familia':familia_json(['familiateste'],{'1':'familiateste'},'familiateste')})
        p = abrir_v(ctx); esperar_ok(p)
        p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-tirar').click(); p.wait_for_timeout(200); p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(3500)
        p.wait_for_load_state('load'); p.wait_for_timeout(800)
        r.t('Depois das 2 semanas: pode tirar a última; a T4 fica só com ➕ e ☁️', perfis(p)['perfis']==[] and aberta(p,'ef-t4') and p.locator('.ef-t4 .ef-novo').count()==1 and p.is_visible('.ef-buscar'))
        p.go_back(); p.wait_for_timeout(300)
        r.t('Sem criança não dá para entrar no app (a T4 não fecha)', aberta(p,'ef-t4'))
        for _ in range(2): p.reload(); p.wait_for_timeout(900)
        brutas = chaves_brutas(p)
        r.t('"Hana fantasma": abrir 2 vezes e nenhuma criança aparece', perfis(p)['perfis']==[] and not p.locator('.ef-t4 .ef-crianca[data-id]').count())
        r.t('...e o app não gravou nenhuma chave hana_* sem criança', not [k for k in brutas if k.startswith('hana_')], [k for k in brutas if k.startswith('hana_')])
        r.t('...e a ficha da Hana na nuvem continua lá', fb.dados_app('hana_1f98a')['hana_done']=='1')
        ctx.close()
        res.append(r.fim())

        # ================= 6) mudar nome/bichinho em OUTRO app =================
        r = R('6) Mudou de nome/bichinho em outro app: pergunta se quer seguir; ficha antiga some')
        fb = FakeFirebase()
        fb.gravar_app('hana_1f98a','Hana','🦊',{'hana_done':'11'}, dispositivo='este')
        fb.gravar_app('hana_1f430','Hana','🐰',{'hana_done':'0011','x':'1'}, app='curiosidades')
        fb.gravar_app('hana_1f430','Hana','🐰',{'hana_done':'0011'})
        fb.docs['familias/familiateste/usuarios/hana_1f98a']['fields']['movidoPara'] = {'stringValue':'hana_1f430'}
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'11','hana_trilha_v2':'1'})
        p = abrir_v(ctx); p.wait_for_timeout(2500)
        r.t('Aviso para o adulto: "🦊 Hana MUDOU PARA 🐰 Hana EM OUTRO APP. MUDAR AQUI TAMBÉM?"', 'MUDOU PARA 🐰 Hana EM OUTRO APP' in p.text_content('.ef-t4'))
        p.locator('.ef-aviso-mudou .ef-verde').click(); p.wait_for_timeout(2000)
        r.t('[MUDAR]: a criança passa a ser 🐰 Hana', perfis(p)['perfis'][0]['av']=='🐰')
        r.t('...e junta o progresso da ficha nova (11 + 0011 = 1111)', (ls(p,'hana_done') or '').startswith('1111'), ls(p,'hana_done'))
        esperar_ok(p)
        r.t('...e a ficha nova na nuvem recebe tudo', fb.dados_app('hana_1f430')['hana_done'].startswith('1111'))
        p.click('.ef-t4 .ef-buscar'); p.wait_for_timeout(1200)
        r.t('A ficha antiga (🦊) não aparece mais duplicada em "☁️ BUSCAR NA NUVEM"', p.locator('.ef-t6 .ef-mini[data-chave="hana_1f98a"]').count()==0 and p.locator('.ef-t6 .ef-mini[data-chave="hana_1f430"]').count()==1)
        ctx.close()
        res.append(r.fim())

        # ================= 7) migração A–H =================
        r = R('7) Migração (casos A–H): só acrescenta; chaves antigas idênticas byte a byte')
        hoje = None
        base_st = {'ev_perfis':pf_json([('1','Hana','👧'),('p1727100000000','Hinata','🐰')],'1'),
                   'hana_done':'1'*50+'0'*10+'1', 'hana_fav':'[3,9]', 'hana_parentes':json.dumps({'pai':'Pedro'}), 'hana_trilha_v2':'1', 'hana_theme':'4',
                   'hana_sil_lidas':json.dumps(['SIMP_M_ma::Mala']), 'hana_diario':json.dumps({'2026-09-20':[1,2]}), 'hana_words':'300', 'hana_bstreak':'5',
                   'p1727100000000_hana_done':'1'*200, 'p1727100000000_hana_trilha_v2':'1', 'p1727100000000_hana_monta_ok':'[1,2,3]',
                   'ev_telaAcesa':'1', 'nuvem_dispositivo':'dteste', 'nuvem_familia':'familia-real'}
        def snapshot(pasta_v121):
            out = {}
            for nome, pasta in (('v121', pasta_v121), ('v122', None)):
                fb = FakeFirebase()
                ctx, _ = nc(b, fb=fb, storage=base_st)
                if pasta: servir_pasta(ctx, pasta, URL)
                fb.offline = True
                p = abrir_v(ctx); p.wait_for_timeout(1500)
                out[nome] = (chaves_brutas(p), p)
                if nome=='v122': out['p'] = p; out['ctx'] = ctx
                else: ctx.close()
            return out
        EXC = ('nuvem_familia','nuvem_alfabetizacao_pendentes','nuvem_alfabetizacao_meta','nuvem_dispositivo','nuvem_auth','escola_familia','escola_conviteVisto')
        if V121 and os.path.isdir(V121):
            o = snapshot(V121)
            a, b2 = o['v121'][0], o['v122'][0]
            dif = [k for k in set(a)|set(b2) if k not in EXC and a.get(k)!=b2.get(k)]
            r.t('A) Retrato com 2 crianças + código: depois de abrir a v122, TODAS as chaves (listas e progresso) idênticas às da v121, byte a byte', not dif, dif)
            r.t('A) ...a única chave nova é escola_familia', set(b2)-set(a) <= {'escola_familia'}, set(b2)-set(a))
            p = o['p']
            efa = estado_familia(p)
            r.t('A) as 2 crianças ficam ligadas à família do celular', efa['criancas']=={'1':'familia-real','p1727100000000':'familia-real'} and efa['atual']=='familia-real')
            r.t('A) abre direto em "Quem vai estudar hoje?" com o aviso "FAMÍLIA fam•••• — TUDO CERTO ✅"', aberta(p,'ef-t4') and 'TUDO CERTO' in toast(p))
            r.t('E) bichinho antigo (👧) continua igual (mesma ficha hana_1f467)', perfis(p)['perfis'][0]['av']=='👧' and p.evaluate("NuvemSync.chaveUsuario('Hana','👧')")=='hana_1f467')
            o['ctx'].close()
        else:
            r.t('A) retrato v121 × v122 (precisa de PASTA_V121)', False, 'defina PASTA_V121')
        # B
        ctx, fb = nc(b, storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1'})
        p = abrir_v(ctx)
        r.t('B) Crianças sem código: T1 com "ESTE CELULAR JÁ TEM: 🦊 Hana — ELAS NÃO VÃO SUMIR." e "AGORA NÃO ›"', aberta(p,'ef-t1') and 'ELAS NÃO VÃO SUMIR' in p.text_content('.ef-t1') and p.is_visible('.ef-t1-agoranao'))
        p.click('.ef-t1-agoranao'); p.wait_for_timeout(300)
        r.t('B) "Agora não": T4 com a criança e a bolinha 🔴 "FALTA O CÓDIGO DA FAMÍLIA"', aberta(p,'ef-t4') and p.locator('.ef-t4 .ef-crianca[data-id="1"]').count()==1 and status_txt(p)['txt']=='FALTA O CÓDIGO DA FAMÍLIA')
        ctx.close()
        # C
        ctx, fb = nc(b); p = abrir_v(ctx)
        r.t('C) Instalação nova: T1 sem "Agora não"', aberta(p,'ef-t1') and not p.is_visible('.ef-t1-agoranao'))
        ctx.close()
        # D
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('p1','Hinata','🦉'),('p2','Hinata','🦉')],'p1'),
                  'p1_hana_done':'11','p2_hana_done':'0011','p1_hana_trilha_v2':'1','p2_hana_trilha_v2':'1'})
        p = abrir_v(ctx); p.wait_for_timeout(4000)
        r.t('D) Duas 🦉 Hinata na mesma família: só a primeira sobe; a segunda espera (🟡 "HÁ DUAS...")', (fb.dados_app('hinata_1f989') or {}).get('hana_done')=='11' and p.evaluate("NuvemSync.status().segurados")>=0 and status_txt(p)['cor']=='amarelo' and 'HÁ DUAS' in status_txt(p)['txt'], status_txt(p))
        p.evaluate("localStorage.setItem('hana_fav','[1]')"); p.wait_for_timeout(2500)
        r.t('D) ...mesmo se a segunda mudar algo, ela não grava por cima da primeira', (fb.dados_app('hinata_1f989') or {}).get('hana_done')=='11')
        p.click('.ef-arrumar'); p.wait_for_timeout(200)
        r.t('D) No "Arrumar": "HÁ DUAS 🦉 Hinata: JUNTAR?"', 'HÁ DUAS 🦉 Hinata: JUNTAR?' in p.text_content('.ef-t4'))
        p.locator('.ef-t4 .ef-aviso .ef-verde').click(); p.wait_for_timeout(200); p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(1500)
        r.t('D) Juntar: fica uma Hinata com o progresso das duas (1111) e uma cópia na lixeira', [x['id'] for x in perfis(p)['perfis']]==['p1'] and ls(p,'p1_hana_done')=='1111' and len(json.loads(ls(p,'escola_lixeira_alfabetizacao')))==1)
        r.t('D) ...e sobe para a nuvem', esperar_ok(p) and fb.dados_app('hinata_1f989')['hana_done']=='1111')
        ctx.close()
        # G
        ctx, fb = nc(b, familia='familiateste', storage={'ev_perfis':json.dumps({"perfis":[],"atual":None})})
        p = abrir_v(ctx)
        r.t('G) Código e nenhuma criança: T4 só com ➕ e ☁️ (sem pedir código)', aberta(p,'ef-t4') and estado_familia(p)['familias'][0]['c']=='familiateste' and p.locator('.ef-t4 .ef-crianca[data-id]').count()==0)
        ctx.close()
        # H
        ctx, fb = nc(b, familia='familia-yyy', storage={'ev_perfis':pf_json([('p1','Ana','🐼'),('p2','Bia','🐰')],'p1'),
                  'escola_familia':familia_json(['familia-xxx'],{'p1':'familia-xxx'},'familia-xxx')})
        p = abrir_v(ctx); efh = estado_familia(p)
        r.t('H) Voltou ao app antigo, trocou o código lá e criou criança: o código novo vence e ninguém fica sem família',
            efh['atual']=='familia-yyy' and efh['criancas']=={'p1':'familia-yyy','p2':'familia-yyy'} and [f['c'] for f in efh['familias']]==['familia-yyy'], efh)
        p.reload(); p.wait_for_timeout(800)
        r.t('H) A reconciliação pode rodar de novo sem estragar nada', estado_familia(p)['criancas']==efh['criancas'] and estado_familia(p)['atual']=='familia-yyy')
        ctx.close()
        res.append(r.fim())

        # ================= 8) voltar ao zip anterior =================
        r = R('8) Voltar ao zip anterior (v121) depois da migração')
        if V121 and os.path.isdir(V121):
            fb = FakeFirebase()
            ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊'),('p2','Bia','🐰'),('p3','Caio','🐯')],'1'),
                      'hana_done':'111','p2_hana_done':'11','p3_hana_done':'1','hana_trilha_v2':'1','p2_hana_trilha_v2':'1','p3_hana_trilha_v2':'1'})
            p = abrir_v(ctx); esperar_ok(p)
            p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-crianca[data-id="p3"] .ef-tirar').click(); p.wait_for_timeout(200); p.click('.ef-pergunta .ef-sim'); p.wait_for_timeout(3500)
            servir_pasta(ctx, V121, URL)
            for _ in range(2): p.reload(); p.wait_for_timeout(1200)
            pf = perfis(p)['perfis']
            r.t('O app anterior abre com as crianças e o progresso de cada uma', [x['id'] for x in pf]==['1','p2'] and p.evaluate("progressoDe('1')")==3 and p.evaluate("progressoDe('p2')")==2, pf)
            r.t('...sem nenhuma "Hana 👧" fantasma (abrindo 2 vezes)', not any(x['av']=='👧' for x in pf))
            r.t('...e continua usando a mesma família', ls(p,'nuvem_familia')=='familiateste')
            ctx.close()
        else:
            r.t('Voltar ao v121 (precisa de PASTA_V121)', False, 'defina PASTA_V121')
        res.append(r.fim())

        # ================= 9) backup junta =================
        r = R('9) Importar backup JUNTA (D14): nem o celular nem a nuvem perdem nada')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1'*10,'hana_fav':'[1]','hana_trilha_v2':'1'})
        p = abrir_v(ctx); esperar_ok(p)
        backup = {'app':'Esforço Vence — Alfabetização','appId':'esforco-vence','dados':{'ev_perfis':pf_json([('1','Hana','🦊'),('p9','Lia','🐼')],'1'),
                  'hana_done':'111','hana_fav':'[7]','p9_hana_done':'1'}}
        p.evaluate("o=>{ window.location.reload=function(){}; aplicarBackup(o); }", backup); p.wait_for_timeout(500)
        pf = perfis(p)['perfis']
        r.t('Backup mais antigo: as 10 frases do celular continuam (nada apagado)', ls(p,'hana_done').count('1')==10 and json.loads(ls(p,'hana_fav'))==[1,7])
        r.t('...a criança que só estava no backup (Lia) entra como nova', any(x['nome']=='Lia' for x in pf))
        p.reload(); p.wait_for_timeout(600); esperar_ok(p, 10000)
        r.t('...e a nuvem continua com as 10 frases (não foi sobrescrita)', fb.dados_app('hana_1f98a')['hana_done'].count('1')==10)
        r.t('...e a Lia sobe para a família', fb.dados_app('lia_1f43c') is not None)
        ctx.close()
        res.append(r.fim())

        # ================= 10) bolinha em todas as telas com ⚙️ =================
        r = R('10) Chip e bolinha: em todas as telas principais; verde, amarela e vermelha')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_done':'1','hana_trilha_v2':'1','hana_abrirhub':'1'})
        p = abrir_v(ctx); esperar_ok(p); fechar_app_popups(p); fechar_tudo(p)
        for pg in ('ler','monta','silaba','treino'):
            p.evaluate("n=>trocarPagina(n)", pg); p.wait_for_timeout(300); esperar_ok(p); p.wait_for_timeout(300)
            suf = '' if pg=='ler' else '_'+pg
            info = p.evaluate("""s=>{ const chip=document.querySelector('#efChip'+s+' .ef-chip'); const lugar=document.getElementById('efChip'+s);
              const cfg=lugar && lugar.nextElementSibling; const pt=cfg && cfg.querySelector('.ef-ponto');
              return {chip:!!(chip&&chip.offsetParent), txt:chip?chip.textContent:'', cfgAoLado: !!cfg && /⚙️/.test(cfg.textContent), ponto: pt?pt.className:''}; }""", suf)
            r.t('%s: chip 🦊 colado à esquerda da ⚙️ e bolinha 🟢 na ⚙️' % pg, info['chip'] and '🦊' in info['txt'] and info['cfgAoLado'] and info['ponto'].endswith('ef-p-verde'), info)
        offline(p, fb, True)
        p.evaluate("trocarPagina('ler'); markDone(construirOrdemDificuldade().find(i=>!isDone(i)))"); p.wait_for_timeout(2000)
        r.t('Sem internet com fila: 🟡 em todas as ⚙️', all(c.endswith('ef-p-amarelo') for c in p.evaluate("Array.from(document.querySelectorAll('.ef-ponto:not(.ef-ponto-solto)')).map(x=>x.className)")))
        offline(p, fb, False); esperar_ok(p)
        p.wait_for_timeout(500)
        r.t('Internet voltou e subiu: 🟢 de novo', ponto_cfg(p).endswith('ef-p-verde'))
        p.click('#efChip .ef-chip'); p.wait_for_timeout(300)
        r.t('Tocar no chip abre "Quem vai estudar hoje?"', aberta(p,'ef-t4'))
        fechar_tudo(p); p.evaluate("openConfig()"); p.wait_for_timeout(300)
        loc = p.locator('.ef-cfg-mostrar'); loc.scroll_into_view_if_needed(); bb = loc.bounding_box()
        p.mouse.move(bb['x']+bb['width']/2, bb['y']+bb['height']/2); p.mouse.down(); p.wait_for_timeout(900)
        p.evaluate("NuvemSync.sincronizar(); localStorage.setItem('hana_fav','[2]')"); p.wait_for_timeout(2600); p.mouse.up(); p.wait_for_timeout(300)
        r.t('Trava do adulto: a nuvem mudar de estado no meio dos 3 s não interrompe (mostra o código)', 'familiateste' in p.text_content('#cfgFamilia'))
        ctx.close()
        res.append(r.fim())

        # ================= 11) botão voltar do Android =================
        r = R('11) Botão voltar do Android: fecha primeiro o pop-up, depois a tela')
        fb = FakeFirebase()
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':pf_json([('1','Hana','🦊')],'1'),'hana_trilha_v2':'1','hana_abrirhub':'1'})
        p = abrir_v(ctx); p.wait_for_timeout(600); fechar_app_popups(p); fechar_tudo(p); p.wait_for_timeout(300)
        p.click('#efChip .ef-chip'); p.wait_for_timeout(300)
        p.click('.ef-t4 .ef-novo'); p.wait_for_timeout(300)
        r.t('Abertos: "Quem vai estudar hoje?" e por cima "Qual é o seu nome?"', aberta(p,'ef-t4') and aberta(p,'ef-t5'))
        p.go_back(); p.wait_for_timeout(400)
        r.t('Voltar: fecha só a de cima', aberta(p,'ef-t4') and not aberta(p,'ef-t5'))
        p.click('.ef-arrumar'); p.locator('.ef-t4 .ef-tirar').click(); p.wait_for_timeout(300)
        r.t('Pop-up de pergunta aberto', aberta(p,'ef-pergunta'))
        p.go_back(); p.wait_for_timeout(400)
        r.t('Voltar: fecha o pop-up primeiro (sem tirar nada)', not aberta(p,'ef-pergunta') and aberta(p,'ef-t4') and len(perfis(p)['perfis'])==1)
        p.go_back(); p.wait_for_timeout(400)
        r.t('Voltar de novo: sai do modo "Arrumar" (a tela continua)', aberta(p,'ef-t4') and 'ARRUMANDO' not in p.text_content('.ef-t4'))
        p.go_back(); p.wait_for_timeout(400)
        r.t('Voltar mais uma vez: fecha "Quem vai estudar hoje?" e volta ao app', not aberta(p,'ef-t4') and p.url.startswith(URL))
        ctx.close()
        res.append(r.fim())

        # ================= 12) riscos antigos de perder histórico =================
        r = R('12) Riscos antigos (6.10-11 e 6.10-14) não perdem mais histórico')
        fb = FakeFirebase(); fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'1'*25,'hana_trilha_v2':'1'}, familia='familia-teste')
        ctx, _ = nc(b, fb=fb)
        p = abrir_v(ctx)
        p.click('.ef-t1-ja'); p.fill('.ef-t2 .ef-codigo','familia-teste'); p.click('.ef-t2 .ef-procurar'); p.wait_for_timeout(1200); p.click('.ef-t2 .ef-escolher'); p.wait_for_timeout(1200)
        fb.falhar_get_app = True
        p.locator('.ef-t4 .ef-nuvemcard').click(); p.wait_for_timeout(2500)
        r.t('6.10-14: trazer da nuvem que FALHA não deixa criança vazia criada', perfis(p)['perfis']==[] and '❌' in toast(p), toast(p))
        fb.falhar_get_app = False; p.wait_for_timeout(3000)
        r.t('...e a ficha da nuvem continua com as 25 frases', fb.dados_app('renata_1f98b', familia='familia-teste')['hana_done'].count('1')==25)
        ctx.close()
        fb = FakeFirebase(); fb.gravar_app('renata_1f98b','Renata','🦋',{'hana_done':'111111','hana_trilha_v2':'1'}, dispositivo='OUTRO')
        ctx, _ = nc(b, fb=fb, familia='familiateste', storage={'ev_perfis':json.dumps({"perfis":[],"atual":None})})
        fb.offline = True; ctx.add_init_script("if(!sessionStorage.getItem('__off')) sessionStorage.setItem('__off','1');")
        p = abrir_v(ctx); offline(p, fb, True)
        p.click('.ef-t4 .ef-novo'); p.wait_for_timeout(300); cadastrar_t5(p, 'Renata', 4); fechar_app_popups(p); fechar_tudo(p)
        p.evaluate("trocarPagina('ler'); idx=construirOrdemDificuldade()[30]; markDone(idx);"); p.wait_for_timeout(1000)
        # o "último a gravar" passa a ser este celular (como no defeito antigo)
        dev = ls(p,'nuvem_dispositivo')
        fb.docs['familias/familiateste/usuarios/renata_1f98b/apps/alfabetizacao']['fields']['dispositivo'] = {'stringValue': dev}
        offline(p, fb, False); esperar_ok(p, 10000)
        d = fb.dados_app('renata_1f98b')
        r.t('6.10-11: recadastrar o mesmo nome + bichinho sem internet NÃO apaga a ficha (junta: 6 + 1 = 7)', d['hana_done'].count('1')==7, d['hana_done'].count('1'))
        r.t('...e o celular também fica com as 7', ls(p,'hana_done').count('1')==7 if ls(p,'hana_done') else p.evaluate("doneN")==7)
        ctx.close()
        res.append(r.fim())

        # ================= 13) arquivos e caixinhas nativas =================
        r = R('13) Arquivos compartilhados e nenhuma caixinha do navegador')
        md5 = lambda f: hashlib.md5(open(os.path.join(PASTA,f),'rb').read()).hexdigest()
        r.t('Nenhum alert/confirm/prompt do navegador apareceu em todos os testes acima', not DIALOGOS, DIALOGOS)
        txt = open(os.path.join(PASTA,'escola-familia.js'),encoding='utf-8').read()
        r.t('escola-familia.js não usa alert/confirm/prompt nem sessionStorage', not re.search(r'\b(alert|confirm|prompt)\s*\(|sessionStorage', re.sub(r'/\*[\s\S]*?\*/','',txt)))
        r.t('sw.js guarda o escola-familia.js (o app abre sem internet)', './escola-familia.js' in open(os.path.join(PASTA,'sw.js'),encoding='utf-8').read())
        b.close()
        res.append(r.fim())
    return res

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nFAMÍLIA: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
