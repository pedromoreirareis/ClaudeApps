# ▶️ Continuar o 📚 Esforço Vence — Alfabetização numa conversa nova

**O que anexar na conversa nova (Pedro):**
1. **`alfabetizacao-completo-v123.zip`** (tudo do app: pacote do Netlify, cópias mestras `compartilhados/`, documentos, testes e arquivos de trabalho).
2. **`HISTORICO_E_PLANO_alfabetizacao.md`** (também está dentro do zip, em `documentos/`; anexe solto para a conversa ler logo).
3. **Quando for mexer no cadastro:** o **`PLANO_CADASTRO_FAMILIA.md`** (versão 3; também está no zip, em `documentos/referencias/`).
4. Se for testar a migração do cadastro com dados de verdade: o **backup exportado** do app (⚙️ › ⬆️ Exportar backup), de preferência dos dois celulares. ⚠️ **Exportar** é seguro. Desde a v122 (e na v123) **importar JUNTA** (nunca apaga); só na **v121** (a antiga) importar substituía o progresso no celular e na nuvem — nela, não importe.

Não precisa anexar `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js` nem `escola-familia.js`: eles já estão no zip (`pacote-netlify/` e `compartilhados/`). Situação em 07/10/2026: o novo cadastro foi testado e **aprovado** no site de teste (`escolasaopedrotestes.netlify.app`, família de teste `pmrtestes`); a **v123** é a versão final, entregue para o site de verdade (`INSTRUCOES_PUBLICAR_v123.md`).

Depois cole o texto entre **COPIE DAQUI** e **ATÉ AQUI** e escreva no fim o que quer.

`========== COPIE DAQUI ==========`

Olá! Vamos continuar o app **📚 Esforço Vence — Alfabetização**, da Escola São Pedro.

**Quem sou eu:**
- Sou o **Pedro**, de Mara Rosa (GO). **Não sou programador**: eu decido a parte pedagógica e você (Claude) escreve todo o código.
- Testo com as minhas filhas num **celular Android de verdade**, quase sempre **espelhado na TV**, com elas sentadas a uns 3 metros. Por isso: letra grande, tela sempre acesa, tela cheia, paisagem.
- **Hinata, 6 anos:** 1º ano do fundamental, mas lê e faz matemática no nível do 3º ano.
- **Hana, 4 anos:** lê com certa fluência e faz pequenas contas de adição e subtração. É a usuária original deste app (o perfil legado `"1"`).
- São 7 apps da Escola São Pedro (marca Coruja 🦉 / "Esforço Vence": o esforço vale mais que o talento): Alfabetização, Matemática, Fluência, Coruja Explica, Provinha, Historinhas e Curiosidades. Todos usam os mesmos `nuvem-config.js`, `nuvem-sync.js` e `escola-pwa.js`.

**O app:**
- Ensina a ler, das sílabas às frases, em 4 módulos: Ler, Treinar Sílabas, Monta a Frase e Sílaba Perdida.
- 2039 frases, 854 palavras de sílabas simples e 2073 de sílabas complexas.
- Um único `index.html` (PWA offline), publicado em https://escolasaopedroalfabetizacao.netlify.app/ — ID na nuvem: `alfabetizacao`.

**Estado atual:**
- Versão **v123** = versão final do novo cadastro da família (`PLANO_CADASTRO_FAMILIA.md`), com desenho deitado com respiro, ⚙️ na "Quem vai estudar hoje?" e tela cheia de verdade; cache do `sw.js` **`esforco-vence-v123`**. A próxima entrega usa **`esforco-vence-v124`**.
- O site de teste é **https://escolasaopedrotestes.netlify.app/** (família de teste **`pmrtestes`** — nunca a família de verdade lá).
- Arquivos compartilhados: `escola-familia.js` **1.2** e `nuvem-sync.js` **4.1** (cópias mestras em `compartilhados/`, com o `LEIA-ME_COMPARTILHADOS.md`); são eles que vão para os outros 6 apps.
- Testes em 07/10/2026: **691** (89 rápidos + 602 num Chromium: cadastro 72, nuvem 81, PWA 34, fonte 58, família 130, revisão 59, desenho 127, v123 41) (capítulo 9 do HISTORICO). Na máquina de trabalho o `teste_fonte.py` dá 57/58 (faltam as fontes Roboto/Arial; igual na v121 e na v122), e as suítes devem rodar uma de cada vez (com a máquina carregada, testes de tempo podem falhar à toa).

**Antes de mexer em qualquer coisa:**
1. **Leia o `HISTORICO_E_PLANO_alfabetizacao.md` inteiro** (os documentos de `documentos/historico/` são antigos: onde conflitarem, vale o HISTORICO_E_PLANO), principalmente:
   - o capítulo 6 (cadastro, família e nuvem);
   - o capítulo 7 (regras);
   - o capítulo 8 (aprendizados);
   - o capítulo 11 (defeitos conhecidos).
2. Extraia o zip, confira que o `pacote-netlify/index.html` tem o md5 que está no `LEIA-ME.txt` do zip e rode os testes como diz o capítulo 9 (precisa de `npm install` dentro de `testes/`).
3. Me diga em poucas linhas o que entendeu e se achou alguma contradição.

**Regras que não podem ser quebradas:**
1. **Edições cirúrgicas.** Não reescreva o que funciona. Explique a causa de cada problema em português simples. Coisa grande, só com a minha autorização.
2. **Nunca inserir frase no meio do array `DATA`**, só no fim. O progresso é um mapa de posições (`hana_done`).
3. **A ordem de leitura é calculada** (`construirTrilha`): primeiro só sílabas simples com frases curtas, depois as complexas começando pelo R (R entre vogais primeiro). Não voltar a ordenar à mão.
4. **Áudio:**
   - no **Ler**, só toca se a criança ligar;
   - no Monta a Frase e na Sílaba Perdida, fala a frase sozinho, mas só com a página aberta na tela.
5. **Pop-ups sempre no estilo do app** (`confirmModal` e as telas do `escola-familia.js`), seguindo a fonte e a caixa alta das Configurações. **Nunca** `alert()`, `confirm()` ou `prompt()` do navegador.
6. **Cada criança grava com prefixo:**
   - `hana_*` para a criança `"1"`, `<id>_hana_*` para as outras;
   - toda chave nova de progresso começa com `hana_` e entra em `CHAVES_LEITORA`;
   - o `nuvem-sync.js` troca o `localStorage.setItem`, e o app recoloca o prefixo **por cima** logo depois do `NuvemSync.iniciar`. Não mexa nessa ordem sem testar com duas crianças.
7. **Tamanho da letra** = frase-padrão (`fitCaixa` + `REF_LER`/`REF_MONTA`/`REF_SILABA`/`REF_PALAVRA`). Nunca "esticar até encher o quadro".
8. **Não altere** `nuvem-sync.js` (4.1), `escola-familia.js` (1.2), `escola-pwa.js` nem `nuvem-config.js` (iguais nos 7 apps; cópias mestras em `compartilhados/`). Se precisar mudar algum, PARE e me pergunte: afeta os outros apps. O `nuvem-config.js` nunca muda. Não mexa nas regras nem na estrutura do Firebase.
9. **Nenhuma perda de histórico.** Na dúvida, juntar em vez de substituir. Desde a v122 o backup junta e o envio junta com a nuvem quando o celular não conhece a ficha (capítulo 6.11); tirar uma criança só com tudo guardado na nuvem ou com cópia na lixeira do celular. Na v121 (a antiga) os riscos 6.10-5, 6.10-11 e 6.10-14 existem: **não importe backup** nela. Com o `nuvem-sync.js` 4.1, a criança tem que estar na lista **antes** de qualquer junção (backup, lixeira, trazer da nuvem).
10. Todo conteúdo novo (palavra, frase) passa por um silabificador antes de entrar. O silabificador antigo se perdeu: avise antes de acrescentar conteúdo.

**Como me entregar:**
1. Rode `python3 trabalho/scripts/checar_sintaxe.py pacote-netlify/index.html` (faz `node --check` em todo JavaScript embutido) e `node --check pacote-netlify/sw.js`.
2. Suba o cache do `sw.js` (`esforco-vence-v123`, depois `v124`...) — **a cada zip entregue**, mesmo uma correção pequena.
3. Copie para `testes/` o `index.html`, o `sw.js` e o `manifest.webmanifest` novos, troque o nome do cache escrito no `testes/testes_navegador/teste_pwa.py` (linhas 102 e 113) e rode **todos** os testes. Tudo tem que passar; testes novos para o que mudou.
4. Zip para o Netlify **só com os 9 arquivos na raiz**:
   - `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`;
   - `nuvem-sync.js`, `escola-pwa.js`, `escola-familia.js`;
   - o **meu `nuvem-config.js` byte a byte igual** (md5 `1d5f060a5ae8339921d3d58498807971`). Nunca o `nuvem-config.js` de teste que está em `testes/`.
5. Extraia o zip pronto e confira de novo (arquivos, md5, sintaxe).
6. Diga claramente o que foi **rodado de verdade** e o que foi só **lido no código**.
7. Antes de entregar algo importante (principalmente cadastro, nuvem ou migração): checagem em 3 etapas (parte 9-A do plano, versão 3): **autochecagem**, **1 agente conferente independente** e **revisor-chefe** (agentes criados por ferramenta, que não viram o trabalho).
8. Termine com um checklist ✅/⬜ em português: o que foi feito e o que eu preciso fazer.
9. **Desenho:** a maioria dos apps fica **deitada** (paisagem): toda tela com respiro, usando a largura (pop-ups largos, botões numa linha com espaço entre eles, nada grudado no topo), letras de 14 px ou mais e botões de 48 px ou mais. Teste nos tamanhos do meu Motorola deitado (cerca de **984×432** e **937×411**) e em 740×360, 640×360 e 568×320.

Eu às vezes falo por voz e o texto sai trocado ("Wolf screen" = "Full screen", "paixão" = "posição"): interprete com boa vontade e pergunte se ficar em dúvida.

O que eu quero agora: **(escreva aqui)**

`========== ATÉ AQUI ==========`
