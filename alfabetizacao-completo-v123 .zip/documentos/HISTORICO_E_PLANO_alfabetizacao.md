# 📚 Esforço Vence — Alfabetização · Histórico e plano completo

**Escola São Pedro · ID na nuvem: `alfabetizacao` · versão v123 (VERSÃO FINAL, para o site de verdade) · passagem escrita em 06/10/2026 · atualizado para a v122, a v122b e a v123 em 07/10/2026**

> ## ⭐ v123 — LEIA PRIMEIRO (07/10/2026, à noite) — VERSÃO FINAL
> O Pedro testou a v122b no site de teste: **funcionamento perfeito**, os dados salvos no teste anterior migraram, e as Configurações ficaram como ele queria. Ele **aprovou** e pediu a versão final para o site de verdade, com 2 mudanças: (1) **⚙️ na "Quem vai estudar hoje?"**; (2) **a tela cheia como era antes** (na v122b, o app instalado deixou de pedir a tela cheia e apareceram as barras do Android — a "borda azul" com os 3 botões —, e o aviso do Chrome continuou; ele prefere sem as barras). A **v123** (capítulo **3.12**) faz isso e fecha 2 pontos 🟡 da revisão: **C1** (`nuvem-sync.js` **4.1**: resposta da nuvem que chega depois de a criança sair não regrava as chaves dela) e **C2** (`escola-familia.js` **1.2**: bolinha 🟡 enquanto uma criança tirada está guardada só na lixeira do celular). Abertura ~15% mais leve. Cache **`esforco-vence-v123`**. Publicar: `INSTRUCOES_PUBLICAR_v123.md`; checagem: `RELATORIO_CHECAGEM_alfabetizacao_v123.md` (protocolo novo: autochecagem + 1 agente conferente + revisor-chefe). As cópias mestras para os outros 6 apps estão em `compartilhados/` (md5 no `LEIA-ME_COMPARTILHADOS.md`).

> ## ⭐ v122b — LEIA PRIMEIRO (07/10/2026, à tarde)
> O Pedro publicou a v122 no site de teste **https://escolasaopedrotestes.netlify.app/** (família de teste `pmrtestes`) e testou em **2 celulares Motorola**: leitura, sílabas marcadas e busca da família **funcionaram** e apareceram no outro celular. Ele pediu **só desenho** (respiro e largura deitado). A **v122b** faz isso (capítulo **3.11**): teclado com a caixa do código no meio; Configurações largas (2 colunas) e "☁️ Família e nuvem" com os botões numa linha; "🎉 Achei a sua família" largo e legível com 1 a 6 crianças; "Quem vai estudar hoje?" e "Famílias" com respiro; o site de teste do Pedro passa a ser reconhecido; o app instalado não pede mais a tela cheia do Chrome (que mostra o aviso "arraste para sair"). `escola-familia.js` passa a **1.1** (só desenho); `nuvem-sync.js`, `escola-pwa.js` e `nuvem-config.js` **iguais**. Cache **`esforco-vence-v122b`**. Roteiro: `INSTRUCOES_SITE_DE_TESTE_v122b.md`; checagem: `RELATORIO_CHECAGEM_alfabetizacao_v122b.md`.
> - ⚠️ **A máquina de trabalho foi reciclada durante a pausa.** O pacote da v122 foi recuperado **baixando o site de teste do Pedro** (md5 idênticos aos entregues: `escola-familia.js` `8872b010…`, `nuvem-sync.js` `c953cfd3…`, `nuvem-config.js` `1d5f060a…`; o `index.html` difere só pela linha que o próprio Netlify injeta) e os testes/documentos foram refeitos **repetindo, em ordem, as edições registradas na conversa**. Conferência: os testes da v122 reconstruída deram os mesmos números de antes (89 · 72 · 81 · 34 · 57/58 · 130 · 59).

> ## ⭐ v122 — LEIA PRIMEIRO (07/10/2026)
> A v122 implantou o **novo cadastro da família e das crianças** do `PLANO_CADASTRO_FAMILIA.md` (aprovado, D1–D16). O que mudou está no **capítulo 3.10** e no **capítulo 6.11**. Os capítulos 6.1 a 6.10 descrevem como era **até a v121** (ficam como histórico; onde conflitarem, valem 3.10 e 6.11).
> - Novos arquivos compartilhados: **`escola-familia.js` v1** (telas T1–T8, chip, bolinha, seção "☁️ Família e nuvem", migração) e **`nuvem-sync.js` v4**. Cópias mestras em `compartilhados/` (md5 no `LEIA-ME.txt`). O `nuvem-config.js` e o `escola-pwa.js` **não mudaram**.
> - O zip do Netlify agora tem **9 arquivos** (o `escola-familia.js` a mais).
> - Situação: **zip do SITE DE TESTE** entregue e publicado pelo Pedro em `escolasaopedrotestes.netlify.app` (o nome sugerido era `escolasaopedroalfabetizacao-teste`; ele escolheu outro). O site de verdade **continua na v121** até o Pedro aprovar o teste.
> - Testes: **521** na v122 (89 rápidos + 432 num Chromium: cadastro 72, nuvem 81, PWA 34, fonte 58, família 128, revisão 59); **651** na v122b (família 130 + desenho 128) (capítulo 9).

Este documento é a memória do app para uma conversa nova. Ele foi escrito a partir do **arquivo** do app (fonte da verdade) e do que lembro das conversas.

**Como ler as marcas:**
- **✔ certeza** = conferido no arquivo (código, pacote ou testes rodados em 06/10/2026).
- **💭 lembrança** = vem das conversas, de documentos antigos ou da memória; pode ter detalhes imprecisos.
- **"não sei"** = não tenho como confirmar.

---

## 1. Identificação

| Item | Valor |
|---|---|
| Nome do app | **Esforço Vence — Alfabetização** (título da página: `Esforço Vence 🦉 — Alfabetização`; nome curto no celular: `Esforço Vence`) ✔ |
| Endereço no Netlify | https://escolasaopedroalfabetizacao.netlify.app/ ✔ (está nos documentos e no código de testes) |
| ID na nuvem | `alfabetizacao` (constante `APP_NUVEM` no `index.html`) ✔ |
| Versão atual | **v123** (versão final do novo cadastro, aprovada pelo Pedro; vai para o site de verdade) |
| Cache do `sw.js` | `esforco-vence-v123` (v122b: `esforco-vence-v122b`; v122: `esforco-vence-v122`) |
| Próximo cache | `esforco-vence-v124` |
| Última entrega | 23/09/2026 (v121) 💭 (data das entregas nesta conversa; os arquivos do zip têm data de 23/09/2026 ✔) |
| Está publicada? | **v122: sim, no SITE DE TESTE** `https://escolasaopedrotestes.netlify.app/` (07/10/2026; conferido baixando o site: `sw.js` = `esforco-vence-v122`). **v122b:** publicada no site de teste e aprovada (07/10). **v123:** entregue para o **site de verdade** (07/10); até o Pedro publicar, o site de verdade segue na v121. **v121:** não sei. O Pedro anexou nesta passagem o zip `esforco-vence-netlify.zip` como "o mais recente" e ele é idêntico à v121 ✔. Não consegui abrir o site daqui para conferir o `sw.js` publicado. Confira: o `sw.js` do site deve dizer `esforco-vence-v121`. |

**Arquivos do pacote da v123** (pasta `pacote-netlify/`; md5 de cada um no `LEIA-ME.txt`): `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`, `nuvem-config.js` (do Pedro, **igual**), `nuvem-sync.js` (**4.1**), `escola-pwa.js` (v2, **igual**), `escola-familia.js` (**1.2**). A v122 publicada está guardada em `trabalho/versoes_anteriores/index_v122.html` (o `escola-familia.js` v1 dela tem md5 `8872b010ad144216e0bb13efd1d84671`).

**Arquivos do pacote da v121** (histórico — idênticos byte a byte ao zip que o Pedro anexou em 06/10 ✔):

| Arquivo | Tamanho (bytes) | md5 | O que é |
|---|---|---|---|
| `index.html` | 986208 | e1cc04016f1b9837d44e904a2ac4f55d | o app inteiro (HTML + CSS + JS + dados) |
| `sw.js` | 1615 | 9364579afe59f6cb5c9d285d56cca7f3 | service worker (funciona sem internet) |
| `manifest.webmanifest` | 811 | ccd9cd750a1b8281395a870c75555329 | nome, ícone, tela cheia, paisagem |
| `icon-192.png` | 24225 | b8d737cdb3c090357b36ee2202db1331 | ícone |
| `icon-512.png` | 101054 | 5d5ac6dbc9397603bb99a4df6ca157a8 | ícone (também "maskable") |
| `nuvem-config.js` | 2043 | 1d5f060a5ae8339921d3d58498807971 | **o do Pedro**, com as chaves do Firebase (igual nos 7 apps) |
| `nuvem-sync.js` | 20277 | f6736f30a4eb5c2e29af1866e79eafe8 | nuvem v3 (igual nos 7 apps) |
| `escola-pwa.js` | 21976 | ec31bf4a195ccf6a28f70e4fe3748c5f | tela acesa, tela cheia, convite de instalar, 8 bichinhos (v2, igual nos 7 apps) |

O `nuvem-sync.js` e o `escola-pwa.js` deste app são **idênticos** (mesmo md5) aos que o Pedro anexou em 23/09/2026 ✔. Não há diferença a registrar.

> ⚠️ Os documentos em `documentos/historico/` (`CONTINUIDADE_v41.md`, `ESFORCO-VENCE-DOCUMENTACAO_v121.md`, `PROMPT_CONTINUACAO_antigo_v121.md`) são **antigos**. Onde contradisserem este documento, **vale este**: o zip do Netlify leva os arquivos **na raiz** (sem pasta; 8 até a v121, **9** desde a v122), os testes precisam de `npm install`, hoje são **651 testes** (v121: 310) e `CHAVES_LEITORA` tem **33** chaves.

---

## 2. Para quem e para quê

- **Objetivo pedagógico:** ensinar a ler em português, do som da sílaba até a frase, para crianças a partir de 3–4 anos. 💭
- **Ordem de ensino** (✔ no código):
  1. **Sílabas simples** (consoante + vogal: BA, BE, BI...): 17 famílias, 89 sílabas, 854 palavras.
  2. **Sílabas complexas** (R, RR, L, CH, LH, NH, SS, S no fim, SC, M/N nasal, Ç, X, QU, GU): 14 grupos, 22 padrões, 2073 palavras.
  3. **Leitura de frases:** 2039 frases, das curtas com sílabas simples às longas com sílabas complexas.
  4. **Compreensão:** Monta a Frase (pôr as palavras na ordem) e Sílaba Perdida (completar a sílaba que falta), sobre as mesmas 2039 frases.
- **Como as meninas usam** 💭: num celular Android de verdade, quase sempre **espelhado na TV**, com elas sentadas a uns 3 metros. Por isso letra grande, tela sempre acesa e tela cheia. O Pedro senta junto, explica e observa.
- **Filosofia "Esforço Vence"** 💭: o esforço vale mais que o talento. Sem placar que humilha, sem "errou" pesado. O que já foi feito é marcado, mas **nunca bloqueia** a repetição. Elementos de jogo que tiram o foco da leitura foram retirados (Conquistas, Diploma, Álbum de Figurinhas).
- **Usuária original:** a **Hana** (perfil legado `"1"`, ver capítulo 6). O app guarda no código os nomes reais da família dela para as frases (capítulo 5). ✔

---

## 3. Linha do tempo, versão por versão

> **Aviso honesto:** só tenho detalhes completos das versões **v117 a v121** (esta conversa). O que vem antes foi reconstruído de documentos antigos (`CONTINUIDADE.md`, da v41, e `ESFORCO-VENCE-DOCUMENTACAO.md`, da v116–v121) e da memória. **Os números exatos das versões antigas não sei.**

### 3.1 Antes da v41 💭 (fonte: `CONTINUIDADE.md`, na pasta `documentos/historico/`)
- O app começou como "Esforço Vence" e depois foi o módulo de leitura da marca Coruja. Em outra época se chamou **Besouro Sábio** 💭 (memória: grande revisão da progressão de dificuldade, que era agressiva demais para 3–4 anos).
- **Token `{NOME}`**: o nome da leitora entra silabado nas frases (substituiu "Ha·na" fixo).
- **800 frases novas** com tokens de família, em 8 blocos (família, casa, brincar, gente que eu amo, bichos, escola, sentimentos, histórias).
- **Cadastro da família** passou de 1 campo por tia para "pools" (vários nomes num campo, separados por `/` ou `;`), com migração automática (`migrarParentesPool`).
- **4 páginas** (Ler, Sílaba Perdida, Monta a Frase, Treinar Sílabas) no lugar de "tudo pop-up", com o hub 🏠.
- **Treinar Sílabas — Simples:** 3 gerações de conteúdo; a 3ª veio da lista `lista-oficial-silabas-v3.md` do Pedro.
- C e G desdobrados em duro/brando; **X não virou família** (tem 4 sons).
- **Arrastar-e-soltar no Monta a Frase foi feito e DESFEITO** a pedido do Pedro: tocar na ordem obriga a ler antes.
- Correções de contraste (cor fixa → `var(--ink)`), animação "voar até a vaga" (contador avança no toque, não no fim da animação).

### 3.2 v41 💭
- `CONTINUIDADE.md`: 2039 frases, 37 blocos, 279 testes (3 suítes JSDOM: 67 + 61 + 151).

### 3.3 Da v41 à v96 💭 (fonte: memória)
- **Sílabas complexas** construídas (grupos e padrões), com **quadros de som** para os padrões antes das palavras. Sílabas "sintéticas" (SSA, NHA, BRA) com `semAudio:true`, porque a voz do celular pronuncia errado.
- "Já estudada" em cascata (letra → sílaba → leitor de palavra).
- Posição do Treinar Sílabas salva por leitora (`hana_treino_ultimo`).
- Níveis "🌱 Nível X de Y" no lugar de contadores crus.
- Duas barras de progresso nos cartões das crianças (frases e sílabas).
- Nome com bichinho no topo (`nomeComEmoji()`); nome puro para a voz (`profName()`).
- Limpeza de código morto (137 linhas).
- Banco de palavras crescendo, sempre validado no silabificador.
- Na v96 havia **531 testes** (memória). **Essas suítes antigas não estão nesta conversa** (ver capítulo 9).

### 3.4 Da v96 à v116 💭 (fonte: seção 4 da `ESFORCO-VENCE-DOCUMENTACAO.md`)
1. Lista de palavras integrada: 854 (simples) + 2073 (complexas). ✔ (contagens conferidas no código)
2. Tamanho de letra padronizado; **retirados**: Modo Surpresa (só o botão; a função `openSurpresa` continua no código ✔), Conquistas, Diploma, Álbum de Figurinhas.
3. Famílias simples em **ordem fonética**: M, P, T, L, S, F, N, V, B, D, G, R, C, J, Z, depois C brando e G brando ✔.
4. Navegação por dificuldade no Ler; controle de velocidade da voz.
5. Bug de escopo do "Marcar estudada" (sílaba × família) corrigido.
6. Botão **"Próxima sílaba →"**: estava invisível por um `style="display:none"` escrito no HTML; foi grudado ao ▶ com a mesma altura; nunca "morre" no fim de uma família.
7. Pop-ups seguem a fonte e a caixa alta das Configurações.
8. **Áudio automático** no Monta a Frase e na Sílaba Perdida (v115).
9. Marca de "já respondida" no Monta a Frase e na Sílaba Perdida.
10. Nome do app: **"Esforço Vence — Alfabetização"**, endereço `escolasaopedroalfabetizacao.netlify.app`.

### 3.5 v117 (23/09/2026) ✔
- **Pedido:** "No Ler o áudio liga sozinho às vezes" e "a sequência de frases ficou inadequada: começar com frases muito curtas e só sílabas simples, ir aumentando, e só depois as complexas, começando pelo R — no Ler, na Sílaba Perdida e no Monta a Frase".
- **Causa do áudio:** a cada frase comemorada, o app ainda chamava `openMonta`/`openSilaba` (resto da época dos pop-ups). Isso montava a página **escondida** atrás do Ler e, desde a v115, falava a frase. **Feito:** a chamada saiu (ficou só o quiz) e a fala automática do Monta/Sílaba Perdida só acontece com a página aberta (`paginaAberta()`). Medido: v116 falou 2 vezes em 10 frases com áudio desligado; v117, 0.
- **Causa da ordem:** a ordem vinha de blocos com um número de dificuldade escolhido à mão. Blocos novos entraram com número baixo e trouxeram "a·ten·de", "pri·ma" para o começo. **Feito:** ordem **calculada frase por frase** (`construirTrilha`, `classificarFrase`), pela sílaba mais difícil de cada frase, e dentro de cada etapa da frase mais curta para a mais longa. O array `DATA` **não mudou de ordem**. A chave `hana_trilha_v2` faz cada módulo voltar, uma única vez, para a 1ª frase da trilha que a criança ainda não fez.
- **Desfeito:** a ordem "à mão" por blocos (`BLOCOS_CONTEUDO` ficou só como registro de onde cada bloco está no array).

### 3.6 v118 (23/09/2026) ✔
- **Pedido:** o pop-up "Toque no desenho da frase!" deve seguir a fonte e a caixa alta das Configurações; um interruptor para ligar/desligar todas as imagens; a tela não pode bloquear com o app aberto.
- **Feito:** `aplicarFonteLeitura()` no quiz; **⚙️ › 🖼️ Imagens das frases e palavras** (chave `hana_imagens`; sem imagens o quiz não aparece); tela acesa com Wake Lock.
- **Desfeito depois (v120):** a tela acesa própria virou só reserva; quem cuida agora é o `escola-pwa.js`.

### 3.7 v119 (23/09/2026) ✔
- **Pedido:** "palavras com R/S entre vogais — você decide o que ficar mais fácil" e "revisão completa para publicar".
- **Feito:** **R entre vogais** (ca·ro, a·do·ra) saiu das simples e virou a **1ª etapa do R** (`r_brando`), porque a criança que aprendeu "RA = rato" lê "caro" como "carro". **S entre vogais** (ca·sa) ficou logo depois das simples (`simples2`). **Duas vogais** (pai, lei·te) antes do R. Revisão completa de todos os módulos.

### 3.8 v120 (23/09/2026) ✔ — padrão Escola São Pedro
- **Pedido:** integrar Firebase (salvar sozinho), tela sem bloquear, cadastro padronizado (Nome + Bichinho), seguindo `PADRAO_CADASTRO_NOME_BICHINHO.md` e `REFERENCIA_INTEGRACAO_CURIOSIDADES.md`. O `nuvem-config.js` do Pedro vai no zip **sem nenhuma alteração**. O pop-up do código da família tem que ser bonito, não o do navegador.
- **Feito:** cadastro `#npOv` com os 8 bichinhos; tela "Quem vai estudar hoje?"; tela "☁️ Recuperar cadastro"; pop-up `#codOv`; seções 📺 Tela e ☁️ Nuvem nas Configurações; bolinha da nuvem na ⚙️; ligação com `nuvem-sync.js` e `escola-pwa.js`; `sw.js` guarda os arquivos compartilhados; manifest com `display_override`.
- **Ponto delicado resolvido:** o `nuvem-sync.js` troca o `localStorage.setItem` para vigiar as gravações, e isso desligava o prefixo por criança deste app. O prefixo é recolocado **por cima** logo depois do `NuvemSync.iniciar` (capítulo 6).
- **Desfeito:** o banner de instalação próprio (`#install`) e a tela cheia "só no 1º toque" (`fsFirstTap`) só funcionam se o `escola-pwa.js` faltar. A tela acesa da v118 também.

### 3.9 v121 (23/09/2026) ✔ — tamanho da letra
- **Pedido:** "o tamanho 22 produz fontes de tamanhos diferentes; 'A TIA' parece 64 ou mais; verifique o Ler e os outros módulos".
- **Causa:** o número escolhido não era um tamanho: era "esticar a frase até encher o quadro × o número". Frase curta ficava gigante.
- **Feito:** `fitCaixa(el, area, escala, referencia, chave)` mede uma **frase-padrão** (`REF_LER` = "a vo·vó co·me o bo·lo"; também `REF_MONTA`, `REF_SILABA`, `REF_PALAVRA`). O **24 = o maior tamanho em que a frase-padrão cabe**; os outros números são proporcionais. A frase só diminui se **ela** não couber (frases longas com o celular em pé). No Treinar Sílabas, a palavra com e sem desenho fica do mesmo tamanho.
- **Efeito visível:** frases curtas ficaram menores do que antes no mesmo número (o certo).
- **Desfeito:** o "encher o quadro".

### 3.12 v123 (07/10/2026, à noite) — VERSÃO FINAL do novo cadastro
- **Pedido (Pedro):** "Funcionamento perfeito. Todos os dados que tinha salvo no teste anterior migraram com sucesso." "A tela de configuração ficou perfeita." Pediu: **⚙️ na "Quem vai estudar hoje?"** ("caso eu queira fazer alguma coisa lá"); a **tela cheia como antes** ("mostra uma borda azul onde estão os três botões de navegação… já que continua aparecendo aquela mensagem do navegador, prefiro sem ela"); a **versão final** para publicação; todo o material para os próximos apps; e o protocolo de checagem novo (autochecagem + 1 agente conferente + revisor-chefe), para usar com o **Sonnet 5.5**. Também relatou: abertura que "trava" uns 5 s (tela preta) e que, desinstalando e limpando o cache, a tela "Já tenho cadastro" não voltou.
- **Feito:**
  - `escola-familia.js` **1.2**: ⚙️ com a bolinha na T4, antes do ⛶ (opcional no adaptador: `abrirConfig(aoFechar)` e `fecharConfig()`); ao tocar, as Configurações do app abrem **por cima** e o módulo fica escondido (sem fechar) até elas e o que foi aberto a partir delas fecharem; uma opção da "☁️ Família e nuvem" que abre tela do módulo fecha as Configurações; o voltar do Android fecha as Configurações. **C2:** criança tirada com "guardar uma cópia neste celular" (`soAqui`) deixa a bolinha 🟡 "🗑️ … GUARDADA SÓ NESTE CELULAR: TRAGA DE VOLTA EM ☁️ BUSCAR NA NUVEM" até voltar; a cópia de reserva de "juntar repetidas" não conta.
  - `nuvem-sync.js` **4.1** (**C1**): `aplicar()` confere **na hora** se a criança ainda está na lista; se saiu, não junta, não envia, e `recuperar`/`juntarVersao` devolvem `false`. Se a lista do app der erro, para sem mexer na fila (como o envio já fazia). **Causa:** a leitura da nuvem saía com a lista de antes; quando a resposta chegava depois de a criança ser tirada, o `mesclar` regravava as chaves dela (nos apps em que o id é o nome, a próxima criança com o mesmo nome herdaria o progresso).
  - `index.html`: `nuvemMesclar` só junta numa criança que está em `PERF.perfis` (segunda proteção do C1); ligação da ⚙️ (`abrirConfig`/`fecharConfig`, vigia os pop-ups do app a cada 250 ms); **tela cheia igual à v122** (desfeitas as 3 mudanças da v122b: `toggleFs`, o pedido ao abrir e o `telaCheia` do `EscolaPWA.iniciar`); abertura: `categoriaSilaba` guarda a resposta de cada combinação (a trilha sai **idêntica**, md5 conferido) — abertura medida com CPU 6× mais lenta: **3,6 s → 3,0 s**.
- **Respostas ao Pedro:** (1) desinstalar o ícone e limpar o cache **não** apagam os dados do site (o app instalado e o Chrome usam o mesmo armazenamento); começar do zero = Chrome › Configurações do site › Limpar e redefinir — é o comportamento certo, protege o progresso. (2) A tela preta ao abrir é o Android criando a janela e o Chrome lendo o arquivo de ≈ 1 MB; o que dava para aliviar sem risco foi feito; separar as frases num arquivo à parte seria uma mudança grande (pedido para depois, só com o OK dele).
- **Desfeito:** a tela cheia da v122b no app instalado (o Pedro prefere sem as barras do Android).
- **Checagem (protocolo versão 3):** autochecagem (690/691 testes, uma suíte de cada vez; provas de que os testes novos falham na v122b) → **conferente independente** (rodada 1: ✅ com 2 🟠 nos documentos — regra da 4.1 para os próximos apps e relatórios no zip —, corrigidos; rodada 2: ✅) → **revisor-chefe: ✅ Pode publicar** (54 verificações próprias: migração v121 → v123 com 2 celulares, volta à v121, caso B, tirar criança, C1 com a lista dando erro, ⚙️ na abertura com o voltar). Ver `RELATORIO_CHECAGEM_alfabetizacao_v123.md`.

### 3.11 v122b (07/10/2026, à tarde) — só desenho, a pedido do Pedro depois do teste nos 2 Motorolas
- **Pedido (Pedro):** "Funcionamento do aplicativo parece ter ficado perfeito." Mudanças de desenho: (1) com o teclado aberto, a caixa do código ficava **grudada no topo** → centralizar entre o topo e o teclado; (2) o pop-up das **Configurações** devia usar a largura, e em "☁️ Família e nuvem" os botões estavam **apertados e um em cima do outro**; (3) "🎉 **Achei a sua família**" pequeno e apertado — com 3 ou 4 crianças "não vai dar para entender nada"; (4) o aviso do Chrome "Para sair da tela cheia, arraste…" — se possível não aparecer, ou ser curto/pequeno; (5) **todas** as telas com respiro, aproveitando a largura deitado.
- **Feito (`escola-familia.js` 1.1):**
  - teclado aberto (área visível ≤ 300 px): T2/T3 **no meio** da área acima do teclado e sem sobra vazia (o erro vazio e a área de resultado vazia somem); T5 também no meio. **Causa:** a regra compacta tinha `align-items:flex-start` (grudava em cima) e o cartão guardava espaço para a linha de erro e para os resultados mesmo vazios;
  - pop-ups mais largos (560 px; perguntas 640 px) e 14 px entre botões;
  - "Achei": o pop-up cresce até 960 px e mostra só o título, o código procurado, as crianças em grade (até 4 numa fileira; 5 ou 6 em 3 + 3; nomes compridos em 2 linhas, nunca cortados) e, embaixo e sempre à vista, **← OUTRO CÓDIGO · ESCOLHER · TRAZER TODAS**; ✕ no canto para cancelar. **Causa:** o cartão tinha 480 px fixos e os cartões, os botões do resultado e os botões CANCELAR/PROCURAR ficavam todos juntos;
  - "☁️ Família e nuvem": texto à esquerda, botões numa linha à direita (só quebram para baixo se não couberem), linhas mais altas; os botões do adulto têm uma forma "curta" numa linha só (`◯ 👨 ABRIR ▶`, `◯ 👨 👁 MOSTRAR`; o toque rápido mostra "PEÇA PARA UM ADULTO SEGURAR O BOTÃO POR 3 SEGUNDOS"); **causa:** `flex-wrap` com botões de 2 andares ("👨 PEÇA PARA UM ADULTO" embaixo) num cartão de 480 px;
  - T4: cartões **no meio** da tela (antes grudados à esquerda), nome em até 2 linhas, rodapé numa faixa clara com o texto da nuvem inteiro e "🔑 FAMÍLIA" à direita; T8: cada família numa linha, botões do adulto curtos, código em CAIXA ALTA (resolve o 🟡 B11); T6/Cópias: cartões com mais espaço;
  - site de teste: reconhecido por **qualquer endereço com "teste"** (o do Pedro, `escolasaopedrotestes`, não terminava em `-teste` e por isso a faixa roxa e a trava do código nunca apareceram para ele); no site de teste o código precisa **conter** "teste" (o `pmrtestes` dele é aceito); a faixa só aparece com as telas da família abertas e não cobre nada.
- **Feito (`index.html`):** Configurações deitado com até 980 px e as opções do app em **2 colunas** a partir de 700 px de largura ("Família e nuvem" ocupa a linha toda); **app instalado aberto pelo ícone** (`display-mode: fullscreen`) não pede mais a tela cheia do navegador — nem ao abrir, nem a cada toque (`EscolaPWA.iniciar({telaCheia:false})`), nem pelos botões ⛶ (`toggleFs`). O `escola-pwa.js` **não mudou**.
- **O aviso do Chrome:** é do próprio Chrome e aparece **sempre** que um site entra em tela cheia; nenhum site consegue esconder, encurtar ou diminuir. Na aba do Chrome continua (o botão voltar do Android, em tela cheia, primeiro sai da tela cheia, e o próximo toque volta a pedir). Com o app **instalado** e aberto pelo ícone, o app já está em tela cheia e não pede mais nada → o aviso não deve aparecer (só o celular confirma; pode ser preciso reinstalar o ícone).
- **Sem mudança:** dados, nuvem, família, crianças, migração, progresso; `nuvem-sync.js` v4, `escola-pwa.js` v2, `nuvem-config.js`.
- **Revisão:** revisor de telas independente (2 rodadas: 2 🟠 na 1ª — nomes cortados no "Achei" e faixa do site de teste por cima da barra — corrigidos) e revisor-chefe (✅ pode publicar no site de teste; 4 🟡: o ⛶ da aba deixou de tirar da tela cheia → **corrigido**; foco no campo depois da lupa do teclado → **corrigido** (`blur`); 2 testes a mais → **feitos**; frases velhas nos documentos → **corrigidas**). Ver `RELATORIO_CHECAGEM_alfabetizacao_v122b.md`.

### 3.10 v122 (07/10/2026) — novo cadastro da família (PLANO_CADASTRO_FAMILIA, D1–D16)
- **Pedido:** implantar o plano aprovado; este é o 1º app (nascem o `escola-familia.js` v1 e o `nuvem-sync.js` v4).
- **Feito:**
  - telas novas iguais nos 7 apps, num arquivo compartilhado: T1 boas-vindas (🔑 Já tenho cadastro / 🌱 Sou novo por aqui), T2 código (confere na nuvem se existe; sugere o código sem tracinho; sem internet "a conferir"), T3 criar código (sugere bicho-0000; confere se está livre; "📝 anote"), T4 "🦉 Quem vai estudar hoje?" **toda vez que abre** (D2), com as crianças da família que estão só na nuvem (☁️, D6), T5 nova criança (pergunta "É você?" se o nome já existe com outro bichinho), T6 buscar na nuvem (com a lixeira do celular e os nomes antigos), T7 arrumar (✏️ mudar / 🗑️ tirar deste celular), T8 famílias neste celular (até 4; trava das 2 semanas), cópias de cada dia;
  - chip da criança **ao lado da ⚙️** nas 4 barras de cima (sai o chip embaixo da 🦉) e bolinha 🟢🟡🔴 em todas as ⚙️; se a barra não couber, o chip fica só com o bichinho e os botões encolhem um pouco;
  - Configurações: saíram "👯 Trocar leitora" e a seção antiga da nuvem; a última seção é "☁️ Família e nuvem";
  - **trava do adulto** (D15): segurar 3 s ("👨 PEÇA PARA UM ADULTO") para 👁 mostrar o código, cópias de cada dia, guardar cópia e tirar, entrar/criar/tirar família;
  - **backup JUNTA** (D14): `aplicarBackup` não apaga mais nada; acha cada criança pelo nome + bichinho;
  - **"Hana fantasma" corrigida**: `carregarPerfis` respeita lista vazia; sem criança escolhida o app não lê nem grava nenhuma chave `hana_*` (`SEM_CRIANCA`);
  - **nuvem-sync v4**: família por criança; criança "segurada" não sobe (família a conferir, nome + bichinho repetido, criança sendo trazida); `existeFamilia`, `garantirGuardado`, `marcarMovido` (com `currentDocument.exists=true`), `limparPendencia`, `semVigiar`; **envio mais seguro**: junta com a nuvem antes de gravar também quando este celular ainda não conhece a ficha (corrige os riscos 6.10-5, 6.10-11 e 6.10-14 na raiz);
  - D9: "Nomes da família" → "👨‍👩‍👧 Nomes dos parentes"; tocar fora dessa janela no começo agora leva ao menu (6.10-13);
  - no **site de teste** (endereço com `-teste.`) aparece a faixa "🧪 SITE DE TESTE" e só códigos que começam com `teste` são aceitos (v122b: qualquer endereço com "teste", e o código precisa **conter** "teste").
- **Desfeito:** `#homeOv`, `#npOv`, `#nuvemOv`, `#codOv` e as funções deles (sobraram `abrirHome`, `abrirNovoPerfil`, `abrirEditarPerfil` como atalhos para o módulo); `hana_nuvemnovo` (a recuperação automática agora é do módulo); "com 1 criança entra direto" (D2); bloquear apagar a última criança (agora pode, **depois das 2 primeiras semanas**).
- **Decisões minhas onde o plano não dizia** (estão no RELATORIO_CHECAGEM): sem nuvem configurada não há T1; tirar a **última** criança fica **proibido** nas 2 primeiras semanas (a v121 cria a Hana fantasma com a lista vazia); na volta ao app antigo com o código trocado (caso H), a família antiga que ficou sem crianças sai da lista do celular.

---

## 4. Decisões de design e de pedagogia

### 4.1 Decisões em vigor
| Decisão | Por quê |
|---|---|
| Arquivo único (`index.html`) | publicar arrastando um zip no Netlify; funciona offline 💭 |
| **Nunca inserir frase no meio do `DATA`**, só no fim | o progresso é um mapa de posições (`hana_done`); inserir no meio embaralha o progresso salvo ✔ |
| Ordem de leitura **calculada** pelas sílabas (`construirTrilha`) | blocos com dificuldade "à mão" estragaram o começo (v117) ✔ |
| Etapas na ordem: simples → S com som de Z → duas vogais → R entre vogais → R → RR → L → CH → LH → NH → SS → S no fim → SC/XC → M/N → Ç → X → QU → GU → outros | começa pelo R, como o Pedro pediu; R entre vogais é a 1ª do R (v119) ✔ |
| **Toque na ordem** no Monta a Frase | obriga a ler antes de acertar 💭 |
| No **Ler** o áudio só toca se a criança ligar | ali ela precisa ler sozinha ✔ |
| No Monta a Frase e na Sílaba Perdida a frase é falada sozinha, só com a página aberta | ouvir é o primeiro contato com a frase ✔ |
| "Já feito" é marcado, **nunca bloqueia** | repetir é bom 💭 |
| Ordem fonética das famílias (M, P, T...) | facilidade de pronúncia 💭 |
| Pop-ups no estilo do app, seguindo fonte e caixa alta | criança que só reconhece caixa alta se perde no pop-up do navegador ✔ |
| Sílabas sintéticas com `semAudio:true` | a voz do celular pronuncia errado 💭 |
| Tamanho da letra fixo pela frase-padrão | consistência (v121) ✔ |
| Cada criança com progresso separado | duas filhas no mesmo celular ✔ |
| Uma criança só: "👋 Bem-vindo de volta!" com 2 botões, se ela estava fora do Ler | pedido do Pedro: escolher toda vez ✔ (comentário no código) |

### 4.2 Decisões rejeitadas ou desfeitas
| O que | Por quê |
|---|---|
| Arrastar-e-soltar no Monta a Frase | criança "tateia" até acertar; não reintroduzir sem pedido 💭 |
| Conquistas, Diploma, Álbum de Figurinhas | gamificação que tira o foco 💭 |
| Botão do Modo Surpresa 🎲 | "não está funcionando bem" (Pedro). Função `openSurpresa()` ainda existe, sem botão ✔ |
| Família do X | X tem 4 sons 💭 |
| Ordem por blocos com dificuldade à mão | estragou o começo da trilha (v117) ✔ |
| Letra "encher o quadro" | frase curta gigante (v121) ✔ |
| `alert()`/`confirm()`/`prompt()` do navegador | ver capítulo 6; hoje não existe nenhum ✔ |
| Bichinho já marcado no cadastro | a criança tem que escolher de propósito ✔ |
| Banner de instalação e tela acesa próprios | substituídos pelo `escola-pwa.js` (v120) ✔ |
| Abrir sempre direto no último módulo sem perguntar | trocado pelo "Bem-vindo de volta!" (só 1 criança) 💭 |

---

## 5. Como o app é por dentro

### 5.1 Estrutura do arquivo `index.html` ✔ (6992 linhas)
1. `<head>`: meta viewport (`interactive-widget=resizes-content`, para o teclado não tampar o campo), manifest, os 3 scripts compartilhados (nesta ordem: `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js`), ícone, CSS (temas com variáveis `--ink`, `--bg`, `--card`...).
2. `<body>`: o HTML das telas (linhas ~738–1038).
3. Script principal:
   - multiperfil e prefixo de chaves (~1040–1130);
   - tokens de família (~1131–1420);
   - dados: `DATA`, `SILABAS_FASE1`, `SILABAS_COMPLEXAS_*`;
   - temas, fontes, Treinar Sílabas, trilha, dia/meta, perfis, backup, páginas, `fitCaixa`, voz, quiz, PWA;
   - nuvem (~6511–6894);
   - abertura (~6896–6989).
4. Há só 2 etiquetas `<script>` sem `src`: a **1ª** (linha 15, no `<head>`, antes do `nuvem-config.js`) só tem `window.__nuvemCfgArq='carregando'` (para saber se o `nuvem-config.js` carregou); a 2ª é o script principal, que começa na linha 1039.

### 5.2 Telas (com os `id`s) ✔
| Tela | id | Como abre |
|---|---|---|
| **Ler** (página de base) | `#top`, `#card` (`#pic`, `#phrase`, `#say` 🔊, `#favB` 🤍), `#bar` (`#prev` ◀, `#tg` SÍLABAS, `#au` 🔇, `#next` ▶) | sempre por baixo |
| **Monta a Frase** | `#pgMonta` (`#mtSlots`, `#mtPool`, `#mtPrev`, `#mtPos`, `#mtSay`, `#mtNext`) | hub 🧩 |
| **Sílaba Perdida** | `#pgSilaba` (`#spFrase`, `#spOps`, `#spPrev`, `#spPos`, `#spSay`, `#spNext`) | hub ⭕ |
| **Treinar Sílabas** | `#pgTreino` (`#silCategoria`, `#silGradeBody`, `#silComplexasMacro`, `#silComplexasPadroes`, `#silComplexasTreino`, `#silLeitorPalavra` com `#lpCard`/`#lpPalavra`, `#silFamBody`, barra `#lpBar` com `#lpProximaSilaba`) | hub 🔗 |
| Hub "O que você quer fazer?" | `#hubOv` (`.hubBtn` com `data-hub` treino/ler/silaba/monta) | 🏠 |
| Calendário / dia | `#calOv`, `#diaOv` | 📅 |
| Quiz "🎯 Toque no desenho da frase!" | `#qzOv` | sozinho (ver 5.4) |
| Cantinho dos Pais | `#paiOv` | ⚙️ › 📊 |
| Mapa de níveis | `#lvlOv` | 🗺️ |
| Configurações | `#cfgOv` | ⚙️ |
| Confirmação (estilo do app) | `#cfmOv` (`#cfmTitulo`, `#cfmCorpo`, `#cfmNao`, `#cfmSim`) | `confirmModal()` |
| Telas da família e das crianças (v122+) | `#efRaiz` (criado pelo `escola-familia.js`): T1 boas-vindas, T2 código, T3 criar código, T4 "Quem vai estudar hoje?" (com ⚙️ na v123), T5 nova criança, T6 buscar na nuvem, T7 arrumar, T8 famílias, cópias de cada dia; chip `#efChip` ao lado da ⚙️ | ver 6.11 |
| *(até a v121; saíram na v122)* | `#homeOv`, `#npOv`, `#nuvemOv`, `#codOv` | histórico (6.1 a 6.10) |
| Nomes dos parentes (D9) | `#famOv` | ⚙️ › 📊 Cantinho dos pais › "👨‍👩‍👧 Nomes dos parentes e amigos" |
| Livrinho para imprimir | `#bookPrint` | ⚙️ › 🖨️ |
| Aviso rápido | `#toast` | `showToast()` |
| Banner de instalação próprio | `#install` | **só se o `escola-pwa.js` faltar** |
| Convite de instalar (do `escola-pwa.js`) | `#escolaConvite` (criado pelo arquivo compartilhado) | sozinho / ⚙️ › 📲 |

**Barra de cima** ✔:
- No Ler: 🦉 com o chip (bichinho + nome, `#curName`), barra de progresso, 🏠 📅 🗺️ ⚙️ (com bolinha) ⛶.
- No Monta e na Sílaba Perdida: igual, montada por `htmlTopo()`.
- No Treinar Sílabas: sem 📅 e sem 🗺️.

### 5.3 Funções principais ✔
| Função | O que faz |
|---|---|
| `carregarPerfis`, `salvarPerfis`, `prefixoDe`, `perfilAtual` | lista de crianças e prefixo de cada uma |
| `trocarPerfil(id)` | troca a criança (grava `hana_abrirhub` e recarrega a página) |
| `abrirHome`, `abrirNovoPerfil`, `abrirEditarPerfil`, `confirmarNovoPerfil`, `apagarPerfil` | cadastro (capítulo 6) |
| `fraseDe(i)` | frase `i` com os tokens trocados pelos nomes da família da criança |
| `classificarFrase`, `construirTrilha`, `construirOrdemDificuldade`, `posicaoNaTrilha`, `vizinhoNaTrilha` | trilha de dificuldade; `LEVELS` = 52 níveis calculados |
| `render`, `go(d)`, `markDone(i)`, `initDay` | Ler, frase lida, meta do dia |
| `renderMontaPagina`, `renderSilabaPagina`, `paginaAberta` | Monta / Sílaba Perdida |
| `abrirLeitorSimples`, `retomarTreino` | Treinar Sílabas |
| `trocarPagina(nome)`, `abrirHub(comoPagina)` | troca de página |
| `fitCaixa`, `tamanhoPadrao`, `maiorQueCabe`, `fitText`, `fitMonta`, `fitSilaba` | tamanho da letra (v121) |
| `speak`, `speakPhrase`, `celebrate`, `openQuiz` | voz, comemoração e quiz |
| `confirmModal(opts)` | pop-up no estilo do app (`soOk` = só um botão) |
| `aplicarFonteLeitura(el)` | pop-up segue fonte e caixa alta |
| `exportarBackup`, `importarBackupArquivo`, `aplicarBackup` | backup (capítulo 6) |
| `nuvemExportar`, `nuvemMesclar`, `nuvemIdDaChave`, `resincronizarDoDisco`, `atualizaNuvemUI` | nuvem (capítulo 6) |

### 5.4 Conteúdo e dados ✔ (contados com o app aberto num navegador em 06/10/2026)
| Dado | Quantidade |
|---|---|
| `DATA` (frases) | **2039** (formato `"pa·la·vra pa·la·vra\|emoji"`; todas com emoji) |
| `BLOCOS_CONTEUDO` (registro dos blocos do array) | 37 |
| `LEVELS` (níveis do mapa) | 52 |
| `ETAPAS_TRILHA` | 19 (simples, simples2, ditongo, r_brando, r, rr, l, ch, lh, nh, ss, s_travado, sc_xc, nasal, ce, x, qu, gu, outros) |
| `SILABAS_FASE1` | 17 famílias, 89 sílabas, **854 palavras** |
| `SILABAS_COMPLEXAS_GRUPOS` / `_MACRO` | 14 grupos, 22 padrões, **2073 palavras** |
| `FONTS` | 9: ABC · bastão [só caixa alta] (padrão), ABC · Sassoon [só caixa alta], Redonda, Sassoon (escolar), Divertida, Estreita, Cursiva Beabá [só minúscula], Cursiva Mamãe [só minúscula], Playwrite [só minúscula] |
| `THEMES` | 20 (há nomes repetidos: "Espaço", "Oceano", "Arco-íris" aparecem 2 vezes) |
| Tamanhos de letra | 10, 12, 14, 16, 18, 20 (padrão), 22, 24 (`FSNOMES`/`FSTEPS`) |
| Velocidade da voz | 🐢 Bem devagar (0,6), 🚶 Devagar (0,75), 🏃 Normal (0,9, padrão) |
| Meta do dia | 10 frases novas (`META_DIA`); "foi além" com 15 (`SUPER_META`) |
| Quiz "Toque no desenho" | a cada **15** frases novas lidas (só com imagens ligadas) |
| Comemoração | 12 imagens embutidas (`POSES`, webp). De quem são as imagens: **não sei** |
| Máximo de crianças | 6 (`MAX_LEITORAS`) |
| Tokens nas frases | `{NOME}` (a criança, silabado), ancorados `{PAI}` `{MAE}` `{AVPP}` `{AVMP}` `{AVPM}` `{AVMM}` `{TIA_1..6}` `{TIO_1..5}` `{PRIMA_1..3}` `{PRIMO_1..3}` `{IRMA_1..3}` `{IRMAO_1..3}` `{AMIGO_1..3}` `{AMIGA_1..3}` e livres `{F...}` (ex.: `{FTIA_1}`; sem nome vira a palavra do papel) |
| Nomes padrão (só para a leitora `"1"`, a Hana) | `PARENTES_PADRAO`: pai Pedro, mãe Roberta, avós Alfeu, Francisca, Roberto e Maria, tias Júnia, Jéssica, Amada, Rita, Gláucia e Irene, primas Helena e Isadora, irmã Hinata. **Outra criança nunca vê esses nomes:** sem cadastro, a frase mostra só "a tia", "o vô". |

### 5.5 Orientação da tela ✔
- O manifest pede **paisagem** (`"orientation":"landscape"`) e tela cheia (`display: fullscreen`, com reserva `standalone` e `minimal-ui`).
- Em tela cheia, `lockLandscape()` trava em paisagem; ao sair da tela cheia, destrava.
- **Em pé também funciona:** o CSS tem regras `@media (orientation:portrait)` e os testes medem 412×915. Ao girar, `fitAtual` recalcula a letra.

### 5.6 Service worker e manifest ✔
- `sw.js`:
  - guarda no aparelho `./`, `index.html`, `manifest.webmanifest`, os 2 ícones, `nuvem-sync.js` e `escola-pwa.js`;
  - `nuvem-config.js` vai **primeiro pela internet** (se falhar, usa a cópia guardada);
  - nada de outro endereço (Firebase) passa pelo cache;
  - ao trocar o nome do cache, apaga os caches antigos.
- O registro só acontece em `https:` ou `localhost`.
- O manifest tem `id: "./"`, ícones 192 e 512 (o 512 também "maskable") e a descrição "854 sílabas e 2073 palavras para treinar, 2039 frases para ler..." (obs.: na verdade 854 é o número de **palavras** simples, não de sílabas; é só texto).

### 5.7 TODAS as chaves do `localStorage` ✔
Foram procurados no código cada `localStorage`, `getItem`, `setItem`, `_rawGet`, `_rawSet`, `_rawRemove` e prefixo, inclusive nos 2 arquivos compartilhados.

**Prefixo:** as chaves `hana_*` da criança `"1"` não têm prefixo. As das outras crianças levam `<id>_` na frente (ex.: `p1727100000000_hana_done`). Ver capítulo 6.

**A) Por criança — as 33 de `CHAVES_LEITORA`** (backup, apagar e nuvem; a nuvem leva 32, todas menos `hana_noinstall`):

| Chave | Guarda | Na nuvem, como junta |
|---|---|---|
| `hana_idx` | posição no Ler (índice do `DATA`) | celular manda* |
| `hana_done` | frases lidas: texto de "0"/"1" por posição do `DATA` | OU (lida em qualquer lado) |
| `hana_today` | frases novas lidas hoje | mesmo dia → maior; dia mais novo → nuvem |
| `hana_day` | data de "hoje" (para zerar a meta) | a mais nova |
| `hana_streak` | dias seguidos com estrela | maior |
| `hana_goalday` | último dia em que bateu a meta | data mais nova |
| `hana_stars` | lista dos dias com estrela | união |
| `hana_words` | palavras lidas (contador) | maior |
| `hana_fav` | frases favoritas (lista de índices) | união |
| `hana_help` | quantas vezes pediu áudio em cada frase | maior por frase |
| `hana_theme` | tema (índice) | celular manda* |
| `hana_font` | tipo de letra (índice) | celular manda* |
| `hana_fsize` | tamanho da letra (índice 0–7) | celular manda* |
| `hana_rate` | velocidade da voz (0–2) | celular manda* |
| `hana_caps` | caixa alta ("1"/"0") | celular manda* |
| `hana_syl` | sílabas separadas ligado | celular manda* |
| `hana_audio` | áudio ao tocar ligado | celular manda* |
| `hana_conf` | modo conforto (espaçamento) | celular manda* |
| `hana_noinstall` | "Agora não" do banner próprio (reserva) | **não vai para a nuvem** |
| `hana_parentes` | nomes da família e amigos (objeto) | preenche o que está vazio (numa recuperação, a nuvem manda) |
| `hana_diario` | frases lidas em cada dia | união dia a dia |
| `hana_bstreak` | recorde de dias seguidos | maior |
| `hana_idx_monta` | posição no Monta a Frase | celular manda* |
| `hana_idx_silaba` | posição na Sílaba Perdida | celular manda* |
| `hana_sil_lidas` | palavras lidas no Treinar Sílabas | união |
| `hana_sil_estudadas` | sílabas/famílias marcadas como estudadas | união |
| `hana_treino_ultimo` | onde parou no Treinar Sílabas | celular manda* |
| `hana_pagina_atual` | último módulo aberto (ler/monta/silaba/treino) | celular manda* |
| `hana_monta_ok` | frases acertadas no Monta a Frase | união |
| `hana_silaba_ok` | frases acertadas na Sílaba Perdida | união |
| `hana_trilha_v2` | já passou pela mudança de trilha da v117 | celular manda* |
| `hana_imagens` | imagens ligadas ("0" = desligadas) | celular manda* |
| `hana_sil_filtro_falta` | "Mostrar só o que falta" no Treinar Sílabas | celular manda* |

\* "celular manda" = a nuvem só preenche se a chave não existe no celular, ou numa **recuperação**. A criança sem nada lido neste celular conta como recuperação.

**B) Por criança, de passagem** (fora de `CHAVES_LEITORA`: não vão para backup nem nuvem e não são apagadas ao apagar a criança):

| Chave | Guarda |
|---|---|
| `hana_abrirhub` | "acabou de trocar de criança: abrir o hub direto". **Só é apagada ao abrir quando há 2+ crianças.** Com 1 criança ela fica gravada (ex.: depois de recuperar da nuvem); quando houver a 2ª criança, a primeira abertura pula "Quem vai estudar hoje?" e vai direto ao hub |
| `hana_pedefam` | "criança nova: perguntar dos nomes da família" (apagada ao abrir) |
| `hana_nuvemnovo` | "criança nova: procurar na nuvem o mesmo nome + bichinho" (apagada ao abrir) |

**C) Do aparelho (sem prefixo, valem para todas as crianças):**

| Chave | Quem grava | Guarda |
|---|---|---|
| `ev_perfis` | app | lista de crianças `{"perfis":[{"id","nome","av"}],"atual":"<id>"}` |
| `ev_telaAcesa` | `escola-pwa.js` (nome passado pelo app) | tela sempre acesa ligada/desligada |
| `escola_conviteVisto` | `escola-pwa.js` | quando o convite de instalar foi fechado |
| `escola_instalado` | `escola-pwa.js` | app instalado |
| `nuvem_familia` | `nuvem-sync.js` | **código da família**. Um só por app em cada celular: cada app tem o próprio endereço, e o navegador separa o armazenamento por endereço; por isso o código é digitado uma vez em cada app |
| `nuvem_dispositivo` | `nuvem-sync.js` | identidade deste celular |
| `nuvem_auth` | `nuvem-sync.js` | login anônimo do Firebase |
| `nuvem_alfabetizacao_pendentes` | `nuvem-sync.js` | fila do que falta enviar (por id de criança) |
| `nuvem_alfabetizacao_meta` | `nuvem-sync.js` | último envio de cada criança |

**D) Só lidas, de versões muito antigas** (nunca gravadas pela v121): `coruja_name1`, `coruja_name2`, `p2_hana_idx` (ver capítulo 11, item sobre a "leitora 2" antiga).

**E) `sessionStorage`:** o app não usa. (Os testes usam `__ini`, só no navegador de teste.)
⚠️ **Armadilha:** a troca do `Storage.prototype.getItem` (linha 1127) usa `_rawGet`, que está preso ao `localStorage`. Por isso, com este app aberto, **`sessionStorage.getItem` lê do `localStorage`**. Hoje não quebra nada, porque ninguém usa `sessionStorage`; mas um arquivo novo (ex.: `escola-familia.js`) que use `sessionStorage` vai ler o lugar errado.

### 5.8 Outros lugares ✔
- **IndexedDB:** não usa (nem o app, nem os arquivos compartilhados).
- **Cache Storage:** o `sw.js` guarda os arquivos em `esforco-vence-v123` (v122b: `esforco-vence-v122b`; v122: `esforco-vence-v122`; v121: `esforco-vence-v121`). Desde a v122 também o `escola-familia.js`.
- **Firebase (Firestore):** `familias/{código}/usuarios/{nome_bichinho}` (nome, bichinho, apps) e `.../apps/alfabetizacao` (campo `dados` = JSON com as 32 chaves). Uma cópia por dia vai em `.../apps/alfabetizacao/versoes/{AAAA-MM-DD}`.
- **Gravações de voz:** este app não grava voz.

---

## 6. Cadastro, família e nuvem

> ⚠️ **6.1 a 6.10 = como era até a v121** (histórico). A v122 está em **6.11**. Riscos 6.10-1, 2, 3, 4, 5, 11, 12, 13 e 14 foram tratados na v122 (ver 6.11-f).

### 6.1 Onde ficam a lista de crianças e a criança atual ✔
- **Chave:** `ev_perfis` (sem prefixo), formato `{"perfis":[{"id":"…","nome":"…","av":"🦊"}],"atual":"<id>"}`.
- **Tipos de id:**
  - `"1"` = **legado** (a Hana, do tempo antes do multiperfil). Chaves **sem prefixo** (`hana_done`).
  - `"p"+Date.now()` (ex.: `p1727100000000`) = toda criança nova. Chaves com prefixo `p1727100000000_hana_done`.
  - `"2"` = legado antigo de uma 2ª leitora (só criado se existir `p2_hana_idx`; ver risco no 6.10).
- **Nome:** até 14 letras, espaços limpos. **Bichinho:** um dos 8 oficiais (🦉 Coruja, 🦊 Raposa, 🐰 Coelho, 🐼 Panda, 🦋 Borboleta, 🐨 Coala, 🐯 Tigre, 🐴 Pônei), lidos de `EscolaPWA.BICHINHOS` (cópia de reserva `BICHINHOS_OFICIAIS`, idêntica). Bichinhos antigos (👧, 🦄, 🐧...) continuam funcionando.
- **Identidade na nuvem:** `NuvemSync.chaveUsuario(nome, bichinho)`, sem acento e minúscula: "Hana" + 🦊 → `hana_1f98a`.

### 6.2 Como o progresso de cada criança é separado ✔
1. Logo ao carregar, o app guarda as funções originais (`_rawGet`, `_rawSet`, `_rawRemove`) e **troca** `Storage.prototype.getItem/setItem/removeItem`: toda chave que começa com `hana_` ganha o prefixo da criança atual (`prefixoDe(id)` = `""` para `"1"`, `id+"_"` para as outras).
2. O `nuvem-sync.js` (carregado antes) troca `setItem/removeItem` de novo em `NuvemSync.iniciar` para "vigiar" as gravações. **Por isso o app recoloca o prefixo POR CIMA** logo depois do `iniciar` (linhas ~6873–6879). Ordem final: app → prefixo → vigia da nuvem → gravação.
3. Para escrever na chave de **outra** criança (ex.: a que vai abrir depois de recarregar), o app usa `_rawSet(prefixoDe(idDestino)+'hana_…')`.
4. **Lista de isolamento:** `CHAVES_LEITORA` (33 chaves, 5.7-A), usada em backup, apagar e nuvem (`CHAVES_NUVEM` = as mesmas menos `hana_noinstall`).
5. Trocar de criança **recarrega a página** (`location.reload()`); o prefixo é calculado uma vez por carga.
6. **Efeito colateral:** como a troca vale para `Storage.prototype` inteiro e `_rawGet` está preso ao `localStorage`, o `sessionStorage.getItem` também lê do `localStorage` (ver 5.7-E).

### 6.3 Telas, com os textos exatos ✔

**a) Primeira abertura (0 crianças)** → abre direto o **cadastro** (`#npOv`), sem botão "← Voltar".

**b) Cadastro** (`#npOv`):
- Título: `🌟 Qual é o seu nome?`
- Campo: placeholder `Digite o seu nome...` (máx. 14)
- `Escolha o seu bichinho:` → 8 botões numa linha
- Depois de escolher: `Você escolheu: 🦊 Raposa`
- Botões: `← Voltar` (só se já existe criança) · `Pronto! ✅` · `☁️ Já tenho cadastro` (só se a nuvem está configurada)
- Avisos (toast):
  - `Escreva o seu nome primeiro 🙂`
  - `Escolha o seu bichinho 🙂`
  - Enter sem bichinho: `Agora escolha o seu bichinho 🙂`
  - Mesmo nome + bichinho que já existe: `🦊 Hana já está neste celular — abrindo!` (abre a existente, não duplica)
  - `Já são 6 crianças — o máximo.`
- Nenhum bichinho vem marcado.

**c) Escolher a criança — "Quem vai estudar hoje?"** (`#homeOv`):
- Título: `🦉 Quem vai estudar hoje?`, botão ⛶
- Aviso: `Cada criança tem o próprio progresso. Toque no seu nome e no seu bichinho para começar.`
- Um cartão por criança: bichinho, nome, `📖 X de 2039 frases` + barra, `🔤 Y de 2927 sílabas` + barra (2927 = 854 + 2073 palavras), e `estudando agora` na atual
- Cartão `➕ Novo usuário` / `cadastrar outra criança` (se menos de 6)
- Botões embaixo: `✏️ Trocar nome ou bichinho` · `🗑️ Apagar este usuário` (só com 2+ crianças) · `☁️ Recuperar da nuvem` (só com a nuvem configurada)
- ⚠️ `✏️ Trocar nome ou bichinho` e `🗑️ Apagar este usuário` agem **sempre na criança "estudando agora"** (`PERF.atual`), **não** no cartão tocado. Tocar no cartão de **outra** criança troca de criança (recarrega); tocar no cartão da criança atual só fecha a tela e abre o hub. Para apagar ou renomear outra criança, é preciso entrar nela primeiro.
- Tocar fora do cartão fecha (se há crianças).

**d) Mudar nome ou bichinho** (`#npOv` em modo edição):
- Título `✏️ Trocar nome ou bichinho`; o nome vem preenchido.
- Se o bichinho é antigo: `O bichinho 👧 mudou: escolha um dos 8 novos 🙂`
- Se já existe outra com o mesmo nome + bichinho: `🦊 Hana já existe neste celular. Escolha outro nome ou bichinho.`
- Ao salvar: `🦊 Agora é Hana (Raposa)`
- Se mudou nome ou bichinho, `nuvemLevarFichaAntiga` junta a ficha antiga da nuvem na nova (a antiga continua lá).
- Também abre tocando no nome no Mapa (`🗺️ Mapa — 👧 <nome>`).

**e) Apagar** (`confirmModal`):
- Título `🗑️ Apagar este usuário?`
- Linhas: `Apagar 🦊 Hana e todo o progresso deste celular?` e, com nuvem configurada, `O que já foi guardado na nuvem continua lá e pode ser recuperado depois (☁️ Recuperar da nuvem).`; sem nuvem, `Isso não tem volta.`
- Botões `Cancelar` / `Apagar` (vermelho)
- Depois: como o botão sempre apaga a criança atual, a página **recarrega** e a **primeira da lista** vira a atual (com 2+ crianças restantes abre "Quem vai estudar hoje?"; com 1, o hub ou "Bem-vindo de volta!"). O aviso `Usuário apagado.` existe no código, mas **pelo botão nunca aparece** (só apareceria se apagasse uma criança que não é a atual).
- Com 1 criança só: o botão não aparece; se chamado: `É preciso ter ao menos uma leitora.`

**f) Recuperar da nuvem** (`#nuvemOv`, tela inteira):
- Topo: 🏠 (voltar), ☁️, título `Recuperar cadastro`
- Mensagens (`#nuvemMsg`):
  - `A nuvem ainda não foi configurada neste aplicativo (veja o guia do Firebase).`
  - `Primeiro digite o código da família (botão 🔑 abaixo).`
  - `📴 Sem internet agora. Conecte no Wi-Fi e toque em "Procurar de novo".`
  - `⏳ Procurando as crianças guardadas na nuvem...`
  - `Ainda não tem nenhuma criança guardada na nuvem com este código da família.`
  - `Toque na criança para trazer o progresso dela para este celular. Nada que já está aqui é apagado.`
- Cartões: bichinho, `Nome · Bichinho`, e `já está neste celular — toque para juntar` / `tem progresso neste app` / `veio de outro app`
- Botões: `🔑 Código da família` · `🔄 Procurar de novo` · `🕘 Versões guardadas`
- Avisos:
  - `☁️ Juntando o progresso de Hana...`
  - `✅ 🦊 Progresso de Hana juntado!`
  - `☁️ Buscando o progresso de Hana...`
  - `✅ 🦊 Progresso de Hana recuperado!`
  - `🦊 Hana pronto! (ainda sem leituras neste app)`
  - `✅ 🦊 Hana atualizado! Abrindo...` (a criança já está no celular, mas não é a atual: junta e troca para ela)
  - `🦊 Hana: nada novo na nuvem`
  - `❌ <mensagem do erro>` (ou `❌ Não deu certo`; na lista: `❌ Não foi possível falar com a nuvem.`)
- O 🏠 do topo (`fecharNuvemTela`): com 0 crianças abre o cadastro; com 2+ abre "Quem vai estudar hoje?"; com 1 só fecha a tela.

**g) Versões guardadas** (mesma tela):
- `⏳ Procurando as versões guardadas de Hana...`
- `🕘 Versões de 🦊 Hana (uma por dia). Tocar numa versão JUNTA ela com o progresso atual — nada é apagado.`
- Cartões `🗓️ DD/MM/AAAA` · `📖 N frases · 🔤 M sílabas`
- Confirmação: `🕘 Juntar esta versão?` / `Juntar a versão de DD/MM/AAAA com o progresso atual de Hana?` / `Nada é apagado: só volta o que estiver faltando.` / `Cancelar` · `Juntar`
- Resultado: `✅ Versão de DD/MM juntada!` ou `Não encontrei essa versão`
- Outras mensagens: `Primeiro escolha ou recupere uma criança.` · `A nuvem ainda não está pronta (configuração ou código da família).` · `📴 Sem internet agora.` · `Ainda não tem versões guardadas de Hana (a primeira aparece depois do primeiro envio).`
- As versões mostradas são **só da criança atual** (`perfilAtual()`).

**h) Pop-up do código da família** (`#codOv`, segue fonte e caixa alta):
- Título `🔑 Código da família`
- Texto: `É o mesmo código em todos os aplicativos e em todos os celulares da família.` / `Pelo menos 6 letras ou números, sem espaço.`
- Campo: placeholder `ex.: saopedro2026`, máx. 40
- Botões `Cancelar` · `🔑 Guardar código`
- Erro: `O código precisa ter pelo menos 6 letras ou números 🙂`
- Depois: `🔑 Código guardado!`
- Se o código já está escrito no `nuvem-config.js`: aviso `🔑 Código da família` / `O código da família já está escrito no arquivo nuvem-config.js.` / `Para trocar, edite aquele arquivo.` / `Entendi`
- Sem nuvem configurada, os botões do código mostram só `☁️ A nuvem ainda não foi configurada`.
- **O código é normalizado:** o texto diz "sem espaço", mas o app aceita espaço, acento e maiúscula. O pop-up confere 6+ caracteres depois de limpar, e o `nuvem-sync.js` (`normalizaFamilia`) guarda a forma limpa: "São Pedro 2026" vira `sao-pedro-2026`. **Espaço vira hífen**, então "sao pedro 2026" (`sao-pedro-2026`) e "saopedro2026" são **famílias diferentes** (ligado ao risco 6.10-3); o hífen conta nos 6 caracteres mínimos. Importa para padronizar os 7 apps.
- **Não confere se o código existe na nuvem** (qualquer código com 6+ letras é aceito).

**i) Depois de cadastrar uma criança nova** (recarrega):
- `👨‍👩‍👧‍👦 Cadastrar família?`
- `Quer cadastrar agora os nomes da família e dos amigos de Hana?`
- `Isso deixa as frases mais especiais pra ela(e). Dá pra fazer depois também, em ⚙️ Configurações.`
- Botões `Depois` / `Cadastrar agora` (abre `#famOv` "👨‍👩‍👧‍👦 Nomes da família", botão `💾 Salvar` → `💾 Nomes salvos!`)
- Ao mesmo tempo, se a nuvem está pronta, procura o mesmo nome + bichinho na nuvem (`nuvemTentarRecuperarNovo`). Se acha: `☁️ 🦊 Achei o progresso de Hana na nuvem!` e recarrega.

**j) Configurações ligadas ao cadastro** (`#cfgOv`, título `⚙️ Configurações`):
- `👯 Trocar leitora` (abre "Quem vai estudar hoje?")
- Seção `☁️ Nuvem (guarda o progresso na internet)`:
  - `☁️ Situação` com `🔄 Enviar agora`
  - `🔑 Código da família` (`Em uso: sao•••`, `Ainda não digitado`, ou `(vem do arquivo)`) com `Digitar ▶`
  - `🔄 Recuperar da nuvem`
- Seção `💾 Backup (todas as leitoras)`: `⬆️ Exportar backup` · `⬇️ Importar backup`

### 6.4 O que acontece ao abrir ✔ (função `_telaDeAberturaPosFam`)
| Situação | O que abre |
|---|---|
| 0 crianças | cadastro (`abrirNovoPerfil`) |
| 1 criança | hub "O que você quer fazer?". Se a última página era Monta, Sílaba Perdida ou Treinar: `👋 Bem-vindo de volta!` / `Você estava em Monta a Frase.` / `🏠 Menu inicial` · `▶ Continuar de onde parei` |
| 2+ crianças | "Quem vai estudar hoje?". Se acabou de trocar de criança (`hana_abrirhub`), vai direto ao hub |
| criança acabou de ser cadastrada | primeiro o pop-up "Cadastrar família?". "Cadastrar agora" → nomes → hub. "Depois" → segue a tabela acima (com 2+ crianças, mostra "Quem vai estudar hoje?" de novo) |

### 6.5 Onde ficam os botões ✔
- **Trocar de criança:**
  - tocar no **chip** (bichinho + nome, embaixo da 🦉) em qualquer página (Ler, Monta, Sílaba Perdida, Treinar) abre "Quem vai estudar hoje?";
  - também ⚙️ › `👯 Trocar leitora`.
- **⚙️:** na barra de cima do Ler, do Monta, da Sílaba Perdida e do Treinar. **Não aparece** no hub, em "Quem vai estudar hoje?", no cadastro nem na tela da nuvem.
- **Bolinha da nuvem** (`.nuvemPonto`): no ⚙️ de todas as barras de cima e na linha `☁️ Situação` das Configurações.
  - verde = tudo guardado; também verde **sem internet quando não há nada na fila**;
  - laranja = enviando, com fila (inclusive sem internet com fila) ou "⏳ Preparando..." logo ao abrir;
  - vermelho = erro ou falta o código da família;
  - nuvem não configurada = a bolinha **não aparece** (CSS `display:none` sem a classe `on`).

### 6.6 Regras de apagar ✔
- **Não dá para apagar a última criança.**
- **O que apaga do celular:** as 33 chaves de `CHAVES_LEITORA` daquela criança (com o prefixo dela) e o item dela em `ev_perfis`. Se era a atual, a primeira da lista vira a atual e a página recarrega.
- **O que NÃO apaga:** a ficha da criança na nuvem e as chaves de passagem (`hana_abrirhub`, `hana_pedefam`, `hana_nuvemnovo`, se sobrarem). A ficha volta pelo `☁️ Recuperar da nuvem`, ou sozinha ao cadastrar de novo o mesmo nome + bichinho **com internet e com o código da família** (`nuvemTentarRecuperarNovo`). ⚠️ Mesmo o `☁️ Recuperar da nuvem` só é seguro se o download **der certo**: se falhar (erro na nuvem, ou Wi-Fi conectado mas sem internet), o app cria a criança vazia do mesmo jeito e o próximo envio grava por cima da ficha (risco 6.10-14). Confira se apareceu `✅ … Progresso de … recuperado!` antes de usar o app. ⚠️ Se a criança for **cadastrada de novo** com o mesmo nome + bichinho num momento em que a recuperação automática não roda (sem internet, sem código da família ou com erro na nuvem), o próximo envio **grava por cima da ficha da nuvem** com o progresso vazio (risco 6.10-11).
- **O que se perde de vez:**
  - progresso que **ainda não subiu** para a nuvem: o `nuvem-sync.js` tira da fila quem foi apagado ("leitor apagado: nada a enviar"). Sem internet, ou nos ~1,5 s antes do envio, isso se perde;
  - `hana_noinstall`, que nunca vai para a nuvem (sem importância).

### 6.7 Ligação com o `nuvem-sync.js` (v3) ✔
- `APP_NUVEM = 'alfabetizacao'`.
- `NuvemSync.iniciar({ app, usuarios, idDaChave, exportar, mesclar })`:
  - `usuarios()` → `PERF.perfis` como `{id, nome, av}`;
  - `idDaChave(k)` = `nuvemIdDaChave`: descobre de qual criança é uma chave pelo prefixo e só aceita chaves de `CHAVES_NUVEM`;
  - `exportar(id)` = `nuvemExportar`: lê as 32 chaves daquela criança com `_rawGet(prefixo+chave)`;
  - `mesclar(id, dados, restaurando)` = `nuvemMesclar`, regra **campo por campo** na tabela 5.7-A:
    - `hana_done` = OU;
    - listas = união;
    - `hana_help` = maior por frase;
    - diário = união por dia;
    - contadores = maior;
    - datas = a mais nova;
    - família = preenche o vazio;
    - preferências e "onde parou" = o celular manda, exceto numa recuperação ou se a criança não tem nada lido no celular;
    - depois, se for a criança aberta, `resincronizarDoDisco` relê tudo para a memória.
- `nuvemTentarRecuperarNovo(id, nome, av)`: depois de cadastrar, procura na nuvem o mesmo nome + bichinho e traz (restaurando).
- `nuvemLevarFichaAntiga(id, nomeAntigo, avAntigo)`: ao trocar nome ou bichinho **com internet e com código**, junta a ficha antiga na nova. **Sem internet** (ou sem código), só marca a criança como pendente: a ficha **nova** sobe depois, mas a **antiga nunca é juntada** mais tarde. Se outro celular continua usando o nome antigo, as duas fichas se separam para sempre.
- **Quando a junção (`mesclar`) acontece de verdade** (no `nuvem-sync.js`):
  - em `recuperar` (Recuperar da nuvem, recuperação automática, trocar nome/bichinho) e em `juntarVersao` (Versões guardadas): sempre junta;
  - no **envio** (`enviarComSeguranca`) e na **checagem** (`checarNuvem`): **só se o último a gravar a ficha foi OUTRO celular** (campo `dispositivo` da ficha diferente do `nuvem_dispositivo` deste celular). **Se o último a gravar foi este mesmo celular, o envio grava por cima, sem juntar.** Isso é a raiz dos riscos 6.10-5 e 6.10-11.
- **Quando envia:** 1,5 s depois de cada gravação de uma chave da criança; 2,5 s depois de abrir; ao voltar para o app; quando a internet volta; ao sair do app (tela escondida) se houver fila (envia na hora); e de 60 em 60 s **só se houver fila** ; depois de um erro, o `nuvem-sync.js` também agenda sozinho uma nova tentativa em 60 s, mesmo sem fila. Cada envio guarda também a cópia do dia em `versoes` (sobrescreve a do mesmo dia).
- **Quando confere outro celular (`checarNuvem`):** só dentro de um envio e só se já passaram 5 minutos desde a última checagem. É **forçada** (sem esperar os 5 minutos) ao abrir o app, quando a internet volta, em `🔄 Enviar agora` e ao guardar o código da família. Ao voltar para o app, só confere se já passaram 5 minutos. Com o app aberto e parado, sem fila, **não confere nada**.
- O backup importado marca todas as crianças como pendentes (sobem na próxima vez).

### 6.8 Passos próprios do cadastro deste app ✔
- **Nomes da família e amigos** (`#famOv`), por criança (`hana_parentes`): pai, mãe, 4 avós (1 campo cada); irmãs, irmãos, tias, tios, primas, primos, amigos, amigas (vários nomes por campo, separados por `/` ou `;`).
- **Não há** turma, idade nem ano neste app.

### 6.9 Pop-ups do navegador ✔
- **Nenhum** `alert()`, `confirm()` nem `prompt()` no `index.html` (procurados; só aparecem em comentários). O teste `teste_cadastro.py` falha se surgir uma caixinha nativa.
- O `deferredPrompt.prompt()` é o pedido de instalação do próprio Chrome, só no banner de reserva.

### 6.10 Riscos e defeitos conhecidos nesta parte
| # | Risco | Gravidade | Certeza |
|---|---|---|---|
| 1 | **Criança "fantasma" Hana 👧:** num celular novo, se o app for fechado (ou recarregado) **antes** do primeiro cadastro, a próxima abertura cria sozinha uma criança "Hana 👧" (id `"1"`) e pula o cadastro. Causa: com 0 crianças o app já grava `hana_idx` sem prefixo; ao reabrir, `carregarPerfis` acha `hana_idx` e entende que é a Hana antiga. | 🟠 importante para o novo cadastro | ✔ reproduzido em 06/10/2026 (`trabalho/scripts/fantasma.py`) |
| 2 | **Apagar uma criança com envio pendente** perde o que não subiu (ver 6.6). | 🔴 | ✔ lido no `nuvem-sync.js` (linha ~253) |
| 3 | **Código digitado errado** cria uma "família nova" vazia sem aviso, e as crianças sobem para lá. | 🔴 | ✔ lido (não confere se o código existe) |
| 4 | **Trocar o código** manda as próximas gravações para a outra família (um só código por celular, `nuvem_familia`). | 🔴 | ✔ lido |
| 5 | **Importar backup SUBSTITUI tudo, no celular E NA NUVEM.** `aplicarBackup` apaga as chaves das crianças atuais, grava as do arquivo e marca todas como pendentes. No celular que fez o último envio (o caso normal, com 1 celular), o envio **não junta** com a nuvem (6.7) e **grava o backup velho por cima da ficha da nuvem**, inclusive a cópia de **hoje** em `versoes`. Só as versões de **dias anteriores** (🕘) continuam lá. Medido por um conferente: nuvem com 10 frases lidas → depois de importar um backup mais antigo → 0 no celular e 0 na nuvem. | 🔴 | ✔ lido + reproduzido pelo agente conferente (Firebase de mentira) |
| 6 | Trocar nome ou bichinho deixa a ficha antiga aparecendo em "Recuperar cadastro" (duas "Hana"). **Sem internet, a ficha antiga nunca é juntada** na nova (6.7); se outro celular segue com o nome antigo, as fichas se separam. | 🟠 | ✔ lido |
| 7 | **Palavras diferentes para a mesma coisa:** "usuário" (`➕ Novo usuário`, `🗑️ Apagar este usuário`), "leitora" (`👯 Trocar leitora`, `É preciso ter ao menos uma leitora.`, `Backup (todas as leitoras)`), "criança" (`Já são 6 crianças`), "leitor(es)" na situação da nuvem. | 🟡 | ✔ |
| 7b | **Diferenças em relação ao `PADRAO_CADASTRO_NOME_BICHINHO.md`** (o padrão dos 7 apps): ver a tabela logo abaixo. | 🟠 | ✔ comparado com o documento de referência |
| 8 | "Leitora 2" muito antiga: o app detecta `p2_hana_idx` e cria a criança `"2"`, mas ela lê as chaves com o prefixo `2_` (não `p2_`). Se algum celular ainda tiver dados `p2_hana_*`, eles não apareceriam. Não sei se algum celular tem isso. | 🟡 | ✔ lido; impacto real não sei |
| 9 | Teclado: o campo de nome usa `interactive-widget=resizes-content` e rola para ficar visível. Os testes passam em 12 tamanhos (inclusive 740×170, com teclado). O Pedro citou este app como **referência de teclado em paisagem** 💭. | ok | ✔ testes; celular real só o Pedro |
| 10 | Bichinho antigo (👧 da Hana legada) gera uma ficha na nuvem diferente da dos outros apps até ser trocado por um dos 8. | 🟠 | ✔ lido |
| 11 | **Apagar e cadastrar de novo o mesmo nome + bichinho pode apagar a ficha da nuvem.** Se a recuperação automática não roda (sem internet, sem código ou com erro na nuvem: `nuvemTentarRecuperarNovo` sai sem fazer nada), o aviso `hana_nuvemnovo` já foi apagado e não tenta de novo. No próximo envio, como o último a gravar foi este celular, não há junção e a ficha da nuvem é **sobrescrita com o progresso vazio**. Medido por um conferente: nuvem com 6 frases → 0. ⚠️ Por isso a dica 2 do `GUIA_FIREBASE_PASSO_A_PASSO.md` ("cadastre com o mesmo nome e o mesmo bichinho… o progresso volta sozinho") **só é segura com internet e com o código da família já digitado**. | 🔴 | ✔ lido + reproduzido pelo agente conferente (Firebase de mentira, com erro simulado) |
| 12 | `hana_abrirhub` fica gravada com 1 criança e faz a 1ª abertura com 2 crianças pular "Quem vai estudar hoje?" (5.7-B). | 🟡 | ✔ lido |
| 13 | No pop-up "Nomes da família" (`#famOv`), **tocar fora** fecha sem ir para o hub (linha ~6913). No fluxo logo depois do cadastro, a criança fica sem o menu (só o ✕ e o 💾 levam ao hub). | 🟡 | ✔ lido |
| 14 | **"☁️ Recuperar da nuvem" que falha pode apagar a ficha da nuvem.** Depois de apagar a criança neste celular, ao tocar nela na lista da nuvem o app **cria a criança vazia antes** de baixar (`nuvemRecuperarLeitor`). Se o download falhar (erro na nuvem, ou Wi-Fi sem internet — a checagem `navigator.onLine` não pega esse caso), o `.catch` só mostra `❌ …` e recarrega, com a criança vazia criada. No próximo envio, como o último a gravar foi este celular, não há junção e a ficha é **sobrescrita com o vazio**. Medido pelo revisor-chefe: nuvem com 10 frases → 0. Hoje, se aparecer `❌` ao recuperar, apague logo essa criança vazia e tente de novo com internet boa. Atenção: a gravação por cima **não depende de alguém usar o app** — se a internet voltar, ela acontece sozinha em poucos segundos. Se a ficha já foi zerada, as **versões de dias anteriores** (🕘 Versões guardadas) continuam lá; só a cópia de hoje se perde. | 🟠 (perda de dados) | ✔ lido + reproduzido pelo revisor-chefe (Firebase de mentira) |

**Tabela 7b — este app × `PADRAO_CADASTRO_NOME_BICHINHO.md`:**
| Ponto | O padrão diz | Este app faz |
|---|---|---|
| Abrir com **1** criança | "entra direto no progresso dela" | abre o hub "O que você quer fazer?", ou o pop-up `👋 Bem-vindo de volta!` se estava fora do Ler |
| Depois de cadastrar | "vai direto para a tela inicial do app" | pop-up `👨‍👩‍👧‍👦 Cadastrar família?` (exclusivo deste app: nomes da família nas frases) |
| Aviso da recuperação automática | `☁️ Achei o progresso de Renata na nuvem!` | `☁️ 🦊 Achei o progresso de Hana na nuvem!` (com o bichinho) |
| Recuperar nas ⚙️ | `☁️ Recuperar da nuvem` | ícone 🔄 com o texto `Recuperar da nuvem` |
| Trocar de criança nas ⚙️ | (o padrão usa "Quem vai estudar hoje?" pelo chip) | linha extra `👯 Trocar leitora` |
| Backup | — | `💾 Backup (todas as leitoras)`, importar **substitui** (risco 5) |

### 6.11 Como está a partir da v122 ✔ (testado com o Firebase de mentira)
**a) Arquivos e ordem de ligação** (fim do script principal): `EscolaFamilia.iniciar({...ADAPTADOR_CRIANCAS})` → `NuvemSync.iniciar({usuarios: EscolaFamilia.paraNuvem(...)})` → prefixo por criança recolocado **por cima** da vigia → `montarChip` / `montarPonto` / `montarSecaoConfig`. Não mudar essa ordem.

**b) Adaptador deste app (`ADAPTADOR_CRIANCAS`)**: `listar`, `atual`, `criar(nome, av, origem)` (não troca a criança aberta; `origem==='nova'` grava `hana_pedefam`), `mudar`, `exportar` (as 33 chaves, sem prefixo; erro se a criança não existe), `importar` (= `nuvemMesclar`, junta), `tirar` (1º sai da lista, depois `_rawRemove` das 33 + 3 chaves de passagem; se era a atual, `SEM_CRIANCA=true` e recarrega), `completoNaNuvem` (sempre true), `entrar` (= `trocarPerfil`: a mesma criança → `passoDoApp`; outra → grava `hana_abrirhub` e recarrega), `resumo`, `resumoDados`, `chavesDaCrianca`.

**c) Ao abrir** (fim do script): 1) `hana_pedefam` → pergunta dos parentes (só se a criança não tem nenhum nome de parente); 2) `hana_abrirhub` (acabou de escolher) → `passoDoApp()` ("👋 Bem-vindo de volta!" se estava em Monta/Sílaba/Treinar, senão o menu); 3) senão `EscolaFamilia.abrirInicio()` → T1 (sem família e com nuvem) ou T4 (sempre, D2).

**d) Chaves novas** (do aparelho, sem prefixo): `escola_familia` (`{v:1, familias:[{c,desde,conferida,origem,problema?}], criancas:{id:código}, atual, ultimoNuvemFamilia, primeiraAberturaEm, liberouSegundaFamilia, mudancasPendentes:[…], recusas:{}}`) e `escola_lixeira_alfabetizacao` (crianças tiradas com cópia). `nuvem_familia` continua sendo gravado (= família atual) para o app antigo funcionar se for preciso voltar. Nenhuma chave antiga é apagada ou renomeada na migração (teste 7-A compara byte a byte com a v121).

**e) Nuvem:** `familias/{código}/usuarios/{nome_bichinho}` ganhou o campo opcional `movidoPara` (só via `PATCH` com `currentDocument.exists=true`). Regras do Firebase: **sem mudança**.

**f) Riscos antigos → v122:** 6.10-1 (fantasma) corrigido; 6.10-2 (apagar com fila) → só tira com `garantirGuardado` ou com cópia na lixeira; 6.10-3 (código errado) → T2 confere; 6.10-4 (trocar código) → código novo acrescenta família, não move ninguém; 6.10-5 (backup) → junta + envio junta; 6.10-6 (ficha antiga) → `movidoPara`, junção automática ao trazer, pergunta nos outros apps; 6.10-7 (palavras) → tabela 3-A; 6.10-11 e 6.10-14 → envio junta quando o celular não conhece a ficha, e trazer que falha não deixa criança vazia; 6.10-12 → `hana_abrirhub` sempre apagada ao abrir; 6.10-13 → tocar fora leva ao menu. **Continuam:** 6.10-8 (`p2_` × `2_`, muito antigo) e 6.10-10 (bichinho antigo = ficha diferente até a criança trocar).

---

## 7. Regras que não podem ser quebradas
1. **Não alterar** `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js` nem `escola-familia.js` (iguais nos 7 apps). A v122 criou o `nuvem-sync.js` v4 e o `escola-familia.js` v1 (cópias mestras em `compartilhados/`); a v122b subiu o `escola-familia.js` para **1.1** (só desenho) e a v123 para **1.2** (⚙️ na T4, C2) e o `nuvem-sync.js` para **4.1** (C1); são estas as cópias mestras que vão para os outros 6 apps; qualquer mudança neles sobe a versão e vale para os 7 apps. O `nuvem-config.js` continua intocado. O `nuvem-config.js` do Pedro vai no zip **byte a byte igual** (md5 `1d5f060a5ae8339921d3d58498807971`).
2. **Nunca inserir frase no meio do `DATA`**, só no fim. Não mudar a ordem do `DATA`.
3. **Não perder progresso:** toda chave nova de progresso começa com `hana_` e entra em `CHAVES_LEITORA`. Se for para a nuvem, também entra na regra de junção.
4. **Não mexer na ordem** "prefixo por cima da vigia da nuvem" sem testar com duas crianças. Lembrar que, com o prefixo, `sessionStorage.getItem` lê do `localStorage` (5.7-E).
5. **Ordem de leitura calculada** (`construirTrilha`); não voltar a ordenar à mão.
6. **Áudio:** Ler só fala se a criança ligar; Monta/Sílaba Perdida falam sozinhos só com a página aberta.
7. **Pop-ups no estilo do app** (`confirmModal` e, desde a v122, as telas do `escola-familia.js`), com fonte e caixa alta das Configurações. Nunca `alert`/`confirm`/`prompt`.
8. **Tamanho da letra pela frase-padrão** (`fitCaixa` + `REF_*`). Nunca "encher o quadro".
9. **Edições cirúrgicas**, sem reescrever o que funciona. Coisa grande, só com autorização do Pedro.
10. **A cada entrega:** subir o cache do `sw.js`, rodar todos os testes, conferir o zip extraído.
11. **Todo conteúdo novo** (palavra, frase) passa pelo silabificador antes de entrar (capítulo 9: o silabificador não está nesta conversa).
12. Nada de Firebase novo: **sem mudar regras nem estrutura no Firebase** 💭 (pedido do Pedro).

---

## 8. Aprendizados difíceis
| Problema | Causa de verdade | Como foi resolvido |
|---|---|---|
| Ler falava sozinho com áudio desligado (v116) | função antiga (`openMonta`/`openSilaba`) chamada "por trás" montava uma página escondida que falava | tirar a chamada + `paginaAberta()` (v117) |
| Começo da trilha com palavras difíceis | blocos com dificuldade escolhida à mão | ordem calculada pelas sílabas (v117) |
| Prefixo por criança sumia com a nuvem | dois códigos trocando a mesma função do navegador; o último apaga o primeiro | recolocar o prefixo por cima depois do `iniciar` (v120) |
| "A TIA" gigante | tamanho = "encher o quadro" | frase-padrão (v121) |
| Botão "Próxima sílaba" invisível | `style="display:none"` no HTML vence o CSS | tirar o estilo do HTML |
| Botões afastados ao pôr um 4º item | `justify-content:space-between` reparte o espaço | agrupar num sub-container |
| Toque rápido contado como erro | contador avançava no fim da animação | avançar no toque |
| Nome da família de uma filha no perfil da outra | dados de família sem separação por criança | `hana_parentes` por criança; outras crianças nunca herdam `PARENTES_PADRAO` |
| Voz lendo errado SSA, NHA, BRA | voz do celular | `semAudio:true` |
| Cor ilegível em tema escuro | cor fixa no CSS | sempre `var(--…)` |
| Regressão ao restaurar um checkpoint velho 💭 | voltar um arquivo antigo desfaz mudanças posteriores | rodar todos os testes depois |
| Teste do navegador travando (JSDOM) | `setInterval` do `escola-pwa.js` | o resumo dos testes encerra o processo |
| Service worker não registrava nos testes | `127.0.0.1` não conta como seguro | usar `localhost` |
| Site de teste sem faixa roxa e sem a trava do código (v122) | o app só reconhecia endereço terminado em `-teste.`; o Pedro escolheu `escolasaopedrotestes` | reconhecer qualquer endereço com "teste" (v122b) e conferir o endereço que o Pedro **de fato** usou |
| Caixa do código grudada no topo com o teclado (v122) | regra compacta com `align-items:flex-start` e cartão guardando espaço para erro/resultados vazios | centralizar e esconder o que está vazio; testar com o teclado abrindo **depois** do toque e medir a sobra em cima × embaixo |
| Grade que não usa a largura ("Achei" com 2 colunas num cartão de 666 px) | `repeat(auto-fit, minmax(170px, 220px))`: o navegador conta as colunas pelo **máximo** (220) | trilhas de largura fixa + `justify-content:center` |
| Tela cheia do app instalado (v122b) | para evitar o aviso do Chrome, o app instalado deixou de pedir a tela cheia; aí o Android mostrou as barras (status e navegação), e o aviso continuou aparecendo | o Pedro prefere **tela cheia de verdade** (sem barras); o aviso do Chrome não tem como sumir — **não mexer mais nisso** |
| "Desinstalei e limpei o cache e não voltou o cadastro" | o app instalado e o site no Chrome guardam os dados no mesmo lugar; desinstalar/limpar cache não apaga | é o certo (protege os dados); começar do zero = Configurações do site › Limpar e redefinir |
| Teste que travava esperando para sempre (07/10) | `p.evaluate("… .then(…)")` devolve uma Promise, e o Playwright espera por ela | embrulhar em `(()=>{ …; })()` quando a promessa não deve ser esperada |
| Máquina de trabalho reciclada no meio do trabalho (07/10) | o ambiente da conversa é apagado depois de um tempo parado | o pacote publicado pode ser baixado do próprio site; entregar sempre o zip completo (testes + documentos) a cada rodada |

---

## 9. Testes automáticos

### 9.1 O que existe ✔ (pasta `testes/` do zip)
**A) 89 testes rápidos** (Node.js + JSDOM, `testes/testes/`), em 12 arquivos:
| Arquivo | O que testa |
|---|---|
| `teste_01_estrutura_dados.js` | integridade do `DATA`, sílabas, cobertura dos `LEVELS` |
| `teste_02_sequenciamento_silabas.js` | "Próxima sílaba" nunca morre no fim |
| `teste_03_popups_e_botao.js` | pop-ups seguem fonte/caixa; botão "Próxima" |
| `teste_04_audio_automatico.js` | fala automática no Monta/Sílaba |
| `teste_05_frases_concluidas.js` | marca de "já respondida" |
| `teste_06_regressao_geral.js` | ids repetidos, chaves repetidas, fluxos |
| `teste_07_backup_por_leitora.js` | backup por criança, sem misturar |
| `teste_08_marcar_estudada_e_fluxos.js` | "Marcar estudada" e fluxo completo |
| `teste_09_telas_auxiliares_e_pacote.js` | Mapa, Calendário, Config, Quiz abrem |
| `teste_10_consistencia_pacote.js` | manifest, `sw.js`, ícones **da cópia que está em `testes/`** (não do `pacote-netlify/`; os comentários dele citam pastas antigas `entrega_testes` e `../../pacote`, que não existem mais) |
| `teste_11_trilha_e_audio_ler.js` | Ler sem áudio; trilha simples → R |
| `teste_12_quiz_imagens_tela.js` | quiz com fonte/caixa; imagens; tela acesa |

**B) 221 testes num Chrome de verdade** (Python + Playwright, `testes/testes_navegador/`), com **Firebase de mentira** (`fakefb.py`, nunca fala com o Firebase real):
| Arquivo | Testes | O que testa |
|---|---|---|
| `teste_cadastro.py` | 55 | cadastro Nome + Bichinho em 12 tamanhos de tela, com teclado, padronização, sem caixinha nativa |
| `teste_nuvem.py` | 75 | sem configuração; envio e fila offline; 2 crianças sem misturar; recuperação; recuperação automática; outro celular gravando no meio; regra de junção; erros em português; versões; trocar nome/bichinho |
| `teste_pwa.py` | 33 | tela acesa, convite de instalar, tela cheia, funciona sem internet (service worker real) |
| `teste_fonte.py` | 58 | tamanho da letra igual em todas as frases (v121) |

**Total da v121: 310 testes.**

**v122** ✔ — os testes de cadastro e de nuvem foram **adaptados** às telas novas (o que conferiam continua conferido; mudaram os textos/ids que o plano mandou mudar), e entrou o `teste_familia.py` (parte 9 do plano). Também: o `_harness.js` abre o app já com uma criança (sem criança, o app não grava mais nada), o `fakefb.py` aceita `currentDocument.exists=true`, simula "sem internet" e erro ao baixar, e usa `RLock` (dois pedidos ao mesmo tempo travavam o teste). A pasta `testes/versao_anterior_v121/` tem a v121, usada nos testes de migração e de voltar ao zip anterior.

| Suíte | v122 |
|---|---|
| rápidos (Node + JSDOM, `testes/testes/`) | 89 (os mesmos da v121; o `teste_07` agora confere que o backup JUNTA) |
| `teste_cadastro.py` | 72 (adaptado às telas novas; 12 tamanhos + 5 do pop-up do código com teclado) |
| `teste_nuvem.py` | 81 (adaptado; + `movidoPara` na mudança de nome) |
| `teste_pwa.py` | 34 (+ o app abre "Quem vai estudar hoje?" sem internet) |
| `teste_fonte.py` | 58 (sem mudança; nesta máquina deu 57/58, igual à v121 rodada aqui — ver 9.5) |
| `teste_familia.py` | 128 (novo: parte 9 do plano — textos 3-A, código, criar código, 2 famílias, tirar/lixeira/última, Hana fantasma, mudar em outro app, migração A–H byte a byte contra a v121, voltar à v121, backup junta, bolinha e chip, botão voltar, riscos 6.10-11/14, caixinhas nativas) |
| `teste_revisao.py` | 59 (novo: um teste para cada achado da revisão independente — teclado abrindo depois do toque, barra de cima sem encolher os botões, ✏️🗑️ sem cobrir o bichinho, ficha antiga escondida, lixeira juntada sozinha, fila mantida se a lista der erro, backup da Hana "1") |
| `teste_desenho.py` | **127** (v122b, novo: teclado com o cartão no meio e sem sobra; "Achei" com 1, 3 e 6 crianças e nomes compridos em 6 tamanhos; Configurações largas, 2 colunas e botões sem encostar; T4 no meio e rodapé inteiro; T8 numa linha; faixa do site de teste; tela cheia — na v123, igual à v122) |
| `teste_v123.py` | **41** (v123, novo: ⚙️ na T4 em 4 tamanhos, opções que abrem tela do módulo, voltar do Android, Cantinho dos pais, sem criança; C1 com a resposta da nuvem segurada até depois de tirar a criança — recuperar e checar; C2 bolinha 🟡 com a lixeira; trilha idêntica à da v122) |
| **Total** | **691** (v123; na v122b eram 651) |

(O número mostrado pelo Playwright conta verificações; alguns `r.t` ficam dentro de laços.) Para rodar os novos: `python3 teste_familia.py` (~10 min), `python3 teste_revisao.py` (~8 min) e `python3 teste_desenho.py` (~12 min), dentro de `testes_navegador/`.

### 9.2 Como rodar ✔
Dentro da pasta `testes/` do zip:
1. `npm install` (instala o `jsdom`; a pasta `node_modules` **não vai no zip** para não pesar).
2. `node testes/rodar_testes.js` → `RESULTADO GERAL: 89/89 testes passaram`.
3. `cd testes_navegador` e depois:
   - `python3 teste_cadastro.py` → `CADASTRO: 72/72` (v121: 55)
   - `python3 teste_nuvem.py` → `NUVEM: 81/81` (v121: 75)
   - `python3 teste_pwa.py` → `PWA: 34/34` (v121: 33)
   - `python3 teste_fonte.py` → `FONTE: 58/58`
   - (v122) `python3 teste_familia.py` → `FAMÍLIA: 130/130` e `python3 teste_revisao.py` → `REVISAO: 59/59`
   - (v122b) `python3 teste_desenho.py` → `DESENHO: 127/127`
   - (v123) `python3 teste_v123.py` → `V123: 41/41`
- Precisa: Node.js, Python 3, `pip install playwright` e um Chromium (`playwright install chromium`, ou o que já vier no ambiente). Na última rodada: Node v22.22.2, jsdom 30.1.x (30.1.0 e 30.1.2 deram o mesmo resultado), Playwright 1.56.0. (O `package.json` antigo pedia jsdom ^24; nesta passagem foi acertado para ^30.1.0. Desde a v122 há um `package-lock.json` em `testes/`.)
- A pasta `testes/` tem **uma cópia** do app (`index.html`, `sw.js`, `manifest`, ícones, `nuvem-sync.js`, `escola-pwa.js`), idêntica ao `pacote-netlify/`. O `testes/nuvem-config.js` é **só de teste**, com chaves falsas. **Nunca publicar esse** (e nunca zipar a pasta `testes/` para o Netlify). Ele precisa ficar ali: o `teste_pwa.py` serve a pasta `testes/` e o service worker guarda esse arquivo (sem ele, 3 testes do PWA falham — conferido nesta passagem).
- ⚠️ **Ao mudar o app:** copie para `testes/` o `index.html`, o **`sw.js`** e o **`manifest.webmanifest`** novos (os testes rápidos e o `teste_10` leem só a cópia de `testes/`; os do navegador também, a não ser que se use `PASTA_PACOTE`). E troque o nome do cache escrito no `teste_pwa.py` (linhas 102 e 113, hoje `esforco-vence-v123`) pela versão nova. Se copiar só o `index.html`, o `teste_pwa.py` passa testando o `sw.js` velho (falso "passou").
- Para testar outra pasta: `PASTA_PACOTE=/caminho python3 teste_x.py`. Para trocar a porta: `PORTA=8811`.
- ⚠️ **Não rode o `teste_pwa.py` com `PASTA_PACOTE` apontando para `pacote-netlify/`:** o service worker buscaria e guardaria o `nuvem-config.js` **real** (com as chaves do Pedro), porque essa busca não passa pela interceptação dos testes. Rode-o sempre na pasta `testes/`.

### 9.3 O que os testes NÃO cobrem
- Celular de verdade: toque, voz real, teclado real, Wake Lock real, espelhamento na TV.
- **Firebase real** (regras, cota, internet ruim de verdade).
- A **criança fantasma** do risco 6.10-1 (descoberta nesta passagem; não há teste dela).
- Apagar criança com envio pendente sem internet (risco 6.10-2).
- Backup substituindo progresso (só testa que é por criança e sem misturar).
- Conteúdo pedagógico (se as frases e palavras estão certas): depende do silabificador e do Pedro.
- iPhone/Safari.

### 9.4 Testes e scripts PERDIDOS 💭
Não estão nesta conversa e **não foram reescritos** (as versões antigas do app que existem estão em `trabalho/versoes_anteriores/`, ver 9.6):
- `silabador.py` / `silabador.js` (o silabificador, com gabarito de exceções), `gabarito_atual.json`, `simples_v2_final.json`, `lista_v3.json`, `validar_lista_v3.py` (citados no `CONTINUIDADE.md` da v41).
- As suítes antigas `teste_frente1.js` (67), `teste_frentes23.js` (61), `teste_hub_silabas.js` (151) da v41, e as **531 verificações** da v96 (memória).
- O app tem um silabificador **embutido** para nomes (`silabasDe`, `silabarNome`) ✔, mas não é a ferramenta de validação de conteúdo.

### 9.5 Último resultado ✔
**07/10/2026 (v123), rodado de verdade, uma suíte de cada vez:** 89 + cadastro 72 + nuvem 81 + PWA 34 + família 130 + revisão 59 + desenho 127 + v123 41 + fonte 57/58 = **690/691** (a falha da fonte é a antiga desta máquina). Na v123, 1 teste antigo do `teste_nuvem.py` foi **ajustado**: ele juntava dados numa criança que **não estava na lista** ("p3novo"); agora isso é bloqueado de propósito (C1), então o teste põe a criança na lista antes, como o app faz ao trazer ou cadastrar.

**07/10/2026 (v122b), rodado de verdade:** ver `RELATORIO_CHECAGEM_alfabetizacao_v122b.md` (89 + cadastro 72 + nuvem 81 + PWA 34 + família 130 + revisão 59 + desenho 128 + fonte 57/58 = 650/651). ⚠️ O item "Com a nuvem em dia: tira (… as chaves dela somem do celular)" do `teste_familia.py` falhou **1 vez** com a máquina carregada (3 suítes ao mesmo tempo) e passou sozinho: é o 🟡 **C1** já conhecido (uma leitura da nuvem que já estava a caminho regrava as chaves da criança tirada; não perde nada neste app) — a correção está marcada para a v123 (capítulo 11).

**07/10/2026 (v122), rodado de verdade:** 89/89 + cadastro 72/72 + nuvem 81/81 + PWA 34/34 + família 128/128 + revisão 59/59 + fonte 57/58. A 1 falha da fonte (Ler 412×915, tamanho 24: 86% em vez de 90%) acontece IGUAL com a v121 nesta máquina, que não tem as fontes Roboto/Arial; em 06/10 a v121 deu 58/58 noutra máquina. Não tem relação com o cadastro.

(v121:)
**06/10/2026**, rodado de verdade nesta passagem, sobre a v121 idêntica ao zip publicado: **89/89 + 55/55 + 75/75 + 33/33 + 58/58 = 310/310 passaram.**

---

### 9.6 Arquivos de trabalho (pasta `trabalho/`) ✔
- `scripts/checar_sintaxe.py`: `node --check` em cada `<script>` embutido.
- `scripts/contar.py`: conta o conteúdo (frases, sílabas, níveis, fontes, temas) com o app aberto.
- `scripts/fantasma.py`: reproduz o defeito da criança "fantasma" (6.10-1).
- `scripts/medir_fonte*.py`: medições do tamanho da letra usadas na v121.
- `versoes_anteriores/index_v118.html`, `index_v119.html`, `index_v120.html`: versões anteriores do app, para comparar ou voltar.
- `versoes_anteriores/index_antiga_ate_v93_referencia_da_ordem.html`: versão antiga **não identificada** (título "Esforço Vence 🦉 — Aprender a Ler"; os comentários citam até a v93, mas ela pode ser posterior, de antes da v117; sem a trilha calculada, sem `fitCaixa` e sem nuvem). O Pedro anexou em 21 e 23/09/2026; 💭 foi a referência da ordem das frases que ele mandou para a v117. Versão exata: não sei.
- Os scripts usam a base dos testes e abrem o `pacote-netlify/` com Firebase de mentira (rodar com `python3 trabalho/scripts/<nome>.py`).

## 10. Como empacotar e publicar
1. Editar só o `index.html` (e, se preciso, o `sw.js`/`manifest`). **Não mexer** nos 3 arquivos compartilhados.
2. Sintaxe: `python3 trabalho/scripts/checar_sintaxe.py pacote-netlify/index.html` → `SINTAXE OK` (roda `node --check` em cada `<script>` embutido) **e** `node --check pacote-netlify/sw.js`.
3. Subir o cache no `sw.js`: `esforco-vence-v123` → **`esforco-vence-v124`** (e o comentário da 1ª linha). **Toda** entrega nova sobe o cache, mesmo uma correção pequena (senão o celular continua com a versão guardada).
4. Copiar para `testes/` o `index.html`, o `sw.js` e o `manifest.webmanifest` novos, trocar o cache escrito no `teste_pwa.py` (linhas 102 e 113) e rodar todos os testes (capítulo 9). Tudo tem que passar.
5. Montar o zip do Netlify **só** com os **9** arquivos do `pacote-netlify/` (na raiz do zip, sem pasta; desde a v122 inclui o `escola-familia.js`). Conferir: `md5sum nuvem-config.js` = `1d5f060a5ae8339921d3d58498807971`.
6. Extrair o zip numa pasta vazia e conferir de novo (arquivos, md5, sintaxe).
7. Publicar: Netlify → site `escolasaopedroalfabetizacao` → arrastar o zip na área de deploy.
8. Antes de publicar algo que mexa em dados: em cada celular, abrir o app, esperar a **bolinha verde** e exportar o backup; guardar o zip anterior para voltar se precisar.
9. ⚠️ **Na v121 (a antiga), nunca IMPORTAR um backup com a nuvem ligada:** lá importar substitui o progresso no celular **e na nuvem** (risco 6.10-5). **Desde a v122, importar JUNTA** (D14), sem apagar nada. O backup exportado serve para guardar e para testes automáticos; para voltar progresso, prefira `☁️ Recuperar da nuvem` e `🕘 Versões guardadas`, **com internet boa**, e confira a mensagem `✅ … recuperado!` / `juntado!` (se aparecer `❌`, ver risco 6.10-14).

---

## 11. Estado atual

> **v123 (07/10/2026, à noite) — VERSÃO FINAL:** aprovada pelo Pedro depois do teste da v122b ("funcionamento perfeito"). Entregue para o **site de verdade** com `INSTRUCOES_PUBLICAR_v123.md` (conferir antes e depois). C1 e C2 **corrigidos**; C3 escrito em destaque nas instruções; C5 não se aplica mais (o site de teste já foi aprovado). **C4 (migração com o backup real):** o Pedro não mandou o backup; a migração foi testada com retratos inventados (33 chaves × 2 crianças, byte a byte) e, no celular dele, a migração v122 → v122b funcionou. Antes de publicar, ele exporta o backup de cada celular e guarda o zip da v121 (instruções, parte 1). **Pendências 🟡:** abertura (≈ 3 s com CPU de celular simulada; diminuir mais exige separar as frases do `index.html`, pedido para depois); 568×320 no site de teste (rodapé da T4 passa um pouco da borda); em pé (360×740), na T4 aberta pelo chip, o título "QUEM VAI ESTUDAR HOJE?" quebra em várias linhas (a barra fica ~20 px mais alta; nada se sobrepõe; o app é usado deitado); ⚙️ da T4 **sem nenhuma criança**: as opções que são da criança (ex.: Cantinho dos pais › Nomes dos parentes) não guardam nada (não há criança) — com crianças, valem para a última criança aberta; não há botão para **descartar** uma cópia da lixeira (só trazer de volta); *(já existia na v122)* na aba do Chrome, depois que o app entra em tela cheia, ele se acha "instalado" e esconde "📲 Instalar o app" das Configurações. **Próximo passo do projeto:** 🌍 Curiosidades, com o `PLANO_CADASTRO_FAMILIA.md` versão 3 (Apêndice A) e as cópias mestras de `compartilhados/`.

> **v122b (07/10/2026, à tarde):** o Pedro publicou a v122 no site de teste (`escolasaopedrotestes.netlify.app`, família `pmrtestes`) e testou em 2 Motorolas: **funcionou** (leitura, sílabas e busca da família passaram de um celular para o outro). A v122b muda **só o desenho** (3.11). Falta: o Pedro publicar a v122b no site de teste e olhar o desenho (`INSTRUCOES_SITE_DE_TESTE_v122b.md`); depois, o zip do site de verdade (**v123**) com C1 a C5 (abaixo).
>
> **v122 (07/10/2026):** zip do **site de teste** pronto e revisado pelas 3 camadas (revisor-chefe: **✅ Pode publicar no site de teste**; ver `RELATORIO_CHECAGEM_alfabetizacao_v122.md` e `documentos/revisao_independente/`). Falta:
> 1. ~~o Pedro testar com 2 celulares e a família `teste-pedro-2026`~~ ✅ feito em 07/10 (com a família `pmrtestes`);
> 2. **antes do zip do site de verdade (v123):** corrigir o 🟡 C1 no `nuvem-sync.js` (leitura da nuvem a caminho regrava chaves de criança tirada — importante para Matemática/Fluência), o C2 (bolinha 🟢 com progresso só na lixeira), testar a migração com o **backup real** do Pedro, subir o cache para `esforco-vence-v123`, colocar em destaque "depois de tirar todas as crianças, nunca volte ao zip antigo" (C3), e passar de novo pelas 3 camadas.
> O texto abaixo é o estado da v121.

**Pronto ✔:** v121 com tudo das seções 3.5 a 3.9; 310 testes passando em 06/10/2026; pacote idêntico ao que o Pedro anexou.

**Pendente (só o Pedro):** 💭
- Confirmar se a v121 está publicada (não consegui abrir o site daqui).
- Teste no celular: tamanho da letra no Ler (frase curta × longa, deitado e em pé), código da família, bolinha verde, tela 2 minutos sem tocar sem bloquear, os 8 bichinhos com o teclado aberto, trocar os bichinhos antigos (👧) pelos novos.

**Defeitos conhecidos (NÃO corrigidos, por regra desta passagem):**
1. 🟠 Criança "fantasma" Hana 👧 no celular novo (6.10-1).
2. 🔴 Apagar criança com envio pendente perde o que não subiu (6.10-2).
3. 🔴 Código errado ou trocado separa ou junta famílias (6.10-3 e 4).
4. 🔴 Importar backup substitui em vez de juntar, **no celular e na nuvem** (6.10-5) — ligado à decisão D14 do plano.
4b. 🔴 Apagar e cadastrar de novo o mesmo nome + bichinho sem internet/código pode sobrescrever a ficha da nuvem (6.10-11).
4c. 🟠 "☁️ Recuperar da nuvem" que falha (erro ou Wi-Fi sem internet) cria a criança vazia e pode sobrescrever a ficha da nuvem (6.10-14).
5. 🟠 Ficha antiga duplicada ao trocar nome/bichinho; sem internet, a antiga nunca é juntada (6.10-6).
6. 🟡 Palavras misturadas: usuário / leitora / criança (6.10-7).
7. 🟡 Legado `p2_` × `2_` (6.10-8).
8. 🟡 Nomes de tema repetidos ("Espaço", "Oceano", "Arco-íris").
9. 🟡 Descrição do manifest diz "854 sílabas" (são 854 palavras simples).
10. 🟡 `hana_abrirhub` fica gravada com 1 criança (6.10-12).
11. 🟡 Tocar fora de "Nomes da família" no fluxo de cadastro deixa sem menu (6.10-13).
12. 🟡 `sessionStorage.getItem` lê do `localStorage` por causa do prefixo (5.7-E).
13. 🟡 Ao abrir, o Chrome mostra **avisos** (não erros) `Failed to execute 'requestFullscreen'... user gesture`: o app e o `escola-pwa.js` tentam a tela cheia sem toque. Inofensivo.
14. 🟡 Diferenças de texto/fluxo em relação ao padrão dos 7 apps (tabela 7b do 6.10).

**Pedidos que ficaram para depois:** 💭
- Consertar e trazer de volta o Modo Surpresa 🎲 (função guardada, sem botão).
- Ideias antigas do `CONTINUIDADE.md`: tela só com as sílabas (BA BE BI BO BU + BÃO) para treinar o som puro; letra maior nos cartões de palavra.

**Ideias futuras:** 💭 crescer o banco de palavras das famílias complexas, sempre pelo silabificador.

**Diferença entre arquivos compartilhados:** nenhuma (md5 iguais aos anexados pelo Pedro).

---

## 12. Plano de desenvolvimento (por prioridade)
1. ✅ (v122/v122b no site de teste; falta o site de verdade, v123) **Padronizar o cadastro da família e das crianças** (código da família + crianças com nome + bichinho, telas e palavras iguais nos 7 apps), seguindo o `PLANO_CADASTRO_FAMILIA.md`:
   - este é o **primeiro app** (nele nascem o `escola-familia.js` v1 e o `nuvem-sync.js` v4) 💭;
   - decisões D1–D13 aprovadas; D14–D16 aguardam o OK do Pedro 💭;
   - aproveitar para resolver os riscos do 6.10 (principalmente os 🔴 2, 3, 4, 5 e 11, que perdem histórico, e o 🟠 1 da criança fantasma);
   - o `mesclar` hoje só roda no envio quando o último a gravar foi outro celular (6.7): qualquer migração, backup ou recadastro que reescreva dados neste celular precisa de junção explícita com a nuvem antes de enviar;
   - a recuperação nova precisa **juntar de propósito** e, se o download falhar, **não pode deixar criada uma criança vazia** que depois sobe para a nuvem (6.10-14);
   - a migração deve **só acrescentar** chaves, nunca apagar; prefixos e ids atuais (`"1"`, `p…`) continuam valendo;
   - testar com o backup real exportado pelo Pedro e num site de teste separado no Netlify antes de publicar.
2. Depois do cadastro publicado e conferido: corrigir os 🟡 restantes (manifest, nomes de tema).
3. Modo Surpresa (se o Pedro quiser).
4. Conteúdo novo (sempre pelo silabificador — recriar ou pedir ao Pedro, já que se perdeu).

---

## 13. Sobre o Pedro e as meninas, e como trabalhar com ele
- **Pedro**, de Mara Rosa (GO). Dono da Escola São Pedro. **Não é programador**: decide a pedagogia, o Claude escreve todo o código. Testa num **Android de verdade**, quase sempre **espelhado na TV**, com as meninas a uns 3 m. O celular dele bloqueia depois de 1 minuto 💭.
- **Hinata, 6 anos:**
  - **mais nova (06/10/2026, prompt do Pedro):** 1º ano do ensino fundamental, lê e faz matemática no nível do 3º ano;
  - **versões anteriores da memória:** "leitura de nível de 8 a 10 anos e matemática de 10 anos" (05/10) e, antes, "nível de 12 anos" (corrigido);
  - já houve a confusão "Renata" (o certo é Hinata);
  - está aprendendo interpretação de texto e os sinais da escrita.
- **Hana, 4 anos:**
  - **mais nova (06/10/2026):** lê com certa fluência e faz pequenas contas de adição e subtração;
  - memória anterior: "jardim; matemática de 1º ano";
  - é a **usuária original** deste app (perfil legado `"1"`).
- **Como trabalhar com o Pedro:**
  - português do Brasil, linguagem simples;
  - **edições cirúrgicas**, nunca quebrar o que funciona;
  - explicar a **causa de cada problema** em palavras simples, junto com a correção;
  - **honestidade** sobre o que foi ou não testado (rodado de verdade × só lido);
  - terminar com checklist ✅/⬜;
  - **pedir autorização antes de coisas grandes**;
  - "mais simples primeiro" numa lista grande;
  - se um pedido contradiz uma decisão anterior dele, apontar e perguntar.
- Ele manda **prints** (olhar com atenção) e às vezes fala por **voz**, e o texto sai trocado ("Wolf screen" = "Full screen", "paixão" = "posição").
- É muito detalhista: nota posição de botão, altura, tamanho de letra.
- Gostos das meninas: neste app não tenho registro específico 💭. Nos outros apps, a Hinata gostou de diálogos pai-filha, quiz no fim e marcadores coloridos (memória de outras conversas).
- Pediu a **revisão por agentes independentes** antes das entregas importantes 💭.
- Modelo recomendado (outra conversa) para o cadastro: Opus, esforço alto 💭.

---

## 14. Glossário
| Palavra | O que quer dizer |
|---|---|
| **Leitora / usuário / criança** | uma criança cadastrada (o código chama de "perfil") |
| **Perfil legado "1"** | a Hana do tempo antes do multiperfil; chaves sem prefixo |
| **Prefixo** | `<id>_` na frente das chaves `hana_*` de cada criança (menos a "1") |
| **`CHAVES_LEITORA`** | lista das 33 chaves de cada criança (backup, apagar, nuvem) |
| **Bichinho** | um dos 8 emojis oficiais que, junto com o nome, identifica a criança |
| **Código da família** | senha comum da família na nuvem (6+ letras), igual em todos os apps e celulares |
| **Ficha** | os dados de uma criança na nuvem (`nome_bichinho`) |
| **Recuperar / juntar** | trazer da nuvem e misturar sem apagar nada |
| **Bolinha** | o pontinho colorido na ⚙️ que mostra a situação da nuvem |
| **Hub** | a tela "O que você quer fazer?" (🏠) |
| **Ler / Monta a Frase / Sílaba Perdida / Treinar Sílabas** | os 4 módulos |
| **Trilha** | a ordem calculada das frases, da mais fácil para a mais difícil |
| **Etapa** | um degrau da trilha (simples, R, RR...) |
| **Nível** | um pedaço da trilha no Mapa (52) |
| **Família (de sílabas)** | BA BE BI BO BU... |
| **Grupo / padrão** | divisão das sílabas complexas (ex.: grupo R, padrão PR) |
| **Quadro de som** | cartões de sílaba só para ouvir, antes das palavras |
| **Já estudada / LIDA** | marcas de progresso que não bloqueiam |
| **Frase-padrão** | "a vovó come o bolo", usada para medir o tamanho da letra |
| **Token** | `{NOME}`, `{TIA_1}`...: trocado pelo nome real na hora de mostrar |
| **Pool** | vários nomes num campo, separados por `/` ou `;` |
| **Cache do sw.js** | nome da versão guardada no celular; subir a cada entrega |
| **Firebase de mentira** | `fakefb.py`, imita o Firebase nos testes |
| **Silabificador** | ferramenta Python que separa sílabas para validar conteúdo (perdida nesta conversa) |
