#!/bin/sh
# Roda todas as baterias de teste do Coruja Explica (v3.1), uma depois da outra.
# Uso:  cd testes  &&  sh rodar_todos.sh
# Precisa de: Node 18+ e Playwright com Chromium (veja COMO_RODAR.md).
# Os testes abrem o app de ../pacote-netlify num servidor local. Só o teste-v3.js usa o
# "Firebase de mentira" (_firebase-falso.js); os outros ficam longe do Firebase real só
# porque o código da família está VAZIO no nuvem-config.js. NUNCA rode com um código escrito lá.
cd "$(dirname "$0")"
mkdir -p saida
total_falhas=0
for t in teste-logica teste-nuvem-logica teste-formatar teste-navegador teste-telas teste-adversarial teste-v2 teste-v21 teste-v3; do
  node "$t.js" > "saida/$t.txt" 2>&1
  n=$(grep -c '❌' "saida/$t.txt")
  ultima=$(grep -v '^[[:space:]]*$' "saida/$t.txt" | tail -1)
  echo "== $t: $n falha(s) | $ultima"
  total_falhas=$((total_falhas + n))
done
echo "TOTAL DE FALHAS: $total_falhas  (detalhes em testes/saida/*.txt)"
