/* Harness compartilhado por todos os teste_*.js — carrega o index.html
   (o app inteiro, HTML+CSS+JS juntos) dentro de um JSDOM, com uns stubs
   pro que o navegador real tem e o JSDOM não implementa (matchMedia,
   Web Speech API, scrollIntoView, canvas), e devolve helpers simples
   de teste (t/assert/assertEq) sem depender de nenhum framework externo. */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const CAMINHO_INDEX = path.join(__dirname, '..', 'index.html');

function carregarApp(opts){
  opts = opts || {};
  let html = fs.readFileSync(CAMINHO_INDEX, 'utf-8');
  // Os 4 arquivos compartilhados entram "colados" no HTML (o JSDOM não tem
  // servidor). A nuvem vai SEMPRE desligada aqui: estes testes nunca podem
  // falar com o Firebase de verdade (os testes da nuvem usam um Firebase
  // simulado, na pasta testes_navegador).
  const pasta = path.dirname(CAMINHO_INDEX);
  const colar = (nome, conteudo) => {
    const tag = '<script src="' + nome + '"';
    const i = html.indexOf(tag); if (i < 0) return;
    const f = html.indexOf('</script>', i) + '</script>'.length;
    html = html.slice(0, i) + '<script>' + conteudo + '</script>' + html.slice(f);
  };
  colar('nuvem-config.js', "window.NUVEM_CONFIG={apiKey:'',projectId:'',familia:''};window.__nuvemCfgArq='ok';");
  ['nuvem-sync.js', 'escola-pwa.js', 'escola-familia.js'].forEach(n => {
    const arq = path.join(pasta, n);
    colar(n, fs.existsSync(arq) ? fs.readFileSync(arq, 'utf-8') : '');
  });
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    resources: 'usable',
    url: 'https://example.com/',
    pretendToBeVisual: true,
    beforeParse(window){
      // matchMedia: usado por isStandalone() logo na carga do script —
      // sem isso o script inteiro quebra antes de terminar de rodar.
      window.matchMedia = function(){
        return { matches:false, addListener(){}, removeListener(){}, addEventListener(){}, removeEventListener(){} };
      };
      // Web Speech API: não existe no JSDOM. Stub mudo só pra speak()
      // não jogar erro quando os testes disparam falas automáticas.
      window.speechSynthesis = {
        speak(){}, cancel(){}, pause(){}, resume(){},
        getVoices(){ return []; }, addEventListener(){}, removeEventListener(){}
      };
      window.SpeechSynthesisUtterance = function(texto){ this.text = texto; };
      // scrollIntoView: elemento chamado em algumas rotas de navegação.
      window.HTMLElement.prototype.scrollIntoView = window.HTMLElement.prototype.scrollIntoView || function(){};
      // v122: sem criança escolhida o app não grava nada (regra da "Hana
      // fantasma"). Estes testes conferem os módulos de leitura, então
      // abrem já com uma criança (a Hana, id "1", como no celular do Pedro).
      if (!opts.semCrianca) {
        try { window.localStorage.setItem('ev_perfis', JSON.stringify({perfis:[{id:'1',nome:'Hana',av:'🦊'}],atual:'1'})); } catch(e) {}
      }
      // gancho opcional: o teste pode simular APIs do navegador antes do app rodar
      if (typeof opts.antes === 'function') opts.antes(window);
    }
  });
  return dom;
}

let _sucessos = 0, _falhas = 0, _detalhesFalha = [];

function t(nome, fn){
  try{
    fn();
    _sucessos++;
    console.log('  OK   - ' + nome);
  }catch(e){
    _falhas++;
    _detalhesFalha.push(nome + ': ' + e.message);
    console.log('  FALHA- ' + nome + '  ::  ' + e.message);
  }
}

async function tAsync(nome, fn){
  try{
    await fn();
    _sucessos++;
    console.log('  OK   - ' + nome);
  }catch(e){
    _falhas++;
    _detalhesFalha.push(nome + ': ' + e.message);
    console.log('  FALHA- ' + nome + '  ::  ' + e.message);
  }
}

function assert(cond, msg){
  if(!cond) throw new Error(msg || 'condição falsa');
}
function assertEq(obtido, esperado, msg){
  if(obtido !== esperado){
    throw new Error((msg || 'valores diferentes') + ' — esperado ' + JSON.stringify(esperado) + ', obtido ' + JSON.stringify(obtido));
  }
}

function resumo(){
  const total = _sucessos + _falhas;
  console.log('\n' + _sucessos + '/' + total + ' passou' + (_falhas ? ' — ' + _falhas + ' falhou(aram)' : ''));
  process.exitCode = _falhas > 0 ? 1 : 0;
  // o escola-pwa.js tem um vigia de 15 s (setInterval): sem isto o processo nunca termina
  setTimeout(() => process.exit(process.exitCode), 30);
}

function esperar(ms){ return new Promise(r => setTimeout(r, ms)); }

module.exports = { carregarApp, t, tAsync, assert, assertEq, resumo, esperar, CAMINHO_INDEX };
