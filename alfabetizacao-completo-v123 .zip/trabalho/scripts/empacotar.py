"""Monta os zips da entrega (rodar da pasta raiz do pacote completo):
   python3 trabalho/scripts/empacotar.py <pasta_saida> [--sem-relatorio]
 - <saida>/alfabetizacao-<VERSAO>-SITE-DE-TESTE-netlify.zip : SÓ os 9 arquivos, na raiz
 - <saida>/alfabetizacao-completo-<VERSAO>.zip : tudo (sem node_modules, __pycache__)
   (VERSAO logo abaixo; mudar a cada entrega, junto com o cache do sw.js)
 - gera o LEIA-ME.txt com tamanho e md5 de cada arquivo."""
import os, sys, zipfile, hashlib, time

VERSAO = 'v123'
RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SAIDA = os.path.abspath(sys.argv[1])
SEM_REL = '--sem-relatorio' in sys.argv
NETLIFY = ['index.html','sw.js','manifest.webmanifest','icon-192.png','icon-512.png','nuvem-config.js','nuvem-sync.js','escola-pwa.js','escola-familia.js']
MD5_CONFIG = '1d5f060a5ae8339921d3d58498807971'

def md5(f): return hashlib.md5(open(f,'rb').read()).hexdigest()
os.makedirs(SAIDA, exist_ok=True)
pac = os.path.join(RAIZ, 'pacote-netlify')
assert sorted(os.listdir(pac)) == sorted(NETLIFY), sorted(os.listdir(pac))
assert md5(os.path.join(pac,'nuvem-config.js')) == MD5_CONFIG, 'nuvem-config.js NÃO é o do Pedro!'
assert ("const C='esforco-vence-"+VERSAO+"'") in open(os.path.join(pac,'sw.js'),encoding='utf-8').read(), 'o cache do sw.js não é o desta versão'
for f in ('index.html','sw.js','nuvem-sync.js','escola-familia.js','escola-pwa.js','manifest.webmanifest','icon-192.png','icon-512.png'):
    assert md5(os.path.join(pac,f)) == md5(os.path.join(RAIZ,'testes',f)), f+': a cópia em testes/ está diferente do pacote'
for f in ('nuvem-sync.js','escola-familia.js'):
    assert md5(os.path.join(pac,f)) == md5(os.path.join(RAIZ,'compartilhados',f)), f+' diferente da cópia mestra'

# LEIA-ME das cópias mestras (gerado aqui, para o md5 estar sempre certo)
def leia_me_compartilhados():
    c = os.path.join(RAIZ, 'compartilhados')
    for f in ('escola-pwa.js','nuvem-config.js'):
        assert md5(os.path.join(c,f)) == md5(os.path.join(pac,f)), f+' em compartilhados/ diferente do pacote'
    linhas = ['# 📦 Cópias mestras dos arquivos compartilhados — Escola São Pedro', '',
      '**Geradas com o 📚 Alfabetização '+VERSAO+' em '+time.strftime('%d/%m/%Y')+'.** São os arquivos que vão, **sem mudar**, para os outros 6 apps',
      'quando chegar a vez de cada um (ordem da decisão D10: Curiosidades → Coruja Explica → Provinha → Historinhas → Matemática → Fluência).',
      'Antes de usar num app, **confira o md5** (no Linux: `md5sum arquivo`; no Windows: `certutil -hashfile arquivo MD5`).', '',
      '| Arquivo | Versão | md5 | Muda de app para app? |', '|---|---|---|---|',
      '| `escola-familia.js` | 1.2 | `%s` | **Não.** Telas da família e das crianças (T1–T8), chip, bolinha, seção "☁️ Família e nuvem", migração, trava do adulto, ⚙️ na "Quem vai estudar hoje?" |' % md5(os.path.join(c,'escola-familia.js')),
      '| `nuvem-sync.js` | 4.1 | `%s` | **Não.** Nuvem (Firestore REST), família por criança, fila, cópias de cada dia, `movidoPara`; 4.1 = não regrava criança tirada |' % md5(os.path.join(c,'nuvem-sync.js')),
      '| `escola-pwa.js` | 2 | `%s` | **Não.** Tela sempre acesa, tela cheia, convite para instalar, os 8 bichinhos |' % md5(os.path.join(c,'escola-pwa.js')),
      '| `nuvem-config.js` | — | `%s` | **Não.** O do Pedro, byte a byte (chaves do Firebase). Nunca usar o `testes/nuvem-config.js` (falso) |' % md5(os.path.join(c,'nuvem-config.js')),
      '| `modelos/sw_alfabetizacao_%s.js` | modelo | `%s` | **Sim:** é o `sw.js` do Alfabetização, só como **modelo**. Cada app tem o seu `sw.js` (nome do cache próprio, lista de arquivos com `escola-familia.js`, `nuvem-config.js` buscado na internet primeiro) |' % (VERSAO, md5(os.path.join(c,'modelos','sw_alfabetizacao_%s.js' % VERSAO))),
      '', '## O que mudou em cada versão', '',
      '- `escola-familia.js` **1** (v122, 07/10/2026): nasceu no Alfabetização (plano `PLANO_CADASTRO_FAMILIA.md`, D1–D16).',
      '- `escola-familia.js` **1.1** (v122b): só desenho — respiro e largura deitado; caixa do código no meio com o teclado; "Achei a sua família" largo; site de teste = qualquer endereço com "teste".',
      '- `escola-familia.js` **1.2** (v123): ⚙️ na "Quem vai estudar hoje?" (opções `abrirConfig(aoFechar)` e `fecharConfig()` no `EscolaFamilia.iniciar`); bolinha 🟡 enquanto uma criança tirada estiver guardada só na lixeira do celular.',
      '- `nuvem-sync.js` **4** (v122): família por criança, `existeFamilia`, `garantirGuardado`, `marcarMovido`, `limparPendencia`, `semVigiar`; junta antes de enviar quando o celular não conhece a ficha; se a lista de crianças der erro, não mexe na fila.',
      '- `nuvem-sync.js` **4.1** (v123): antes de juntar o que veio da nuvem, confere **na hora** se a criança ainda está no celular (resposta atrasada não regrava criança tirada).',
      '', '## Como ligar num app', '',
      'Siga a parte 5.2 e a parte 14 do `PLANO_CADASTRO_FAMILIA.md` (versão 3) e copie o jeito do Alfabetização: o `ADAPTADOR_CRIANCAS` e o bloco "liga o cadastro da família, a nuvem e o escola-pwa.js" no fim do `index.html` dele. No `sw.js` do app, acrescente `./escola-familia.js` à lista de arquivos e **suba o nome do cache**.',
      '', '**Regra:** quem precisar mudar um destes arquivos **para** e pergunta ao Pedro; mudança sobe a versão e vale para todos os apps.']
    open(os.path.join(c,'LEIA-ME_COMPARTILHADOS.md'),'w',encoding='utf-8').write('\n'.join(linhas)+'\n')
leia_me_compartilhados()

def pular(rel):
    partes = rel.split(os.sep)
    if 'node_modules' in partes or '__pycache__' in partes: return True
    if rel == 'LEIA-ME.txt': return False
    if SEM_REL and partes[0]=='documentos' and partes[-1].startswith('RELATORIO_CHECAGEM'): return True
    return False

arquivos = []
for d, _, fs in os.walk(RAIZ):
    for f in fs:
        rel = os.path.relpath(os.path.join(d,f), RAIZ)
        if not pular(rel) and rel != 'LEIA-ME.txt': arquivos.append(rel)
arquivos.sort()
linhas = ['Esforço Vence — Alfabetização · pacote completo '+VERSAO+' (versão final, para o site de verdade) · gerado em '+time.strftime('%d/%m/%Y %H:%M'),
          '', 'Pastas: pacote-netlify/ (os 9 arquivos do Netlify) · compartilhados/ (cópias mestras para os 7 apps)',
          '        documentos/ · testes/ (npm install antes) · trabalho/', '',
          'ZIP DO NETLIFY: só os 9 arquivos de pacote-netlify/, na raiz. nuvem-config.js = o do Pedro (md5 '+MD5_CONFIG+').',
          'NUNCA publicar a pasta testes/ (o nuvem-config.js de lá é falso).', '', 'arquivo | bytes | md5']
for rel in arquivos:
    full = os.path.join(RAIZ, rel)
    linhas.append('%s | %d | %s' % (rel, os.path.getsize(full), md5(full)))
open(os.path.join(RAIZ,'LEIA-ME.txt'),'w',encoding='utf-8').write('\n'.join(linhas)+'\n')

z1 = os.path.join(SAIDA, 'alfabetizacao-'+VERSAO+'-netlify.zip')
with zipfile.ZipFile(z1, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in NETLIFY: z.write(os.path.join(pac,f), f)
z2 = os.path.join(SAIDA, 'alfabetizacao-completo-'+VERSAO+'.zip')
with zipfile.ZipFile(z2, 'w', zipfile.ZIP_DEFLATED) as z:
    for rel in arquivos + ['LEIA-ME.txt']: z.write(os.path.join(RAIZ,rel), rel)
print(z1, md5(z1)); print(z2, md5(z2)); print(len(arquivos)+1, 'arquivos no completo')
