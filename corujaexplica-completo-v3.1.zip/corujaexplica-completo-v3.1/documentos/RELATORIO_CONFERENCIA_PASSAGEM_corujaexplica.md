# Relatório da conferência da passagem — 🦉 Coruja Explica (v3.1)

**Data:** 14/10/2026 · **Versão empacotada:** 3.1 (cache `coruja-explica-v3-1`) · **Regra:** o código do app **não foi alterado**.

## O que foi rodado e o que foi só lido

**Rodado de verdade (14/10/2026):**
- `node --check` em `sw.js`, `nuvem-sync.js`, `escola-pwa.js` e `nuvem-config.js`.
- Conferência de sintaxe dos 2 `<script>` embutidos no `index.html` (`vm.Script` do Node).
- md5 de todos os arquivos.
- `cmp` do `nuvem-config.js` com o anexo do Pedro de 14/10 e com o original de 24/09.
- Download do site publicado e comparação com o pacote.
- **As 9 baterias de teste (816 verificações, 0 falhas)** rodadas de dentro da pasta do zip (`sh testes/rodar_todos.sh`).
- Abertura do app num Chromium sem tela (Playwright), na 1ª abertura e com 1 criança: sem erros no console, nenhum pedido ao Firebase real.
- Zip aberto de novo depois de pronto, com os md5 conferidos.

**Só lido no código (não executado):**
- comportamento no celular de verdade (toque, teclado, Wake Lock, rotação);
- Firebase real;
- instalação do PWA;
- TV.

## Etapa 1 — Autochecagem (pedido → prova)

| # | Pedido | Prova | Situação |
|---|---|---|---|
| 1 | `HISTORICO_E_PLANO_corujaexplica.md` com os 14 capítulos | arquivo em `documentos/`; títulos "## 1." a "## 14." conferidos por `grep` | ✅ |
| 2 | Cap. 1: identificação (endereço, ID, versão, cache, data, arquivos) | tabela com md5 calculados; site baixado e comparado | ✅ |
| 3 | Cap. 3: linha do tempo versão por versão | resumo + `CHANGELOG_POR_VERSAO_v1.3-v3.1.md`, feito comparando os 11 zips entregues. v1.0–v1.2 marcadas "não sei" | ✅ |
| 4 | Cap. 5: TODAS as chaves do `localStorage` | `grep` de `localStorage`/`getItem`/`setItem`/`removeItem` e prefixos no `index.html`, no `nuvem-sync.js` v3 e no `escola-pwa.js` v2 | ✅ |
| 5 | Cap. 6: cadastro, família e nuvem com textos exatos | textos copiados do HTML e dos `showToast`/`abrirConfirm`/`textContent` | ✅ |
| 6 | Cap. 9: testes (quantos, como rodar, o que não cobrem, último resultado) | 816/816 em 14/10/2026 | ✅ |
| 7 | Cap. 13: Pedro e as meninas (inclusive versões diferentes da memória) | registrado: Hinata 6 / Hana 4 (mais nova); "Renata" foi engano antigo | ✅ |
| 8 | `PROMPT_CONTINUACAO_corujaexplica.md` (anexos, COPIE DAQUI…ATÉ AQUI, "O que eu quero agora") | arquivo em `documentos/` | ✅ |
| 9 | `pacote-netlify/` exatamente o que vai para o Netlify | 8 arquivos; `index.html` md5 `24e3ad15…` = zip v3.1 entregue = publicado (o publicado tem só a linha do HUD do Netlify a mais) | ✅ |
| 10 | `nuvem-config.js` byte a byte | `cmp` com o anexo de 14/10 e com o original de 24/09: idênticos (`1d5f060a…`) | ✅ |
| 11 | `nuvem-sync.js`/`escola-pwa.js`: a cópia que o app usa hoje, comparada com a anexada | `escola-pwa.js` igual (`ec31bf4a…`). `nuvem-sync.js` anexado é a **4.1** (`f151bb17…`); o app usa a **3** (`f6736f30…`), **não trocado**; registrado no cap. 11 | ✅ |
| 12 | `documentos/` com toda a documentação | histórico, prompt, changelog, prompts da IA (gerados do código), exemplo, `historico/` (prompts v1.7–v2.1, pedido v3.0, prompt de continuação antigo), `referencias/` (plano v3, padrão, referência Curiosidades, pedido, guia Firebase, prompts de passagem) | ✅ |
| 13 | `testes/` com todas as baterias, o Firebase de mentira e como rodar | 9 baterias + `_firebase-falso.js` + `COMO_RODAR.md` + `rodar_todos.sh` + `antigos/`. **Nenhum teste perdido** | ✅ |
| 14 | `trabalho/` | modelo do cadastro novo (não usado), zips v1.3–v3.0, estudo dos espaços, scripts, capturas | ✅ |
| 15 | `LEIA-ME.txt` com todos os arquivos, tamanho e md5, versão e data | gerado por script; LEIA-ME e relatório fora da lista | ✅ |
| 16 | `node --check` | ok nos 4 `.js` do pacote e nos testes; scripts do `index.html` sem erro de sintaxe | ✅ |
| 17 | Testes rodados | 816/816, 0 falhas (14/10/2026) | ✅ |
| 18 | Não mudar o código do app | `index.html`, `sw.js` e manifest idênticos (md5) ao zip v3.1 entregue em 24/09 | ✅ |
| 19 | Separar certeza de lembrança | marcas [certeza], [lembrança] e "não sei" no histórico | ✅ |

**Observação:** nos testes, só os **caminhos** foram ajustados (para rodar de dentro do zip). A lógica não mudou; está explicado no capítulo 9 e em `testes/COMO_RODAR.md`.

## Etapa 2 — Agente conferente independente

**Rodada 1 (14/10/2026)**

O conferente é um agente novo, criado pela ferramenta de agentes, que não viu a conversa. Ele recebeu o zip, os 2 `.md`, o pedido de passagem, o `nuvem-config.js` original, o zip do Netlify de 24/09 e o endereço do site publicado.

**O que ele rodou:**
- md5 das 90 linhas do LEIA-ME (90/90);
- pacote = entregue = publicado;
- `nuvem-config.js` byte a byte;
- `node --check`;
- **816/816 testes** de dentro do zip, com uma guarda de rede (nenhum pedido escapou);
- app no Chromium com 0, 1 e 2 crianças, sem erro de página;
- 18 chaves do `localStorage` = cap. 5.7;
- 9 afirmações do cap. 3 conferidas nos zips antigos.

**Achados e correções:**

| Achado | Gravidade | Correção feita (só nos documentos e no zip; o app não mudou) |
|---|---|---|
| A1: os documentos diziam que o Curiosidades "já usa" o `nuvem-sync.js` 4.1; o site de verdade dele ainda é a v1.8 com a v3 (a 4.1 só no site de teste) | 🟠 | Corrigido nos caps. 1, 3, 9 e 12, no `COMO_RODAR.md` e no prompt de continuação. As duas versões (pedido × lembrança) estão registradas no cap. 3, "Depois da v3.1", com a conferência de 14/10 no site (eu mesmo baixei os `sw.js` e `nuvem-sync.js` dos sites) |
| A2: "todos os testes interceptam o Firebase" era falso (só o `teste-v3.js`) | 🟠 | Texto corrigido no cap. 9, no `COMO_RODAR.md` e no `rodar_todos.sh`, com o aviso "nunca rodar com código escrito no `nuvem-config.js`". Sugestão de trava no cap. 11 (item 10) e no cap. 12 |
| A3: o pedido escrito da v2.0 (anexo de 23/09) não estava no zip e era tratado como lembrança; pedia 300–400 palavras (feito 300–500) | 🟠 | Arquivo em `documentos/historico/PEDIDO_v2.0_23-09.txt`. Cap. 3 (v2.0) passou a [certeza], com a diferença 300–400 × 300–500 registrada (cap. 11, item 14). O que a criança gostou foi para o cap. 2 |
| A4: cap. 3 sem o "por quê" de cada versão | 🟠 | Cap. 3 reescrito versão por versão, com "Pedido / Feito / Por quê / Desfeito", e "não sei" onde não se sabe |
| B1: `alinharOn` "lido" | 🟡 | Corrigido no 5.7 (é ignorado) |
| B2: formato do id | 🟡 | Corrigido no 6.1 |
| B3: bolinha vermelha sem código | 🟡 | Acrescentado no 6.5 e no cap. 11 |
| B4: `CORUJA_PORT` | 🟡 | Corrigido no cap. 9 e no `COMO_RODAR.md` |
| B5: biblioteca gigante de não lidos nunca sobe | 🟡 | Acrescentado no 6.10 (item 8) e no cap. 11 |
| B6: anexos antigos fora do zip | 🟡 | Incluídos: textos de 18/09 e 21/09, as 26 capturas do Pedro, os HTML de referência do Esforço Vence e do Curiosidades v1.3, e o pedido da v3.1 com o texto exato. O que ficou fora está explicado no LEIA-ME |
| B7: documento antigo do Projeto e regras do Firestore | 🟡 | Prompt de continuação avisa que substitui o antigo; regras do Firestore no 6.7 |
| B8: "Renata" | 🟡 | Marcado [lembrança] + [certeza]: até a v2.1 |
| B9: scripts da passagem | 🟡 | Em `trabalho/scripts-da-passagem/`; o do CHANGELOG está registrado como "uso único, não guardado" |
| Para o cap. 11: aviso `requestFullscreen`, bolinha vermelha, envio acima do limite, testes sem trava | — | Acrescentados no cap. 11 (itens 10 a 13) |

**Rodada 2 (14/10/2026), com o mesmo agente conferente:**
- **Rodou:** abriu o zip de novo numa pasta vazia; 125/125 md5 do LEIA-ME certos; `pacote-netlify/` igual à rodada 1 (`index.html` `24e3ad15…`, `nuvem-config.js` byte a byte); os `.js` dos testes iguais aos da rodada 1 (por isso os 816 testes não foram rodados de novo); arquivos novos iguais aos anexos originais (md5); `PEDIDO_v3.1` igual ao registro da conversa; scripts novos com sintaxe ok.
- **Leu:** os trechos alterados dos documentos.
- **Resultado:** A1–A4 e B1–B9 **corrigidos**. Um 🟡 novo:
  - **C1:** o cap. 3 dava a data "(07/10)" ao pedido de passagem sem explicar. **Corrigido:** "o `PROMPT_HANDOFF_APPS.md` diz 'versão 3 · 07/10/2026'; foi anexado aqui em 14/10" (cap. 3 e cap. 13).
- **Veredito do conferente:** ✅ Passagem aprovada (zero 🔴 e zero 🟠).

## Etapa 3 — Revisor-chefe

**Quando:** 14/10/2026, à noite. A conversa tinha parado antes desta etapa (o ambiente foi reiniciado); ela foi retomada quando o Pedro mandou o pedido de novo, com os mesmos anexos (md5 conferidos: iguais aos usados à tarde).

**Quem:** um agente **novo**, criado pela ferramenta de agentes, que não viu a conversa nem o conferente. Recebeu o zip final, os 2 `.md`, este relatório, os relatórios completos do conferente (rodadas 1 e 2), o pedido de passagem, o `nuvem-config.js` original e o zip de 24/09 (o publicado).

**O que ele rodou:**
- os 8 arquivos de `pacote-netlify/` com o mesmo md5 do zip de 24/09 (`index.html` `24e3ad15…`, igual ao publicado sem a linha do Netlify); `nuvem-config.js` byte a byte igual aos dois originais do Pedro;
- os 125 md5 e tamanhos do `LEIA-ME.txt`; `node --check` em todos os `.js` e nos 2 `<script>` do `index.html`; os 2 `.md` de fora iguais aos de dentro do zip;
- baixou os sites publicados e confirmou a correção do A1 (o Curiosidades oficial ainda é a v1.8 com o `nuvem-sync.js` v3);
- **as 9 baterias: 816 verificações, 0 falhas**, com uma trava própria que bloqueia todo pedido que não seja local (nada tentou sair para o Firebase);
- comparou os testes com os originais de 24/09: só mudaram os caminhos;
- passou pelo capítulo 6 no navegador (0, 1 e 2 crianças, avisos, criança repetida, trocar nome, apagar, pop-up do código): títulos, botões e avisos batem letra por letra.

**O que ele só leu:** o capítulo 6 contra o código do app, o `nuvem-sync.js` v3 e o `escola-pwa.js` v2; a lista de chaves do capítulo 5 (completa e certa).

**Conferência dos achados do conferente:** A1–A4 (🟠) e B1–B9, C1 (🟡) **corrigidos de verdade** no zip.

**Achados novos (todos 🟡, não bloqueiam) e correções feitas (só no `HISTORICO_E_PLANO`; o app não mudou):**

| # | Achado | Correção |
|---|---|---|
| D1 | 6.4 "Versões guardadas": faltavam mensagens da tela e que o botão 🕘 some sem criança atual | Mensagens exatas acrescentadas no 6.4 |
| D2 | Apagar deixa o id na fila `nuvem_corujaexplica_pendentes`/`_meta`; sem código da família fica para sempre na contagem; depois de apagar, a atual vira a primeira da lista | Registrado no 6.6, no 6.10 (item 9) e no cap. 11 (item 18) |
| D3 | Trocar nome/bichinho sem internet ou sem código não junta a ficha antiga e não tenta de novo (ficha órfã) | Registrado no 6.7, no 6.10 (item 10) e no cap. 11 (item 19) |
| D4 | No "Recuperar", tocar numa criança que já está no celular a torna a atual; num celular sem crianças, a 1ª recuperada recebe a biblioteca antiga da v2.x | Acrescentado no 6.4 |
| D5 | Faltava descrever o 2º documento da nuvem (`familias/<código>/usuarios/<chave>`) e os campos da ficha do app | Acrescentado no 6.7 |

**Depois das correções (rodado):** o `LEIA-ME.txt` e o zip foram refeitos pelo mesmo script (`trabalho/scripts-da-passagem/fazer_leiame_zip.py`); o zip foi aberto de novo numa pasta vazia e **todos** os md5 do `LEIA-ME.txt` conferidos; `pacote-netlify/` e `testes/` continuam com os mesmos md5 de antes (só o `HISTORICO_E_PLANO` mudou). Os 816 testes não foram rodados de novo porque nenhum arquivo de código nem de teste mudou.

**Veredito do revisor-chefe:** nenhum 🔴 nem 🟠; os 🟡 novos já foram acrescentados aos documentos.

✅ Passagem aprovada
