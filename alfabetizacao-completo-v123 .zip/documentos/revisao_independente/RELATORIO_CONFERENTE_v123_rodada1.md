# Conferente independente: Esforço Vence — Alfabetização v123 (rodada 1)

**Data:** 07/10/2026 · **Conferi:** `alfabetizacao-completo-v123.zip`, `alfabetizacao-v123-netlify.zip` e os 3 documentos soltos (plano, prompt de passagem e texto de colar), comparando com a v122b e a v121.
**Como trabalhei:** descompactei tudo em `/home/claude/conf123/` (não mexi em `/home/claude/v122/`). Não abri `RELATORIO_CHECAGEM_*` nem `revisao_independente/`. Usei só o Firebase de mentira. Rodei uma suíte de cada vez, nas portas 8911 a 8973.

---

## Resumo em 1 minuto

- **O app está pronto para o site de verdade.** Os 9 arquivos do Netlify estão certos e todos os md5 batem. O `nuvem-config.js` é o do Pedro, o `escola-pwa.js` é igual ao da v121 e o `sw.js` usa o cache `esforco-vence-v123` com o `escola-familia.js` na lista.
- **Testes:** rodei todos e os números batem com os documentos: **690/691**. A única falha é a antiga do `teste_fonte.py`.
- Escrevi **4 testes meus**, todos passaram:
  - **C1 pelo envio:** caminho que o teste do autor não cobria;
  - **C1 com a lista de crianças dando erro;**
  - **C1 com a cópia de um dia;**
  - **migração v122b → v123 → volta à v121.**
- **Nada perde dados.** O novo jeito de juntar (`aplicar` 4.1) continua juntando em todos os caminhos normais: trazer da nuvem, cadastrar um nome que já existe, juntar a cópia de um dia, mudar o bichinho, backup e lixeira. Em todos eles a criança entra na lista **antes** de juntar. Quando a lista do app dá erro, nada sobe e a fila fica guardada.
- **A ⚙️ na "Quem vai estudar hoje?" funciona** em 6 tamanhos, com 0, 1, 2 e 6 crianças e com 1 ou 2 famílias. Nenhum botão fica por cima de outro ou para fora da tela.
- **A tela cheia voltou a ser a da v122.** Comparei o código da v122 com o da v123: as 3 partes da tela cheia estão idênticas.
- **Achados:** **2 🟠, nos documentos** (nenhum no app que vai para o Netlify) e 7 🟡.
  - O plano não avisa os próximos apps sobre uma regra nova do 4.1: a criança tem que entrar na lista **antes** de juntar.
  - Os relatórios de checagem da v122 e da v122b sumiram do zip completo, e o histórico ainda manda lê-los.

---

## Pedido do Pedro → atendido? → prova

| # | Pedido | Atendido? | Prova |
|---|---|---|---|
| 1 | ⚙️ (Configurações) na "Quem vai estudar hoje?" | ✅ | `teste_v123` parte 1: 28/28. Meu `telas.py`: 42 combinações (6 tamanhos × 4 situações × abertura/chip), 0 problemas, capturas olhadas. Cantinho dos pais, Livrinho, Exportar e as opções da família abertos pela ⚙️, com e sem criança: sem erro de JavaScript e sem criar chave `hana_*`. Achados 🟡4 e 🟡6. |
| 2 | Tela cheia "como era antes" (sem a borda azul dos botões do Android) | ✅ (só o celular confirma o visual) | `diff` entre `index_v122.html` e o `index.html` da v123: a tela cheia está idêntica. As 3 mudanças da v122b foram desfeitas: `toggleFs`, o pedido ao abrir e o `telaCheia` no `EscolaPWA.iniciar`. `teste_desenho` item 7 passa (aberto pelo ícone, o app pede a tela cheia). O `manifest` e o `escola-pwa.js` não mudaram. |
| 3 | "Trava uns 5 s ao abrir (tela preta)" | ✅ explicado com honestidade, melhora parcial | Medi com o processador 6× mais lento: abertura **≈2,7 s → ≈2,4 s**; montar a trilha **≈400 ms → ≈150 ms**. A trilha continua idêntica (md5 conferido pelo `teste_v123`). Li o código: a memória só depende da sílaba, da posição e da sílaba anterior, igual ao cálculo. A cor de fundo do manifest é azul-clara (`#c4f1ff`), então a tela preta não vem dela. A resposta ao Pedro (o Android abre a janela e o Chrome lê ≈1 MB; diminuir mais exige separar as frases, só com o OK dele) é honesta. |
| 4 | Desinstalar e limpar o cache não volta a tela "Já tenho cadastro" | ✅ | A resposta está certa: no Android, o app instalado e o Chrome guardam os dados no mesmo lugar. O caminho para começar do zero (Configurações do site › Limpar e redefinir) está correto, com o aviso de só fazer isso com a bolinha verde. |
| 5 | Versão final | ✅ | Pacote e testes abaixo. |
| 6 | Arquivos para os próximos apps | ✅ | `compartilhados/` tem `escola-familia.js` 1.2, `nuvem-sync.js` 4.1, `escola-pwa.js`, `nuvem-config.js` e o modelo `sw_alfabetizacao_v123.js`. Os 5 md5 batem com o `LEIA-ME_COMPARTILHADOS.md`. `compartilhados/` = `pacote-netlify/` = `testes/` (fora o `nuvem-config.js` falso dos testes, que é de propósito). |
| 7 | Plano, prompt de passagem e texto de colar com "autochecagem + 1 agente independente + revisor", para o Sonnet 5.5 | ✅ com ressalvas | Os 3 estão na versão 3 e dizem "autochecagem, 1 agente conferente independente e revisor-chefe", Sonnet 5.5, esforço alto. "2 agentes" só aparece no histórico de mudanças (v1→v2), como deve. O `_PROMPT_HANDOFF_APPS_COLAR.md` é **idêntico** ao bloco COPIE DAQUI…ATÉ AQUI do arquivo completo (só tem o título a mais). Os 3 soltos são iguais aos de dentro do zip. Achados 🟠1 e 🟡8. |
| 8 | Revisão final | (esta etapa) | — |

---

## Achados

### 🟠1 Plano: falta a regra "a criança entra na lista ANTES de juntar"
- **Onde:** `PLANO_CADASTRO_FAMILIA.md`, parte 5.2 (adaptador, `criar`/`importar`), parte 5.3 item 14 e Apêndice A.
- **O problema:** com o `nuvem-sync.js` 4.1, as funções `recuperar`, `juntarVersao` e `checarNuvem` **só juntam** se a criança **já estiver** em `usuarios()`. O plano também recomenda que o `mesclar` de cada app ignore um id que não está na lista. Mas o plano **não diz** que:
  - `criar()` tem que pôr a criança em `listar()` **na hora**;
  - o backup e a lixeira de cada app têm que pôr a criança na lista **antes** de chamar o `mesclar`.

  No Alfabetização a ordem está certa: conferi `trazer`, `criarNova`, `trazerDaLixeira`, `juntarLixeira` e `aplicarBackup`. Num app novo, porém, um backup que junta antes de criar a criança passaria a **não juntar nada, sem avisar**. E um `trazer` com lista atrasada mostraria "sem leituras" (o envio seguro junta depois, então a nuvem não perde, mas o celular fica vazio até lá).
- **Não afeta a v123.**
- **Sugestão:**
  - uma frase na parte 5.2: "`criar()` devolve o id **já presente** em `listar()`; backup e lixeira põem a criança na lista **antes** de `mesclar`/`importar`";
  - a mesma frase no item 14 e no Apêndice A;
  - pedir um teste "importar backup com criança nova" em cada app.

### 🟠2 Zip completo: os relatórios de checagem sumiram, mas continuam citados
- **Onde:** `alfabetizacao-completo-v123.zip`, pasta `documentos/`.
- **O problema:** `RELATORIO_CHECAGEM_alfabetizacao_v122.md` e `RELATORIO_CHECAGEM_alfabetizacao_v122b.md` estavam no zip da v122b e **não estão** no da v123. O `RELATORIO_CHECAGEM_alfabetizacao_v123.md` também não está. Mesmo assim, o `HISTORICO_E_PLANO` manda lê-los (linha 6, capítulo 3.11 e linha 746).
- **Sugestão:** recolocar os dois antigos (estão no zip da v122b e em `/home/claude/entrega/`) e incluir o da v123 no fechamento. Depois, refazer as linhas do `LEIA-ME.txt`.

### 🟡3 Frases velhas no prompt de continuação e no histórico
- **`PROMPT_CONTINUACAO_alfabetizacao.md`:**
  - item 4 de "O que anexar": diz que "hoje importar substitui o progresso no celular e também na nuvem". Isso é falso desde a v122 (o backup junta) e contradiz a regra 9 do mesmo arquivo;
  - linha 33: "o 🟡 C1, a corrigir na v123", mas o C1 já foi corrigido;
  - regra 5: cita o `#codOv`, que saiu na v122.
- **`HISTORICO_E_PLANO_alfabetizacao.md`:**
  - a tabela 5.2 lista `#homeOv`, `#npOv`, `#nuvemOv` e `#codOv` como telas atuais;
  - o capítulo 10, item 9, repete que "importar substitui" e cita botões antigos ("☁️ Recuperar da nuvem", "🕘 Versões guardadas").
- **Sugestão:** atualizar essas frases. Não mudam nada no app.

### 🟡4 ⚙️ da T4: as Configurações mexem na criança aberta por último, sem dizer qual
- **Como reproduzir:**
  1. Celular com uma família e **nenhuma criança**.
  2. Na T4, tocar ⚙️ › 📊 Cantinho dos pais › Nomes dos parentes.
  3. Escrever "Pedro" e tocar em Salvar.
- **Resultado:** aparece "💾 Nomes salvos!", mas **nada é salvo** (sem criança, o app não grava nenhuma chave `hana_*`).
- **Com crianças:** tema, letra e parentes mudam para a criança que estava aberta por último (no meu teste, a Hina), e a tela não diz qual é.
- **O que deveria acontecer:** sem criança, avisar "escolha uma criança primeiro" (ou esconder "Nomes dos parentes"). Com crianças, mostrar de quem são ("de 🐰 Hina").
- **Por que é 🟡:** não perde nada; é só uma situação que confunde.

### 🟡5 C2: bolinha 🟡 por cópias antigas da lixeira, e não dá para descartar uma cópia
- **O problema:** as entradas da lixeira gravadas na v122/v122b não têm a marca nova `soAqui`, então contam como "guardada só neste celular". Isso vale até para a cópia de reserva de "juntar repetidas".
- **Prova:** meu `mig122b.py` tirou o Caio com cópia na v122b. Depois de trocar para a v123, a bolinha ficou 🟡 "🗑️ 1 CRIANÇA… SÓ NESTE CELULAR".
- **Onde isso aparece:** no site de teste, se o Pedro seguir o passo 1 das instruções. No site de verdade não acontece (a v121 não tem lixeira).
- **Outro ponto:** não existe "descartar a cópia". A única saída é trazer a criança de volta e tirar de novo com a nuvem em dia.
- **Sugestão:** uma linha no passo 1 das instruções ("no site de teste a bolinha pode ficar 🟡 por uma criança tirada antes; é só trazer de volta em ☁️ Buscar na nuvem").

### 🟡6 Em pé (360×740), com "← VOLTAR", a barra de cima cresceu
- **O problema:** na T4 aberta pelo chip, a ⚙️ nova fez o "← VOLTAR" quebrar em 2 linhas e a barra ficar ~25 px mais alta que na v122b.
- **Por que é 🟡:** não fica nada por cima de nada e o app quase sempre é usado deitado.
- **Capturas:** `cap/f1c6_chip_360x740.png` (v123) e `cap122b/f1c6_chip_360x740.png` (v122b), na minha pasta de rascunho.

### 🟡7 Instruções de publicar, parte 3, passo 3
- **O problema:** o texto diz "Toque numa criança → ▶ Continuar de onde parei". Esse aviso só aparece se a criança estava no Monta a Frase, na Sílaba Perdida ou no Treinar Sílabas. Quem estava no **Ler** vai direto para o menu (`passoDoApp`).
- **Sugestão:** "ela volta ao menu ou pergunta '▶ Continuar de onde parei'".

### 🟡8 Prompt de passagem, "Como usar", item 2
- **O problema:** pede para anexar "`nuvem-sync.js`, `escola-pwa.js`…" sem dizer de qual app. O Pedro pode anexar o 4.1 do Alfabetização na passagem de outro app. O bloco de colar já diz "use a cópia que ESTE app usa hoje", mas o roteiro do Pedro não diz.
- **Sugestão:** "o `nuvem-sync.js` que está publicado **naquele** app (não o 4.1 do Alfabetização)".

### 🟡9 Contagem errada num texto (só aparência)
- **O problema:** o título do teste e o comentário da `categoriaSilaba` falam em "poucas/algumas centenas" de combinações. São **2632**.
- **Sugestão:** trocar para "≈2,6 mil".

### Observações sobre o que já existia (não são da v123; vão para o capítulo 11)
- **"📲 Instalar o app" some no Chrome:** na aba do Chrome, qualquer toque põe o app em tela cheia. Aí o `escola-pwa.js` acha que o app está "instalado" e some com o "📲 Instalar o app" das Configurações (o convite também não abre). Reproduzi pela ⚙️ da T4. O comportamento é o mesmo da v122.
- **2 famílias na T4, deitado (984×432):** a 2ª família fica atrás da fileira de botões e só aparece rolando, sem nenhuma dica de que dá para rolar. É igual à v122b, que o Pedro aprovou; aparece no próprio print dele.

---

## O que RODEI × o que só LI

**Rodei:**
- **Testes do autor:**
  - node: 89/89;
  - cadastro: 72/72;
  - nuvem: 81/81;
  - pwa: 34/34;
  - família: 130/130 (inclui a migração v121 → v123 byte a byte e a volta à v121);
  - revisão: 59/59;
  - desenho: 127/127;
  - v123: 41/41;
  - fonte: 57/58 (a falha antiga).
  - **Total: 690/691, igual ao HISTORICO.**
- **Testes meus** (em `/tmp/claude-0/.../scratchpad/conf/`):
  - `meu_c1.py` (13/13): segurei a resposta da nuvem **no envio** (`enviarComSeguranca`), tirei a criança e soltei. Nenhuma chave voltou, nada subiu por cima da nuvem e a fila ficou vazia. Também: a lista do app dá erro enquanto a nuvem responde (nada sobe; quando a lista volta, junta e sobe a união) e a cópia de um dia com a criança tirada (devolve `false`, nada gravado);
  - `mig122b.py` (8/8): v122b → v123 com as chaves iguais byte a byte, as mesmas famílias e crianças e a bolinha 🟡 da lixeira antiga; depois a volta à v121 (sem Hana fantasma, progresso igual);
  - `telas.py`: 42 capturas e medidas da T4 com a ⚙️, mais as mesmas na v122b para comparar;
  - `cfg_t4.py`, `inst.py`, `semcrianca.py`, `parentes.py`: as opções das Configurações abertas pela T4;
  - `medir_abertura.py`: tempo de abertura, v122b × v123.
- **Pacote:**
  - todos os md5 do `LEIA-ME.txt`: 102 linhas, 0 erros, nenhum arquivo sem linha;
  - os 9 arquivos na raiz do zip do Netlify;
  - `nuvem-config.js` = `1d5f060a…`;
  - `escola-pwa.js` igual ao da v121;
  - `node --check` nos 5 `.js` e `checar_sintaxe.py` no `index.html`: OK.
- **Documentos:**
  - texto de colar × bloco do arquivo completo (`difflib`);
  - os 3 documentos soltos × os de dentro do zip (`cmp`).

**Só li:**
- os diffs v122b → v123 (`nuvem-sync.js`, `escola-familia.js`, `index.html`, `sw.js`) e v122 → v123 (tela cheia);
- a ordem "cria e depois junta" em `trazer`, `criarNova`, `trazerDaLixeira`, `juntarLixeira`, `aplicarBackup`, `processarMudancas` e `avisosMudanca`;
- as instruções de publicar, o capítulo 3.12, o plano (partes 5.2, 5.3, 9-A, 10, 13 e o cabeçalho), o prompt de passagem, o prompt de continuação e o LEIA-ME dos compartilhados;
- confirmei que os textos citados nas instruções existem no app: "QUEM VAI ESTUDAR HOJE?", "TUDO CERTO ✅", "JÁ TENHO CADASTRO", "ESTE CELULAR JÁ TEM", ⬆️ Exportar backup na v121 e o chip que abre a T4.

## O que só o celular confirma
- A tela cheia de verdade, sem a borda azul dos 3 botões, aberta pelo ícone; e o aviso do Chrome aparecendo só por alguns segundos.
- O tempo real da tela preta ao abrir; no Chromium daqui a melhora foi de ≈10–15%.
- O toque na ⚙️ da T4, o botão voltar do Android de verdade, e o Cantinho dos pais aberto por ela.
- A migração com os dados **de verdade** dos 2 celulares das meninas (v121 → v123) e o aviso "FAMÍLIA •••• — TUDO CERTO ✅".
- 2 celulares com o Firebase real ("🔄 ATUALIZAR AGORA" leva o progresso de um para o outro).
- Que desinstalar o ícone não apaga os dados no Android dele (a resposta dada está certa, mas depende do aparelho).

O zip do Netlify pode ir para o site de verdade. Os 🟠 são só dos documentos e do zip completo: corrigir antes de usar o plano no próximo app (🌍 Curiosidades).

✅ Pode publicar
