/* MODELO_LIGACAO_CURIOSIDADES_v2.2.js — SÓ PARA LEITURA (não é para rodar).
   Trechos do index.html do 🌍 Curiosidades do Mundo v2.2 (publicado e aprovado pelo Pedro em 14/10/2026)
   que mostram COMO o novo cadastro da família (escola-familia.js 1.2 + nuvem-sync.js 4.1) foi ligado num app.
   Cada app tem os seus nomes de chaves e as suas regras de juntar dados: adapte, não copie às cegas.
   Leia junto com GUIA_IMPLANTAR_CADASTRO_NOVO_APP.md. */
/* ======================================================================
   1) TRAVA "SEM CRIANÇA" (ligada cedo, antes de carregar os dados, e de novo por cima da vigia da nuvem)
   ====================================================================== */
function instalarTravaSemCrianca(){
  const setV=Storage.prototype.setItem, remV=Storage.prototype.removeItem;
  const fantasma=k=>typeof k==='string' && k.indexOf('mundo_p0_')===0;
  Storage.prototype.setItem=function(k,v){ if(this===window.localStorage && fantasma(k)) return; return setV.call(this,k,v); };
  Storage.prototype.removeItem=function(k){ if(this===window.localStorage && fantasma(k)) return; return remV.call(this,k); };
}

/* ======================================================================
   2) TROCAR DE CRIANÇA (a mesma criança escolhida no meio do uso volta para onde estava)
   ====================================================================== */
function trocarUser(id, opc){
  if(!U.us.some(x=>x.id===id)) return;
  if(id===U.atual){
    /* a mesma criança, escolhida pelo chip no meio do uso: só volta para onde estava */
    if(opc && opc.naAbertura===false) return;
    irParaEstante(); return;
  }
  if(U.atual) saveState();     /* guarda o progresso de quem estava lendo */
  U.atual=id; salvarUsers();
  carregarDados();             /* traz o progresso e as cores da outra criança */
  applyTheme(); applyFont(); updateCsBtn(); updateFsizeBtn();
  aplicaAjustes(); applyAudioUI(); atualizaMute();
  irParaEstante();
  showToast(userAtual().av+' Agora é a vez de '+userAtual().nome+'!');
}

/* ======================================================================
   3) ID NOVO DE CRIANÇA (nunca repetido)
   ====================================================================== */
function novoIdCrianca(){
  let id='p'+Date.now();
  while(U.us.some(x=>x.id===id)) id='p'+(Date.now()+1+Math.floor(Math.random()*100000));
  return id;
}

/* ======================================================================
   4) ADAPTADOR DO CADASTRO (o que o escola-familia.js 1.2 espera do app; parte 5.2 do PLANO). entrar() já com a correção da v2.1 (sincroniza a nuvem ao trocar de criança)
   ====================================================================== */
const ADAPTADOR_CRIANCAS={
  listar(){ return U.us.map(u=>({id:u.id,nome:u.nome,av:u.av})); },
  atual(){ return U.atual; },
  /* cria SEM herdar nada e SEM trocar a criança aberta (a troca é no entrar) */
  criar(nome, av){
    const id=novoIdCrianca();
    U.us.push({id:id,nome:nome,av:av}); salvarUsers();
    return id;
  },
  mudar(id, nome, av){
    const u=U.us.find(x=>x.id===id); if(!u) return;
    u.nome=nome; u.av=av; salvarUsers();
    atualizaChipUser();
  },
  /* tudo da criança (para a lixeira do celular): as 22 chaves, igual à nuvem */
  exportar(id){
    if(!U.us.some(x=>x.id===id)) throw new Error('criança não existe neste celular');
    return nuvemExportar(id);
  },
  /* devolve da lixeira: JUNTA (mesma regra da nuvem), nunca substitui */
  importar(id, dados){ nuvemMesclar(id, dados||{}, false); },
  /* tira SÓ deste celular. Ordem: 1º sai da lista (a vigia da nuvem deixa de
     reconhecer as chaves), depois as chaves são apagadas (o escola-familia.js
     chama isto com a vigia desligada) */
  tirar(id){
    const eraAtual=(U.atual===id);
    U.us=U.us.filter(x=>x.id!==id);
    /* era a criança aberta: fica "sem criança" (nada mais grava) até a página recarregar */
    if(eraAtual) U.atual=null;
    salvarUsers();
    this.chavesDaCrianca(id).forEach(k=>{ try{ localStorage.removeItem(k); }catch(e){} });
    return {recarregar:eraAtual};
  },
  completoNaNuvem(){ return true; },
  entrar(id, opc){
    const antes=U.atual;
    trocarUser(id, opc);
    /* v2.1: trocou de criança (ou abriu o app): confere a nuvem já, para o progresso
       feito em outro celular chegar (antes isso vinha de carona na gravação do dia) */
    if(id!==antes || !(opc && opc.naAbertura===false)){
      try{ if(window.NuvemSync && NuvemSync.configurada()){ const r=NuvemSync.sincronizar(); if(r && r.catch) r.catch(()=>{}); } }catch(e){}
    }
  },
  resumo(id){
    const n=curiosidadesLidasDe(id);
    return {linha:'🌍 '+n+' de '+TOTAL_CUR, barra:TOTAL_CUR?n/TOTAL_CUR:0};
  },
  resumoDados(d){
    let n=0;
    try{ const l=JSON.parse((d&&d.lidas)||'{}')||{}; for(const c in l) n+=(String(l[c]||'').match(/1/g)||[]).length; }catch(e){}
    return '🌍 '+n+' curiosidade(s) lida(s)';
  },
  /* TODAS as chaves da criança: as do backup (CHAVES_DADOS) e as da nuvem (+ ultimoDia/seqDias) */
  chavesDaCrianca(id){ return CHAVES_NUVEM.map(n=>'mundo_'+id+'_'+n); }
};

/* ======================================================================
   5) EXPORTAR / JUNTAR COM A NUVEM (nuvemMesclar blindado + regra "celular vazio" da v2.0b com PREFS_LOCAIS)
   ====================================================================== */
function nuvemExportar(id){
  const o={};
  CHAVES_NUVEM.forEach(n=>{ try{ const v=localStorage.getItem('mundo_'+id+'_'+n); if(v!==null) o[n]=v; }catch(e){} });
  return o;
}

function nuvemMesclar(id, dn, restaurando){
  /* v2.0: só junta numa criança que está na lista deste celular (uma resposta
     da nuvem que chega depois de a criança sair não regrava as chaves dela) */
  if(!U.us.some(u=>u.id===id)) return;
  if(!dn || typeof dn!=='object') dn={};
  const P='mundo_'+id+'_';
  const get=n=>{ try{ return localStorage.getItem(P+n); }catch(e){ return null; } };
  const set=(n,v)=>{ try{ localStorage.setItem(P+n,v); }catch(e){} };
  const Jp=(t,d)=>{ try{ const v=JSON.parse(t); return (v===null||v===undefined||typeof v!=='object')?d:v; }catch(e){ return d; } };
  const obj=v=>(v && typeof v==='object' && !Array.isArray(v)) ? v : {};
  const lista=v=>Array.isArray(v) ? v : [];
  /* v2.0: cada parte fica no seu try — um dado estragado nunca para a junção no meio */
  /* lidas: fica marcada se estiver marcada em QUALQUER um dos lados */
  let lL={};
  try{
    lL=obj(Jp(get('lidas'),{})); const lN=obj(Jp(dn.lidas,{}));
    /* leitor que ainda não leu nada neste celular (acabou de ser cadastrado
       ou os dados foram apagados) adota também as preferências da nuvem.
       v2.0b: SÓ se ele também não tem nenhuma preferência gravada aqui — senão
       uma preferência que o adulto acabou de mudar neste celular (ex.: "destacar
       por sílabas") voltava ao valor do outro celular assim que a nuvem juntava. */
    const PREFS_LOCAIS=['theme','font','caps','fsize','cfgHi','cfgSyl','cfgAudio','voz','modoLinha','ajustes','sayTap','margem','recuo','palavra'];
    if(!restaurando && !Object.keys(lL).some(c=>/1/.test(String(lL[c]||''))) && PREFS_LOCAIS.every(n=>get(n)===null)) restaurando=true;
    for(const c in lN){
      const a=String(lL[c]||''), b=String(lN[c]||''); let r='';
      for(let i=0;i<Math.max(a.length,b.length);i++) r+=(a[i]==='1'||b[i]==='1')?'1':'0';
      lL[c]=r;
    }
    set('lidas',JSON.stringify(lL));
  }catch(e){}
  /* favoritas, palavras aprendidas, festejos já vistos: junta os dois */
  CHAVES_OBJ_NUVEM.forEach(n=>{
    try{
      if(dn[n]===undefined) return;
      set(n, JSON.stringify(Object.assign({}, obj(Jp(dn[n],{})), obj(Jp(get(n),{})))));
    }catch(e){}
  });
  /* onde parou em cada assunto */
  try{
    if(dn.posPais!==undefined){
      const a=obj(Jp(get('posPais'),{})), b=obj(Jp(dn.posPais,{}));
      set('posPais', JSON.stringify(restaurando ? Object.assign({},a,b) : Object.assign({},b,a)));
    }
  }catch(e){}
  /* últimas lidas: junta, sem repetir, só as que continuam marcadas */
  try{
    if(dn.ultimasLidas!==undefined){
      const a=lista(Jp(get('ultimasLidas'),[])), b=lista(Jp(dn.ultimasLidas,[]));
      const tudo=(restaurando? b.concat(a) : a.concat(b)), vistos={}, fim=[];
      tudo.forEach(x=>{ if(!x||!x.code) return; const k=x.code+':'+x.idx;
        if(vistos[k]) return; vistos[k]=1;
        if(String(lL[x.code]||'')[x.idx]==='1') fim.push({code:x.code,idx:x.idx}); });
      set('ultimasLidas', JSON.stringify(fim.slice(0,10)));
    }
  }catch(e){}
  /* cores, letra, onde parou: numa recuperação vêm da nuvem;
     no dia a dia, o que está neste celular manda */
  CHAVES_SIMPLES_NUVEM.forEach(n=>{
    try{
      if(dn[n]===undefined || dn[n]===null || typeof dn[n]==='object') return;
      if(restaurando || get(n)===null) set(n, String(dn[n]));
    }catch(e){}
  });
  /* se for quem está lendo agora, atualiza a tela */
  if(id===U.atual){
    try{
      if(restaurando){
        carregarDados();
        applyTheme(); applyFont(); updateCsBtn(); updateFsizeBtn();
        aplicaAjustes(); applyAudioUI(); atualizaMute();
      } else {
        resincronizarDoDisco();
      }
      if(!document.getElementById('home').classList.contains('hidden')) buildHome();
    }catch(e){}
  }
}

/* ======================================================================
   6) BACKUP QUE JUNTA (nunca apaga antes de gravar; sem alert/confirm)
   ====================================================================== */
function criancasDoBackup(b){
  const us=(b && b.usuarios && Array.isArray(b.usuarios.us)) ? b.usuarios.us : [];
  const dados=(b && b.dados && typeof b.dados==='object') ? b.dados : {};
  const r=[];
  us.forEach(u=>{
    if(!u || typeof u.id!=='string' || typeof u.nome!=='string' || !u.nome.trim() || typeof u.av!=='string' || !u.av) return;
    const bruto=dados[u.id], d={};
    if(bruto && typeof bruto==='object') CHAVES_NUVEM.forEach(k=>{
      const v=bruto[k];
      if(typeof v==='string') d[k]=v; else if(typeof v==='number' && isFinite(v)) d[k]=String(v);
    });
    r.push({nome:u.nome, av:u.av, dados:d});
  });
  return r;
}

function aplicarBackup(backup){
  const lista=criancasDoBackup(backup);
  const famAtual=(window.EscolaFamilia && EscolaFamilia.familiaAtual) ? EscolaFamilia.familiaAtual() : '';
  const naFam=x=>!window.EscolaFamilia || !EscolaFamilia.familiaDe(x.id) || EscolaFamilia.familiaDe(x.id)===famAtual;
  let juntadas=0, novas=0, puladas=0;
  lista.forEach(c=>{
    const ch=chaveLeitor(c.nome, c.av);
    const local=U.us.find(x=>naFam(x) && chaveLeitor(x.nome,x.av)===ch);
    let id;
    if(local){ id=local.id; juntadas++; }
    else{
      if(U.us.filter(naFam).length>=MAX_USERS){ puladas++; return; }
      /* primeiro a criança entra na lista, depois junta (regra da nuvem 4.1) */
      id=novoIdCrianca(); U.us.push({id:id, nome:c.nome, av:c.av}); salvarUsers(); novas++;
    }
    nuvemMesclar(id, c.dados, false);
    try{ if(window.NuvemSync && NuvemSync.configurada()) NuvemSync.marcarPendente(id); }catch(e){}
  });
  showToast('✅ Backup juntado: '+juntadas+' criança(s) juntada(s), '+novas+' nova(s)'+(puladas?(', '+puladas+' não coube(ram)'):''));
  setTimeout(()=>{ try{ location.reload(); }catch(e){} },1500);
  return {juntadas:juntadas, novas:novas, puladas:puladas};
}

function perguntaApp(o){
  return new Promise(res=>{
    const ov=document.getElementById('perguntaOv');
    const sim=document.getElementById('perguntaSim'), nao=document.getElementById('perguntaNao');
    document.getElementById('perguntaTitulo').textContent=o.titulo||'';
    const p=document.getElementById('perguntaTexto'); p.textContent='';
    (o.linhas||[]).forEach((l,i)=>{ if(i) p.appendChild(document.createElement('br')); p.appendChild(document.createTextNode(l)); });
    sim.textContent=o.sim||'OK'; nao.textContent=o.nao||'Cancelar';
    nao.style.display=(o.nao===false)?'none':'';
    const fim=v=>{ ov.classList.remove('open'); sim.onclick=null; nao.onclick=null; ov.onclick=null; res(v); };
    sim.onclick=()=>fim(true); nao.onclick=()=>fim(false);
    ov.onclick=e=>{ if(e.target===ov) fim(false); };
    ov.classList.add('open');
  });
}

/* ======================================================================
   7) LIGAÇÃO (ordem: escola-familia.js → nuvem-sync.js → trava → chip/bolinha/seção)
   ====================================================================== */
/* ---------- liga o cadastro da família, a nuvem e o escola-pwa.js ----------
   ORDEM (igual ao Alfabetização v123): 1) escola-familia.js (migração: só
   acrescenta a chave escola_familia); 2) nuvem-sync.js (cada criança sobe para
   a pasta da família DELA); 3) a trava "sem criança" por cima da vigia da nuvem. */
if(window.EscolaFamilia){
  EscolaFamilia.iniciar({
    app: APP_NUVEM, nomeApp:'Curiosidades do Mundo', iconeApp:'🌍', maxPorFamilia: MAX_USERS,
    criancas: ADAPTADOR_CRIANCAS,
    passoExtra: null,
    aoAbrirTelas(){ try{ speechSynthesis.cancel(); }catch(e){} },
    aoFecharTelas(){ ajustarBarrasDeCima(); },
    /* ⚙️ na "Quem vai estudar hoje?": as Configurações do app abrem por cima.
       aoFechar é chamado quando elas e o que foi aberto a partir delas
       (Dicionário, pergunta do backup…) fecharem */
    abrirConfig(aoFechar){
      openCfg();
      const algum=()=>{
        const ab=i=>{ const e=document.getElementById(i); return !!(e && e.classList.contains('open')); };
        const pal=document.getElementById('palavras');
        return ab('cfgOv') || ab('perguntaOv') || !!(pal && !pal.classList.contains('hidden'));
      };
      clearInterval(window._efVigiaCfg);
      window._efVigiaCfg=setInterval(()=>{ if(!algum()){ clearInterval(window._efVigiaCfg); try{ aoFechar(); }catch(e){} } },250);
    },
    fecharConfig(){
      clearInterval(window._efVigiaCfg);
      closeCfg();
    }
  });
}
if(window.NuvemSync){
  NuvemSync.aoMudar(()=>{ atualizaAvisoVersoes(); });
  NuvemSync.iniciar({
    app: APP_NUVEM,
    usuarios: ()=>{ const l=U.us.map(u=>({id:u.id,nome:u.nome,av:u.av})); return window.EscolaFamilia ? EscolaFamilia.paraNuvem(l) : l; },
    idDaChave: nuvemIdDaChave,
    exportar: nuvemExportar,
    mesclar: nuvemMesclar
  });
}
/* a trava "sem criança" volta POR CIMA da vigia da nuvem (que trocou o setItem/removeItem) */
instalarTravaSemCrianca();
if(window.EscolaFamilia){
  EscolaFamilia.montarChip(document.getElementById('efChipHome'));
  EscolaFamilia.montarChip(document.getElementById('efChipLeitura'));
  EscolaFamilia.montarPonto(document.getElementById('cfgGearHome'));
  EscolaFamilia.montarPonto(document.getElementById('gear'));
  EscolaFamilia.montarSecaoConfig(document.getElementById('cfgFamilia'));
}

