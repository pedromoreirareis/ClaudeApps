/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
// carrega o módulo CorujaLogic direto do index.html (mesmo método dos testes)
const fs = require('fs');
module.exports = function(caminho){
  const html = fs.readFileSync(caminho || process.env.CORUJA_INDEX || require('path').join(__dirname, '..', 'pacote-netlify', 'index.html'), 'utf8');
  const linhas = html.split('\n');
  const ini = linhas.findIndex(l => l.startsWith('(function(root)'));
  const fim = linhas.findIndex(l => l.startsWith('})(typeof window'));
  const codigo = linhas.slice(ini, fim + 1).join('\n');
  const m = { exports: {} };
  new Function('module', codigo)(m);
  return m.exports;
};
