import os, sys
# roda de qualquer lugar: usa a base dos testes (testes/testes_navegador) e abre o app de pacote-netlify/ (o nuvem-config.js é trocado por um vazio e o Firebase é de mentira: nunca fala com a nuvem real)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "testes", "testes_navegador"))
os.environ.setdefault("PASTA_PACOTE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "pacote-netlify"))
import sys, json
import os; os.environ.setdefault('PORTA','8798')
from base import *
servidor()
with sync_playwright() as pw:
    b=pw.chromium.launch()
    ctx,fb=novo_contexto(b,config='vazia',largura=800,altura=360)
    p=abrir(ctx)
    print('1a abertura - chaves:', p.evaluate("()=>Object.keys(localStorage).sort()"))
    print('npOv aberto:', p.evaluate("()=>document.getElementById('npOv').classList.contains('open')"))
    p.reload(); p.wait_for_timeout(800)
    print('2a abertura - ev_perfis:', p.evaluate("()=>localStorage.getItem('ev_perfis')"))
    print('npOv aberto:', p.evaluate("()=>document.getElementById('npOv').classList.contains('open')"), 'homeOv:', p.evaluate("()=>document.getElementById('homeOv').classList.contains('open')"))
