PARA O PAI:
Interrogação: na pergunta do primeiro parágrafo, sobre engolir água do mar.
Exclamação: na frase sobre a altura que o sal do mar formaria em terra firme.
Dois-pontos: antes da explicação de onde a história do sal começa.
Reticências: na frase em que a chuva e o sol se repetem ano após ano.
Travessão: no diálogo entre a criança e o pai, no meio do texto.
Aspas em "de passagem", parênteses na explicação do vaivém, hífen em água-viva, crase em "à beira do mar" e a lista com • aparecem ao longo do texto.

TÍTULO: 🌊 Por que a água do mar é salgada?

TAGS: mar, sal, água, oceano, rios, evaporação, natureza, ciência

TEXTO:
Você já tomou um caldo no mar e engoliu um pouquinho de água sem querer? Aquele gosto forte, que faz a gente fazer careta, tem uma história que começa bem longe da praia: começa na chuva.

Quando chove, a água não cai só em cima do mar. Ela cai nas pedras, nos morros e no chão do lugar onde você mora. A água da chuva é um pouquinho ácida, tão pouco que você nem sente. Mesmo assim, gota por gota, ela vai dissolvendo pedacinhos minúsculos das rochas.

Esses pedacinhos são levados pelos rios. Todo rio está fazendo uma viagem em direção ao mar, carregando sais que raspou das pedras pelo caminho. Chegando lá, a água do rio se junta à do mar e a viagem termina.

Mas aí vem a parte mais surpreendente. O sol esquenta a superfície do mar e evapora a água, só a água. O sal não evapora: ele fica. Aí chove de novo, o rio traz mais sal, o sol evapora mais água, e o sal fica outra vez...

Isso acontece há bilhões de anos. Sabe quanto sal já se juntou? Se alguém tirasse todo o sal do mar e espalhasse por cima da terra firme, ele formaria uma camada mais alta que um prédio de cinquenta andares!

— Pai, se o rio leva sal para o mar, por que a água do rio não é salgada?

— Porque no rio a água está sempre "de passagem". Ela chega e vai embora, e não dá tempo de o sal se acumular.

— E por que o mar não fica cada vez mais salgado, então?

— Porque parte do sal gruda no fundo e vira rocha de novo (um vaivém que se equilibra ao longo de muito tempo).

Nem todo mar é igualmente salgado. Isso depende de três coisas:

• quanto sol e calor o lugar recebe, porque o calor evapora mais água;

• quantos rios deságuam ali, trazendo água doce;

• se existe gelo derretendo por perto, o que também adoça a água.

É por isso que a vida no mar é do jeito que é. Um peixe de água doce colocado no mar passaria muito mal, e o contrário também. Cada bicho, do menorzinho até a água-viva, nasceu ajustado ao sal do lugar onde vive.

Da próxima vez que você estiver à beira do mar, lembre: aquele gosto salgado é feito de pedacinhos de montanhas que os rios levaram embora, bem devagar, durante um tempo que a gente nem consegue imaginar.

PALAVRAS NOVAS:
ácida = um líquido com gosto meio azedo, parecido com o do limão.
superfície = a parte de cima de alguma coisa, aquela que a gente enxerga e toca.
dissolver = é quando uma coisa some dentro da água e fica misturada nela, como o açúcar que você mexe no copo e não consegue mais ver. Ele continua ali, e é por isso que a água fica doce.
evaporar = é quando a água esquenta e vira um vapor invisível que sobe para o céu. É o mesmo que acontece com a roupa no varal: ela seca porque a água foi embora pelo ar, sem ninguém ver.
acumular = é ir juntando aos poucos, um pouquinho de cada vez, até virar bastante. Acontece igual com as moedas de um cofrinho: cada uma sozinha é pouca coisa, mas depois de muito tempo vira um montão.
deságuam = é quando os rios terminam a viagem deles e despejam toda a água que carregam dentro de outro lugar, como o mar.

PERGUNTAS:
1) De onde vem o sal que está no mar?
a) Do fundo do mar, que já nasceu salgado.
b) Das rochas, dissolvidas pela chuva e levadas pelos rios. *
c) Do sol, que derrete o sal em cima da água.
> A chuva vai soltando pedacinhos de sal das pedras, e os rios carregam tudo isso até o mar. O sal chega lá aos poucos, vindo de bem longe.

2) Por que o mar vai ficando salgado, mesmo recebendo tanta água doce dos rios?
a) Porque o sol evapora a água, mas o sal fica para trás. *
b) Porque a chuva já cai salgada em cima do mar.
c) Porque os peixes soltam sal dentro da água.
> Quando o sol esquenta o mar, só a água vira vapor e sobe. O sal não consegue subir junto, e vai se juntando ali ano após ano.

3) Juntando o que o pai explicou com o que o sol faz, por que a água do rio não é salgada como a do mar?
a) Porque o rio tem menos peixes do que o mar.
b) Porque no rio a água está de passagem e o sal não tem tempo de se acumular. *
c) Porque a chuva cai só nos rios e nunca no mar.
> No rio a água chega e vai embora rapidinho, levando o sal junto. No mar ela fica parada, o sol evapora só a água, e é essa demora que deixa o sal se acumulando.

PARA PENSAR:
O que você acha que aconteceria com o mar se todos os rios do mundo parassem de correr? E se nunca mais chovesse em lugar nenhum?
