"""Ajudantes para as telas do escola-familia.js (cadastro da família, v122)."""
import json

def aberta(p, cls):
    return p.evaluate("c=>!!document.querySelector('#efRaiz .'+c)", cls)

def toast(p):
    return (p.evaluate("(document.getElementById('efToast')||{}).textContent||''") or '') + ' | ' + (p.text_content('#toast') or '')

def textos(p):
    return p.evaluate("EscolaFamilia.TEXTOS")

def perfis(p):
    from base import ls
    return json.loads(ls(p, 'ev_perfis') or '{"perfis":[]}')

def estado_familia(p):
    from base import ls
    return json.loads(ls(p, 'escola_familia') or 'null')

def fechar_app_popups(p):
    """fecha os pop-ups do app (cadastrar parentes, bem-vindo) clicando no 'não'."""
    for _ in range(3):
        if p.evaluate("document.getElementById('cfmOv').classList.contains('open')"):
            p.click('#cfmNao'); p.wait_for_timeout(300)

def fechar_tudo(p):
    p.evaluate("""()=>{ try{ EscolaFamilia.fecharTudo(); }catch(e){}
      ['cfmOv','hubOv','qzOv','cfgOv','famOv'].forEach(i=>{const e=document.getElementById(i); if(e) e.classList.remove('open');}); }""")
    p.wait_for_timeout(150)

def esperar_recarga(p, ms=4000):
    p.wait_for_timeout(ms)
    p.wait_for_load_state('load')
    p.wait_for_timeout(700)

def segurar(p, seletor, ms=3300):
    """trava do adulto: segura o botão por 3 s"""
    loc = p.locator(seletor).first
    loc.scroll_into_view_if_needed()
    bb = loc.bounding_box()
    p.mouse.move(bb['x'] + bb['width'] / 2, bb['y'] + bb['height'] / 2)
    p.mouse.down(); p.wait_for_timeout(ms); p.mouse.up()
    p.wait_for_timeout(300)

def cadastrar_t5(p, nome, bicho_idx, esperar=True):
    p.fill('#efRaiz .ef-nome-campo', nome)
    p.locator('#efRaiz .ef-bicho').nth(bicho_idx).click()
    vis = p.evaluate("(()=>{const b=document.querySelector('#efRaiz .ef-pronto'); return !!(b && b.offsetParent);})()")
    p.click('#efRaiz .ef-pronto' if vis else '#efRaiz .ef-pronto-mini')
    if esperar:
        esperar_recarga(p)

def nova_crianca(p, nome, bicho_idx, fam=None):
    """abre a T5 (➕ Nova criança) e cadastra; depois recusa o pop-up dos parentes"""
    if fam is None:
        p.evaluate("EscolaFamilia.abrir('nova')")
    else:
        p.evaluate("f=>EscolaFamilia.abrir('nova', f)", fam)
    p.wait_for_timeout(300)
    cadastrar_t5(p, nome, bicho_idx)
    fechar_app_popups(p)

def familia_json(fams, criancas, atual, extra=None):
    st = {"v": 1, "familias": [{"c": c, "desde": 1, "conferida": True, "origem": "teste"} for c in fams],
          "criancas": criancas, "atual": atual, "ultimoNuvemFamilia": atual, "primeiraAberturaEm": 1,
          "liberouSegundaFamilia": False, "mudancasPendentes": [], "recusas": {}}
    if extra: st.update(extra)
    return json.dumps(st)

def ponto_cfg(p):
    return p.evaluate("(document.querySelector('#btnCfg .ef-ponto')||{}).className||''")

def status_txt(p):
    return p.evaluate("EscolaFamilia.situacao()")

OFFLINE_INIT = """(function(){ const g=Storage.prototype.getItem, st=Storage.prototype.setItem;
  Object.defineProperty(Navigator.prototype,'onLine',{configurable:true,get(){ try{ return g.call(sessionStorage,'__off')!=='1'; }catch(e){ return true; } }});
  window.__offline=function(v){ st.call(sessionStorage,'__off',v?'1':'0'); window.dispatchEvent(new Event(v?'offline':'online')); };
})();"""
def instalar_offline(ctx):
    """'sem internet' que sobrevive ao recarregar a página (no celular o service worker abre o app)"""
    ctx.add_init_script(OFFLINE_INIT)

def offline(p, fb, sim):
    fb.offline = bool(sim)
    p.evaluate("v=>window.__offline(v)", bool(sim))
    p.wait_for_timeout(200)
