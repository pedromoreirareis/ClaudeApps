# Prompts do Coruja Explica (v1.7)

Cópia exata dos pedidos que o botão 🤖 PROMPT e o menu ▾ colocam na área de
transferência. Gerado a partir do próprio código do aplicativo, então não tem
como estar diferente do que o app copia.

---

## 1. Gerar um texto novo (botão 🤖 PROMPT)

Substitua o trecho entre colchetes pelo assunto que você quiser.

```
Você vai escrever um texto para uma criança ler em voz alta junto com o pai.
O texto será colado num aplicativo de leitura, então siga EXATAMENTE o formato
que está no final deste pedido.

ASSUNTO: [escreva aqui o assunto, com o máximo de detalhes que quiser]
IDADE: 6 anos
NÍVEL DE LEITURA: lê bem, como uma criança de 12 anos

O OBJETIVO
Quando terminar de ler, a criança precisa ter ENTENDIDO o assunto — não ter
ouvido falar dele. Se faltar uma peça para a explicação fechar, coloque a
peça. Se o assunto já estiver explicado, pare de escrever.

O TAMANHO QUEM DECIDE É O ASSUNTO
1. Não existe cota de parágrafos. Um assunto simples ("por que o gelo
   derrete") fica bem resolvido em 5 ou 6 parágrafos. Um assunto grande
   ("o que acontece no corpo quando a gente corre") pode precisar de 15.
2. Nunca encha linguiça: repetir a mesma ideia com outras palavras, enfeitar
   sem explicar nada ou alongar a conclusão cansa a criança e faz ela largar
   o texto no meio.
3. Nunca corte no meio: se a explicação precisa de mais um passo para fazer
   sentido, escreva esse passo.
4. Antes de terminar, confira: uma criança de 6 anos que leu SÓ este
   texto conseguiria explicar o assunto para outra pessoa? Se não conseguiria,
   falta alguma coisa.

O QUE FAZ O TEXTO PRENDER A ATENÇÃO
Um texto correto mas sem graça falhou. Escreva como quem conta uma coisa
fascinante para alguém de quem gosta muito — não como quem explica matéria.
5. Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
   criança consiga sentir no próprio corpo ou ver dentro da própria casa.
   Nunca comece com "Neste texto vamos aprender sobre...".
6. Coloque pelo menos dois momentos de "nossa, eu não sabia disso!": fatos
   verdadeiros e surpreendentes, contados de um jeito que dê vontade de sair
   contando para outra pessoa.
7. Transforme números e tamanhos em coisas imagináveis. "Caberia um milhão de
   Terras dentro do Sol" vale muito mais do que "o Sol tem 1,4 milhão de
   quilômetros de diâmetro".
8. Toda explicação difícil vem junto com uma comparação com o mundo dela:
   cozinha, banho, escola, bicicleta, futebol, bichos, comida, chuva, o
   próprio corpo, o quintal, o interior do Brasil.
9. Uma ideia de cada vez: apresente, explique, compare — e só então siga em
   frente. Nunca empilhe três conceitos novos no mesmo parágrafo.
10. Fale diretamente com a criança, usando "você".
11. Termine com uma ideia que ela leve para a vida ou que a faça olhar para
    algo do dia a dia com outros olhos. Sem lição de moral pesada.

SINAIS DA ESCRITA QUE O TEXTO DEVE CONTER
A criança está aprendendo os sinais da escrita, e o pai aponta cada um durante
a leitura. Por isso eles precisam aparecer de forma natural — nunca forçada.
Se algum não couber com naturalidade neste assunto, deixe de fora.
12. Ponto final, vírgula, interrogação e exclamação.
13. Dois-pontos, abrindo uma fala ou uma explicação.
14. Reticências, marcando uma pausa ou uma ideia que fica no ar.
15. Um diálogo curto (2 a 4 falas) usando travessão. Cada fala fica sozinha na
    sua própria linha, com uma linha em branco antes e depois.
16. Aspas, num pensamento ou numa fala repetida do jeito exato.
17. Parênteses, com uma explicação extra que cabe dentro da frase.
18. Pelo menos uma palavra com hífen (bem-estar, guarda-chuva).
19. Palavras com acento agudo, com circunflexo e com til.
20. Pelo menos uma crase (à), num lugar em que ela seja realmente correta.
21. Uma lista de 3 itens, cada item numa linha começando com o sinal •
22. Cada parágrafo é uma ideia, separado por uma linha em branco.

COMO ESCREVER AS FRASES
23. Português do Brasil, com ortografia, acentuação e pontuação impecáveis. A
    criança aprende a escrever certo lendo este texto — um erro aqui ensina
    errado.
24. Frases de tamanho variado, a maioria entre 8 e 18 palavras. Uma ideia por
    frase. Evite frases com mais de 25 palavras.
25. Números até vinte, escreva por extenso.

PALAVRAS NOVAS — O DICIONÁRIO DO APLICATIVO
No aplicativo a criança toca numa palavra e aparece só a explicação dela, sem
o texto em volta. Então cada explicação precisa se sustentar sozinha.
26. Inclua TODAS as palavras que uma criança de 6 anos provavelmente
    não conhece. Na dúvida, inclua.
27. O tamanho da explicação acompanha a DIFICULDADE da palavra, e nada mais:

    • Palavra fácil, do dia a dia, que ela só talvez não saiba: UMA frase
      curta e direta. Não alongue.
      Exemplo: alerta = quando o corpo fica ligado e pronto para agir.

    • Palavra difícil ou ideia abstrata, que exige imaginar algo novo: 2 ou 3
      linhas, nesta ordem — o que é em palavras simples, uma comparação com
      algo que ela conhece, e onde ela vê isso na vida dela.
      Exemplo: atmosfera = é a camada de ar que fica em volta de um planeta
      inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar
      que você respira e que faz as estrelas cadentes brilharem antes de
      chegar aqui embaixo.

28. Explicação comprida numa palavra fácil cansa, e a criança para de tocar
    nas palavras. Explicação curta numa palavra difícil deixa ela sem
    entender. Meça pelo esforço que a palavra exige dela.
29. Nunca explique uma palavra difícil usando outra palavra difícil.
30. Escreva sempre no formato:  palavra = explicação

TAGS — PARA ACHAR O TEXTO DEPOIS
31. Escreva de 5 a 8 palavras-chave, separadas por vírgula, que o pai digitaria
    para reencontrar este texto daqui a seis meses: o assunto principal, a
    área (corpo humano, espaço, animais, história, plantas...) e as palavras
    que ele provavelmente lembraria.
32. As tags não aparecem para a criança — servem só para a busca.

PERGUNTAS — O QUIZ DO FINAL
Terminada a leitura, o aplicativo mostra três perguntas para a criança
responder tocando na resposta. Elas medem se ela ENTENDEU, não se decorou.
33. Faça exatamente 3 perguntas, na ordem em que os assuntos aparecem no texto.
34. Cada pergunta tem 3 alternativas. Marque a certa com um asterisco no fim.
35. As alternativas erradas precisam ser possíveis — enganos que uma criança
    realmente cometeria. Nada de alternativa boba ou de brincadeira: isso
    ensina a chutar em vez de pensar.
36. Depois das alternativas, escreva uma linha começando com > explicando, com
    carinho, por que a resposta certa é a certa. É o que a criança lê quando
    erra, então essa linha precisa ensinar, não corrigir.
37. Pelo menos uma das três perguntas deve exigir juntar duas partes
    diferentes do texto, e não só achar uma frase pronta.

CUIDADOS COM O CONTEÚDO
38. Seja fiel à ciência. Não invente fatos, números, nomes nem datas. Se algo
    ainda não se sabe, escreva que os cientistas continuam estudando.
39. Deixe claro, com respeito, a diferença entre ciência comprovada, crença ou
    tradição (astrologia, signos, simpatias) e lenda. Use frases como "os
    cientistas descobriram que...", "algumas pessoas acreditam que..." e
    "uma lenda antiga conta que...".
40. Religiões: conte como cada uma acredita, com respeito, sem dizer qual é a
    certa.
41. Saúde e corpo: explique como o corpo funciona. Não fale de remédios,
    doses, diagnósticos nem tratamentos. Lembre que quem cuida disso é o
    médico junto com a família.
42. Temas difíceis (doença, morte, guerra, desastres): conte a verdade com
    carinho, sem detalhes assustadores, e termine acolhendo.
43. Coisas perigosas (fogo, eletricidade, remédios, produtos de limpeza,
    bichos peçonhentos): explique e lembre que só se mexe nisso com um adulto.
44. Nada de propaganda, marcas ou opinião política.

REGRAS DE FORMATAÇÃO (o aplicativo depende delas)
45. Não use negrito, itálico, asteriscos, #, tabelas, listas numeradas, links
    nem "Fonte:". O único asterisco permitido é o que marca a alternativa
    certa nas PERGUNTAS.
46. Emoji, só na linha do TÍTULO. Nunca dentro do texto.
47. Letras normais: maiúscula só no começo das frases e nos nomes próprios.
    NÃO escreva nada todo em maiúsculas.
48. Uma linha em branco entre cada parágrafo, entre cada fala do diálogo e
    antes de cada item da lista com •

FORMATO DA RESPOSTA

Primeiro, escreva para o pai (o aplicativo ignora tudo o que vier antes de
TÍTULO:):

PARA O PAI: [em até 6 linhas, quais sinais da escrita aparecem no texto e em
qual frase cada um está, para ele saber o que apontar durante a leitura]

Depois, escreva o bloco do texto, com os rótulos exatamente assim:

TÍTULO: [um emoji] [título curto, de preferência uma pergunta curiosa]

TAGS: [de 5 a 8 palavras-chave separadas por vírgula]

TEXTO:
[os parágrafos, o diálogo com travessão e a lista com •, tudo separado por
linhas em branco]

PALAVRAS NOVAS:
[uma palavra por linha, com a explicação no tamanho certo para a dificuldade
dela, assim:]
palavra = explicação

PERGUNTAS:
1) [a pergunta]
a) [alternativa]
b) [alternativa certa] *
c) [alternativa]
> [por que a certa é a certa, com carinho]

2) [a pergunta]
a) [alternativa certa] *
b) [alternativa]
c) [alternativa]
> [por que a certa é a certa]

3) [a pergunta]
a) [alternativa]
b) [alternativa]
c) [alternativa certa] *
> [por que a certa é a certa]

PARA PENSAR:
[uma ou duas perguntas abertas, de conversa com o pai, que não têm resposta
certa ou errada]

Não escreva mais nada depois de PARA PENSAR.
```

---

## 2. Adaptar um texto pronto (menu ▾)

O aplicativo cola o texto original no lugar do {{TEXTO}} automaticamente.

```
Reescreva o texto do final para uma criança de 6 anos ler em voz alta
junto com o pai. Não é para resumir: é para contar de novo, de um jeito que
prenda a atenção dela e que ela entenda de verdade.

COMO REESCREVER
1. Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
   criança consiga sentir no corpo ou ver dentro de casa.
2. Toda explicação difícil vem com uma comparação com o mundo dela: cozinha,
   banho, escola, bicicleta, bichos, comida, chuva, o próprio corpo.
3. Uma ideia por parágrafo, frases entre 8 e 18 palavras, falando com "você".
4. O tamanho quem decide é o assunto: não encha linguiça nem corte no meio.
   Ao terminar, a criança precisa conseguir explicar o assunto para alguém.
5. Mantenha apenas as ideias que estão no texto original e que são corretas.
   Não acrescente fatos novos que não estejam lá.

SINAIS DA ESCRITA (de forma natural, nunca forçada)
6. Um diálogo curto com travessão, cada fala sozinha na sua linha, com linha
   em branco antes e depois; aspas; parênteses; reticências; dois-pontos; uma
   palavra com hífen; acentos agudo, circunflexo e til; uma crase; e uma lista
   de 3 itens, cada um numa linha começando com •

PALAVRAS NOVAS (o dicionário do aplicativo)
7. Inclua TODAS as palavras que uma criança de 6 anos provavelmente
   não conhece. Na dúvida, inclua.
8. O tamanho da explicação acompanha a dificuldade da palavra:
   • fácil: uma frase curta e direta. Ex.: alerta = quando o corpo fica ligado
     e pronto para agir.
   • difícil ou abstrata: 2 ou 3 linhas — o que é em palavras simples, uma
     comparação com algo conhecido e onde ela vê isso na vida dela.
9. Nunca explique uma palavra difícil usando outra palavra difícil.

TAGS
10. De 5 a 8 palavras-chave separadas por vírgula, para o pai reencontrar este
    texto depois. Não aparecem para a criança.

PERGUNTAS
11. Exatamente 3 perguntas de interpretação, cada uma com 3 alternativas. A
    certa leva um asterisco no fim. As erradas precisam ser enganos possíveis,
    nunca alternativas bobas. Depois das alternativas, uma linha começando com
    > explicando com carinho por que a certa é a certa.

FORMATAÇÃO
12. Sem negrito, sem #, sem listas numeradas e sem emoji fora do TÍTULO. Uma
    linha em branco entre cada parágrafo. O único asterisco permitido é o que
    marca a alternativa certa.

Responda somente com este bloco, nesta ordem: PARA O PAI, TÍTULO, TAGS, TEXTO,
PALAVRAS NOVAS, PERGUNTAS e PARA PENSAR, exatamente com esses rótulos. Nas
PERGUNTAS use o formato:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa

Não escreva nada depois de PARA PENSAR.

TEXTO ORIGINAL:
[o texto que você colar na caixinha entra aqui]
```

---

## 3. Continuar o mesmo assunto (menu ▾)

Para usar na MESMA conversa com a IA, logo depois de um texto pronto.

```
Continue o mesmo assunto explicando agora [a próxima pergunta que você digitar],
com as mesmas regras e exatamente o mesmo formato de antes, incluindo TAGS e
PERGUNTAS. Não repita o que já foi explicado.

Lembretes: comece com um gancho que dê curiosidade; toda explicação difícil
vem com uma comparação com o mundo da criança; o tamanho quem decide é o
assunto; em PALAVRAS NOVAS o tamanho da explicação acompanha a dificuldade da
palavra (fácil = uma frase; difícil = 2 ou 3 linhas com comparação); e as 3
perguntas do final precisam ter alternativas erradas que sejam enganos
possíveis, com a linha > explicando a certa.
```

---

## 4. Consertar o formato (menu ▾)

Para quando a IA responder fora do formato combinado.

```
Sua resposta saiu do formato combinado. Reescreva exatamente no formato
PARA O PAI / TÍTULO / TAGS / TEXTO / PALAVRAS NOVAS / PERGUNTAS / PARA PENSAR,
com uma linha em branco entre os parágrafos e entre cada fala do diálogo, sem
negrito, sem #, sem listas numeradas, sem emoji fora do TÍTULO e sem escrever
nada depois de PARA PENSAR.

Nas PERGUNTAS use exatamente este formato, com 3 perguntas:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa
```
