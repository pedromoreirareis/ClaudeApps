/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* v3.1 — Formatar texto solto (livro/cartilha): título e frases uma por linha */
const fs = require('fs');
const INDEX = process.env.CORUJA_INDEX || require('path').join(__dirname, '..', 'pacote-netlify', 'index.html');
const TMP = require('path').join(process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'), '_logic_fmt.js'); require('fs').mkdirSync(require('path').dirname(TMP), { recursive: true });
const html = fs.readFileSync(INDEX, 'utf8');
const script = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m => m[1]).find(t => t.includes('(function(root)'));
const L = script.split('\n'); const i = L.findIndex(l => l.startsWith('(function(root)')); const j = L.findIndex(l => l.startsWith('})(typeof window'));
fs.writeFileSync(TMP, L.slice(i, j + 1).join('\n')); const C = require(TMP);
let f = 0, n = 0; const ok = (nome, c, d) => { n++; if (c) console.log('✅', nome); else { f++; console.log('❌', nome, d ? '— ' + d : ''); } };
const A = C.arrumarParaCaixa, T = t => C.interpretarTexto(A(t));
const CAMILA = 'CAMILA E O CAVALO.\n\nCamila tem um cavalo.\n\nO cavalo é o Caco.\n\nCamila cuida do cavalo Caco.\n\nCamila come cocada.\n\nO cavalo come capim.\n\nCamila cavalga no cavalo Caco.\n\nEla é esperta.\n\nO cavalo obedece a Camila.';
var r = T(CAMILA);
ok('"Camila e o cavalo" (colado de cartilha): vira Formato Coruja com título separado', !!C.parseFormatoCoruja(A(CAMILA)) && r.titulo === 'Camila e o cavalo', r.titulo);
ok('…o título NÃO se repete dentro do texto', !r.paragrafos.some(p => /^CAMILA E O CAVALO/i.test(p.texto)));
ok('…as 8 frases, uma por linha, viram 3 parágrafos (3+3+2), sem perder nenhuma', r.paragrafos.length === 3 && r.paragrafos.map(p => p.texto).join(' ').split(/[.!?]/).filter(x => x.trim()).length === 8, JSON.stringify(r.paragrafos));
ok('…nenhuma palavra muda', A(CAMILA).replace(/^TÍTULO:.*\n\nTEXTO:\n/, '').replace(/\s+/g, ' ') === CAMILA.split('\n\n').slice(1).join(' '));
ok('Formatar duas vezes dá o mesmo resultado', A(A(CAMILA)) === A(CAMILA));
ok('Título sem ponto e sem maiúsculas: "Camila e o cavalo" + texto', T('Camila e o cavalo\n\nCamila tem um cavalo. O cavalo é o Caco.').titulo === 'Camila e o cavalo');
ok('Título em maiúsculas guarda os nomes próprios do texto ("São Paulo", "Caco")', T('A VIAGEM DO CACO PARA SÃO PAULO\n\nO Caco foi para São Paulo com a Camila.').titulo === 'A viagem do Caco para São Paulo');
ok('Emoji no título continua', T('🐴 CAMILA E O CAVALO\n\nCamila tem um cavalo.').emoji === '🐴');
ok('Linha quebrada no meio da frase (PDF) NÃO vira título', !C.parseFormatoCoruja(A('Camila tem um cavalo e ele\né muito bonito e forte.')));
ok('Primeira frase normal com ponto NÃO vira título', !C.parseFormatoCoruja(A('Camila tem um cavalo.\nEla gosta dele.')));
ok('Pergunta na primeira linha (sem maiúsculas) NÃO vira título', !C.parseFormatoCoruja(A('Você já viu o mar?\n\nO mar é grande.')));
ok('Texto de uma linha só: sem título separado', !C.parseFormatoCoruja(A('CAMILA E O CAVALO')));
ok('Cartilha TODA em maiúsculas: a 1ª frase (com ponto) continua no texto, não vira título', !C.parseFormatoCoruja(A('CAMILA TEM UM CAVALO.\nO CAVALO É O CACO.\nELA CUIDA DELE.')) && /CAMILA TEM UM CAVALO/.test(A('CAMILA TEM UM CAVALO.\nO CAVALO É O CACO.\nELA CUIDA DELE.')));
ok('Cartilha toda em maiúsculas com título sem ponto: título separado e mantido em maiúsculas', T('CAMILA E O CAVALO\n\nCAMILA TEM UM CAVALO.\n\nO CAVALO É O CACO.').titulo === 'CAMILA E O CAVALO');
ok('Resposta de chat ("Claro! Aqui está...:") não vira título', !C.parseFormatoCoruja(A('Claro! Aqui está um texto sobre o Sol:\n\nO Sol é uma estrela.')));
ok('Título em markdown (# O Sol) vira título', T('# O Sol\n\nO Sol é uma estrela. Ele é quente.').titulo === 'O Sol');
for (const [txt, nome] of [['Era uma vez uma menina chamada\nCamila, que morava longe.', 'frase quebrada de PDF'], ['Batatinha quando nasce\nEspalha a rama pelo chão.', 'poema sem título'],
  ['A MENINA FOI À FEIRA\nCOM A MAMÃE.', 'cartilha em maiúsculas'], ['Um dia\nO menino acordou cedo.', '"Um dia"'], ['Oi amor segue o texto\nA formiga trabalha muito.', 'recado de WhatsApp']])
  ok('Sem linha em branco depois, a 1ª linha NÃO vira título (' + nome + ') e nenhuma palavra sai do texto', !C.parseFormatoCoruja(A(txt)) && A(txt).replace(/\s+/g, ' ').includes(txt.split('\n')[0].replace(/\.$/, '')), A(txt));
ok('"O CAVALO DE CAMILA": o nome continua com maiúscula mesmo só aparecendo no começo das frases', T('O CAVALO DE CAMILA\n\nCamila tem um cavalo. Camila gosta dele.').titulo === 'O cavalo de Camila', T('O CAVALO DE CAMILA\n\nCamila tem um cavalo. Camila gosta dele.').titulo);
r = T('O CÃO\n\nO cão late.\n\nEle corre.\n\nCapítulo 2\n\nUm dia o cão fugiu.\n\nEle voltou.');
ok('Subtítulo sem ponto ("Capítulo 2") não é grudado nas frases', r.paragrafos.some(p => /^Capítulo 2/.test(p.texto) && !/fugiu/.test(p.texto)), r.paragrafos.map(p => p.texto).join('|'));
const DIAL = 'O PASSEIO\n\nAna saiu cedo.\n\n— Pai, vamos?\n\n— Vamos, filha.\n\nEles andaram muito.\n\nViram um rio.';
r = T(DIAL);
ok('Falas com travessão ficam cada uma no seu parágrafo', r.paragrafos.filter(p => /^—/.test(p.texto)).length === 2, JSON.stringify(r.paragrafos));
ok('Frases soltas antes/depois das falas não atravessam as falas', r.paragrafos.map(p => p.texto).join('|') === 'Ana saiu cedo.|— Pai, vamos?|— Vamos, filha.|Eles andaram muito. Viram um rio.', r.paragrafos.map(p => p.texto).join('|'));
const LONGO = 'O SOL\n\nO Sol é uma estrela enorme que fica no centro do nosso sistema e ilumina todos os planetas que giram em volta dele todos os dias.\n\nEle é muito quente.';
r = T(LONGO);
ok('Parágrafo longo (mais de 20 palavras) não é juntado com frase curta', r.paragrafos.length === 2);
const CORUJA = 'TÍTULO: ☀️ O Sol\n\nTEXTO:\nO Sol é quente.\n\nEle brilha.';
ok('Texto já no Formato Coruja: parágrafos da IA ficam como estão', C.interpretarTexto(A(CORUJA)).paragrafos.length === 2);
console.log(`\n===== ${n - f}/${n} testes do Formatar ${f ? '— ❌ HÁ FALHAS' : '— ✅ TUDO CERTO'} =====`);
process.exit(f ? 1 : 0);
