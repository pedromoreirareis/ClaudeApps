# Relatório da conferência da passagem — 📚 Alfabetização (v121)

**Data:** 06/10/2026 · **App:** Esforço Vence — Alfabetização · **ID na nuvem:** `alfabetizacao` · **Versão:** v121 (`esforco-vence-v121`)

## O que foi RODADO de verdade × só LIDO

**Rodado de verdade (nesta passagem, 06/10/2026):**
- md5 dos 8 arquivos do zip anexado pelo Pedro × `pacote-netlify/` → idênticos.
- md5 do `nuvem-config.js`, `nuvem-sync.js` e `escola-pwa.js` × os anexados pelo Pedro em 23/09 → idênticos.
- `node --check` nos 2 `<script>` embutidos do `index.html` e nos 4 `.js` soltos; `manifest.webmanifest` é JSON válido.
- Zip montado, extraído numa pasta vazia, `npm install` e **todos os testes** a partir da pasta extraída: 89/89 + 55/55 + 75/75 + 33/33 + 58/58 = **310/310**.
- Contagem do conteúdo com o app aberto num Chromium (`trabalho/scripts/contar.py`).
- Reprodução do defeito da criança "fantasma" (`trabalho/scripts/fantasma.py`).

**Só lido no código:**
- Toda a parte de cadastro, nuvem, backup, apagar e textos dos capítulos 5 e 6 (conferidos linha a linha no `index.html`, `nuvem-sync.js` e `escola-pwa.js`).
- Riscos 6.10-2 a 6.10-8 (não reproduzidos com teste).
- Se a v121 está publicada: **não conferido** (não foi possível abrir o site).

## Camada 1 — autochecagem (pedido → prova)

| # | Pedido | Como provei | Estado |
|---|---|---|---|
| 1 | Não alterar nada no app | `pacote-netlify/` com md5 idêntico ao zip anexado (8 de 8) | ✅ |
| 2 | Cap. 1 Identificação | nome, endereço, ID, versão, cache, data, lista de arquivos com md5 tirados do pacote | ✅ |
| 3 | Cap. 2 Para quem e para quê | escrito; contagens conferidas por `contar.py` | ✅ |
| 4 | Cap. 3 Linha do tempo | v117–v121 com pedido/feito/por quê/desfeito; antes disso marcado como lembrança, com "não sei" para números exatos | ✅ |
| 5 | Cap. 4 Decisões, inclusive rejeitadas | duas tabelas (em vigor e rejeitadas) | ✅ |
| 6 | Cap. 5 Por dentro: estrutura, telas com ids, funções, dados, orientação, sw/manifest | ids conferidos no HTML; funções com `grep`; dados por `contar.py` | ✅ |
| 7 | Cap. 5 TODAS as chaves do localStorage | `grep` de `localStorage`, `getItem`, `setItem`, `_rawGet/_rawSet/_rawRemove`, literais `hana_`/`ev_`/`nuvem_`/`escola_`, chaves dinâmicas (`chaveConcluidas`), e os 2 arquivos compartilhados | ✅ |
| 8 | Cap. 5 IndexedDB e outros | `grep` sem nenhum uso de IndexedDB/sessionStorage no app e nos compartilhados | ✅ |
| 9 | Cap. 6 Cadastro, família e nuvem (todos os subitens) | textos copiados do código; fluxo de abertura lido em `_telaDeAberturaPosFam` | ✅ |
| 10 | Cap. 6 pop-ups do navegador | `grep` de `alert(`, `confirm(`, `prompt(` → só em comentários | ✅ |
| 11 | Cap. 6 riscos e defeitos | 10 itens; o 1º reproduzido de verdade | ✅ |
| 12 | Cap. 7 Regras | 12 regras | ✅ |
| 13 | Cap. 8 Aprendizados | tabela causa → solução | ✅ |
| 14 | Cap. 9 Testes (quais, quantos, como rodar, o que não cobrem, último resultado com data) | rodados de verdade em 06/10/2026 a partir do zip extraído | ✅ |
| 15 | Cap. 9 Testes/scripts PERDIDOS listados, sem reescrever | listados no cap. 9.4 e no `LEIA-ME.txt` | ✅ |
| 16 | Cap. 10 Empacotar e publicar, próximo cache | passo a passo; próximo `esforco-vence-v122` | ✅ |
| 17 | Cap. 11 Estado atual | pronto, pendente, 9 defeitos, pedidos para depois, ideias | ✅ |
| 18 | Cap. 12 Plano (1º = cadastro) | 1º item = padronização do cadastro | ✅ |
| 19 | Cap. 13 Pedro e meninas (com versões diferentes e qual é a mais nova) | Hinata e Hana com as 2–3 versões e a data de cada | ✅ |
| 20 | Cap. 14 Glossário | 26 termos | ✅ |
| 21 | PROMPT_CONTINUACAO: anexos no começo, bloco COPIE/ATÉ AQUI, "leia o HISTORICO inteiro", "O que eu quero agora" | conferido no arquivo | ✅ |
| 22 | Zip: `pacote-netlify/`, `documentos/`, `testes/`, `trabalho/`, `LEIA-ME.txt` | `unzip -l` | ✅ |
| 23 | `nuvem-sync.js`/`escola-pwa.js` = os que o app usa hoje; comparar md5 com os anexados | idênticos; registrado no cap. 1 e 11 | ✅ |
| 24 | `nuvem-config.js` byte a byte | md5 `1d5f060a5ae8339921d3d58498807971` no zip extraído | ✅ |
| 25 | `LEIA-ME.txt` com todos os arquivos, tamanho, md5, versão e data (sem ele e sem o relatório) | gerado por script a partir da pasta | ✅ |
| 26 | `node --check` | 2 blocos embutidos + 4 `.js` soltos | ✅ |
| 27 | Testes rodados | 310/310 a partir do zip extraído | ✅ |
| 28 | Conferência por 2 agentes independentes + revisor-chefe | ver as camadas 2 e 3 abaixo | ✅ (camada 2: zero 🔴/🟠 na rodada 2) |

## Camada 2 — conferência por 2 agentes independentes

Os dois agentes foram criados pela ferramenta de agentes, com contexto vazio, sem ver esta conversa. Receberam o pedido do Pedro, o zip que ele anexou, o zip montado e os 2 documentos, sem explicações. **O código do app não mudou em nenhuma correção** (md5 dos 8 arquivos conferido pelos dois agentes nas duas rodadas).

### Agente 1 — conferente do pacote (empacotamento e Netlify)

**Rodada 1** (rodou de verdade: md5, `node --check`, `npm install` + 310 testes, app aberto num Chromium sem tela com a nuvem bloqueada): 0 🔴, 1 🟠, 10 🟡.

| Achado | Gravidade | Correção feita |
|---|---|---|
| A. Depois de subir o cache, copiar só o `index.html` para `testes/` dá falso "passou" no `teste_pwa.py` (cache escrito nas linhas 102 e 113) | 🟠 | §9.2, §10 passo 4 e PROMPT: copiar `index.html`, `sw.js` e `manifest` e trocar o cache no `teste_pwa.py` |
| B. PROMPT dizia "iguais aos publicados", mas a publicação não foi confirmada | 🟡 | texto trocado |
| C. `__pycache__` dentro do zip e no LEIA-ME | 🟡 | retirado |
| D. Uma versão antiga do app existia nos anexos e estava dada como perdida | 🟡 | incluída em `trabalho/versoes_anteriores/` como "não identificada" |
| E. Documentos antigos com instruções que contradizem as atuais | 🟡 | aviso no HISTORICO (cap. 1), no PROMPT e banner no topo dos 3 documentos antigos |
| F. Faltava o guia do Firebase | 🟡 | `documentos/referencias/GUIA_FIREBASE_PASSO_A_PASSO.md` (cópia do documento do Projeto) |
| G. "2ª etiqueta `<script>`" (é a 1ª) | 🟡 | corrigido |
| H. `testes/nuvem-config.js` falso pode ser confundido; sugeriu remover | 🟡 | **não removido**: testado sem ele, o `teste_pwa.py` cai para 30/33 (o service worker guarda esse arquivo). Mantido com aviso. O agente refez o teste na rodada 2 e concordou |
| I. Avisos `requestFullscreen` no console (do próprio app) | 🟡 | registrado no cap. 11 (item 13) |
| J. `teste_10` confere a cópia de `testes/`, não o pacote | 🟡 | explicado no §9.1 |
| K. Versão do jsdom não fixa | 🟡 | "jsdom 30.1.x" |

**Rodada 2** (de novo a partir de uma extração limpa: md5 de todos os arquivos do LEIA-ME, `node --check`, 310/310 testes, app sem erro no console): **0 🔴, 0 🟠, 3 🟡** — todos corrigidos depois:
- LEIA-ME afirmava a versão da cópia antiga ("até a v93") → agora "não identificada";
- a dica 2 do guia do Firebase (recadastrar para recuperar) choca com o risco 6.10-11 → aviso no 6.10-11 e no PROMPT;
- rodar o `teste_pwa.py` com `PASTA_PACOTE=pacote-netlify` faria o service worker guardar o `nuvem-config.js` real → aviso no §9.2.

### Agente 2 — conferente do histórico (código × documentação)

**Rodada 1** (rodou o app no Chromium com o Firebase de mentira para reproduzir os 🔴; o resto lido no código): **2 🔴, 3 🟠, 9 🟡**.

| Achado | Gravidade | Correção feita |
|---|---|---|
| 1. Importar backup apaga também a nuvem: a nuvem só junta quando o último a gravar foi outro celular. Reproduzido: 10 frases → 0 no celular e na nuvem | 🔴 | risco 6.10-5 reescrito; cap. 10 passo 9 e PROMPT avisam para não importar com a nuvem ligada; cap. 11 e 12 |
| 2. Apagar e recadastrar o mesmo nome + bichinho sem internet/código sobrescreve a ficha da nuvem. Reproduzido: 6 frases → 0 | 🔴 | novo risco 6.10-11; 6.6 corrigido; cap. 11 (4b) |
| 3. O 6.7 não dizia quando a junção acontece | 🟠 | 6.7: "quando a junção acontece de verdade" |
| 4. Trocar nome/bichinho sem internet nunca junta a ficha antiga depois | 🟠 | 6.7 e risco 6.10-6 |
| 5. Faltava comparar os textos com os outros apps | 🟠 | tabela 7b no 6.10 (comparação com o `PADRAO_CADASTRO_NOME_BICHINHO.md`) |
| 6. `hana_abrirhub` nem sempre é apagada | 🟡 | 5.7-B e risco 6.10-12 |
| 7. Apagar/trocar nome agem só na criança atual; "Usuário apagado." nunca aparece pelo botão | 🟡 | 6.3-c e 6.3-e |
| 8. Faltavam mensagens (recuperar, versões, código) e o 🏠 da tela da nuvem; `#famOv` fecha sem ir ao hub | 🟡 | 6.3-f, g, h; risco 6.10-13 |
| 9. O código da família é normalizado (espaço, acento, maiúscula) | 🟡 | 6.3-h |
| 10. Cores da bolinha | 🟡 | 6.5 |
| 11. A nuvem não confere "a cada 5 minutos" | 🟡 | 6.7 |
| 12. `sessionStorage.getItem` lê do `localStorage` por causa do prefixo | 🟡 | 5.7-E, 6.2 item 6, regra 4 do cap. 7 |
| 13. "2ª etiqueta" | 🟡 | corrigido |
| 14. PROMPT sem o comando completo de sintaxe | 🟡 | PROMPT e cap. 10 |

**Rodada 2** (todos os trechos novos conferidos contra o código, que não mudou): **0 🔴, 0 🟠, 2 🟡** — corrigidos depois:
- quando a checagem é forçada (abrir, internet voltar, "🔄 Enviar agora", guardar o código; ao voltar para o app só depois de 5 minutos);
- depois de apagar, "a primeira da lista" (não "a próxima"); a ficha também volta pela recuperação automática com internet e código.

## Camada 3 — revisor-chefe
**Rodada 1 do revisor-chefe** (extração limpa; rodou de verdade: md5 do pacote e do LEIA-ME, sintaxe, 310/310 testes e um cenário próprio com o Firebase de mentira; leu o capítulo 6 inteiro contra o código): confirmou que **todas** as correções dos agentes 1 e 2 estão feitas. Achou **0 🔴, 1 🟠, 4 🟡**:

| Achado | Gravidade | Correção feita |
|---|---|---|
| 1. "☁️ Recuperar da nuvem" que falha (erro ou Wi-Fi sem internet) depois de apagar a criança: o app cria a criança vazia e o próximo envio grava por cima da ficha. Reproduzido: 10 frases → 0. Os documentos apontavam esse caminho como seguro | 🟠 (perda de dados) | novo risco 6.10-14; ressalva no 6.6, no cap. 10 passo 9, no cap. 11 (4c), no cap. 12 e na regra 9 do PROMPT. Conferido no código (`nuvemRecuperarLeitor`, ramo `.catch`) |
| 2. Regra "não altere o `nuvem-sync.js`" × o plano que cria o `nuvem-sync.js` v4 | 🟡 | exceção escrita na regra 1 do cap. 7 e na regra 8 do PROMPT |
| 3. Tocar no cartão da criança atual não recarrega | 🟡 | 6.3-c |
| 4. "Quando envia" sem o envio ao sair do app e a nova tentativa a cada 60 s | 🟡 | 6.7 |
| 5. Espaço vira hífen no código: "sao pedro 2026" ≠ "saopedro2026" | 🟡 | 6.3-h |

**Rodada 2 do revisor-chefe** (extração nova; comparou arquivo por arquivo com a rodada 1 — só mudaram o LEIA-ME e os 3 documentos; md5 do pacote, do `nuvem-config.js` e do LEIA-ME conferidos; cada correção lida contra o código): as 5 correções estão feitas e batem com o código. **0 🔴, 0 🟠.** Deixou 2 🟡 de texto, que foram aplicados depois do veredito (só texto do HISTORICO, sem mudar sentido):
- 6.10-14: a gravação por cima acontece sozinha se a internet voltar (não depende de usar o app); as versões de dias anteriores (🕘) continuam na nuvem;
- 6.7: depois de um erro, o `nuvem-sync.js` agenda uma nova tentativa em 60 s mesmo sem fila.

## O que foi rodado × só lido (resumo final)
- **Rodado de verdade:** md5 (pacote, `nuvem-config.js`, compartilhados, LEIA-ME), `node --check`, 310/310 testes a partir do zip extraído (por mim e pelos 3 agentes), app aberto num Chromium sem erro no console, contagem de conteúdo, e 4 cenários de defeito com o Firebase de mentira (criança fantasma; importar backup; recadastrar sem internet; recuperar que falha).
- **Só lido:** o resto dos capítulos 5 e 6 contra o código.
- **Não conferido:** se a v121 está publicada no Netlify; o Firebase real; o celular de verdade.

## Veredito do revisor-chefe
✅ Passagem aprovada
