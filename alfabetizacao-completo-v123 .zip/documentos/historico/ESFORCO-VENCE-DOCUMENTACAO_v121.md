> ⚠️ **DOCUMENTO ANTIGO, guardado só como histórico.** Onde ele contradisser o `documentos/HISTORICO_E_PLANO_alfabetizacao.md`, vale o HISTORICO_E_PLANO (por exemplo: o zip do Netlify leva os 8 arquivos **na raiz**, sem pasta; os testes precisam de `npm install`; hoje são 310 testes; `CHAVES_LEITORA` tem 33 chaves).

# Esforço Vence — Documentação completa do projeto

*Escrito em 19/09/2026 (atualizado em 23/09/2026 — v121), pra registrar o app do jeito que ele está hoje: por que existe, como foi pensado, como funciona por dentro, e como retomar o trabalho numa conversa nova se for preciso.*

---

## 1. O que é o Esforço Vence

O **Esforço Vence** é um aplicativo de alfabetização em português, feito pelo Pedro pra suas duas filhas (e usado na Escola São Pedro), dentro de uma família maior de apps educacionais chamada **Coruja 🦉**. O nome "Esforço Vence" não é só o nome do app — é a filosofia por trás de todos os apps do Pedro: **esforço e persistência importam mais que talento natural**. Isso não é só um slogan; é o critério que decide praticamente toda escolha de design: sem gamificação que humilha quem erra, sem "resposta errada" em pergunta de opinião, progresso medido por tentativa e prática, não por comparação.

O app ensina, nessa ordem de complexidade:
1. **Sílabas simples** (padrão consoante+vogal: BA, BE, BI...) — 17 famílias, 854 palavras
2. **Sílabas complexas** (dígrafos, encontros consonantais, nasalização, R/L em posições diferentes etc.) — 14 grupos, 22 padrões, 2073 palavras
3. **Leitura de frases** — 2039 frases, da mais simples (2-3 palavras, sílaba simples) até frases bem mais longas
4. **Formação de frase** (Monta a Frase) e **sílaba que falta** (Sílaba Perdida) — dois jeitos de praticar compreensão em cima das mesmas 2039 frases

É um PWA (Progressive Web App) — funciona 100% offline depois de instalado, sem servidor, sem login, sem coleta de dado nenhuma. Tudo fica salvo no aparelho da criança.

---

## 2. Como foi pensado — as ideias por trás das decisões

Algumas decisões de design não são óbvias olhando o app pronto, mas vieram de tentativa, erro e observação de criança de verdade usando:

- **Toque sequencial, não arrastar.** No Monta a Frase, testamos arrastar-e-soltar livre (a criança podia montar a frase em qualquer ordem, physically dragging pieces). Foi revertido de propósito: com o toque sequencial (só a próxima palavra certa reage), a criança é obrigada a *ler e saber qual vem primeiro* antes de agir — não dá pra "tatear" até acertar por sorte. Pedagogicamente mais forte, mesmo sendo uma interação mais simples de programar.

- **Áudio automático, não sob demanda.** Item recente (setembro/2026): a frase passou a ser falada sozinha sempre que aparece — na entrada do módulo e a cada Próxima/Anterior — em vez de depender só do interruptor de áudio manual (vale só dentro do Monta a Frase e da Sílaba Perdida — no **Ler** o áudio só toca quando a criança liga, por decisão explícita do Pedro: ali a criança precisa ler sozinha, sem interrupção). A lógica: para uma criança em fase de alfabetização, ouvir a frase é o primeiro contato com ela; esperar um toque extra pra isso quebra o fluxo natural de "ver, ouvir, tentar".

- **Progressão nunca "morre" no fim de uma trilha.** Quando a criança termina a última sílaba da última família (ex.: PÃO, fim da família do P), o app sugere sozinho seguir pra próxima família (T · TA) em vez de simplesmente parar. A ideia é que a criança nunca precise "descobrir sozinha" pra onde ir depois — o app sempre aponta o próximo passo.

- **Ordem fonética, não ordem alfabética.** As 17 famílias de sílabas simples seguem a ordem M, P, T, L, S, F, N, V, B, D, G, R, C, J, Z — uma ordem pensada pela facilidade de pronúncia/reconhecimento pra criança pequena, não pela ordem do alfabeto.

- **Sinalizar "já feito" sem travar.** Em vários lugares do app (palavra já lida, sílaba já estudada, frase já respondida certo no Monta a Frase/Sílaba Perdida), o app marca visualmente o que já foi concluído — mas **nunca bloqueia** a criança de repetir. A repetição é bem-vinda; a marcação é só pra dar clareza de progresso (com 2039 frases, é fácil perder o fio de "o que eu já fiz").

- **Tudo pode ser reconfigurado pra quem está lendo.** Fonte (várias, incluindo cursivas tipo "Beabá"/"Mamãe" pra quem já treina letra cursiva em casa), tamanho de letra, velocidade de fala, caixa alta ou baixa — tudo isso é ajustável porque cada criança está numa fase de alfabetização diferente. E, desde essa última rodada de ajustes, **os pop-ups e mensagens do app também respeitam essa fonte/caixa escolhida** — antes eles ficavam "fora do padrão", o que confundia quem só reconhece caixa alta ainda.

- **Sem telas fora do fluxo pedagógico.** Já existiram (e foram removidas de propósito) features como "Conquistas", "Diploma" e "Álbum de Figurinhas" — elementos de gamificação que competiam com o foco principal (ler) em vez de reforçá-lo. A filosofia "esforço vence" prefere menos elementos de distração, não mais.

- **Cada leitora (criança) tem seu próprio espaço.** O app suporta múltiplos perfis (uma leitora = uma filha), cada um com progresso, configurações e histórico completamente isolados um do outro — inclusive os nomes de família usados nas frases (`{PAI}`, `{MAE}` etc. viram o nome real que cada leitora cadastrou). Isso já teve um bug sério (dado de uma filha vazando pro perfil da outra) que foi corrigido e é hoje uma área testada com bastante cuidado.

---

## 3. Como o app é organizado por dentro (arquitetura técnica)

### Arquivo único
O app inteiro — HTML, CSS e JavaScript — vive num **único arquivo** (`index.html`, ~930 KB). Essa não é uma limitação, é uma escolha: junto com um `manifest.webmanifest` (nome, ícone, cor) e um `sw.js` (service worker, cache offline), ele forma um pacote que dá pra publicar como zip no Netlify e funciona como PWA instalável, 100% offline, sem depender de nenhum servidor rodando código.

### Os quatro módulos
1. **Ler** — tela principal, mostra uma frase de cada vez (das 2039), com destaque de sílaba durante a fala (efeito "karaokê"), navegação Próxima/Anterior numa **ordem de dificuldade** própria (não é a ordem crua do array de dados — ver abaixo).
2. **Treinar Sílabas** — grade de famílias (Simples) e grupos/padrões (Complexas); dentro de cada uma, um "Leitor de Palavra" mostra uma palavra grande de cada vez pra praticar aquela sílaba específica.
3. **Monta a Frase** — a frase aparece embaralhada em blocos; a criança toca as palavras na ordem certa pra reconstruí-la.
4. **Sílaba Perdida** — a frase aparece com uma sílaba faltando (um "buraco"); a criança escolhe, entre 3 opções, qual sílaba completa a palavra certo.

### Estrutura de dados (números de hoje)
- `DATA`: array com as **2039 frases** pra ler (formato `"pa·la·vra pa·la·vra|emoji"`)
- `SILABAS_FASE1`: **17 famílias** de sílabas simples, com **854 palavras** no total
- `SILABAS_COMPLEXAS_MACRO` / `SILABAS_COMPLEXAS_GRUPOS`: **14 grupos**, **22 padrões**, **2073 palavras**
- `LEVELS`: **52 níveis**, calculados na abertura do app pela trilha pedagógica (seção 4b); juntos cobrem `DATA` inteiro sem buraco nem repetição (testado)
- `CHAVES_LEITORA`: lista de **32 chaves** de localStorage que precisam ser isoladas por leitora (backup, restauração, apagar perfil)

### Ordem de dificuldade ≠ ordem do array
Um ponto sutil e importante: a ordem em que a criança **navega** as frases (Próxima/Anterior no módulo Ler) segue `LEVELS`, que pode reordenar blocos do array `DATA` por dificuldade pedagógica — não necessariamente a ordem em que as frases estão fisicamente guardadas no array. Isso é deliberado (frases de conteúdo específico, tipo "Bloco V · Tios", foram acrescentadas no **fim** do array pra não corromper o progresso já salvo de ninguém, mas entram no meio da ordem de dificuldade). **Regra de ouro: nunca inserir frase no meio do array `DATA`** — só no final — porque o progresso de cada criança é guardado como um bitmap de posições desse array; inserir no meio desloca tudo e corrompe o progresso salvo.

### Isolamento por leitora (perfil)
Cada leitora tem um `id`. Toda chave de `localStorage` que começa com `hana_` é automaticamente prefixada com o id da leitora ativa (ex.: `hana_idx` vira `2_hana_idx` pra leitora "2"), então múltiplas leitoras no mesmo aparelho nunca compartilham progresso sem querer — isso é automático pra qualquer chave nova que comece com `hana_`. Mas separadamente, `CHAVES_LEITORA` é a lista usada por **backup/exportação** e por **apagar perfil**: uma chave nova (tipo as `hana_monta_ok`/`hana_silaba_ok` adicionadas agora) só entra no backup ou é limpa ao apagar um perfil se estiver nessa lista.

### Sistema de fontes e caixa alta/baixa
`FONTS` é um array de fontes disponíveis (bastão, Sassoon, redonda, divertida, estreita, e três cursivas — Beabá, Mamãe, Playwrite), cada uma podendo forçar `mode:'caps'` (só caixa alta) ou `mode:'lower'` (só minúscula, faz sentido pras cursivas). `capsOn()` decide o estado efetivo. Desde a última rodada, isso também é aplicado aos pop-ups de confirmação (`confirmModal`), não só ao texto da frase.

---

## 4. O que foi feito na última fase de trabalho (setembro/2026)

Pra deixar registrado o que motivou as últimas versões (chegamos na **v116**):

1. **Integração da lista de palavras** — 854 (Simples) + 2073 (Complexas) palavras, cada uma validada.
2. **Padronização de tamanho de fonte** e remoção de features de gamificação fora do foco (Surpresa, Conquistas, Diploma, Álbum de Figurinhas).
3. **Reordenação fonética** das famílias de sílabas simples (M,P,T,L,S,F,N,V,B,D,G,R,C,J,Z).
4. **Navegação por dificuldade** no módulo Ler, controle de velocidade de fala.
5. **Correção de um bug de escopo** em "Marcar estudada" (marcar uma sílaba específica estava vazando e marcando a família inteira, ou vice-versa).
6. **Botão "Próxima sílaba"** com confirmação, que:
   - Não desaparecia por causa de um `style="display:none"` fixo no HTML (bug raiz encontrado só depois de o Pedro mandar prints comparando a tela real com o esperado)
   - Foi reposicionado pra ficar **grudado no botão "▶" normal**, mesma altura (usando `align-items:stretch` dentro de um grupo flex compartilhado — o navegador calcula a altura sozinho, sem chutar pixel)
   - Agora **nunca morre no fim de uma família** — ao terminar a última sílaba de uma família (ex.: PÃO, fim do P), sugere seguir pra próxima família (T · TA) automaticamente
7. **Pop-ups seguem fonte/caixa alta** escolhidas nas Configurações.
8. **Áudio automático** no Monta a Frase e Sílaba Perdida (entrada + Próxima/Anterior), independente do interruptor manual.
9. **Marcação visual de "já respondida"** no Monta a Frase e Sílaba Perdida — persistente, mas não bloqueia repetição.
10. Renomeação do app para **"Esforço Vence — Alfabetização"**, com link sugerido `escolasaopedroalfabetizacao.netlify.app`.

---

## 4b. v117 (23/09/2026) — duas correções urgentes

**1. O Ler falava sozinho com o áudio desligado.** Causa: a cada 5 frases lidas, o app chamava `openMonta`/`openSilaba` — resto da época em que Monta a Frase e Sílaba Perdida eram pop-ups. Hoje são páginas próprias, então a chamada montava a página *escondida* por trás do Ler, e desde a v115 (fala automática nesses dois módulos) ela falava a frase em voz alta. Correção: essa chamada saiu (ficou só o quiz, que é o único que aparece na tela) e a fala automática do Monta/Sílaba Perdida agora só acontece se a página estiver aberta (`paginaAberta()`). Teste confirma: v116 falou 2 vezes em 10 frases com áudio desligado; v117 fala 0.

**2. Ordem das frases inadequada pra quem está começando.** Causa: a ordem vinha de uma lista de blocos com um número de dificuldade escolhido à mão (`d`). Os blocos W, X, Y e Z (frases de família, dia em casa etc.) entraram com número baixo e caíram no Nível 2 — trazendo "a·ten·de", "a·do·ra", "pri·ma" pro começo. Correção: a ordem agora é **calculada frase por frase** (`construirTrilha`), olhando as sílabas de verdade de cada frase (já com os nomes da família daquela leitora):
- cada frase recebe a etapa da sua sílaba mais difícil, nesta ordem: sílabas simples → S com som de Z (ca·sa) → duas vogais (pai, lei·te) → **R entre vogais (ca·ro)** → **R** (pra·to, mar) → RR → L → CH → LH → NH → S no fim → SC → M/N (nasal) → Ç → X → QU → GU → outros (a mesma ordem das Sílabas Complexas do Treinar Sílabas);
- dentro de cada etapa, da frase com menos palavras pra com mais;
- vale pro Ler, Monta a Frase, Sílaba Perdida e Mapa de Níveis (52 níveis agora).
- O array `DATA` **não mudou de ordem** — progresso salvo continua valendo. Só a ordem de navegação mudou. Na primeira abertura da v117, cada módulo volta pra 1ª frase da trilha que a leitora ainda não fez (chave `hana_trilha_v2`).
- `BLOCOS_CONTEUDO` (a antiga `LEVELS` de faixas) ficou só como registro de onde cada bloco está no array.

---

## 4c. v118 (23/09/2026) — quiz, imagens e tela acesa

- **Quiz "Toque no desenho da frase!"** agora usa a mesma fonte e a mesma caixa (ALTA/Capitalizado) das Configurações — antes a frase dele saía sempre em minúscula. Função única `aplicarFonteLeitura()`, usada também pelos pop-ups de confirmação.
- **Configurações › 🖼️ Imagens das frases e palavras** (liga/desliga): esconde os desenhos do Ler e do Treinar Sílabas. Salvo por leitora (`hana_imagens`, padrão ligado). Com imagens desligadas o quiz de desenho não aparece (não faria sentido).
- **Tela sempre acesa**: o app pede ao sistema pra não bloquear a tela enquanto está aberto e visível (Wake Lock API — Chrome no Android). O sistema solta esse pedido quando o app vai pro fundo; o app pede de novo ao voltar e a cada toque. Motivo: celular espelhado na TV bloqueava depois de 1 minuto quando a criança demorava numa frase.

---

## 4d. v119 (23/09/2026) — R entre vogais + revisão final

- **R entre vogais (ca·ro, a·do·ra, Ma·ri·a) saiu da fase das sílabas simples** e virou a **primeira etapa do R** (🐭 "R entre vogais"), antes do PR/TR/R no fim. Motivo: a letra é a mesma do RA de RATO, mas o som muda — a criança que acabou de aprender "RA = rato" lê "caro" como "carro". É o mesmo lugar em que a lista de sílabas complexas do Pedro coloca "R no meio após vogal".
- **S entre vogais (ca·sa, me·sa, ro·sa) continua logo depois das simples**: o som de Z não costuma travar a leitura, são palavras das primeiras cartilhas e já estavam no início da sequência de referência que o Pedro mandou.
- **Duas vogais juntas (pai, lei·te, cui·da) continuam antes do R**: não estão na lista de complexas e também aparecem no começo da sequência de referência.
- Revisão completa antes da publicação: todos os módulos percorridos em sequência sem erro (Ler 70 frases, Monta a Frase e Sílaba Perdida 35 cada, todas as famílias simples e todos os grupos complexos do Treinar Sílabas, os 52 níveis do Mapa, Calendário, Configurações, Quiz, Cantinho dos pais, backup); pacote sem nenhuma dependência externa.

---

## 4e. v120 (23/09/2026) — padrão Escola São Pedro: cadastro Nome + Bichinho, nuvem, tela acesa, instalação

Feito seguindo `PADRAO_CADASTRO_NOME_BICHINHO.md` e `REFERENCIA_INTEGRACAO_CURIOSIDADES.md` (modelo: Curiosidades v1.7), **adaptado** ao jeito deste app guardar as crianças.

**Arquivos compartilhados** (iguais nos 7 apps, NÃO editar): `nuvem-config.js` (o do Pedro, com as chaves — vai no zip exatamente como ele mandou), `nuvem-sync.js` v3, `escola-pwa.js` v2. Conferidos byte a byte com os enviados pelo Pedro.

**Cadastro** (`#npOv`): "🌟 Qual é o seu nome?" → "Digite o seu nome..." (14 letras) → "Escolha o seu bichinho:" → os 8 oficiais numa linha só (🦉🦊🐰🐼🦋🐨🐯🐴, lidos de `EscolaPWA.BICHINHOS`, cópia de reserva idêntica) → "Você escolheu: …" → "← Voltar" / "Pronto! ✅" / "☁️ Já tenho cadastro". Nenhum bichinho pré-escolhido; sem nome ou sem bichinho não cadastra; espaços limpos; Enter confirma só se já tem bichinho; mesmo nome+bichinho abre o existente; máx. 6. Meta viewport com `interactive-widget=resizes-content`.
**Acesso**: 0 crianças → cadastro; 1 → direto; 2+ → "Quem vai estudar hoje?" (cartões + "✏️ Trocar nome ou bichinho", "🗑️ Apagar este usuário", "☁️ Recuperar da nuvem", "➕ Novo usuário"). O chip (bichinho + nome ao lado da coruja) volta para essa tela. Bichinho antigo (👧, 🦄, 🐧...) continua funcionando; ao editar pede um dos 8.

**Nuvem** (`NuvemSync.iniciar({app:'alfabetizacao', ...})`): identidade = nome + bichinho (ex.: Hana 🦊 → `hana_1f98a`). Sincroniza todas as `CHAVES_LEITORA` (menos `hana_noinstall`). Junção (`nuvemMesclar`): frases lidas = OU; listas (sílabas lidas/estudadas, Monta/Sílaba Perdida concluídas, favoritas, estrelas) = união; ajuda por frase = maior; diário = união dia a dia; palavras/sequência/recorde = maior; nomes da família = preenche o que está vazio; onde parou e preferências = o celular manda (a nuvem manda numa recuperação ou se a criança não tem nada no celular). Depois de juntar, `resincronizarDoDisco()` relê a memória da criança aberta.
⚠️ **Ponto delicado deste app:** cada criança grava com prefixo (`hana_*` para a leitora "1", `<id>_hana_*` para as outras) trocando o `localStorage.setItem`. O `nuvem-sync.js` também troca essa função para "vigiar" as gravações — e isso desligaria o prefixo. Por isso, logo depois do `NuvemSync.iniciar`, o prefixo é recolocado POR CIMA da vigia. `exportar`/`mesclar` usam sempre `_rawGet/_rawSet` com o prefixo da criança certa. Testado: duas crianças no mesmo celular nunca se misturam, nem no celular nem na nuvem.
**Telas**: "☁️ Recuperar cadastro" (`#nuvemOv`: lista a família, inclusive crianças de outros apps; 🔑 Código da família; 🔄 Procurar de novo; 🕘 Versões guardadas — juntar uma versão nunca apaga nada). Configurações ganham "📺 Tela" (Tela sempre acesa, Instalar o app) e "☁️ Nuvem" (Situação/Enviar agora, Código da família, Recuperar). Pontinho na ⚙️: verde ok, laranja fila, vermelho erro/sem código.
**Pop-up do código da família** (`#codOv`): no estilo do app, seguindo fonte e caixa alta das Configurações — nada de `prompt()`/`alert()`/`confirm()` do navegador (os testes falham se aparecer algum).

**escola-pwa.js**: tela sempre acesa (Wake Lock + modo reserva com vídeo mudo + vigia de 15 s; chave `ev_telaAcesa`, ligada por padrão), tela cheia a cada toque (não atrapalha campos de digitar nem o convite), convite para instalar. Saíram: o banner de instalação próprio do app e a tela cheia "só no 1º toque" (ficam só de reserva se o escola-pwa.js faltar). A tela acesa própria da v118 também virou só reserva.
**sw.js** (cache `esforco-vence-v120`): guarda `nuvem-sync.js` e `escola-pwa.js`; `nuvem-config.js` é buscado primeiro na internet; não intercepta o Firebase. **manifest**: + `display_override`.

## 4f. v121 (23/09/2026) — tamanho da letra igual em todas as frases

**Problema (Pedro):** no Ler, com o tamanho 22, "A TIA" aparecia gigante (parecia 64) e outras frases menores.
**Causa:** o número escolhido não era um tamanho de letra: era "esticar a frase até encher o quadro × o número". Frase curta tem pouco texto, então era esticada até ficar enorme; frase longa ficava pequena.
**Solução:** `fitCaixa(el, area, escala, referencia, chave)` agora mede uma **frase-padrão** (`REF_LER` = "a vo·vó co·me o bo·lo"; `REF_MONTA`, `REF_SILABA`, `REF_PALAVRA`). O número **24 = o maior tamanho em que a frase-padrão cabe no quadro**; os outros números são proporcionais (22 ≈ 92%, 20 ≈ 83%, 10 = 42%). Toda frase usa esse tamanho; só diminui se **ela** não couber (frases longas com o celular em pé). A medida fica guardada em `_refFonte` por tamanho de tela/fonte/caixa alta/sílabas. No Treinar Sílabas, a palavra sem desenho usa o mesmo tamanho da com desenho (a medida reserva o espaço do desenho sempre).
**Efeito visível:** com o mesmo número, as letras ficam um pouco menores do que antes nas frases curtas — isso é o certo; antes a frase curta ficava grande demais.
**Cuidado:** a frase-padrão usa os mesmos ids dos elementos reais (`mtSlots`, `mtPool`, `spFrase`, `spOps`) para pegar o mesmo estilo; os reais saem da tela durante a medida. Por isso os ids são escritos com `_ID('...')`.
**Teste:** `testes_navegador/teste_fonte.py` (58): 4 tamanhos de tela × tamanhos 10/20/22/24; deitado, TODAS as frases do mesmo tamanho; nenhuma cortada; frase curtinha nunca maior; número maior = letra maior; Monta e Sílaba Perdida sem cortes.

---

## 5. Aprendizados difíceis (coisas que já deram problema e como foram evitadas)

Vale registrar porque são o tipo de erro fácil de repetir sem querer:

- **`style="display:none"` inline sempre vence CSS de classe.** O botão "Próxima sílaba" ficou invisível por várias versões porque tinha esse atributo escrito direto no HTML, sobrescrevendo qualquer `.mostra{display:...}` do CSS. Foi só encontrado com prints reais do Pedro comparando comportamento esperado vs. tela.
- **Vazamento de dado entre perfis.** Já aconteceu de o nome de família de uma filha aparecer no perfil da outra — corrigido, e hoje é área com teste dedicado.
- **`justify-content:space-between` com um item novo bagunça o layout todo.** Ao adicionar o botão "Próxima sílaba" como 4º item de uma barra flex que tinha 3, o espaço extra passou a ser dividido em mais vãos, empurrando os itens pra longe uns dos outros. Resolvido agrupando os dois botões relacionados num sub-container.
- **Animação de "voar até a vaga" precisa avançar o contador na hora do toque, não no fim da animação** — senão, um toque rápido demais no meio da animação é registrado como erro.
- **Sílabas sintéticas (tipo SSA, NHA, BRA) precisam de `semAudio:true`** — o TTS do navegador pronuncia errado esse tipo de sílaba isolada.
- **Inserir frase no meio do array `DATA` corrompe progresso salvo** (ver seção 3) — sempre no fim.
- **Dois códigos trocando a mesma função do navegador.** O app troca o `localStorage.setItem` para separar as crianças e o `nuvem-sync.js` troca de novo para vigiar. Quem troca por último apaga a troca do outro. Solução: recolocar o prefixo por cima depois de ligar a nuvem — e testar com duas crianças.
- **Não decidir ordem de leitura à mão por bloco.** Um bloco novo com número de dificuldade baixo estragou o começo da trilha sem ninguém notar até testar com muitas frases. A ordem agora é calculada pelas sílabas; frase nova entra sozinha no lugar certo.
- **Função antiga chamada "por trás" continua rodando.** Quando um pop-up vira página, procurar quem ainda chama a função dele.
- **Tamanho de letra não pode depender do tamanho da frase.** "Encher o quadro" faz frase curta virar gigante. O número escolhido tem que valer um tamanho fixo (medido numa frase-padrão).
- **Todo conteúdo novo passa pelo silabificador Python antes de entrar no app** — mesmo listas que pareciam prontas já teve erro real encontrado dessa forma.

---

## 6. Testes automatizados

O app tem **310 testes automáticos**: 89 rápidos em 12 arquivos (Node.js + JSDOM, pasta `testes/`) e 221 num Chrome de verdade (Playwright, pasta `testes_navegador/`: cadastro 55, nuvem 75 com Firebase simulado, PWA 33, tamanho da letra 58). Os rápidos cobrem:

| Arquivo | O que testa |
|---|---|
| `teste_01_estrutura_dados.js` | Integridade de `DATA`, `SILABAS_FASE1`, `SILABAS_COMPLEXAS_*`, cobertura de `LEVELS` |
| `teste_02_sequenciamento_silabas.js` | Trilha "Próxima sílaba" nunca morre no fim de família/grupo |
| `teste_03_popups_e_botao.js` | Pop-ups seguem fonte/caixa; botão "Próxima" na posição/altura certa |
| `teste_04_audio_automatico.js` | Frase fala sozinha na entrada e no Próxima/Anterior |
| `teste_05_frases_concluidas.js` | Marcação de "já respondida" persiste e reaparece sozinha |
| `teste_06_regressao_geral.js` | Ids duplicados, chaves repetidas, fluxos centrais sem erro |
| `teste_07_backup_por_leitora.js` | Backup/restauração inclui as chaves certas, sem misturar leitoras |
| `teste_08_marcar_estudada_e_fluxos.js` | Bug de escopo (sílaba vs. família); fluxo real de clique até concluir |
| `teste_09_telas_auxiliares_e_pacote.js` | Mapa de Níveis, Calendário, Config, Quiz abrem sem erro |
| `teste_10_consistencia_pacote.js` | manifest.webmanifest válido, sw.js versionado, ícones existem |
| `teste_12_quiz_imagens_tela.js` | Quiz segue fonte/caixa; interruptor de imagens; pedido de tela acesa |
| `teste_11_trilha_e_audio_ler.js` | Ler não fala com áudio desligado; trilha começa só com sílabas simples e curtas, complexas depois começando pelo R |

Como rodar: `node testes/rodar_testes.js` (precisa de Node.js instalado; o zip de testes já vem com as dependências, não precisa `npm install`).

**Limite honesto:** esses testes rodam num navegador simulado — provam que a estrutura e a lógica estão certas, mas não substituem o teste real no celular (só lá dá pra confirmar layout, toque, fala e sensação de uso de verdade).

---

## 7. Como publicar / pipeline de entrega

1. Editar `index_trabalho.html` (o arquivo de trabalho).
2. Extrair o `<script>` e rodar `node --check` (sintaxe válida).
3. Rodar a bateria de testes (`node testes/rodar_testes.js`) — tudo tem que passar.
4. Copiar pra `pacote/index.html`, junto com `icon-192.png`, `icon-512.png`, `manifest.webmanifest`, `nuvem-sync.js`, `escola-pwa.js`, o `nuvem-config.js` do Pedro (sem mexer), e um `sw.js` com o nome de cache **atualizado** (ex.: `esforco-vence-v122`, incrementando a versão anterior — isso é o que faz o navegador saber que precisa baixar a versão nova em vez de usar a cache antiga).
5. Zipar a pasta `pacote/` inteira — esse é o arquivo que vai pro Netlify (arrastar e soltar no painel, ou via CLI).
6. Verificar de novo depois de zipar (extrair o zip final e rodar `node --check` nele, não só no arquivo de trabalho) — evita entregar um pacote diferente do que foi testado.

---

## 8. Estado atual (23/09/2026)

**Pronto e entregue:** v121, com os itens das seções 4 a 4f, todos os 310 testes passando, pacote e HTML avulso já enviados ao Pedro.

**Pendente — só o Pedro consegue confirmar:**
- Teste real no celular Android (layout, toque, fala, sensação de uso) — os testes automatizados não substituem isso.

**Sem pendência técnica conhecida** além do teste em dispositivo real.

---

## 9. Como continuar isso numa conversa nova (se for preciso)

Esta sessão específica já teve o ambiente de trabalho reiniciado mais de uma vez (perdendo arquivos temporários no meio do processo), o que é normal em sessões longas — mas significa que **o único lugar confiável onde o estado do projeto sobrevive de verdade é o que foi entregue ao Pedro** (os arquivos que ele baixou) e **este próprio documento**, se salvo no projeto.

Se for preciso continuar em uma conversa nova, o jeito mais seguro é:

1. **Pedro anexa o `index.html` mais recente que ele tem** (o da última entrega) — esse é sempre a fonte da verdade, não o que estiver ou não numa pasta de trabalho de uma sessão anterior.
2. **Pedro descreve o que quer mudar/corrigir**, com prints de tela quando for sobre aparência ou comportamento visual — isso já se mostrou essencial pra encontrar bugs (o bug do `style="display:none"` só foi achado assim).
3. Uma conversa nova deve: extrair o `<script>` do HTML anexado, rodar `node --check`, e (se o Pedro tiver o zip de testes) rodar a bateria de 62 testes pra confirmar o estado antes de mudar qualquer coisa.
4. Ao entregar de novo: **sempre subir o número de versão do cache** no `sw.js` (não repetir uma versão já usada), e reconferir o pacote final extraído do zip — não só o arquivo de trabalho — antes de mandar.
5. Este documento (`ESFORCO-VENCE-DOCUMENTACAO.md`) deve ser mantido atualizado a cada rodada grande de mudanças — é o resumo que substitui ter que reler o histórico inteiro da conversa.

### Preferências do Pedro (pra quem for continuar)
- Comunicação em português.
- Prefere edições cirúrgicas — nunca reescrever código que já funciona sem motivo.
- Valora diagnóstico honesto mais que garantias vazias — se algo não foi testado de verdade (tipo layout em tela real), dizer isso claramente.
- Espera explicação em linguagem simples da causa raiz de um bug, além do conserto.
- É bem detalhista — presta atenção em detalhes sutis (posição de botão, altura, ordem de família) que passam despercebidos numa primeira olhada.
- Termina cada resposta de desenvolvimento com uma lista ✅/⬜ do que foi feito e do que falta.
- Testa tudo com as próprias filhas usando de verdade, no celular Android — o feedback delas (inclusive "sensação" relatada por print) é o critério final.
