import os, sys
# roda de qualquer lugar: usa a base dos testes (testes/testes_navegador) e abre o app de pacote-netlify/ (o nuvem-config.js é trocado por um vazio e o Firebase é de mentira: nunca fala com a nuvem real)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "testes", "testes_navegador"))
os.environ.setdefault("PASTA_PACOTE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "pacote-netlify"))
from base import *
import json, statistics, sys
servidor()
PF=json.dumps({"perfis":[{"id":"1","nome":"Hana","av":"🦊"}],"atual":"1"})
tam=[(int(a),int(b)) for a,b in (x.split('x') for x in sys.argv[1:])] or [(800,360)]
with sync_playwright() as pw:
    b=pw.chromium.launch()
    for w,h in tam:
        ctx,fb=novo_contexto(b,config='vazia',largura=w,altura=h,storage={'ev_perfis':PF,'hana_trilha_v2':'1'})
        p=abrir(ctx)
        r=p.evaluate("""()=>{
          ['hubOv','cfmOv'].forEach(i=>document.getElementById(i).classList.remove('open'));
          trocarPagina('ler');
          const seq=construirOrdemDificuldade(); const out=[];
          for(let k=0;k<400;k+=4){ idx=seq[k]; render(); out.push([k, parseFloat(phraseEl.style.fontSize), fraseDe(idx).split('|')[0], areaEl.clientWidth, areaEl.clientHeight]); }
          return out; }""")
        fs=[x[1] for x in r]
        print('%dx%d area=%sx%s  FSCALE=1: min %.0f  mediana %.0f  max %.0f' % (w,h,r[0][3],r[0][4],min(fs),statistics.median(fs),max(fs)))
        for x in sorted(r,key=lambda x:-x[1])[:3]+sorted(r,key=lambda x:x[1])[:3]: print('   ',x[1],x[2])
        ctx.close()
    b.close()
