# Relatório do Revisor B: Telas, crianças e celular (rodada 3)

**App:** 📚 Esforço Vence (Alfabetização) · **v122 corrigida (rodada 3)**, comparada com a v121 (publicada) e com as rodadas 1 e 2
**Data:** 07/10/2026 · **Revisor:** B (independente; não abri `documentos/RELATORIO_*`)

Pastas deste revisor:
- pacote da rodada 3 descompactado: `/home/claude/revB/novo_r3/` (o zip do Netlify em `netlify_r3/`);
- capturas: `/home/claude/revB/capturas_r3/`;
- registros: `/home/claude/revB/r3/`;
- scripts: `/home/claude/revB/scripts/` (os mesmos de antes, mais o novo `b14_barra.py`).

---

## Resumo em 1 minuto

- **O N1 🟠 foi corrigido.** Os botões da barra de cima voltaram ao tamanho da v121 (52 px deitado, 46 px em pé) em **todas** as 15 larguras que medi e nas 4 telas principais.
  - Nenhum botão fica escondido, sobreposto ou para fora da tela.
  - A pílula "☀️ 0/10 · 🌱 Nível 1 de 52" nunca fica embaixo de um botão. Isso é **melhor que a v121**, onde ela ficava por baixo de 568 a 640 px.
- **O N2 e o N4 melhoraram, e o B14 foi corrigido.**
- **O B1, o B2 e o B3 continuam corrigidos.** Rodei de novo e as provas são as mesmas da rodada 2.
- Ficam só **pontos 🟡** (2 novos, bem pequenos, que a própria correção trouxe).

**Não há nenhum 🔴 nem 🟠 aberto na minha área (telas, crianças e celular).**

---

## Cada item, com a prova

| Item | Situação | Prova (o que rodei) |
|---|---|---|
| **N1 🟠** Botões da barra de cima encolhiam para 42 px e 36 px | ✅ **Corrigido** | `b14_barra.py` em 15 tamanhos (568x320, 600, 640, 660, 680, 700, 720, 740, 760, 780 e 800 x360, 915x412, e em pé 360x740, 320x568 e 412x915) × 4 telas (Ler, Monta a Frase, Sílaba Perdida, Treinar Sílabas). Menor botão: **52 px deitado e 46 px em pé**, igual à v121 (rodei a v121 no mesmo script: 52/46). Nenhum botão sobreposto ou para fora; até o ⛶, que saía da tela em pé na v121, agora fica dentro. Pílula: nunca coberta (na v121 era coberta de 568 a 640 px). Capturas `barra_novo_r3_ler_640x360.png` e `barra_novo_r3_ler_700x360.png`; registros `r3/log_b14_r3.txt` e `r3/log_b14_v121.txt`. |
| **N2 🟡** A parte que rola da T4 ficava com 48–68 px em 568x320 | ✅ **Melhorou** | `b13_meio.py`: em 568x320 essa parte agora tem **130 px** e mostra **98%** do cartão (antes 50%). No Arrumar o cartão aparece **inteiro**, com ✏️🗑️ à vista (antes 36%). Em 740x360 sem internet: 98% (antes 81%). Em 568x320 no Arrumar, a bolinha fica embaixo e é preciso rolar a tela (aceitável: é a tela inteira que rola). Capturas `meio_normal_568x320.png` e `meio_arrumar_568x320.png`. `b8_dobras.py`: com 2, 4 e 6 crianças, em todos os tamanhos, a bolinha, "BUSCAR" e "ARRUMAR" ficam à vista na T4 normal. |
| **N3 🟡** `sw.js` com o mesmo nome de cache | ⬜ **Aceito, com uma condição** | O autor diz que nenhum zip da v122 foi publicado ainda. Não tenho como conferir o site do Pedro, mas faz sentido: os zips das rodadas 1 e 2 estavam marcados como "não publicar" até a revisão terminar. Se for assim, `esforco-vence-v122` é o primeiro cache e está certo. **Condição:** depois que esta versão for publicada no site de teste, qualquer zip corrigido tem que mudar o nome do cache (ex.: `esforco-vence-v122b`). |
| **N4 🟡** Texto dos botões pequenos encostado em cima | ✅ **Corrigido** | Captura `kb_t5_k740x170.png`: "PRONTO! ✅" e "←" agora centralizados. O campo estreito em pé com 320 px e teclado (`kb_t2_kp320x300.png`) continua igual: 🟡 leve, porque o app é usado deitado. |
| **B14 🟡** Textos fora do `TEXTOS` | ✅ **Corrigido** | Lido no código: `juntar:'JUNTAR'` e `telaCheia:'TELA CHEIA'` entraram no `TEXTOS`; a linha 1166 (⛶) e a linha 1512 (cópias) usam `T.telaCheia` e `T.juntar`. O chip tem 48 px (desde a rodada 2). |
| **B1 🔴** Campo perde o foco e às vezes some com o teclado | ✅ **Continua corrigido** | `b2_foco.py`: 24 casos, **0** `focusout`. `b2c_repete20.py`: **100/100** com o foco no campo. `b3_sumico.py`: o campo continua com 272×48 px com a tela baixa. `b1_telas.py`: 18 casos de teclado, todos com campo, botão, ✕/← e os 8 bichinhos visíveis. |
| **B2 🟠** Barra de cima escondia a pílula | ✅ **Continua corrigido** | veja o N1 acima |
| **B3 🟠** ✏️🗑️ cobria o bichinho | ✅ **Continua corrigido** | `b8_dobras.py`: cobre **0%** em 568, 640, 740 e 915 px. |
| B5, B6, B7, B9, B10, B12, B13 | ✅ **Continuam corrigidos** | `b4_t4.py`, `b8_dobras.py`, `b7r2_fluxos.py` (41 de 41 OK), `b12r3_siteteste.py` (a faixa do site de teste some com o teclado). |
| B8 (T4 sem ⚙️) e B11 (código em minúsculas na T8) | ⬜ 🟡 mantidos de propósito | dependem do OK do Pedro |
| B15 (`teste_fonte.py` 57/58) | ⬜ 🟡 falha antiga | a mesma falha acontece na v121 |

---

## Problemas NOVOS (só 🟡)

### 🟡 R3-1. A pílula de estrelas e nível fica com letra de 13 px em celulares de 568 a 700 px de largura (deitado)

- **Onde:** `index.html`, linha 88: `body.efBarraApertada #meta{font-size:13px…}`. Normalmente ela tem 16 px.
- **Prova:** `b14_barra.py`: letra de 13 px de 568 a 700 px de largura; 16 px de 720 px para cima.
- O plano pede letras de 14 px ou mais (parte 4.12). Essa regra é das telas da família, e a pílula é do app, por isso classifiquei como leve. Mas é 1 px abaixo.
- **Sugestão:** deixar 14 px e encurtar o texto em tela estreita (ex.: "☀️ 0/10 · 🌱 1/52").

### 🟡 R3-2. Em celulares de 568 a 640 px de largura (deitado), a 🦉 da esquerda some da barra

- **Onde:** `index.html`, linha 89: `body.efBarraMinima #owlWrap … {display:none}`.
- **Prova:** `b14_barra.py` ("owl: False" em 568, 600 e 640); captura `barra_novo_r3_ler_640x360.png`.
- No **Ler**, essa coruja não é só enfeite: ela **pula** quando a criança toca numa palavra e quando passa de frase (`bounce()`, linhas 6014, 6209 e 6329). Nesses celulares a criança perde esse pequeno "parabéns". No Monta a Frase, na Sílaba Perdida e no Treinar Sílabas ela é só enfeite.
- **Sugestão:** em vez de esconder a 🦉, deixá-la menor (ex.: 30 px), ou esconder primeiro a barrinha de progresso que fica em cima da pílula.

---

## O que eu RODEI de verdade (rodada 3)

**Conferências e testes do zip**
- O zip do Netlify da rodada 3 é **idêntico, byte a byte,** à pasta `pacote-netlify/`.
  - As cópias em `compartilhados/` e `testes/` são iguais.
  - `nuvem-config.js` é o do Pedro (md5 `1d5f060a…`).
  - `nuvem-sync.js` igual ao da rodada 2.
  - `node --check` OK nos 5 arquivos `.js`.
- Testes do zip em Node: **89/89** ("Tudo passou").
- Testes do zip com navegador (portas 8851/8852):

  | Teste | Resultado |
  |---|---|
  | `teste_familia.py` | **128/128** |
  | `teste_revisao.py` | **55/55** |
  | `teste_cadastro.py` | **72/72** |
  | `teste_nuvem.py` | **81/81** |
  | `teste_pwa.py` | **34/34** |
  | `teste_fonte.py` | **57/58** (a mesma falha antiga da v121) |

**Os meus scripts, contra a rodada 3**
- `b14_barra.py` (novo, na rodada 3 **e** na v121), `b2_foco.py`, `b2c_repete20.py`, `b3_sumico.py`, `b1_telas.py`, `b4_t4.py`, `b8_dobras.py`, `b13_meio.py`, `b7r2_fluxos.py`, `b9_smoke.py` e `b12r3_siteteste.py`.
- Resultados de `b4_t4.py`:
  - telas do módulo (T1 a T8 e Configurações) com letras de 14 px ou mais e botões de 48 px ou mais;
  - chip colado à esquerda da ⚙️ e ⚙️ com bolinha nas 4 telas principais;
  - "☁️ Família e nuvem" é a última seção das Configurações;
  - as únicas "falhas" do script são os 46 px da barra em pé, que são o tamanho da v121 (o app é usado deitado), e os bichinhos em pé com 33 a 43 px, que o plano permite (de 30 a 62 px).
- Fluxos (`b7r2_fluxos.py`), todos OK:
  - primeira abertura (T1→T3→T5→parentes→menu);
  - D2: a T4 toda vez que abre, e "Continuar de onde parei" depois;
  - chip → mesma criança só fecha a tela;
  - "Já tenho cadastro" com "Trazer todas";
  - código errado e "Você quis dizer";
  - "Agora não" → bolinha 🔴;
  - botão voltar (pop-up → Arrumar → tela);
  - trava do adulto com o dedo (1,5 s não abre, 3 s abre);
  - tirar com a nuvem em dia;
  - **nenhum alert/confirm/prompt**.
- `b9_smoke.py`: o app antigo (frases, áudio, tipo e tamanho da letra, calendário, mapa, Configurações, Cantinho dos pais, Nomes dos parentes, Monta a Frase, Sílaba Perdida, Treinar Sílabas, menu): **0 erros**.
- **Olhei** as capturas novas: a barra de cima do Ler em 640 e 700 e a do Monta a Frase em 640; a T4 e a T7 em 568x320; a T5 com teclado; a T2 em pé com teclado.

## O que eu só LI

- Os diffs da rodada 2 → rodada 3 (`index.html`, 16 linhas; `escola-familia.js`, 20 linhas).
- O B14 (`TEXTOS`) e o N3 (`sw.js`; não tenho como ver o que está publicado no Netlify).
- A parte de dados e nuvem não foi aprofundada: é do Revisor A.

## O que só um celular de verdade pode confirmar (Pedro, confira no celular)

1. **Teclado de verdade** na T2 ("🔑 Já tenho cadastro"), na T3 ("🌱 Sou novo") e na T5 ("Qual é o seu nome?"), deitado: o teclado abre, **fica aberto**, e o campo e o botão aparecem. Repita umas 5 vezes.
2. Celulares em que o teclado cobre a página em vez de encolher: o cartão gruda em cima do teclado?
3. A barra de cima no **seu** celular: botões grandes, chip ao lado da ⚙️, pílula inteira e legível, e a 🦉 aparecendo (R3-2).
4. Segurar 3 s com o dedo não abre o menu de "copiar/selecionar" do Android.
5. O botão voltar no app instalado: fecha o pop-up, sai do "Arrumar", depois fecha a tela.
6. Na TV a 3 m: as crianças acham o próprio bichinho na "Quem vai estudar hoje?" e no "Arrumar".
7. Ao publicar uma correção depois desta, confira que o celular mostra a versão nova (o nome do cache precisa mudar: N3).

---

## Veredito

✅ Pode publicar (no site de teste, pela minha área de telas, crianças e celular): zero 🔴 e zero 🟠 abertos. Ficam só pontos 🟡 (R3-1, R3-2, N3, B8, B11, B15 e o campo estreito em pé com 320 px) para o OK do Pedro.
