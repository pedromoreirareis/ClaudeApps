/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Caça a bugs: casos-limite e combinações estranhas que um teste "feliz" não
   pega — textos antigos sem quiz, perguntas malformadas, apagar com a busca
   ligada, sair no meio de editar o título, ler sem salvar, e por aí. */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const ROOT = process.env.CORUJA_ROOT || require('path').join(__dirname, '..', 'pacote-netlify');
const PORT = Number(process.env.CORUJA_PORT || 8981);
const OUT = process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'); require('fs').mkdirSync(OUT, { recursive: true });
const MIME = { '.html':'text/html','.js':'application/javascript','.png':'image/png','.webmanifest':'application/manifest+json' };
const server = http.createServer((q,s)=>{
  let p=q.url.split('?')[0]; if(p==='/')p='/index.html';
  fs.readFile(path.join(ROOT,p),(e,d)=>{ if(e){s.writeHead(404);s.end();return;}
    s.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream'}); s.end(d); });
}).listen(PORT);

/* Texto no formato antigo: sem TAGS e sem PERGUNTAS, como os que o Pedro já
   tem salvos no celular. */
const TEXTO_ANTIGO = `TÍTULO: 🫁 Respiração

TEXTO:
Você já reparou no que acontece com o seu corpo quando corre bastante?

PALAVRAS NOVAS:
oxigênio = gás do ar que o corpo precisa.

PARA PENSAR:
Você já sentiu o coração acelerar?`;

/* Perguntas malformadas: nenhuma tem resposta certa marcada. */
const TEXTO_QUIZ_QUEBRADO = `TÍTULO: 🧪 Teste quebrado
TAGS: teste

TEXTO:
Um texto curtinho só para testar.

PERGUNTAS:
1) Uma pergunta sem resposta marcada?
a) Uma alternativa.
b) Outra alternativa.

2) Outra pergunta também sem marca?
a) Uma.
b) Outra.

PARA PENSAR:
E aí?`;

/* Uma pergunta boa e uma quebrada: só a boa deve entrar. */
const TEXTO_QUIZ_MISTO = `TÍTULO: 🧩 Teste misto
TAGS: misto, teste

TEXTO:
Outro texto curtinho para testar o quiz.

PERGUNTAS:
1) Esta pergunta está certa?
a) Não está.
b) Está sim. *
c) Talvez.
> Porque tem uma alternativa marcada com asterisco.

2) Esta aqui está quebrada?
a) Sim.
b) Também sim.

PARA PENSAR:
E aí?`;

/* Alternativas e pergunta muito longas, para ver se o cartão aguenta. */
const TEXTO_LONGO = `TÍTULO: 📏 Alternativas compridas
TAGS: teste, layout

TEXTO:
Um texto para testar alternativas bem compridas dentro do quiz.

PERGUNTAS:
1) Por que, segundo tudo o que você acabou de ler com bastante atenção neste texto, a água que existe dentro dos rios acaba chegando até o mar depois de uma viagem tão longa?
a) Porque os rios correm sempre na direção das partes mais baixas do terreno até encontrarem o mar, carregando tudo o que pegaram no caminho. *
b) Porque alguém empurra a água dos rios todos os dias bem cedinho, antes de o sol nascer, para que ela chegue no mar a tempo.
c) Porque a água tem vontade própria e decidiu, há muitos e muitos anos, que queria morar no mar em vez de morar na montanha.
> A água sempre desce: ela vai escorregando pelos lugares mais baixos até chegar ao mar, e leva junto o que encontrou pelo caminho.

PARA PENSAR:
E aí?`;

(async () => {
  const problemas = [];
  const okays = [];
  function ok(nome, cond, det){ (cond ? okays : problemas).push(nome + (det ? ' — ' + det : '')); }

  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 915 } });
  await require('./_usuario-teste.js')(ctx);
  const page = await ctx.newPage();
  const errosJs = [];
  page.on('pageerror', e => errosJs.push(e.message));
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const loc = m.location() || {};
    if (/favicon/.test(m.text()) || /favicon/.test(loc.url || '')) return;
    errosJs.push('console: ' + m.text() + (loc.url ? ' @ ' + loc.url : ''));
  });

  await page.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);

  async function novoTextoSalvo(txt){
    const naInicial = await page.isVisible('#telaInicio');
    if (naInicial) await page.click('.btnInicioPreparar');
    else if (await page.isVisible('#telaBiblioteca')) await page.click('text=+ Novo');
    await page.waitForTimeout(200);
    await page.evaluate((t) => {
      const c = document.getElementById('caixaTexto');
      c.value = t;
      const dt = new DataTransfer(); dt.setData('text/plain', t);
      c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
      c.dispatchEvent(new Event('input', { bubbles: true }));
    }, txt);
    await page.waitForTimeout(350);
    await page.click('#btnSalvar');
    await page.waitForTimeout(350);
  }

  // ---- 1. Texto antigo (sem tags nem perguntas) ----
  await novoTextoSalvo(TEXTO_ANTIGO);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  ok('Texto antigo (sem quiz) abre normalmente', await page.evaluate(() => document.getElementById('detOv').classList.contains('open')));
  ok('Texto antigo não mostra convite de quiz', await page.$('.conviteQuiz') === null);
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);

  // ---- 2. Quiz totalmente quebrado ----
  await novoTextoSalvo(TEXTO_QUIZ_QUEBRADO);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  ok('Perguntas sem resposta certa não viram quiz quebrado', await page.$('.conviteQuiz') === null);
  const corpoQuebrado = await page.textContent('#detTexto');
  ok('Perguntas malformadas não vazam para o texto lido', !/alternativa/i.test(corpoQuebrado), corpoQuebrado.slice(0,60));
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);

  // ---- 3. Quiz misto: só a pergunta boa entra ----
  await novoTextoSalvo(TEXTO_QUIZ_MISTO);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  const rotulo = await page.textContent('.conviteQuizBtn').catch(() => '');
  ok('Com uma pergunta boa e uma quebrada, só a boa entra', /1 PERGUNTA|1 pergunta/i.test(rotulo), `"${rotulo}"`);
  await page.click('.conviteQuizBtn');
  await page.waitForTimeout(300);
  ok('Quiz de uma pergunta só mostra "Ver o resultado"', /resultado/i.test(await page.textContent('#quizProxima')));
  await page.evaluate(() => document.querySelectorAll('.quizOpcao')[1].click());
  await page.waitForTimeout(250);
  await page.click('#quizProxima');
  await page.waitForTimeout(250);
  ok('Quiz de uma pergunta chega ao resultado', await page.isVisible('#quizFim'));
  await page.click('#quizFim .ok');
  await page.waitForTimeout(200);

  // ---- 4. Abrir o quiz duas vezes zera a contagem ----
  await page.click('.conviteQuizBtn');
  await page.waitForTimeout(300);
  ok('Reabrir o quiz volta para a primeira pergunta', /1 de 1|1 DE 1/.test(await page.textContent('#quizContador')));
  ok('Reabrir o quiz destrava as alternativas', await page.$$eval('.quizOpcao', els => els.every(e => !e.disabled)));
  const acertos = await page.evaluate(() => quizAcertos);
  ok('Reabrir o quiz zera os acertos', acertos === 0, String(acertos));
  await page.evaluate(() => fecharQuiz());
  await page.waitForTimeout(200);
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);

  // ---- 5. Alternativas muito compridas ----
  await novoTextoSalvo(TEXTO_LONGO);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  await page.click('.conviteQuizBtn');
  await page.waitForTimeout(350);
  const compridas = await page.evaluate(() => {
    const card = document.querySelector('#quizOv .pcard');
    const r = card.getBoundingClientRect();
    return { rolando: card.scrollHeight > card.clientHeight + 2, dentro: r.right <= innerWidth + 1 && r.left >= -1 };
  });
  ok('Alternativas compridas não vazam para os lados', compridas.dentro);
  if (compridas.rolando) okays.push('(nota) com alternativas muito compridas o quiz rola — aceitável');
  await page.screenshot({ path: `${OUT}/adv-quiz-comprido.png` });
  await page.evaluate(() => fecharQuiz());
  await page.waitForTimeout(200);
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);

  // ---- 6. Apagar um texto com a busca ligada ----
  await page.fill('#buscaTexto', 'misto');
  await page.waitForTimeout(250);
  const antes = (await page.$$('.cardTexto')).length;
  await page.click('.cardTexto .cardExcluir');
  await page.waitForTimeout(250);
  await page.click('#confirmOv .confirmOk');
  await page.waitForTimeout(350);
  const depois = (await page.$$('.cardTexto')).length;
  ok('Apagar com a busca ligada não quebra a lista', antes === 1 && depois === 0, `${antes} -> ${depois}`);
  ok('Some a lista mas aparece o recado de "nada encontrado"', await page.isVisible('.buscaSemResultado'));
  await page.click('#btnLimparBusca');
  await page.waitForTimeout(250);
  ok('Limpar a busca traz os outros textos de volta', (await page.$$('.cardTexto')).length === 3, String((await page.$$('.cardTexto')).length));

  // ---- 7. Editar um texto e sair no meio da edição do título ----
  await page.click('.cardTexto .cardEditar');
  await page.waitForTimeout(300);
  ok('Editar mostra o título salvo', (await page.textContent('#tituloDetectado')).length > 3);
  await page.click('.btnEditarTitulo');
  await page.waitForTimeout(200);
  ok('O lápis abre a caixa de título', await page.isVisible('#linhaTituloManual'));
  await page.click('#telaEstudio .btnVoltar');   // sai sem dar OK
  await page.waitForTimeout(250);
  await page.click('.btnInicioPreparar');
  await page.waitForTimeout(250);
  ok('Voltar ao Preparar Texto fecha a caixa de título que ficou aberta', await page.isVisible('#linhaTituloManual') === false);

  // ---- 8. Ler sem salvar (botão LER AGORA) ----
  await page.evaluate((t) => {
    const c = document.getElementById('caixaTexto');
    c.value = t;
    const dt = new DataTransfer(); dt.setData('text/plain', t);
    c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
    c.dispatchEvent(new Event('input', { bubbles: true }));
  }, TEXTO_LONGO);
  await page.waitForTimeout(350);
  await page.click('text=LER AGORA');
  await page.waitForTimeout(400);
  ok('LER AGORA abre a leitura sem salvar', await page.evaluate(() => document.getElementById('detOv').classList.contains('open')));
  ok('LER AGORA também traz o quiz', await page.isVisible('.conviteQuiz'));
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);
  ok('Depois de LER AGORA o texto continua na caixa', (await page.inputValue('#caixaTexto')).length > 50);

  // ---- 9. Trocar caixa alta/baixa com o quiz ----
  await page.click('#telaEstudio .btnVoltar');
  await page.waitForTimeout(200);
  await page.click('text=LER');
  await page.waitForTimeout(250);
  await page.click('.cardTexto .cardLer');
  await page.waitForTimeout(400);
  await page.click('button[onclick="toggleCase()"]');
  await page.waitForTimeout(300);
  ok('O botão Aa não some com o convite do quiz', await page.isVisible('.conviteQuiz'));
  await page.click('.conviteQuizBtn');
  await page.waitForTimeout(300);
  ok('O quiz abre depois de trocar a caixa das letras', await page.evaluate(() => document.getElementById('quizOv').classList.contains('open')));
  await page.evaluate(() => fecharQuiz());
  await page.waitForTimeout(200);
  await page.click('#detCard .detX');
  await page.waitForTimeout(300);

  // ---- 10. Backup: exportar e reimportar preserva tudo ----
  const backupJson = await page.evaluate(() => {
    return JSON.stringify({ app: 'coruja-explica', exportedAt: new Date().toISOString(), textos: JSON.parse(localStorage.getItem('explica_p1_textos') || '[]') });
  });
  const temTags = /TAGS:/.test(backupJson), temPerguntas = /PERGUNTAS:/.test(backupJson);
  ok('O backup leva as TAGS junto', temTags);
  ok('O backup leva as PERGUNTAS junto', temPerguntas);

  // ---- 11. Um texto salvo sem o campo texto (backup estragado) ----
  const sobreviveu = await page.evaluate(() => {
    try {
      const atuais = JSON.parse(localStorage.getItem('explica_p1_textos') || '[]');
      atuais.push({ id: 'quebrado1', titulo: 'Item sem texto', criadoEm: new Date().toISOString() });
      localStorage.setItem('explica_p1_textos', JSON.stringify(atuais));
      renderizaBiblioteca(carregarTextos());
      return document.querySelectorAll('.cardTexto').length;
    } catch (e) { return 'ERRO: ' + e.message; }
  });
  ok('Um item de backup sem texto não derruba a biblioteca', typeof sobreviveu === 'number' && sobreviveu >= 3, String(sobreviveu));
  const buscaComQuebrado = await page.evaluate(() => {
    try { document.getElementById('buscaTexto').value = 'mar'; filtrarBiblioteca(); return 'ok'; }
    catch (e) { return 'ERRO: ' + e.message; }
  });
  ok('A busca também aguenta o item quebrado', buscaComQuebrado === 'ok', String(buscaComQuebrado));

  await browser.close();
  server.close();

  console.log('\n===== CAÇA A BUGS =====');
  okays.forEach(o => console.log('✅', o));
  console.log('\n===== ERROS DE JAVASCRIPT =====');
  if (!errosJs.length) console.log('(nenhum)');
  else errosJs.forEach(e => problemas.push('erro de JavaScript: ' + e));
  if (problemas.length){
    console.log('\n===== PROBLEMAS =====');
    problemas.forEach(p => console.log('❌', p));
  }
  console.log(`\n${okays.length} verificações — ` + (problemas.length ? '❌ ' + problemas.length + ' PROBLEMA(S)' : '✅ NENHUM BUG ENCONTRADO'));
  process.exit(problemas.length ? 1 : 0);
})();
