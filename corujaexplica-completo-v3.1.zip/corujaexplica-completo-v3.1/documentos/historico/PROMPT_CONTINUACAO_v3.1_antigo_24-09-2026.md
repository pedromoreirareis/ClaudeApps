# PROMPT DE CONTINUAÇÃO — Coruja Explica 🦉 (versão 3.1)

> Cole este arquivo no começo de uma conversa nova para continuar o desenvolvimento do **Coruja Explica** sem perder nada do que já foi decidido. Anexe junto o **zip mais recente** (coruja-explica-netlify_v3_1.zip ou mais novo).

## 1. Quem é o Pedro e como trabalhar com ele
- Pai de duas meninas (uma delas, a Hinata, com uns 6 anos). **Não é programador.** Testa em celular Android de verdade e espelha o celular na TV para ler com as filhas.
- Escreva sempre em **português do Brasil**, com explicações simples e honestas (qual era a causa de verdade de cada problema).
- **Mudanças cirúrgicas**: não reescreva o que funciona, não mude o que não foi pedido.
- **Revisão tripla** de tudo que for entregue (testes automáticos + conferência visual + revisão independente).
- Termine as respostas com um **checklist ✅/⬜** (inclua o que o Pedro precisa fazer).
- Publicação: Netlify, em **https://escolasaopedrocorujaexplica.netlify.app** (arrastar o zip / pasta).

## 2. O que é o app
PWA de um arquivo só (`index.html`, ~430 KB), que funciona sem internet:
1. **Preparar**: o pai pede um texto a uma IA (menu com prompts prontos — "Leitura do dia", etc.), cola a resposta, o app formata (título, emoji, tags, texto, palavras novas, perguntas com gabarito, "para pensar").
2. **Meus textos** (biblioteca) → **Ler**: tela de leitura imersiva, deitada (em pé, o cartão gira 90°), tamanhos de letra em px (12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 56, 64 — padrão 22; aviso "🔤 Tamanho 24" como nos outros apps), fontes Bastão (padrão) e Sassoon, caixa alta, **margem direita com 3 modos** (Normal / Sílabas / Espaços), **recuo de parágrafo** (liga/desliga, ligado de fábrica), dicionário por toque na palavra, marca-texto por linha (também dentro do dicionário), leitura em voz alta, quiz no fim do texto.
3. **✅ Lido** manda o texto para **Textos lidos** (histórico: quando foi lido, quantas vezes foi aberto, melhor resultado no quiz). Dá para devolver para "Meus textos".

## 3. O que a versão 3.0 trouxe
- **Uma biblioteca por criança** (cadastro padrão da Escola São Pedro: nome + 1 dos 8 bichinhos oficiais, até 6 crianças).
- **Nuvem (Firebase/Firestore)** pelo arquivo compartilhado `nuvem-sync.js` v3, com **código da família** digitado num **pop-up próprio** (sem `prompt()` do navegador) que encolhe quando o teclado abre.
- **Tela sempre acesa, tela cheia e convite para instalar** pelo arquivo compartilhado `escola-pwa.js` v2.
- **⚙️ Configurações**: 👧 Quem está usando · 📺 Tela (Tela sempre acesa + Instalar) · ☁️ Nuvem (Situação, Código da família, Recuperar) · 💾 Backup. Pontinho no ⚙️ (verde ok / amarelo esperando / vermelho erro).
- Backup agora **junta** (não substitui) e é por criança.
- Correções: Esc fechava a tela errada; pop-ups da leitura (dicionário/quiz/ajustes) giram junto na tela em pé; letras do convite do quiz nunca abaixo de 14 px.
- **Degrau de segurança no voltar**: a primeira tela fica duas vezes no histórico. O voltar do Android fecha primeiro um pop-up aberto; sem pop-up, avisa "Para sair do app, toque em voltar de novo".

## 3b. O que a versão 3.1 trouxe
- **Margem direita (⚙️ da leitura), 3 opções:** Normal (linha termina onde a palavra acaba) · Sílabas (corta na sílaba com tracinho; sobra dividida entre os espaços, teto 0,20 da letra) · Espaços (sem cortar; cada espaço cresce no máximo **75% do espaço normal** — estudo com 9.291 linhas: no celular ~64% das linhas ficam retas, na TV ~22%; o resto só chega mais perto). Config antiga `silabasOn:true` vira "Sílabas".
- **Recuo de parágrafo** (chave nos ajustes, com amostra). Ajustes em 2 colunas quando a tela é baixa ou o cartão está girado — o "Pronto" cabe sem rolar de 360×640 a 1280×720.
- **Tamanho em px** (guardado como `fsize`; o antigo `fsizeIdx` é convertido).
- **Tela sempre acesa ligada de fábrica**, inclusive no modo simples (sem escola-pwa.js).
- **Formatar texto solto** (livro/cartilha): 1ª linha vira título quando tem cara de título **e** linha em branco depois (ou é TODA EM MAIÚSCULAS com o texto em letras normais logo abaixo); ponto final do título sai; título em maiúsculas vira normal mantendo nomes próprios; frases uma por linha viram parágrafos de até 3 frases (falas, listas e subtítulos sem ponto ficam como estão). Nenhuma palavra muda.
- **Formatar ↔ ↩️ Desfazer**; nenhum botão fica apagado; **todo botão avisa** o que aconteceu. Colar com texto na caixa pergunta e **troca** (antes juntava duas histórias). Contador conta só as palavras da história. Rascunho lembra se era edição (não duplica ao reabrir o app).
- Aviso (toast) com largura certa e tempo proporcional ao tamanho da mensagem.

## 4. Arquivos do site (zip para o Netlify)
| Arquivo | Pode mexer? |
|---|---|
| `index.html` | sim — é o app inteiro |
| `sw.js` | sim — **troque o nome do cache (`C`) a cada versão** |
| `manifest.webmanifest`, `icon-192.png`, `icon-512.png` | sim |
| `nuvem-sync.js` (v3) | **NÃO** — igual em todos os apps da escola |
| `escola-pwa.js` (v2) | **NÃO** — igual em todos os apps |
| `nuvem-config.js` | **NÃO** — é o do Pedro (Firebase `escola-sao-pedro-5ee62`), vai no zip **byte a byte igual** ao recebido |

`sw.js`: guarda `./`, `index.html`, manifest, ícones, `nuvem-sync.js`, `escola-pwa.js`; `nuvem-config.js` e a página principal são "rede primeiro" **com tempo máximo** (2,5 s e 4 s; depois disso abre a cópia guardada e atualiza por trás); nunca intercepta outros endereços (Firebase).

## 5. Como os dados ficam guardados (localStorage)
- `explica_usuarios` → `{ us: [{id:'p…', nome, av}], atual: id }`
- `explica_<id>_textos` → lista de textos da criança: `{id, titulo, texto, criadoEm, alteradoEm, arquivado, arquivadoEm, estadoEm, leituras, ultimaLeitura, quiz:{tentativas:[{em,acertos,total}] (até 30), melhor, total}, semTexto?}`
- `explica_<id>_excluidos` → "lápides" `{idTexto: dataISO}` de textos apagados
- `explica_<id>_config` → `{fsize (px), capsMode, fontIdx, modoMargem ('normal'|'silabas'|'espacos'), recuo (bool)}`
- `explica_rascunho` (do aparelho: título, texto, `editando` = id do texto em edição, `crianca`), `explica_telaAcesa` (escola-pwa), `nuvem_*` (nuvem-sync), `escola_*` (escola-pwa)
- **Migração da v2.x**: a biblioteca antiga (`explica_textos`/`explica_config`) passa para a **primeira criança** cadastrada; fica uma cópia em `explica_textos_antes_v3`/`explica_config_antes_v3` (a cópia de textos é apagada sozinha se faltar espaço).

## 6. Nuvem — contrato com o nuvem-sync.js
`NuvemSync.iniciar({ app:'corujaexplica', usuarios, idDaChave, exportar, mesclar })`
- `idDaChave(k)`: `explica_<id>_(textos|excluidos|config)` de criança existente → id; o resto → null.
- `exportar(id)` → `{textos, excluidos, config}` em texto JSON (`montarExportacao`, limite **850 000 bytes**; se passar, os textos **já lidos mais antigos** sobem sem o conteúdo — `semTexto` —, o histórico sobe inteiro). **Lança erro** (não envia nada) se a criança foi apagada no meio do envio ou se a mistura com a nuvem não coube na memória do celular.
- `mesclar(id, dados, restaurando)` → `mesclarBibliotecas` (regra de ouro: **nada se perde**): conteúdo = edição mais nova (`alteradoEm`); lido/devolvido = `estadoEm` mais novo; `criadoEm` mais antigo; `leituras` maior; quiz = união das tentativas (sem repetir, 30 mais novas) e melhor resultado maior; lápide só apaga se for mais nova que a **última mexida** (editar, lido, abrir para ler, responder quiz). Criança sem textos no celular adota também os ajustes da nuvem.
- Chave da criança na nuvem = nome (minúsculo, sem acento) + código do bichinho (`ana_1f98a`). Trocar nome/bichinho cria a ficha nova e junta a antiga nela (a antiga não é apagada).
- Firestore: `familias/{codigo}/usuarios/{chave}/apps/corujaexplica` + `versoes/AAAA-MM-DD`. Regras: `usuarios`, `apps` e `versoes` com `allow read, create, update: if request.auth != null;` (sem delete). Login anônimo ligado.

## 7. Telas (ids) e navegação
`telaInicio` (chip da criança + ⚙️), `telaEstudio` (Preparar), `telaBiblioteca`, `telaArquivo` (Textos lidos), `telaUsuarios` ("Quem vai estudar hoje?"), `telaCadastro`, `telaNuvem` (Recuperar / versões), `telaConfig`; sobreposições: `detOv` (leitura), `glossOv`, `quizOv`, `ajustesOv`, `promptOv`, `confirmOv` (`abrirConfirm(msg, cb, soOk)`), `codOv` (código da família), `#escolaConvite` (escola-pwa).
Abertura: 0 crianças → cadastro; 1 → início direto; 2+ → "Quem vai estudar hoje?". `mostrarTela(nome, push)`; `popstate` fecha uma camada por vez (quiz/dicionário/ajustes → código → confirmação → convite → leitura → telas).

## 8. Testes (Playwright + Chromium, Firebase DE MENTIRA — nunca tocar no Firebase real)
Pasta de trabalho com: `teste-logica.js` (272), `teste-nuvem-logica.js` (37), `teste-formatar.js` (27), `teste-navegador.js` (64), `teste-telas.js` (96, 6 tamanhos), `teste-adversarial.js` (26), `teste-v2.js` (74), `teste-v21.js` (41, inclui o modo Espaços), `teste-v3.js` (179: cadastro, 8 bichinhos em 12 tamanhos com teclado, pop-up do código, nuvem A–N com dois "celulares", tela acesa/tela cheia/convite/offline, letras ≥ 12 px, padronização, correções da revisão). `_firebase-falso.js` imita identitytoolkit, securetoken e Firestore REST (com `currentDocument.exists/updateTime`). Variáveis: `CORUJA_ROOT`, `CORUJA_INDEX`, `CORUJA_PORT` para testar a pasta extraída do zip.

## 9. Limites conhecidos (honestos)
- Limpar os dados do navegador **sem internet** apaga o que ainda não subiu (o app avisa: "⚠️ Não limpe os dados do navegador até conectar na internet").
- Biblioteca gigante (mais de ~850 KB mesmo sem os textos lidos) não sobe; o app mostra o erro na Situação.
- Com a memória do celular cheia, a sincronização daquela criança para (com aviso) até liberar espaço — a nuvem nunca recebe menos do que tinha.

## 10. Histórico
v1.x formatação/biblioteca/quiz · v2.0 10 tamanhos, tela acesa, sílabas, fontes, textos lidos · v2.1 marca-texto no dicionário, alinhamento à direita, prompt "Leitura do dia" com diálogo · v3.0 crianças + nuvem + escola-pwa + configurações · **v3.1 margem em 3 modos, recuo, tamanhos em px, Formatar de texto solto com Desfazer, avisos em todos os botões**.
