/* Confere o pacote final que vai pro Netlify (não é o index.html avulso
   desta pasta de testes — é o zip separado): manifest.webmanifest é um
   JSON válido, sw.js tem uma versão de cache coerente, e os arquivos
   que o app referencia (ícones) existem. Roda direto nos arquivos do
   pacote gerado, sem precisar do JSDOM. */
const fs = require('fs');
const path = require('path');
const { t, assert, assertEq, resumo } = require('./_harness');

// Tenta a pasta de entrega (manifest.webmanifest + sw.js + ícones ao
// lado do index.html, mesmo nível desta pasta "testes") primeiro —
// é o caso normal de quem recebeu o zip. Cai pra "../../pacote" só
// como conveniência do ambiente de build interno, se existir.
const PASTA_ENTREGA = path.join(__dirname, '..');
const PASTA_PACOTE_BUILD = path.join(__dirname, '..', '..', 'pacote');
const PASTA_PACOTE = fs.existsSync(path.join(PASTA_ENTREGA, 'manifest.webmanifest'))
  ? PASTA_ENTREGA
  : PASTA_PACOTE_BUILD;

console.log('teste_10_consistencia_pacote');

if (!fs.existsSync(PASTA_PACOTE)) {
  console.log('  (pulado — pasta "pacote" não encontrada ao lado de "entrega_testes"; ' +
    'esse teste só roda quando executado de dentro do diretório de build, não da entrega final)');
} else {
  t('manifest.webmanifest é um JSON válido', () => {
    const raw = fs.readFileSync(path.join(PASTA_PACOTE, 'manifest.webmanifest'), 'utf-8');
    const obj = JSON.parse(raw); // lança se for inválido
    assert(obj.name && obj.short_name, 'manifest sem name/short_name');
  });

  t('sw.js tem um nome de cache versionado (esforco-vence-vNN)', () => {
    const sw = fs.readFileSync(path.join(PASTA_PACOTE, 'sw.js'), 'utf-8');
    const m = sw.match(/esforco-vence-v(\d+)/);
    assert(m, 'não encontrei "esforco-vence-vNN" dentro de sw.js');
  });

  t('index.html do pacote e manifest.webmanifest concordam no nome do app', () => {
    const html = fs.readFileSync(path.join(PASTA_PACOTE, 'index.html'), 'utf-8');
    const manifest = JSON.parse(fs.readFileSync(path.join(PASTA_PACOTE, 'manifest.webmanifest'), 'utf-8'));
    const tituloHtml = (html.match(/<title>([^<]*)<\/title>/) || [, ''])[1];
    assert(tituloHtml.indexOf(manifest.short_name) >= 0 || manifest.short_name.indexOf('Esforço Vence') >= 0,
      '<title> do html ("' + tituloHtml + '") e short_name do manifest ("' + manifest.short_name + '") parecem dessincronizados');
  });

  t('Ícones referenciados pelo manifest existem de fato no pacote', () => {
    const manifest = JSON.parse(fs.readFileSync(path.join(PASTA_PACOTE, 'manifest.webmanifest'), 'utf-8'));
    manifest.icons.forEach(ic => {
      const p = path.join(PASTA_PACOTE, ic.src);
      assert(fs.existsSync(p), 'ícone referenciado no manifest não existe no pacote: ' + ic.src);
    });
  });

  resumo();
}
