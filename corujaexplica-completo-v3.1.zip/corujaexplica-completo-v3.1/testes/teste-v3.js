/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Camada 3: Coruja Explica v3.0 — cadastro Nome + Bichinho, nuvem (Firebase
   DE MENTIRA — nada sai para a internet), tela acesa, tela cheia, convite
   para instalar, offline com o service worker real, fontes e pop-up do
   código da família. Tudo medido no Chromium de verdade. */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const FB = require('./_firebase-falso.js');

const ROOT = process.env.CORUJA_ROOT || require('path').join(__dirname, '..', 'pacote-netlify');
const PORT = Number(process.env.CORUJA_PORT || 9071);
const OUT = process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'); require('fs').mkdirSync(OUT, { recursive: true });
const UP = process.env.CORUJA_ORIGINAIS || path.join(__dirname, 'originais');
const MIME = { '.html':'text/html','.js':'application/javascript','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };
const BASE = `http://localhost:${PORT}/index.html`;
const FAM = 'familiasaopedro';
const TEXTO = (t) => `TÍTULO: 🌟 ${t}\n\nTAGS: teste\n\nTEXTO:\nUm texto sobre ${t}.\n\nPALAVRAS NOVAS:\nestrela = uma bola de fogo bem longe.\n\nPERGUNTAS:\n1) O que é?\na) Um peixe.\nb) Uma estrela. *\nc) Um carro.\n> Porque sim.\n\nPARA PENSAR:\nE aí?`;

let atrasoConfig = 0;
function serve(){
  return http.createServer((req, res) => {
    let p = req.url.split('?')[0]; if (p === '/') p = '/index.html';
    const vai = () => fs.readFile(path.join(ROOT, p), (e, d) => {
      if (e){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' });
      res.end(d);
    });
    if (atrasoConfig && p.endsWith('nuvem-config.js')) setTimeout(vai, atrasoConfig); else vai();
  }).listen(PORT);
}
let total = 0, falhas = 0;
function ok(nome, cond, det){
  total++;
  if (cond) console.log('✅', nome, det !== undefined && det !== '' ? '— ' + det : '');
  else { falhas++; console.log('❌', nome, det !== undefined && det !== '' ? '— ' + det : ''); }
}
const espera = ms => new Promise(r => setTimeout(r, ms));
const erros = [];

/* um "celular": contexto novo, com o Firebase de mentira ligado */
async function celular(browser, banco, opt){
  opt = opt || {};
  const ctx = await browser.newContext({ viewport: opt.vp || { width: 412, height: 915 }, hasTouch: true, serviceWorkers: opt.sw ? 'allow' : 'block' });
  if (banco){ await FB.ligar(ctx, banco); if (opt.lat) await ctx.route(/googleapis\.com/, async r => { await espera(opt.lat); r.fallback(); }); }
  else await ctx.route(/googleapis\.com/, r => { erros.push('pedido à internet sem Firebase falso: ' + r.request().url()); r.abort(); });
  await ctx.addInitScript((o) => {
    try{
      if (!o.convite) localStorage.setItem('escola_instalado', '1');
      if (o.familia) localStorage.setItem('nuvem_familia', o.familia);
    }catch(e){}
    /* prompt()/alert()/confirm() do navegador não podem aparecer */
    window.__dialogosNativos = 0;
    window.prompt = function(){ window.__dialogosNativos++; return null; };
    window.alert = function(){ window.__dialogosNativos++; };
    window.confirm = function(){ window.__dialogosNativos++; return false; };
    if (o.atraso){
      const D = Date, off = o.atraso;
      class FD extends D { constructor(...a){ if (!a.length) super(D.now() + off); else super(...a); } static now(){ return D.now() + off; } }
      window.Date = FD;
    }
  }, { convite: !!opt.convite, familia: opt.familia || '', atraso: opt.atraso || 0 });
  if (opt.init) await ctx.addInitScript(opt.init);
  const page = await ctx.newPage();
  page.on('pageerror', e => erros.push('pageerror: ' + e.message));
  page.on('console', m => {
    if (m.type() !== 'error') return;
    const u = (m.location() && m.location().url) || '';
    if (/favicon/i.test(m.text() + u)) return;
    if (/googleapis\.com/.test(u) || /status of 4\d\d/.test(m.text())) return;  /* erros de rede simulados de propósito */
    erros.push('console: ' + m.text() + ' @ ' + u);
  });
  if (opt.semConfig) await page.route('**/nuvem-config.js', r => r.fulfill({ contentType: 'application/javascript',
    body: 'window.NUVEM_CONFIG={apiKey:"",projectId:"",familia:""};' }));
  await page.goto(BASE);
  await page.waitForTimeout(300);
  return { ctx, page };
}
async function cadastrar(page, nome, bichinho){
  await page.evaluate(() => { if (!document.getElementById('telaCadastro').classList.contains('ativa')) abrirNovoUser(); });
  await page.fill('#nuNome', nome);
  await page.click(`.nuEmoji[title="${bichinho}"]`);
  await page.click('#nuPronto');
  await page.waitForTimeout(250);
}
async function salvarTexto(page, titulo){
  await page.evaluate(([t, x]) => {
    idEmEdicao = null;
    document.getElementById('caixaTexto').value = x;
    document.getElementById('inpTitulo').value = t;
    salvarNaBiblioteca();
  }, [titulo, TEXTO(titulo)]);
  await page.waitForTimeout(100);
}
async function digitarCodigo(page, codigo){
  await page.evaluate(() => pedirCodigoFamilia(false));
  await page.waitForSelector('#codOv.open');
  await page.fill('#codCampo', codigo);
  await page.click('#codGuardar');
  await page.waitForTimeout(150);
}
const sync = page => page.evaluate(() => NuvemSync.sincronizar());
const textosAqui = page => page.evaluate(() => carregarTextos());
const toast = page => page.evaluate(() => document.getElementById('toast').textContent);

(async () => {
  const server = serve();
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  /* ====================================================================
     1ª CONFERÊNCIA — CADASTRO: FUNCIONAMENTO
     ==================================================================== */
  console.log('\n### 1. Cadastro Nome + Bichinho — funcionamento\n');
  let { ctx, page } = await celular(browser, FB.criarBanco());
  ok('Sem nenhuma criança, o app abre no cadastro', await page.evaluate(() => telaAtual === 'cadastro' && document.getElementById('telaCadastro').classList.contains('ativa')));
  const tela = await page.evaluate(() => ({
    titulo: document.getElementById('nuTitulo').textContent,
    ph: document.getElementById('nuNome').placeholder,
    max: document.getElementById('nuNome').maxLength,
    sub: document.querySelector('.nuSub').textContent,
    bichos: [...document.querySelectorAll('.nuEmoji')].map(b => b.textContent + ':' + b.title),
    marcados: document.querySelectorAll('.nuEmoji.on').length,
    voltar: getComputedStyle(document.getElementById('nuVoltar')).display,
    pronto: document.getElementById('nuPronto').textContent,
    jaTenho: document.getElementById('nuNuvem').textContent,
    jaTenhoVisivel: document.getElementById('nuNuvem').offsetParent !== null,
    ordem: [...document.getElementById('nuConteudo').children].map(e => e.id || e.className)
  }));
  ok('Título "🌟 Qual é o seu nome?"', tela.titulo === '🌟 Qual é o seu nome?', tela.titulo);
  ok('Campo "Digite o seu nome..." com até 14 letras', tela.ph === 'Digite o seu nome...' && tela.max === 14);
  ok('Texto "Escolha o seu bichinho:"', tela.sub === 'Escolha o seu bichinho:');
  ok('Os 8 bichinhos oficiais, na ordem e com os nomes certos',
    tela.bichos.join(' ') === '🦉:Coruja 🦊:Raposa 🐰:Coelho 🐼:Panda 🦋:Borboleta 🐨:Coala 🐯:Tigre 🐴:Pônei', tela.bichos.join(' '));
  ok('Nenhum bichinho vem escolhido sozinho', tela.marcados === 0);
  ok('Ordem da tela: título → nome → texto → bichinhos → escolhido → botões',
    tela.ordem.join(',') === 'nuTitulo,nuNome,nuSub,nuEmojis,nuEscolhido,nuBotoes', tela.ordem.join(','));
  ok('Sem criança ainda: "← Voltar" escondido', tela.voltar === 'none');
  ok('Botões "Pronto! ✅" e "☁️ Já tenho cadastro" (nuvem configurada)', tela.pronto === 'Pronto! ✅' && tela.jaTenho === '☁️ Já tenho cadastro' && tela.jaTenhoVisivel);
  ok('A lista vem do escola-pwa.js e a cópia de reserva é idêntica', await page.evaluate(() =>
    BICHINHOS === EscolaPWA.BICHINHOS || JSON.stringify(BICHINHOS) === JSON.stringify(EscolaPWA.BICHINHOS)) &&
    await page.evaluate(() => JSON.stringify(EscolaPWA.BICHINHOS) === JSON.stringify(BICHINHOS_OFICIAIS)));
  await page.click('#nuPronto'); await page.waitForTimeout(100);
  ok('Sem nome não cadastra ("Escreva o seu nome primeiro 🙂")', await toast(page) === 'Escreva o seu nome primeiro 🙂' && await page.evaluate(() => U.us.length === 0));
  await page.fill('#nuNome', 'Renata'); await page.click('#nuPronto'); await page.waitForTimeout(100);
  ok('Sem bichinho não cadastra ("Escolha o seu bichinho 🙂")', await toast(page) === 'Escolha o seu bichinho 🙂' && await page.evaluate(() => U.us.length === 0));
  await page.focus('#nuNome'); await page.keyboard.press('Enter'); await page.waitForTimeout(100);
  ok('Enter sem bichinho: não cadastra e pede o bichinho', await toast(page) === 'Agora escolha o seu bichinho 🙂' && await page.evaluate(() => U.us.length === 0));
  await page.click('.nuEmoji[title="Borboleta"]');
  ok('"Você escolheu: 🦋 Borboleta"', await page.textContent('#nuEscolhido') === 'Você escolheu: 🦋 Borboleta');
  await page.fill('#nuNome', ' Renata  Maria');
  await page.focus('#nuNome'); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  let us = await page.evaluate(() => U.us);
  ok('Enter com bichinho cadastra, com os espaços limpos', us.length === 1 && us[0].nome === 'Renata Maria' && us[0].av === '🦋', JSON.stringify(us));
  ok('Depois de cadastrar vai direto para a tela inicial, com o chip da criança', await page.evaluate(() =>
    telaAtual === 'inicio' && document.getElementById('userChip').classList.contains('on') && /🦋\s*Renata Maria/.test(document.getElementById('userChip').textContent)));
  await page.reload(); await page.waitForTimeout(300);
  ok('Reabrir o app mantém o cadastro e, com uma criança, entra direto nela', await page.evaluate(() => telaAtual === 'inicio' && U.us.length === 1));
  await page.evaluate(() => abrirNovoUser()); await page.waitForTimeout(100);
  ok('Com criança cadastrada, o "← Voltar" aparece', await page.evaluate(() => getComputedStyle(document.getElementById('nuVoltar')).display !== 'none'));
  await cadastrar(page, 'renata maria', 'Borboleta');
  ok('Mesmo nome + bichinho (sem diferença de maiúscula) não cria repetido — abre a que existe',
    await page.evaluate(() => U.us.length) === 1 && /já está neste celular — abrindo!/.test(await toast(page)), await toast(page));
  await cadastrar(page, 'Renata Maria', 'Tigre');
  ok('Mesmo nome com outro bichinho é outra criança', await page.evaluate(() => U.us.length === 2 && userAtual().av === '🐯'));
  await page.reload(); await page.waitForTimeout(300);
  const qv = await page.evaluate(() => ({
    tela: telaAtual, titulo: document.querySelector('#telaUsuarios .marca').textContent,
    cards: [...document.querySelectorAll('#usersGrid .userCard')].map(c => c.querySelector('.uAv').textContent + ' ' + c.querySelector('.uNome').textContent),
    botoes: [...document.querySelectorAll('#usersAcoes .userAcao')].map(b => b.textContent)
  }));
  ok('Duas crianças: abre em "Quem vai estudar hoje?"', qv.tela === 'usuarios' && /Quem vai estudar hoje\?/.test(qv.titulo));
  ok('Um cartão por criança + "➕ Novo usuário"', qv.cards.join('|') === '🦋 Renata Maria|🐯 Renata Maria|➕ Novo usuário', qv.cards.join('|'));
  ok('Botões "✏️ Trocar nome ou bichinho", "🗑️ Apagar este usuário", "☁️ Recuperar da nuvem"',
    qv.botoes.join('|') === '✏️ Trocar nome ou bichinho|🗑️ Apagar este usuário|☁️ Recuperar da nuvem', qv.botoes.join('|'));
  await page.click('#usersGrid .userCard:nth-child(1)'); await page.waitForTimeout(200);
  ok('Tocar no cartão entra naquela criança', await page.evaluate(() => telaAtual === 'inicio' && userAtual().av === '🦋'));
  await salvarTexto(page, 'Estrelas');
  await page.evaluate(() => { fsizeIdx = 6; salvarConfig(); });
  await page.evaluate(() => irParaInicio()); await page.waitForTimeout(100);
  await page.click('#userChip'); await page.waitForTimeout(150);
  ok('Tocar no chip volta para "Quem vai estudar hoje?"', await page.evaluate(() => telaAtual === 'usuarios'));
  await page.click('#usersGrid .userCard:nth-child(2)'); await page.waitForTimeout(150);
  ok('Cada criança tem os PRÓPRIOS textos (a 🐯 não vê os da 🦋)', (await textosAqui(page)).length === 0);
  ok('Cada criança tem os PRÓPRIOS ajustes de leitura (tamanho padrão 22 na 🐯)', await page.evaluate(() => FSIZES[fsizeIdx] === 22));
  await page.evaluate(() => trocarUser(U.us[0].id)); await page.waitForTimeout(100);
  ok('Voltando para a 🦋, o texto e o tamanho dela estão lá', (await textosAqui(page)).length === 1 && await page.evaluate(() => fsizeIdx === 6));
  await page.evaluate(() => editarUser()); await page.waitForTimeout(100);
  ok('Editar: título "✏️ Trocar nome ou bichinho" e o nome já preenchido', await page.evaluate(() =>
    document.getElementById('nuTitulo').textContent === '✏️ Trocar nome ou bichinho' && document.getElementById('nuNome').value === 'Renata Maria'));
  await page.click('.nuEmoji[title="Tigre"]'); await page.click('#nuPronto'); await page.waitForTimeout(150);
  ok('Trocar para a identidade de OUTRA criança do celular é bloqueado', /já existe neste celular/.test(await toast(page)) && await page.evaluate(() => userAtual().av === '🦋'));
  await page.fill('#nuNome', 'Renatinha'); await page.click('.nuEmoji[title="Coelho"]'); await page.click('#nuPronto'); await page.waitForTimeout(200);
  ok('Trocar nome e bichinho leva os textos junto', await page.evaluate(() => userAtual().nome === 'Renatinha' && userAtual().av === '🐰' && carregarTextos().length === 1));
  await ctx.close();

  // bichinho antigo, máximo de 6, apagar, migração
  ({ ctx, page } = await celular(browser, FB.criarBanco(), { init: () => {
    if (!localStorage.getItem('explica_usuarios')){
      localStorage.setItem('explica_usuarios', JSON.stringify({ us: [{ id: 'p9', nome: 'Lia', av: '🦄' }, { id: 'p8', nome: 'Bia', av: '🐼' }], atual: 'p9' }));
      localStorage.setItem('explica_p9_textos', JSON.stringify([{ id: 'x1', titulo: 'Antigo', texto: 'TÍTULO: Antigo\n\nTEXTO:\nOi.', criadoEm: '2026-01-01' }]));
    }
  } }));
  ok('Criança com bichinho ANTIGO (🦄) continua aparecendo', await page.evaluate(() =>
    [...document.querySelectorAll('#usersGrid .uAv')].map(e => e.textContent).includes('🦄')));
  await page.evaluate(() => trocarUser('p9')); await page.waitForTimeout(100);
  ok('…e abre normalmente, com os textos dela', (await textosAqui(page)).length === 1);
  await page.evaluate(() => editarUser()); await page.waitForTimeout(100);
  ok('Ao editar: "O bichinho 🦄 mudou: escolha um dos 8 novos 🙂" e nenhum vem marcado', await page.evaluate(() =>
    document.getElementById('nuEscolhido').textContent === 'O bichinho 🦄 mudou: escolha um dos 8 novos 🙂' && !document.querySelector('.nuEmoji.on')));
  await page.click('#nuPronto'); await page.waitForTimeout(100);
  ok('…e só salva quando um dos 8 é escolhido', await page.evaluate(() => userAtual().av === '🦄'));
  await page.click('.nuEmoji[title="Coala"]'); await page.click('#nuPronto'); await page.waitForTimeout(150);
  ok('Escolhido um dos 8, o progresso vai junto', await page.evaluate(() => userAtual().av === '🐨' && carregarTextos().length === 1));
  ok('Nunca troca o bichinho de ninguém sozinho (a 🐼 continua 🐼)', await page.evaluate(() => U.us.find(u => u.id === 'p8').av === '🐼'));
  await page.evaluate(() => { for (let i = 0; i < 4; i++){ U.us.push({ id: 'pz' + i, nome: 'K' + i, av: '🦉' }); } salvarUsuarios(); abrirUsuarios(); });
  ok('Com 6 crianças, o cartão "Novo usuário" some', await page.evaluate(() => !document.querySelector('#usersGrid .userCard.novo')));
  await page.evaluate(() => abrirNovoUser()); await page.waitForTimeout(100);
  ok('…e o cadastro avisa que é o máximo', /Já são 6 crianças/.test(await toast(page)));
  await page.evaluate(() => trocarUser('pz3')); await page.evaluate(() => abrirUsuarios()); await page.click('.userAcao.apagar'); await page.waitForTimeout(100);
  ok('Apagar pede confirmação num pop-up do app (não do navegador)', await page.evaluate(() =>
    document.getElementById('confirmOv').classList.contains('open') && window.__dialogosNativos === 0));
  await page.click('#confirmOv .confirmOk'); await page.waitForTimeout(150);
  ok('Apagar tira só aquela criança', await page.evaluate(() => U.us.length === 5 && !U.us.some(u => u.id === 'pz3')));
  await ctx.close();

  ({ ctx, page } = await celular(browser, FB.criarBanco(), { init: () => {
    if (!sessionStorage.getItem('semeado')){
      sessionStorage.setItem('semeado', '1');
      localStorage.setItem('explica_textos', JSON.stringify([{ id: 'v1', titulo: 'Da versão 2', texto: 'TÍTULO: Velho\n\nTEXTO:\nOi.', criadoEm: '2026-09-01', arquivado: true, arquivadoEm: '2026-09-02', leituras: 3 }]));
      localStorage.setItem('explica_config', JSON.stringify({ fsizeIdx: 8, capsMode: false }));
    }
  } }));
  await cadastrar(page, 'Hinata', 'Raposa');
  const FS56 = await page.evaluate(() => FSIZES.indexOf(56));
  const mig = await page.evaluate(() => ({ t: carregarTextos(), f: fsizeIdx, caps: capsMode,
    antigo: localStorage.getItem('explica_textos'), copia: !!localStorage.getItem('explica_textos_antes_v3') }));
  ok('A biblioteca que já estava no celular vira da PRIMEIRA criança (nada se perde, histórico junto)',
    mig.t.length === 1 && mig.t[0].leituras === 3 && mig.t[0].arquivado === true, JSON.stringify(mig.t));
  ok('Os ajustes antigos (tamanho nível 9 = 56px, caixa) também passam para ela', mig.f === FS56 && mig.caps === false, JSON.stringify(mig.f));
  ok('Uma cópia da biblioteca antiga fica guardada (explica_textos_antes_v3)', mig.antigo === null && mig.copia);
  await cadastrar(page, 'Aiko', 'Panda');
  ok('A segunda criança começa do zero', (await textosAqui(page)).length === 0);
  ok('Tela de cadastro NÃO é girada', await page.evaluate(() => { abrirNovoUser(); return getComputedStyle(document.getElementById('telaCadastro')).transform === 'none'; }));
  ok('Meta viewport com interactive-widget=resizes-content', await page.evaluate(() => /interactive-widget=resizes-content/.test(document.querySelector('meta[name=viewport]').content)));
  await ctx.close();

  /* ====================================================================
     2ª CONFERÊNCIA — CADASTRO: CELULAR (12 tamanhos, com e sem teclado)
     ==================================================================== */
  console.log('\n### 2. Cadastro no celular — 8 bichinhos numa linha em 12 tamanhos\n');
  const TAM = [[740,360,'deitado'],[640,360,'deitado'],[568,320,'deitado'],[1024,600,'tablet'],[360,740,'em pé'],[320,568,'em pé'],[412,915,'em pé'],
               [740,170,'teclado deitado'],[640,150,'teclado deitado'],[568,140,'teclado deitado'],[360,420,'teclado em pé'],[320,300,'teclado em pé']];
  for (const [w, h, nome] of TAM){
    ({ ctx, page } = await celular(browser, FB.criarBanco(), { vp: { width: w, height: h } }));
    await page.focus('#nuNome'); await page.waitForTimeout(450);
    const m = await page.evaluate(() => {
      const bs = [...document.querySelectorAll('.nuEmoji')].map(b => b.getBoundingClientRect());
      const vis = el => { const r = el.getBoundingClientRect(); return r.top >= -1 && r.bottom <= innerHeight + 1 && r.left >= -1 && r.right <= innerWidth + 1 && r.height > 0; };
      let encosta = false;
      for (let i = 1; i < bs.length; i++) if (bs[i].left - bs[i - 1].right < 1) encosta = true;
      return { umaLinha: bs.every(b => Math.abs(b.top - bs[0].top) < 2), dentro: bs.every(b => b.left >= 0 && b.right <= innerWidth && b.top >= 0 && b.bottom <= innerHeight),
        encosta, menor: Math.min(...bs.map(b => Math.min(b.width, b.height))), nome: vis(document.getElementById('nuNome')), pronto: vis(document.getElementById('nuPronto')),
        vsw: document.documentElement.scrollWidth <= innerWidth + 1 };
    });
    const pon = await page.evaluate(() => { const r = document.querySelector('.nuEmoji[title="Pônei"]').getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; });
    await page.mouse.click(pon[0], pon[1]); await page.waitForTimeout(80);
    const escolheu = await page.evaluate(() => nuEmoji === '🐴');
    ok(`${w}×${h} (${nome}): 8 numa linha, inteiros, sem encostar, ≥30px, 🐴 tocável, nome e Pronto à vista`,
      m.umaLinha && m.dentro && !m.encosta && m.menor >= 30 && escolheu && m.nome && m.pronto && m.vsw,
      JSON.stringify(Object.assign({}, m, { escolheu })));
    if (w === 740 && h === 170) await page.screenshot({ path: path.join(OUT, 'v3-cadastro-teclado-deitado.png') });
    if (w === 360 && h === 420) await page.screenshot({ path: path.join(OUT, 'v3-cadastro-teclado-empe.png') });
    await ctx.close();
  }

  /* ====================================================================
     POP-UP DO CÓDIGO DA FAMÍLIA
     ==================================================================== */
  console.log('\n### 3. Pop-up do código da família (sem prompt() do navegador)\n');
  const fonte = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  ok('O app não chama prompt()/alert()/confirm() do navegador em lugar nenhum', !/[^\w.]prompt\(|[^\w.]alert\(|[^\w.]confirm\(|window\.(prompt|alert|confirm)\(/.test(fonte.replace(/\/\*[\s\S]*?\*\//g, '').replace(/<!--[\s\S]*?-->/g, '')));
  for (const [w, h] of [[412, 915], [740, 360], [740, 170], [640, 150], [568, 140], [360, 420], [320, 300]]){
    ({ ctx, page } = await celular(browser, FB.criarBanco(), { vp: { width: w, height: h } }));
    await cadastrar(page, 'Ana', 'Raposa');
    await page.evaluate(() => pedirCodigoFamilia(false));
    await page.waitForTimeout(350);
    const c = await page.evaluate(() => {
      const vis = el => { const r = el.getBoundingClientRect(); return r.height > 0 && r.top >= -1 && r.bottom <= innerHeight + 1 && r.left >= -1 && r.right <= innerWidth + 1; };
      return { campo: vis(document.getElementById('codCampo')), guardar: vis(document.getElementById('codGuardar')), cancelar: vis(document.getElementById('codCancelar')),
               texto: getComputedStyle(document.getElementById('codTexto')).display !== 'none', foco: document.activeElement.id === 'codCampo',
               nativos: window.__dialogosNativos };
    });
    const teclado = h <= 300;
    ok(`${w}×${h}${teclado ? ' (teclado aberto)' : ''}: campo e botões à vista${teclado ? ', explicação escondida' : ', com a explicação'}`,
      c.campo && c.guardar && c.cancelar && c.foco && c.nativos === 0 && (teclado ? !c.texto : c.texto), JSON.stringify(c));
    if (w === 740 && h === 170) await page.screenshot({ path: path.join(OUT, 'v3-codigo-teclado.png') });
    if (w === 412) await page.screenshot({ path: path.join(OUT, 'v3-codigo.png') });
    if (w === 412){
      await page.fill('#codCampo', 'abc'); await page.click('#codGuardar'); await page.waitForTimeout(80);
      ok('Código curto: mensagem de erro no próprio pop-up, que continua aberto', await page.evaluate(() =>
        /pelo menos 6/.test(document.getElementById('codErro').textContent) && document.getElementById('codOv').classList.contains('open')));
      await page.click('#codCancelar'); await page.waitForTimeout(80);
      ok('Cancelar fecha sem guardar', await page.evaluate(() => !document.getElementById('codOv').classList.contains('open') && !localStorage.getItem('nuvem_familia')));
      await page.evaluate(() => pedirCodigoFamilia(false)); await page.waitForTimeout(100);
      await page.goBack(); await page.waitForTimeout(150);
      ok('Botão voltar do Android fecha só o pop-up', await page.evaluate(() => !document.getElementById('codOv').classList.contains('open') && telaAtual === 'inicio'));
      await page.evaluate(() => pedirCodigoFamilia(false)); await page.waitForTimeout(100);
      await page.fill('#codCampo', 'Família São Pedro'); await page.keyboard.press('Enter'); await page.waitForTimeout(150);
      ok('Enter guarda o código (normalizado: familia-sao-pedro)', await page.evaluate(() => localStorage.getItem('nuvem_familia') === 'familia-sao-pedro' && !document.getElementById('codOv').classList.contains('open')));
    }
    await ctx.close();
  }

  /* ====================================================================
     NUVEM
     ==================================================================== */
  console.log('\n### 4. Nuvem (Firebase de mentira)\n');
  // A) sem configuração
  ({ ctx, page } = await celular(browser, null, { semConfig: true }));
  await cadastrar(page, 'Ana', 'Raposa');
  await salvarTexto(page, 'Sem nuvem');
  await page.waitForTimeout(3000);
  ok('A) Sem configuração: o app funciona igual (texto salvo)', (await textosAqui(page)).length === 1);
  ok('A) …e não chama a nuvem nenhuma vez', !erros.some(e => /sem Firebase falso/.test(e)));
  await page.evaluate(() => abrirConfig());
  ok('A) Configurações dizem que a nuvem está desligada', /Desligada/.test(await page.textContent('#cfgNuvemSt')));
  ok('A) Botões de nuvem escondidos (sem "Já tenho cadastro")', await page.evaluate(() => { abrirNovoUser(); return document.getElementById('nuNuvem').offsetParent === null; }));
  await ctx.close();

  // B) histórico antigo sobe na primeira sincronização
  const banco = FB.criarBanco();
  ({ ctx, page } = await celular(browser, banco, { init: () => {
    if (!sessionStorage.getItem('s')){ sessionStorage.setItem('s', '1');
      localStorage.setItem('explica_textos', JSON.stringify([{ id: 'v1', titulo: 'Sol', texto: 'TÍTULO: Sol\n\nTEXTO:\nOi.', criadoEm: '2026-09-01', arquivado: true, arquivadoEm: '2026-09-02', estadoEm: '2026-09-02', leituras: 4,
        quiz: { tentativas: [{ em: '2026-09-02T10:00:00Z', acertos: 2, total: 3 }], melhor: 2, total: 3 } }])); }
  } }));
  const cel1 = page, ctx1 = ctx;
  await cadastrar(cel1, 'Ana', 'Raposa');
  ok('B) Antes do código da família: nenhum dado sai do celular', !banco.pedidos.some(p => p.metodo === 'PATCH'));
  await digitarCodigo(cel1, FAM);
  await sync(cel1);
  let nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('B) O histórico antigo do celular sobe na primeira sincronização (lido, 4 leituras, quiz)',
    nv && nv.textos.length === 1 && nv.textos[0].arquivado && nv.textos[0].leituras === 4 && nv.textos[0].quiz.melhor === 2, nv && JSON.stringify(nv.textos));
  ok('B) Ficha da criança com nome, bichinho e apps.corujaexplica', (() => { const d = banco.docs['familias/' + FAM + '/usuarios/ana_1f98a']; return d && d.fields.nome.stringValue === 'Ana' && d.fields.av.stringValue === '🦊' && d.fields.apps.mapValue.fields.corujaexplica; })());
  await cel1.evaluate(() => { fsizeIdx = 7; salvarConfig(); }); await sync(cel1);
  nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('B) Ajustes da leitura também sobem (tamanho escolhido pela criança)', nv && nv.config && nv.config.fsize === 26, nv && JSON.stringify(nv.config));
  await cel1.evaluate(() => abrirConfig()); await cel1.waitForTimeout(100);
  ok('B) Situação: "✅ Tudo guardado na nuvem" e pontinho verde', /Tudo guardado na nuvem/.test(await cel1.textContent('#cfgNuvemSt')) && await cel1.evaluate(() => document.getElementById('nuvemPonto').className === 'on ok'));
  await cel1.screenshot({ path: path.join(OUT, 'v3-config.png'), fullPage: true });
  ok('B) Histórico de versões: cópia do dia criada', Object.keys(banco.docs).some(k => /apps\/corujaexplica\/versoes\/\d{4}-\d\d-\d\d$/.test(k)));

  // C) fila offline
  await ctx1.setOffline(true);
  await cel1.evaluate(() => window.dispatchEvent(new Event('offline')));
  await salvarTexto(cel1, 'Sem internet');
  await cel1.waitForTimeout(1800);
  await cel1.evaluate(() => abrirConfig()); await cel1.waitForTimeout(100);
  const off = await cel1.evaluate(() => ({ st: document.getElementById('cfgNuvemSt').textContent, ponto: document.getElementById('nuvemPonto').className, pend: NuvemSync.status().pendentes }));
  ok('C) Sem internet: o texto fica na fila (pendente)', off.pend >= 1, JSON.stringify(off));
  ok('C) Aviso "⚠️ Não limpe os dados do navegador até conectar na internet" e pontinho laranja', /Não limpe os dados do navegador/.test(off.st) && off.ponto === 'on espera');
  ok('C) Nada subiu sem internet', FB.lerApp(banco, FAM, 'ana_1f98a').textos.length === 1);
  await ctx1.setOffline(false);
  await cel1.evaluate(() => window.dispatchEvent(new Event('online')));
  await cel1.waitForTimeout(2500);
  nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('C) A internet voltou: a fila sobe sozinha', nv.textos.some(t => t.titulo === 'Sem internet'), nv.textos.map(t => t.titulo).join(','));

  // D) desmarcar, marcar, apagar também sobem
  const idSI = (await textosAqui(cel1)).find(t => t.titulo === 'Sem internet').id;
  await cel1.evaluate(id => arquivarTexto(id), idSI); await sync(cel1);
  ok('D) Marcar como lido sobe', FB.lerApp(banco, FAM, 'ana_1f98a').textos.find(t => t.id === idSI).arquivado === true);
  await cel1.evaluate(id => devolverTexto(id), idSI); await sync(cel1);
  ok('D) Desmarcar ("Ler de novo") também sobe', !FB.lerApp(banco, FAM, 'ana_1f98a').textos.find(t => t.id === idSI).arquivado);
  await cel1.evaluate(id => { registrarLeitura(id); registrarQuiz(id, 1, 1); }, idSI); await sync(cel1);
  nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('D) Leituras e respostas do quiz sobem', nv.textos.find(t => t.id === idSI).leituras === 1 && nv.textos.find(t => t.id === idSI).quiz.melhor === 1);
  await salvarTexto(cel1, 'Para apagar');
  const idAp = (await textosAqui(cel1)).find(t => t.titulo === 'Para apagar').id;
  await sync(cel1);
  await cel1.evaluate(id => { confirmarExclusao(id, 'x'); confirmarOk(); }, idAp); await sync(cel1);
  nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('D) Apagar um texto sobe como "apagado" e ele sai da nuvem', !nv.textos.some(t => t.id === idAp) && !!nv.excluidos[idAp]);

  // E) recuperação num celular limpo, pela tela
  let r2 = await celular(browser, banco);
  const cel2 = r2.page, ctx2 = r2.ctx;
  await cel2.click('#nuNuvem'); await cel2.waitForTimeout(200);
  ok('E) "☁️ Já tenho cadastro" abre "Recuperar cadastro" pedindo o código', await cel2.evaluate(() => telaAtual === 'nuvem' && /código da família/.test(document.getElementById('nuvemMsg').textContent)));
  await cel2.click('text=🔑 Código da família'); await cel2.waitForSelector('#codOv.open');
  await cel2.fill('#codCampo', FAM); await cel2.click('#codGuardar');
  await cel2.waitForSelector('#nuvemGrid .userCard', { timeout: 5000 });
  const lista = await cel2.$$eval('#nuvemGrid .userCard', cs => cs.map(c => c.querySelector('.uAv').textContent + ' ' + c.querySelector('.uNome').textContent + ' | ' + c.querySelector('.uProg').textContent));
  ok('E) A lista mostra a criança (bichinho + nome + nome do bichinho)', lista.some(l => /🦊 Ana · Raposa \| tem textos neste app/.test(l)), lista.join(' / '));
  await cel2.screenshot({ path: path.join(OUT, 'v3-recuperar.png') });
  await cel2.click('#nuvemGrid .userCard'); await cel2.waitForTimeout(800);
  let t2 = await textosAqui(cel2);
  ok('E) Tocar traz os textos e o histórico para este celular', t2.length === 2 && t2.find(t => t.id === 'v1').leituras === 4 && !t2.some(t => t.id === idAp),
    t2.map(t => t.titulo).join(','));
  ok('E) …e entra direto na criança recuperada', await cel2.evaluate(() => telaAtual === 'inicio' && userAtual().nome === 'Ana'));
  await ctx2.close();

  // F) recuperação automática: cadastrar o mesmo nome + bichinho
  r2 = await celular(browser, banco, { familia: FAM });
  await cadastrar(r2.page, 'ANA', 'Raposa');
  await r2.page.waitForTimeout(1200);
  t2 = await textosAqui(r2.page);
  ok('F) Cadastrar o mesmo nome + bichinho traz os textos sozinho', t2.length === 2, t2.map(t => t.titulo).join(','));
  ok('F) …com o aviso "☁️ 🦊 Achei os textos de ANA na nuvem!"', /Achei os textos/.test(await toast(r2.page)));
  await sync(r2.page);
  ok('F) …sem apagar nada da nuvem', FB.lerApp(banco, FAM, 'ana_1f98a').textos.length === 2);

  // G) mistura entre aparelhos
  const cel3 = r2.page, ctx3 = r2.ctx;
  await cel3.evaluate(() => { arquivarTexto(carregarTextos().find(t => t.titulo === 'Sem internet').id); });
  await salvarTexto(cel1, 'Só no celular 1');
  await sync(cel3); await sync(cel1); await sync(cel3);
  const c1 = await textosAqui(cel1), c3 = await textosAqui(cel3);
  ok('G) O que um celular marcou como lido aparece no outro', c1.find(t => t.id === idSI).arquivado === true);
  ok('G) O texto novo de um celular chega no outro', c3.some(t => t.titulo === 'Só no celular 1'));
  ok('G) Nuvem com tudo junto (3 textos)', FB.lerApp(banco, FAM, 'ana_1f98a').textos.length === 3);
  ok('G) A tela do celular 1 foi atualizada sem tirar a criança do lugar', await cel1.evaluate(() => telaAtual === 'biblioteca' && userAtual().nome === 'Ana' && !/Sem internet/.test(document.getElementById('listaBiblioteca').textContent) && /Só no celular 1/.test(document.getElementById('listaBiblioteca').textContent) && /Textos lidos \(2\)/.test(document.getElementById('linkArquivoTexto').textContent)), await cel1.evaluate(() => telaAtual + ' | ' + document.getElementById('listaBiblioteca').textContent.slice(0,200) + ' | ' + document.getElementById('linkArquivoTexto').textContent));

  // H) outro celular gravando no MEIO do envio
  let vez = 0;
  banco.antesDoPatch = async (caminho, b) => {
    if (/apps\/corujaexplica$/.test(caminho) && vez++ === 0){
      const atual = FB.lerApp(b, FAM, 'ana_1f98a');
      FB.gravarApp(b, FAM, 'ana_1f98a', 'Ana', '🦊', atual.textos.concat([{ id: 'meio', titulo: 'Gravado no meio', texto: 'TÍTULO: Meio\n\nTEXTO:\nOi.', criadoEm: '2026-09-24T09:00:00.000Z' }]),
        { excluidos: JSON.stringify(atual.excluidos) });
    }
  };
  await salvarTexto(cel1, 'Enviado junto');
  await sync(cel1);
  banco.antesDoPatch = null;
  nv = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('H) Outro celular gravou no meio do envio: a trava de versão recusa, junta e manda de novo — nada se perde',
    nv.textos.some(t => t.id === 'meio') && nv.textos.some(t => t.titulo === 'Enviado junto'), nv.textos.map(t => t.titulo).join(','));
  ok('H) O texto do outro celular chegou também neste', (await textosAqui(cel1)).some(t => t.id === 'meio'));

  // I) relógio atrasado
  const r4 = await celular(browser, banco, { familia: FAM, atraso: -3 * 864e5 });
  await cadastrar(r4.page, 'Ana', 'Raposa'); await r4.page.waitForTimeout(1000);
  await r4.page.evaluate(() => { const t = carregarTextos().find(x => x.id === 'meio'); arquivarTexto(t.id); registrarQuiz(t.id, 1, 1); });
  await sync(r4.page); await sync(cel1);
  const m1 = (await textosAqui(cel1)).find(t => t.id === 'meio');
  ok('I) Celular com o relógio 3 dias atrasado: o que ele marcou não se perde', m1 && m1.arquivado === true && m1.quiz && m1.quiz.melhor === 1, JSON.stringify(m1));
  await r4.ctx.close();

  // M) versões guardadas
  const ontem = 'familias/' + FAM + '/usuarios/ana_1f98a/apps/corujaexplica/versoes/2026-09-01';
  banco.docs[ontem] = { updateTime: FB.novoTempo(banco), createTime: 'x', fields: {
    nome: { stringValue: 'Ana' }, av: { stringValue: '🦊' }, dispositivo: { stringValue: 'velho' },
    dados: { stringValue: JSON.stringify({ textos: JSON.stringify([{ id: 'perdido', titulo: 'Texto que se perdeu', texto: 'TÍTULO: P\n\nTEXTO:\nOi.', criadoEm: '2026-08-30' }]), excluidos: '{}' }) } } };
  await cel3.evaluate(() => abrirNuvemTela()); await cel3.click('#nuvemVersoesBt');
  await cel3.waitForSelector('#nuvemGrid .userCard', { timeout: 5000 }); await cel3.waitForTimeout(200);
  const vers = await cel3.$$eval('#nuvemGrid .userCard', cs => cs.map(c => c.querySelector('.uNome').textContent + ' | ' + c.querySelector('.uProg').textContent));
  ok('M) "🕘 Versões guardadas" lista os dias, com um resumo', vers.length >= 2 && vers.some(v => /01\/09\/2026 \| 1 texto\(s\)/.test(v)), vers.join(' / '));
  const antesJuntar = (await textosAqui(cel3)).length;
  await cel3.click('#nuvemGrid .userCard:last-child'); await cel3.waitForTimeout(100);
  await cel3.click('#confirmOv .confirmOk'); await cel3.waitForTimeout(600);
  const depoisJuntar = await textosAqui(cel3);
  ok('M) Juntar a versão antiga traz o que faltava sem apagar o de hoje', depoisJuntar.some(t => t.id === 'perdido') && depoisJuntar.length === antesJuntar + 1,
    antesJuntar + ' → ' + depoisJuntar.length);

  // N) trocar nome ou bichinho leva a ficha da nuvem
  await cel3.evaluate(() => { editarUser(); });
  await cel3.fill('#nuNome', 'Aninha'); await cel3.click('.nuEmoji[title="Coelho"]'); await cel3.click('#nuPronto');
  await cel3.waitForTimeout(800); await sync(cel3);
  const nova = FB.lerApp(banco, FAM, 'aninha_1f430'), velha = FB.lerApp(banco, FAM, 'ana_1f98a');
  ok('N) Trocar o nome/bichinho: a ficha nova na nuvem recebe tudo', nova && nova.textos.length >= 4, nova && nova.textos.length);
  ok('N) …e a ficha antiga continua lá (nada é apagado)', !!velha);
  await ctx3.close();

  // J) regras bloqueando e K) regras sem "versoes"
  const bj = FB.criarBanco(); bj.modo = 'permissao';
  let rj = await celular(browser, bj, { familia: FAM });
  await cadastrar(rj.page, 'Bia', 'Panda'); await sync(rj.page);
  await rj.page.evaluate(() => abrirConfig());
  ok('J) Erro das regras aparece em português nas Configurações', /As Regras do Firestore estão bloqueando/.test(await rj.page.textContent('#cfgNuvemSt')) &&
    await rj.page.evaluate(() => document.getElementById('nuvemPonto').className === 'on erro'));
  ok('J) …e a criança não vê erro nenhum na tela inicial (só o pontinho)', await rj.page.evaluate(() => { irParaInicio(); return !document.getElementById('toast').classList.contains('show') || !/Regras/.test(document.getElementById('toast').textContent); }));
  await rj.ctx.close();
  const bk = FB.criarBanco(); bk.modo = 'semVersoes';
  rj = await celular(browser, bk, { familia: FAM });
  await cadastrar(rj.page, 'Bia', 'Panda'); await salvarTexto(rj.page, 'X'); await sync(rj.page);
  await rj.page.evaluate(() => abrirConfig());
  ok('K) Regras sem "versoes": o principal sobe mesmo assim', !!FB.lerApp(bk, FAM, 'bia_1f43c'));
  ok('K) …e as Configurações avisam', /Histórico de versões não gravou/.test(await rj.page.textContent('#cfgNuvemSt')));
  await rj.ctx.close();
  await ctx1.close();

  /* ====================================================================
     TELA ACESA · TELA CHEIA · CONVITE · OFFLINE
     ==================================================================== */
  console.log('\n### 5. Tela sempre acesa, tela cheia, convite para instalar, offline\n');
  const WL = () => {
    window.__wl = { pedidos: 0, ativos: 0, ultimo: null };
    Object.defineProperty(navigator, 'wakeLock', { configurable: true, value: { request(){
      window.__wl.pedidos++; const ouv = [];
      const l = { released: false, addEventListener(e, f){ if (e === 'release') ouv.push(f); }, release(){ this.released = true; window.__wl.ativos--; ouv.forEach(f => f()); return Promise.resolve(); } };
      window.__wl.ativos++; window.__wl.ultimo = l; return Promise.resolve(l); } } });
  };
  let rp = await celular(browser, FB.criarBanco(), { init: WL });
  await cadastrar(rp.page, 'Ana', 'Raposa');
  ok('Tela acesa pedida ao abrir o app', await rp.page.evaluate(() => window.__wl.pedidos >= 1 && window.__wl.ativos >= 1));
  await rp.page.evaluate(() => window.__wl.ultimo.release()); await rp.page.waitForTimeout(1000);
  ok('Quando o sistema solta, pede de novo sozinho', await rp.page.evaluate(() => window.__wl.ativos >= 1 && window.__wl.pedidos >= 2));
  await rp.page.evaluate(() => abrirConfig());
  ok('Configurações: chave "Tela sempre acesa" ligada, modo "Ligado"', await rp.page.evaluate(() =>
    document.getElementById('cfgTela').classList.contains('on') && /✅ Ligado:/.test(document.getElementById('cfgTelaSt').textContent)));
  await rp.page.click('#cfgTela'); await rp.page.waitForTimeout(100);
  ok('Desligar a chave solta a tela', await rp.page.evaluate(() => !document.getElementById('cfgTela').classList.contains('on') && window.__wl.ativos === 0));
  await rp.page.click('#cfgTela');
  await rp.ctx.close();
  rp = await celular(browser, FB.criarBanco(), { init: () => {
    Object.defineProperty(navigator, 'wakeLock', { configurable: true, value: { request(){ return Promise.reject(Object.assign(new Error('x'), { name: 'NotAllowedError' })); } } });
    window.__plays = 0; const p = HTMLMediaElement.prototype.play; HTMLMediaElement.prototype.play = function(){ window.__plays++; return p.call(this); };
  } });
  await cadastrar(rp.page, 'Ana', 'Raposa'); await rp.page.waitForTimeout(400);
  ok('Wake Lock recusado: entra o modo reserva (vídeo mudo invisível)', await rp.page.evaluate(() => window.__plays >= 1 && !!document.querySelector('video[aria-hidden="true"]')));
  await rp.ctx.close();
  rp = await celular(browser, FB.criarBanco(), { init: () => {
    try{ delete Navigator.prototype.wakeLock; }catch(e){}
    window.__plays = 0; const p = HTMLMediaElement.prototype.play; HTMLMediaElement.prototype.play = function(){ window.__plays++; return p.call(this); };
    window.__fs = 0; Element.prototype.requestFullscreen = function(){ window.__fs++; return Promise.resolve(); };
  } });
  await cadastrar(rp.page, 'Ana', 'Raposa'); await rp.page.waitForTimeout(300);
  ok('Navegador sem Wake Lock: também usa o modo reserva', await rp.page.evaluate(() => !('wakeLock' in navigator) && window.__plays >= 1));
  await rp.page.evaluate(() => { window.__fs = 0; });
  await rp.page.click('.inicioMarca'); await rp.page.waitForTimeout(80);
  ok('Tela cheia pedida ao tocar num lugar qualquer', await rp.page.evaluate(() => window.__fs >= 1));
  await rp.page.evaluate(() => { entrarPreparar(); window.__fs = 0; });
  await rp.page.click('#caixaTexto'); await rp.page.waitForTimeout(80);
  ok('Tocar na caixa de digitar NÃO pede tela cheia (não atrapalha o teclado)', await rp.page.evaluate(() => window.__fs === 0));
  await rp.ctx.close();

  // convite para instalar
  rp = await celular(browser, FB.criarBanco(), { convite: true });
  await rp.page.waitForTimeout(2900);
  ok('Aberto pelo navegador: aparece o convite com o passo a passo', await rp.page.evaluate(() =>
    !!document.getElementById('escolaConvite') && /três pontinhos/.test(document.getElementById('escolaConvite').textContent) && /Coruja Explica/.test(document.getElementById('escolaConvite').textContent)));
  await rp.page.screenshot({ path: path.join(OUT, 'v3-convite.png') });
  await rp.page.evaluate(() => {
    const ev = new Event('beforeinstallprompt');
    ev.prompt = () => Promise.resolve(); ev.userChoice = Promise.resolve({ outcome: 'accepted' });
    window.dispatchEvent(ev);
  });
  await rp.page.waitForTimeout(100);
  ok('Com o Chrome permitindo: botão "📲 Instalar agora"', await rp.page.evaluate(() => !!document.getElementById('ecInstalar')));
  await rp.page.click('#ecInstalar'); await rp.page.waitForTimeout(200);
  ok('Instalou: o convite some e fica marcado', await rp.page.evaluate(() => !document.getElementById('escolaConvite') && localStorage.getItem('escola_instalado') === '1'));
  await rp.ctx.close();
  rp = await celular(browser, FB.criarBanco(), { convite: true, init: () => {
    const mm = window.matchMedia.bind(window);
    window.matchMedia = q => /display-mode: fullscreen/.test(q) ? { matches: true, addListener(){}, removeListener(){}, addEventListener(){}, removeEventListener(){} } : mm(q);
  } });
  await cadastrar(rp.page, 'Ana', 'Raposa'); await rp.page.waitForTimeout(2900);
  ok('Aberto pelo ícone (app instalado): nenhum convite', await rp.page.evaluate(() => !document.getElementById('escolaConvite')));
  await rp.page.evaluate(() => abrirConfig());
  ok('…e a linha "📲 Instalar" some das Configurações', await rp.page.evaluate(() => document.getElementById('cfgInstRow').style.display === 'none'));
  await rp.ctx.close();

  // manifest + service worker real, sem internet
  const man = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.webmanifest'), 'utf8'));
  ok('Manifest instalável: name, short_name, start_url, display, ícones 192 e 512',
    man.name && man.short_name && man.start_url && /fullscreen|standalone/.test(man.display) &&
    man.icons.some(i => i.sizes === '192x192') && man.icons.some(i => i.sizes === '512x512'));
  const sw = fs.readFileSync(path.join(ROOT, 'sw.js'), 'utf8');
  ok('sw.js: guarda nuvem-sync.js e escola-pwa.js, busca nuvem-config.js na internet primeiro e não intercepta o Firebase',
    /nuvem-sync\.js/.test(sw) && /escola-pwa\.js/.test(sw) && /REDE_PRIMEIRO\s*=\s*\['nuvem-config\.js'\]/.test(sw) && /url\.origin !== self\.location\.origin\) return/.test(sw));
  rp = await celular(browser, FB.criarBanco(), { sw: true });
  await rp.page.evaluate(() => navigator.serviceWorker.ready);
  await rp.page.reload(); await rp.page.waitForTimeout(500);
  await cadastrar(rp.page, 'Ana', 'Raposa'); await salvarTexto(rp.page, 'Offline');
  await rp.ctx.setOffline(true);
  await rp.page.reload(); await rp.page.waitForTimeout(700);
  ok('Sem internet, o app abre pelo service worker real, com a criança e os textos', await rp.page.evaluate(() =>
    telaAtual === 'inicio' && carregarTextos().length === 1 && !!window.EscolaPWA && !!window.NuvemSync));
  ok('Sem internet, a configuração da nuvem vem da cópia guardada', await rp.page.evaluate(() => NuvemSync.configurada()));
  await rp.ctx.close();

  /* ====================================================================
     FONTES 12–24 px
     ==================================================================== */
  console.log('\n### 6. Tamanho das letras (nada abaixo de 12 px)\n');
  for (const vp of [{ width: 360, height: 740 }, { width: 740, height: 360 }]){
    rp = await celular(browser, FB.criarBanco(), { vp });
    const pequenos = [];
    const medir = async (onde) => {
      const r = await rp.page.evaluate(() => {
        const out = [];
        const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = w.nextNode())){
          if (!n.textContent.trim()) continue;
          const el = n.parentElement; if (!el) continue;
          const r = el.getBoundingClientRect(); if (!r.width || !r.height) continue;
          const cs = getComputedStyle(el);
          if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) continue;
          if (el.closest('.tela') && !el.closest('.tela.ativa')) continue;
          const px = parseFloat(cs.fontSize);
          if (px < 12) out.push(px.toFixed(1) + 'px «' + n.textContent.trim().slice(0, 30) + '»');
        }
        return out;
      });
      r.forEach(x => pequenos.push(onde + ': ' + x));
    };
    await medir('cadastro');
    await cadastrar(rp.page, 'Ana', 'Raposa'); await salvarTexto(rp.page, 'Fonte');
    await rp.page.evaluate(() => { const t = carregarTextos()[0]; registrarQuiz(t.id, 1, 1); });
    await rp.page.evaluate(() => irParaInicio()); await medir('início');
    await rp.page.evaluate(() => entrarLer()); await medir('meus textos');
    await rp.page.evaluate(() => { arquivarTexto(carregarTextos()[0].id); entrarArquivo(); }); await medir('lidos');
    await rp.page.evaluate(() => entrarPreparar()); await medir('preparar');
    await rp.page.evaluate(() => abrirMenuPrompt()); await medir('menu de pedidos');
    await rp.page.evaluate(() => { fecharPromptMenu(); abrirConfig(); }); await medir('configurações');
    await rp.page.evaluate(() => abrirUsuarios()); await medir('quem vai estudar');
    await rp.page.evaluate(() => abrirNuvemTela()); await medir('recuperar');
    await rp.page.evaluate(() => { irParaInicio(); abrirLeitura(carregarTextos()[0]); }); await rp.page.waitForTimeout(500); await medir('leitura');
    await rp.page.evaluate(() => abrirAjustes()); await medir('ajustes');
    await rp.page.evaluate(() => { fecharAjustes(); abrirQuiz(); }); await rp.page.waitForTimeout(300); await medir('quiz');
    ok(`${vp.width}×${vp.height}: nenhum texto visível abaixo de 12 px em 13 telas`, pequenos.length === 0, pequenos.slice(0, 8).join(' | '));
    await rp.ctx.close();
  }

  /* ====================================================================
     3ª CONFERÊNCIA — PADRONIZAÇÃO
     ==================================================================== */
  console.log('\n### 7. Padronização com os outros apps\n');
  const igual = (a, b) => fs.readFileSync(a).equals(fs.readFileSync(b));
  ok('nuvem-config.js é EXATAMENTE o arquivo enviado (byte a byte)', igual(path.join(ROOT, 'nuvem-config.js'), UP + '/3d480a65-nuvem-config.js'));
  ok('nuvem-sync.js é o mesmo arquivo compartilhado (v3)', igual(path.join(ROOT, 'nuvem-sync.js'), UP + '/e783fd2b-nuvem-sync.js') && /var VERSAO = '3'/.test(fs.readFileSync(path.join(ROOT, 'nuvem-sync.js'), 'utf8')));
  ok('escola-pwa.js é o mesmo arquivo compartilhado (v2)', igual(path.join(ROOT, 'escola-pwa.js'), UP + '/f56a856b-escola-pwa.js') && /var VERSAO = '2'/.test(fs.readFileSync(path.join(ROOT, 'escola-pwa.js'), 'utf8')));
  ok('…e são iguais aos publicados no Curiosidades, Alfabetização e Historinhas', ['curiosidades', 'alfabetizacao', 'historinhas'].every(a =>
    igual(path.join(ROOT, 'nuvem-sync.js'), path.join(process.env.CORUJA_REF || path.join(__dirname, 'referencias-outros-apps'), a, 'nuvem-sync.js')) && igual(path.join(ROOT, 'escola-pwa.js'), path.join(process.env.CORUJA_REF || path.join(__dirname, 'referencias-outros-apps'), a, 'escola-pwa.js'))));
  ok('ID na nuvem: "corujaexplica"', /var APP_NUVEM = 'corujaexplica';/.test(fonte));
  ok('Todo arquivo que o index.html chama existe no pacote', ['nuvem-config.js', 'nuvem-sync.js', 'escola-pwa.js', 'manifest.webmanifest', 'icon-192.png', 'sw.js']
    .every(f => fs.existsSync(path.join(ROOT, f))));

  /* ====================================================================
     8 — CORREÇÕES DA REVISÃO INDEPENDENTE
     ==================================================================== */
  console.log('\n### 8. Correções da revisão independente\n');
  const esperaOk = async (pg) => { for (let i = 0; i < 40; i++){ const st = await pg.evaluate(() => NuvemSync.status()); if (st.estado === 'ok' && !st.pendentes) return true; await espera(300); } return false; };
  // 8a) apagar criança no meio de um envio
  {
    const b8 = FB.criarBanco();
    const { ctx: c8, page: p8 } = await celular(browser, b8, { familia: FAM, lat: 400 });
    await cadastrar(p8, 'Ana', 'Coruja');
    await salvarTexto(p8, 'Sol');
    await cadastrar(p8, 'Bia', 'Raposa');
    await esperaOk(p8);
    const antes = FB.lerApp(b8, FAM, 'ana_1f989');
    const ids = await p8.evaluate(() => U.us.map(u => u.id));
    await p8.evaluate(ids => { localStorage.setItem('explica_' + ids[1] + '_config', '{"fsizeIdx":3}'); localStorage.setItem('explica_' + ids[0] + '_config', '{"fsizeIdx":4}'); }, ids);
    await espera(2700);
    await p8.evaluate(id => { trocarUser(id); apagarUser(); confirmarOk(); }, ids[0]);
    await espera(6000);
    const depois = FB.lerApp(b8, FAM, 'ana_1f989');
    ok('8a) Apagar uma criança durante um envio NÃO esvazia a cópia dela na nuvem',
      antes && antes.textos.length === 1 && depois && depois.textos.length === 1, (antes && antes.textos.length) + ' → ' + (depois && depois.textos.length));
    ok('8a) …e não sobra nenhum dado dela no celular', await p8.evaluate(id => Object.keys(localStorage).filter(k => k.indexOf(id) >= 0).length === 0, ids[0]));
    await c8.close();
  }
  // 8b) memória do celular cheia na hora de juntar
  {
    const b8 = FB.criarBanco();
    FB.gravarApp(b8, FAM, 'ana_1f989', 'Ana', '🦉', [{ id: 'r1', titulo: 'Remoto', texto: 'x'.repeat(300000), criadoEm: '2026-09-01T00:00:00.000Z',
      quiz: { tentativas: [{ em: '2026-09-02T00:00:00.000Z', acertos: 3, total: 3 }], melhor: 3, total: 3 } }]);
    const { ctx: c8, page: p8 } = await celular(browser, b8, { familia: FAM, lat: 100 });
    await p8.evaluate(() => { let c = 'j'.repeat(512 * 1024), i = 0; try{ for (;; i++) localStorage.setItem('lixo' + i, c); }catch(e){}
      let m = 'k'.repeat(16 * 1024), j = 0; try{ for (;; j++) localStorage.setItem('lixoP' + j, m); }catch(e){}
      for (let k = 0; k < 10; k++) localStorage.removeItem('lixoP' + k); });
    await cadastrar(p8, 'Ana', 'Coruja');
    await espera(4000);
    let nv = FB.lerApp(b8, FAM, 'ana_1f989');
    ok('8b) Memória cheia: a nuvem continua com a cópia completa do outro celular', nv.textos.length === 1 && nv.dispositivo === 'outroCelular' && nv.textos[0].quiz.melhor === 3);
    ok('8b) …e a situação avisa o problema (não mostra ✅)', await p8.evaluate(() => NuvemSync.status().estado === 'erro' && /memória do celular está cheia/.test(NuvemSync.status().detalhe)),
      await p8.evaluate(() => JSON.stringify(NuvemSync.status().estado + ' ' + NuvemSync.status().detalhe)));
    await p8.evaluate(() => { Object.keys(localStorage).filter(k => /^lixo/.test(k)).forEach(k => localStorage.removeItem(k)); });
    await p8.evaluate(() => NuvemSync.sincronizar()); await espera(500);
    nv = FB.lerApp(b8, FAM, 'ana_1f989');
    ok('8b) Liberado o espaço: o texto chega no celular e tudo volta a sincronizar',
      (await textosAqui(p8)).length === 1 && nv.textos.length === 1 && await p8.evaluate(() => NuvemSync.status().estado === 'ok'));
    await c8.close();
  }
  // 8c) dois toques em "Recuperar cadastro"
  {
    const b8 = FB.criarBanco();
    FB.gravarApp(b8, FAM, 'ana_1f989', 'Ana', '🦉', [{ id: 't1', titulo: 'A', texto: 'aaa', criadoEm: '2026-09-01T00:00:00.000Z' }]);
    const { ctx: c8, page: p8 } = await celular(browser, b8, { familia: FAM, lat: 700 });
    await p8.evaluate(() => abrirNuvemTela()); await espera(3500);
    await p8.locator('#nuvemGrid .userCard').first().click();
    await p8.locator('#nuvemGrid .userCard').first().click({ timeout: 1500 }).catch(() => {});
    await espera(3000);
    ok('8c) Dois toques rápidos no cartão da nuvem criam UMA criança só', await p8.evaluate(() => U.us.length === 1 && carregarTextos().length === 1), await p8.evaluate(() => JSON.stringify(U.us)));
    await c8.close();
  }
  // 8d) primeiro cadastro não deixa um "voltar" morto
  {
    const { ctx: c8, page: p8 } = await celular(browser, FB.criarBanco());
    await cadastrar(p8, 'Ana', 'Coruja');
    await p8.goBack(); await espera(200);
    ok('8d) Depois do primeiro cadastro, o voltar não cai num cadastro "morto": fica na tela inicial e avisa "toque de novo para sair"',
      await p8.evaluate(() => telaAtual === 'inicio' && history.state.base && location.hash === '#inicio') && /voltar de novo/.test(await toast(p8)));
    await p8.evaluate(() => entrarLer()); await espera(100);
    await p8.goBack(); await espera(200);
    ok('8d) Voltar da biblioteca → tela inicial', await p8.evaluate(() => telaAtual === 'inicio'));
    await p8.reload(); await espera(300);
    await p8.evaluate(() => abrirConfirm('Teste?', function(){})); await espera(100);
    await p8.goBack(); await espera(200);
    ok('8d) App reaberto, pop-up na primeira tela: o voltar fecha só o pop-up (e o degrau volta)', await p8.evaluate(() =>
      !document.getElementById('confirmOv').classList.contains('open') && telaAtual === 'inicio' && !history.state.base));
    await c8.close();
  }
  // 8e) backup devolve um texto que tinha sido apagado
  {
    const b8 = FB.criarBanco();
    const { ctx: c8, page: p8 } = await celular(browser, b8, { familia: FAM });
    await cadastrar(p8, 'Ana', 'Coruja');
    await salvarTexto(p8, 'Lua');
    const copia = await p8.evaluate(() => JSON.stringify({ app: BACKUP_APP_NAME, versao: 3, usuario: userAtual(), textos: carregarTextos(), excluidos: {} }));
    await p8.evaluate(() => { const id = carregarTextos()[0].id; marcarExcluido(U.atual, id); salvarTextos([]); });
    await sync(p8);
    ok('8e) (texto apagado também sumiu da nuvem)', FB.lerApp(b8, FAM, 'ana_1f989').textos.length === 0);
    await p8.setInputFiles('#backupFileInput', { name: 'b.json', mimeType: 'application/json', buffer: Buffer.from(copia) });
    await espera(300);
    await p8.evaluate(() => confirmarOk()); await espera(200);
    ok('8e) Importar o backup traz de volta o texto apagado', (await textosAqui(p8)).length === 1 && /Backup juntado/.test(await toast(p8)));
    await sync(p8); await sync(p8);
    ok('8e) …e ele não some de novo na sincronização (sobe para a nuvem)', (await textosAqui(p8)).length === 1 && FB.lerApp(b8, FAM, 'ana_1f989').textos.length === 1);
    await c8.close();
  }
  // 8f) migração na abertura sobe para a nuvem
  {
    const b8 = FB.criarBanco();
    FB.gravarApp(b8, FAM, 'ana_1f98a', 'Ana', '🦊', []);
    b8.docs['familias/' + FAM + '/usuarios/ana_1f98a/apps/corujaexplica'].fields.dispositivo.stringValue = 'dEste';
    const { ctx: c8, page: p8 } = await celular(browser, b8, { familia: FAM, init: () => {
      if (sessionStorage.getItem('m')) return; sessionStorage.setItem('m', '1');
      localStorage.setItem('nuvem_dispositivo', 'dEste');
      localStorage.setItem('explica_usuarios', JSON.stringify({ us: [{ id: 'p1', nome: 'Ana', av: '🦊' }], atual: 'p1' }));
      localStorage.setItem('explica_textos', JSON.stringify([{ id: 'v9', titulo: 'Velho', texto: 'TÍTULO: Velho\n\nTEXTO:\nOi.', criadoEm: '2026-08-01T00:00:00.000Z' }]));
    } });
    await espera(2500); await sync(p8);
    ok('8f) Biblioteca antiga achada na abertura passa para a criança e sobe para a nuvem',
      (await textosAqui(p8)).length === 1 && FB.lerApp(b8, FAM, 'ana_1f98a').textos.length === 1);
    await c8.close();
  }
  // 8g) internet lenta não deixa a tela branca (service worker)
  {
    const { ctx: c8, page: p8 } = await celular(browser, null, { sw: true, semConfigRota: true });
    await p8.evaluate(() => navigator.serviceWorker.ready); await p8.reload(); await espera(800);
    const controlado = await p8.evaluate(() => !!navigator.serviceWorker.controller);
    atrasoConfig = 12000;
    const t0 = Date.now();
    await p8.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
    const ms = Date.now() - t0;
    atrasoConfig = 0;
    ok('8g) Internet lenta: com o app instalado, abre em poucos segundos com a cópia guardada', controlado && ms < 5000, ms + ' ms');
    ok('8g) …e a nuvem continua configurada (nuvem-config.js da cópia)', await p8.evaluate(() => window.__nuvemCfgArq === 'ok' && NuvemSync.configurada()));
    await c8.close();
  }

  /* ====================================================================
     9 — v3.1: tela acesa de fábrica, tamanhos em px, Formatar com aviso
     ==================================================================== */
  console.log('\n### 9. v3.1 — tela acesa, tamanhos, Formatar e avisos\n');
  {
    const { ctx: c9, page: p9 } = await celular(browser, FB.criarBanco());
    await cadastrar(p9, 'Hinata', 'Raposa');
    await p9.evaluate(() => abrirConfig()); await espera(100);
    ok('9) Tela sempre acesa vem LIGADA de fábrica', await p9.evaluate(() => document.getElementById('cfgTela').classList.contains('on') && EscolaPWA.estado().telaAcesa.ligada));
    await p9.evaluate(() => entrarPreparar());
    const t9 = () => p9.evaluate(() => document.getElementById('toast').textContent);
    await p9.click('#btnFormatar'); await espera(60);
    ok('9) Formatar com a caixa vazia avisa', /Cole ou escreva um texto primeiro/.test(await t9()));
    await p9.click('#btnLimpar'); await espera(60);
    ok('9) Limpar com a caixa vazia avisa', /já está vazia/.test(await t9()));
    await p9.click('#btnSalvar'); await espera(60);
    ok('9) Salvar com a caixa vazia avisa', /Cole ou escreva um texto primeiro/.test(await t9()));
    await p9.click('.btnSecundario'); await espera(60);
    ok('9) Ler agora com a caixa vazia avisa', /Cole ou escreva um texto primeiro/.test(await t9()));
    const CAM = 'CAMILA E O CAVALO.\n\nCamila tem um cavalo.\n\nO cavalo é o Caco.\n\nCamila cuida do cavalo Caco.\n\nCamila come cocada.\n\nO cavalo come capim.\n\nCamila cavalga no cavalo Caco.\n\nEla é esperta.\n\nO cavalo obedece a Camila.';
    await p9.fill('#caixaTexto', CAM);
    await p9.click('#btnFormatar'); await espera(80);
    ok('9) "Camila e o cavalo": Formatar separa o título, junta as frases e AVISA o resultado',
      /TÍTULO: Camila e o cavalo/.test(await p9.inputValue('#caixaTexto')) && /Formatado: título «Camila e o cavalo» · 3 parágrafos/.test(await t9()), await t9());
    ok('9) O título detectado aparece na linha "Título:" sem o ponto', (await p9.textContent('#tituloDetectado')) === 'Camila e o cavalo');
    await p9.click('#btnFormatar'); await espera(80);
    ok('9) "↩️ Desfazer" devolve o texto original', await p9.inputValue('#caixaTexto') === CAM && /voltou/.test(await t9()));
    await p9.click('#btnFormatar'); await espera(60);
    await p9.type('#caixaTexto', ' ');
    ok('9) Mexer no texto depois de formatar: o botão volta a ser "🪄 Formatar"', (await p9.textContent('#btnFormatar')) === '🪄 Formatar');
    await p9.click('#btnSalvar'); await espera(120);
    ok('9) Salvar avisa em nome de quem ficou', /Salvo em Meus textos de Hinata/.test(await t9()), await t9());
    await p9.evaluate(() => { abrirLeitura(carregarTextos()[0]); }); await espera(400);
    ok('9) Tamanho padrão continua 22', await p9.evaluate(() => FSIZES[fsizeIdx] === 22 && parseFloat(getComputedStyle(document.querySelector('#detTexto p')).fontSize) === 22));
    await p9.click('#btnFontMais'); await espera(80);
    ok('9) A+ avisa "🔤 Tamanho 24" (em px, como nos outros apps)', await p9.evaluate(() => document.getElementById('detAviso').textContent === '🔤 Tamanho 24'));
    ok('9) Tamanhos disponíveis: 12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 56, 64', await p9.evaluate(() => FSIZES.join(',') === '12,14,16,18,20,22,24,26,28,32,36,40,48,56,64'));
    await p9.click('.detMini[onclick="toggleCase()"]'); await espera(80);
    ok('9) Aa avisa o que mudou', await p9.evaluate(() => /Letras maiúsculas e minúsculas/.test(document.getElementById('detAviso').textContent)));
    const ind = () => p9.evaluate(() => parseFloat(getComputedStyle(document.querySelector('#detTexto p')).textIndent));
    ok('9) Recuo de parágrafo vem LIGADO (o parágrafo começa com um espacinho)', await ind() > 10 && await p9.evaluate(() => document.getElementById('chaveRecuo').classList.contains('on')));
    await p9.evaluate(() => abrirAjustes()); await espera(100);
    await p9.click('#chaveRecuo'); await espera(120);
    ok('9) Desligar o recuo: parágrafo rente à margem, amostra muda, aviso e fica guardado', await ind() === 0 &&
      await p9.evaluate(() => document.getElementById('amostraRecuo').classList.contains('semRecuo') && /desligado/.test(document.getElementById('detAviso').textContent) &&
        JSON.parse(localStorage.getItem('explica_' + U.atual + '_config')).recuo === false));
    await p9.evaluate(() => { fecharAjustes(); fecharDet(true); }); await p9.reload(); await espera(300);
    await p9.evaluate(() => abrirLeitura(carregarTextos()[0])); await espera(300);
    ok('9) Reabrindo o app, o recuo continua desligado', await ind() === 0);
    await p9.evaluate(() => { alternarRecuo(); }); await espera(80);
    ok('9) Religando, o recuo volta', await ind() > 10);
    await p9.evaluate(() => { fecharDet(true); abrirConfig(); instalarApp(); }); await espera(500);
    ok('9) "Instalar" sempre responde (convite ou aviso)', await p9.evaluate(() => !!document.getElementById('escolaConvite') || /instalado|Instalar app|Adicionar/.test(document.getElementById('toast').textContent)));
    await c9.close();
  }
  {
    /* Colar com texto na caixa: pergunta e TROCA (antes juntava as duas histórias) */
    const { ctx: c9, page: p9 } = await celular(browser, FB.criarBanco());
    await c9.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'http://localhost:' + PORT });
    await cadastrar(p9, 'Ana', 'Coruja');
    await p9.evaluate(() => entrarPreparar());
    const t9 = () => p9.evaluate(() => document.getElementById('toast').textContent);
    await p9.evaluate(t => navigator.clipboard.writeText(t), TEXTO('Estrelas'));
    await p9.click('#btnColar'); await espera(200);
    const primeiro = await p9.inputValue('#caixaTexto');
    ok('9) Colar (botão) formata e avisa', /Estrelas/.test(primeiro) && /Colado e formatado/.test(await t9()));
    await p9.click('#btnColar'); await espera(150);
    ok('9) Colar o MESMO texto de novo: avisa que já está na caixa e não repete', await p9.inputValue('#caixaTexto') === primeiro && /já está na caixa/.test(await t9()));
    await p9.evaluate(t => navigator.clipboard.writeText(t), 'O SAPO\n\nO sapo pulou.\n\nO sapo nadou.');
    await p9.click('#btnColar'); await espera(200);
    ok('9) Colar OUTRO texto com a caixa cheia: pergunta antes', await p9.evaluate(() => document.getElementById('confirmOv').classList.contains('open') && /Trocar pelo texto/.test(document.getElementById('confirmMsg') ? document.getElementById('confirmMsg').textContent : document.getElementById('confirmOv').textContent)));
    await p9.evaluate(() => confirmarOk()); await espera(150);
    const trocado = await p9.inputValue('#caixaTexto');
    ok('9) …e TROCA (não junta as duas histórias)', /O sapo pulou\. O sapo nadou\./.test(trocado) && !/Estrelas/.test(trocado), trocado);
    await p9.click('#btnFormatar'); await espera(100);
    ok('9) ↩️ Desfazer traz de volta o texto anterior inteiro', await p9.inputValue('#caixaTexto') === primeiro);
    /* rascunho de uma EDIÇÃO: fechar e abrir o app não cria cópia repetida */
    await p9.evaluate(() => { salvarNaBiblioteca(); editarTexto(carregarTextos()[0].id); });
    await p9.fill('#caixaTexto', 'TÍTULO: Estrelas 2\n\nTEXTO:\nMudei o texto.');
    await p9.reload(); await espera(300);
    await p9.evaluate(() => { entrarPreparar(); salvarNaBiblioteca(); }); await espera(100);
    ok('9) Editando um texto, fechar e abrir o app e Salvar ATUALIZA (não duplica)', await p9.evaluate(() => carregarTextos().length === 1 && /Mudei/.test(carregarTextos()[0].texto)) && /atualizado/.test(await t9()), await t9());
    await c9.close();
  }
  {
    /* sem o escola-pwa.js (ex.: arquivo de teste aberto direto no celular) */
    const { ctx: c9, page: p9 } = await celular(browser, FB.criarBanco(), { init: () => {} });
    await p9.route('**/escola-pwa.js', r => r.fulfill({ status: 404, body: '' }));
    await p9.reload(); await espera(300);
    await cadastrar(p9, 'Ana', 'Coruja');
    await p9.evaluate(() => abrirConfig()); await espera(80);
    ok('9) Sem o escola-pwa.js a tela acesa também vem LIGADA (modo simples)', await p9.evaluate(() => !window.EscolaPWA && document.getElementById('cfgTela').classList.contains('on') && /Ligado/.test(document.getElementById('cfgTelaSt').textContent)));
    await p9.click('#cfgTela'); await espera(60);
    ok('9) …e dá para desligar (com aviso) e fica guardado', await p9.evaluate(() => !document.getElementById('cfgTela').classList.contains('on') && localStorage.getItem('explica_telaAcesa') === '0' && /apagar/.test(document.getElementById('toast').textContent)));
    await c9.close();
  }

  console.log('\n===== ERROS DE JAVASCRIPT =====');
  console.log(erros.length ? erros.join('\n') : '(nenhum)');
  ok('Nenhum erro de JavaScript em todo o teste', erros.length === 0);
  console.log(`\n${total - falhas}/${total} verificações da v3.x — ${falhas ? '❌ HÁ FALHAS' : '✅ TUDO CERTO'}`);
  await browser.close(); server.close();
  process.exit(falhas ? 1 : 0);
})().catch(e => { console.error('ERRO NO TESTE:', e); process.exit(2); });
