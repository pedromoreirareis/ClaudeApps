const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT='/home/claude/build',PORT=9195;
const MIME={'.html':'text/html','.js':'application/javascript','.png':'image/png'};
const srv=http.createServer((q,r)=>{let p=q.url.split('?')[0]; if(p==='/')p='/index.html'; fs.readFile(path.join(ROOT,p),(e,d)=>{if(e){r.writeHead(404);r.end();return;} r.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'x'}); r.end(d);});}).listen(PORT);
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
for (const vp of [{width:360,height:640},{width:360,height:740},{width:412,height:915},{width:640,height:360},{width:740,height:360},{width:770,height:340},{width:915,height:412},{width:1280,height:720}]){
const ctx=await b.newContext({viewport:vp});await ctx.route(/googleapis/,r=>r.abort());
await ctx.addInitScript(()=>{localStorage.setItem('escola_instalado','1');localStorage.setItem('explica_usuarios',JSON.stringify({us:[{id:'p1',nome:'H',av:'🦊'}],atual:'p1'}));});
const p=await ctx.newPage();await p.goto(`http://localhost:${PORT}/`);await p.waitForTimeout(300);
console.log(JSON.stringify(vp), await p.evaluate(async()=>{abrirLeitura({titulo:'x',texto:'Oi. Tudo bem.'});abrirAjustes();await new Promise(r=>setTimeout(r,300));
const c=document.querySelector('#ajustesOv .pcard');const cs=getComputedStyle(c);const ok=c.querySelector('.ok').getBoundingClientRect();const r=c.getBoundingClientRect();
return JSON.stringify({sh:c.scrollHeight,ch:c.clientHeight,ov:cs.overflowY,maxH:cs.maxHeight,card:[r.left,r.top,r.right,r.bottom].map(Math.round),ok:[ok.left,ok.top,ok.right,ok.bottom].map(Math.round)});}));
await ctx.close();}
await b.close();srv.close();})();
