"""Testes da v123 (versão final do novo cadastro, 07/10/2026):

1) ⚙️ na "Quem vai estudar hoje?" (pedido do Pedro): aparece com a bolinha,
   abre as Configurações do app POR CIMA, e ao fechar a tela volta igual;
   uma opção da "☁️ Família e nuvem" que abre tela do módulo fecha as
   Configurações; o botão voltar do Android fecha as Configurações; funciona
   também sem nenhuma criança no celular.
2) C1 (nuvem-sync 4.1): uma leitura da nuvem que já estava a caminho quando a
   criança foi tirada NÃO regrava as chaves dela (recuperar e checar a nuvem).
3) C2 (escola-familia 1.2): criança tirada com "guardar uma cópia neste
   celular" deixa a bolinha 🟡 até voltar; cópia de reserva de "juntar
   repetidas" não deixa amarelo.
4) Abertura mais leve: a trilha de leitura sai IDÊNTICA à da v122 (a
   classificação das sílabas só passou a guardar as respostas).
Chromium + Firebase de mentira (nunca o Firebase real)."""
from base import *
from ef import *
import json, hashlib

TRILHA_V122 = '19235fa60071451576e916a8437b1bb1'   # md5 do JSON de construirTrilha() da v122 publicada (Hina 🐰, família pmrtestes)

def st_criancas(lista, fam='pmrtestes', atual=None):
    pf = {"perfis":[{"id":i,"nome":n,"av":a} for i,n,a in lista], "atual": atual or (lista[0][0] if lista else None)}
    return {'ev_perfis': json.dumps(pf), 'escola_familia': familia_json([fam], {i: fam for i,_,_ in lista}, fam)}

def cfg_aberta(p):
    return p.evaluate("document.getElementById('cfgOv').classList.contains('open')")

def raiz_visivel(p):
    return p.evaluate("getComputedStyle(document.getElementById('efRaiz')).visibility") == 'visible'

def chaves_de(p, pre):
    return [k for k in p.evaluate("Object.keys(localStorage)") if k.startswith(pre)]

def main():
    servidor()
    res = []
    with sync_playwright() as pw:
        b = pw.chromium.launch()

        # ================= 1) ⚙️ na T4 =================
        r = R('1) ⚙️ na "Quem vai estudar hoje?"')
        for (W,H) in [(984,432),(740,360),(568,320),(360,740)]:
            ctx, fb = novo_contexto(b, largura=W, altura=H, storage=st_criancas([('1','Hina','🐰')]))
            erros = []
            p = abrir(ctx, erros); p.wait_for_timeout(2500)
            t4 = aberta(p, 'ef-t4')
            g = p.locator('#efRaiz .ef-t4-config')
            bb = g.bounding_box() if g.count() else None
            ponto = p.evaluate("(document.querySelector('#efRaiz .ef-t4-config .ef-ponto')||{}).className||''")
            r.t('%dx%d: ao abrir, a T4 tem a ⚙️ (48 px ou mais, dentro da tela) com a bolinha' % (W,H),
                t4 and bb and bb['width']>=48 and bb['height']>=48 and bb['x']+bb['width']<=W and 'ef-p-' in ponto, (bb, ponto))
            fs = caixas = p.evaluate("(()=>{const a=document.querySelector('#efRaiz .ef-t4-config').getBoundingClientRect(), b=document.querySelector('#efRaiz .ef-t4 .ef-topo .ef-icone:last-child').getBoundingClientRect(); return [a.right, b.left];})()")
            r.t('%dx%d: a ⚙️ fica antes do ⛶, sem encostar' % (W,H), fs[0] <= fs[1] - 2, fs)
            g.click(); p.wait_for_timeout(500)
            r.t('%dx%d: tocar na ⚙️ abre as Configurações do app por cima (a T4 fica escondida, sem fechar)' % (W,H),
                cfg_aberta(p) and not raiz_visivel(p) and aberta(p,'ef-t4'))
            p.click('#cfgOv .cfgX'); p.wait_for_timeout(700)
            r.t('%dx%d: fechar as Configurações volta para a T4' % (W,H), not cfg_aberta(p) and raiz_visivel(p) and aberta(p,'ef-t4'))
            r.t('%dx%d: nenhum erro de JavaScript' % (W,H), not [e for e in erros if 'console.error' not in e], erros)
            ctx.close()
        # opções da seção que abrem telas do módulo e o botão voltar
        ctx, fb = novo_contexto(b, largura=984, altura=432, storage=st_criancas([('1','Hina','🐰'),('p2','Bia','🐱')]))
        p = abrir(ctx); p.wait_for_timeout(2500)
        p.click('#efRaiz .ef-t4-config'); p.wait_for_timeout(400)
        p.evaluate("document.getElementById('cfgFamilia').scrollIntoView()"); p.click('.ef-cfg-buscar'); p.wait_for_timeout(800)
        r.t('Dentro das Configurações, "☁️ BUSCAR CRIANÇAS NA NUVEM" fecha as Configurações e mostra a tela de buscar', not cfg_aberta(p) and raiz_visivel(p) and p.is_visible('.ef-t6'))
        p.go_back(); p.wait_for_timeout(500)
        r.t('...e o voltar fecha a busca e deixa a T4', not aberta(p,'ef-t6') and aberta(p,'ef-t4'))
        p.click('#efRaiz .ef-t4-config'); p.wait_for_timeout(400)
        p.evaluate("document.getElementById('cfgFamilia').scrollIntoView()"); p.click('.ef-cfg-arrumar'); p.wait_for_timeout(600)
        r.t('"✏️ ARRUMAR" das Configurações: fecha as Configurações e a T4 entra no modo arrumar', not cfg_aberta(p) and raiz_visivel(p) and p.evaluate("document.querySelector('#efRaiz .ef-t4').classList.contains('ef-arrumando')"))
        p.go_back(); p.wait_for_timeout(400)
        p.click('#efRaiz .ef-t4-config'); p.wait_for_timeout(400)
        p.go_back(); p.wait_for_timeout(700)
        r.t('Botão voltar do Android com as Configurações abertas: fecha as Configurações e a T4 continua', not cfg_aberta(p) and raiz_visivel(p) and aberta(p,'ef-t4'))
        p.click('#efRaiz .ef-t4-config'); p.wait_for_timeout(400)
        p.click('#cfgPaiB'); p.wait_for_timeout(700)
        pai = p.evaluate("document.getElementById('paiOv').classList.contains('open')")
        r.t('Cantinho dos pais aberto pelas Configurações: a T4 continua escondida enquanto ele está aberto', pai and not raiz_visivel(p))
        p.evaluate("document.getElementById('paiOv').classList.remove('open')"); p.wait_for_timeout(700)
        r.t('...e volta quando ele fecha', raiz_visivel(p) and aberta(p,'ef-t4'))
        p.click('#efRaiz .ef-crianca[data-id="p2"]'); p.wait_for_timeout(300)
        esperar_recarga(p); fechar_app_popups(p)
        r.t('Depois de usar a ⚙️, escolher uma criança continua funcionando (entra a 🐱 Bia)', perfis(p)['atual']=='p2' and not aberta(p,'ef-t4'))
        ctx.close()
        # sem nenhuma criança
        ctx, fb = novo_contexto(b, largura=984, altura=432, storage={'escola_familia': familia_json(['pmrtestes'], {}, 'pmrtestes')})
        erros = []
        p = abrir(ctx, erros); p.wait_for_timeout(2500)
        p.click('#efRaiz .ef-t4-config'); p.wait_for_timeout(400)
        for s in ['#cfgTema','#cfgTam','#cfgFonte','#cfgCaixa']:
            p.click(s); p.wait_for_timeout(150)
        p.click('#cfgOv .cfgX'); p.wait_for_timeout(700)
        r.t('Sem nenhuma criança: a ⚙️ abre e fecha as Configurações, mudar tema/letra não dá erro e não cria criança nem chave hana_*',
            aberta(p,'ef-t4') and raiz_visivel(p) and not [e for e in erros if 'console.error' not in e] and json.loads(ls(p,'ev_perfis') or '{"perfis":[]}')['perfis']==[] and not [k for k in chaves_de(p,'') if 'hana_' in k], erros)
        ctx.close()
        res.append(r.fim())

        # ================= 2) C1 =================
        r = R('2) C1: resposta da nuvem que chega depois de a criança sair não regrava as chaves dela')
        for modo in ('recuperar', 'checar'):
            fb = FakeFirebase()
            fb.gravar_app('bia_1f431', 'Bia', '🐱', {'hana_done':'111', 'hana_trilha_v2':'1'}, familia='pmrtestes')
            ctx, _ = novo_contexto(b, fb=fb, storage=st_criancas([('1','Hina','🐰'),('p2','Bia','🐱')]))
            segurados = []; estado = {'segurar': False}
            def segura(route):
                if estado['segurar'] and route.request.method == 'GET' and 'bia_1f431' in route.request.url and '/versoes' not in route.request.url:
                    segurados.append(route); return
                route.fallback()
            ctx.route('**/firestore.googleapis.com/**', segura)
            p = abrir(ctx); p.wait_for_timeout(2500); fechar_tudo(p); fechar_app_popups(p)
            p.wait_for_timeout(1500)
            estado['segurar'] = True
            if modo == 'recuperar':
                p.evaluate("(()=>{ window.__r = null; NuvemSync.recuperar('p2','Bia','🐱',false).then(v=>window.__r=v, e=>window.__r='erro'); })()")
            else:
                p.evaluate("(()=>{ const m=JSON.parse(localStorage.getItem('nuvem_alfabetizacao_meta')||'{}'); delete m['p2']; localStorage.setItem('nuvem_alfabetizacao_meta', JSON.stringify(m)); window.__r=null; NuvemSync.sincronizar({checarNuvem:true}).then(v=>window.__r=v); })()")
            for _ in range(20):
                if segurados: break
                p.wait_for_timeout(150)
            pegou = len(segurados) > 0
            # a criança sai do celular enquanto a resposta da nuvem está a caminho
            p.evaluate("(()=>{ const f=()=>ADAPTADOR_CRIANCAS.tirar('p2'); if(NuvemSync.semVigiar) NuvemSync.semVigiar(f); else f(); NuvemSync.limparPendencia && NuvemSync.limparPendencia('p2'); })()")
            antes = chaves_de(p, 'p2_')
            estado['segurar'] = False
            for rt in segurados:
                try: rt.fallback()
                except Exception: pass
            p.wait_for_timeout(2500)
            depois = chaves_de(p, 'p2_')
            r.t('%s: a resposta chegou depois de a Bia sair e as chaves p2_hana_* NÃO voltaram' % modo, pegou and not antes and not depois, (pegou, antes, depois))
            if modo == 'recuperar':
                r.t('recuperar: devolve "não juntou" (false)', p.evaluate("window.__r") is False, p.evaluate("window.__r"))
            hana = ls(p, 'hana_done')
            r.t('%s: a Hana continua intacta e a ficha da Bia na nuvem continua lá' % modo, (fb.dados_app('bia_1f431', familia='pmrtestes') or {}).get('hana_done') == '111')
            ctx.close()
        # o app também se protege: juntar numa criança que não está na lista não grava nada
        ctx, fb = novo_contexto(b, storage=st_criancas([('1','Hina','🐰')]))
        p = abrir(ctx); p.wait_for_timeout(2000)
        p.evaluate("nuvemMesclar('p9', {hana_done:'111'}, false)")
        r.t('nuvemMesclar numa criança que não está no celular não grava nenhuma chave', not chaves_de(p, 'p9_'))
        p.evaluate("nuvemMesclar('1', {hana_done:'0101'}, false)")
        r.t('...e numa criança do celular continua juntando como antes', '1' in (ls(p,'hana_done') or '') )
        r.t('nuvem-sync.js é a 4.1 e escola-familia.js é a 1.2', p.evaluate("NuvemSync.versao")=='4.1' and p.evaluate("EscolaFamilia.versao")=='1.2')
        ctx.close()
        res.append(r.fim())

        # ================= 3) C2 =================
        r = R('3) C2: criança guardada só na lixeira deste celular deixa a bolinha 🟡')
        fb = FakeFirebase()
        ctx, _ = novo_contexto(b, fb=fb, storage=st_criancas([('1','Hina','🐰'),('p2','Bia','🐱')]))
        instalar_offline(ctx)
        p = abrir(ctx); p.wait_for_timeout(3000); fechar_tudo(p); fechar_app_popups(p)
        p.evaluate("NuvemSync.sincronizar()"); p.wait_for_timeout(2500)
        cor0 = status_txt(p)['cor']
        lix = [{"id":"p2","nome":"Bia","av":"🐱","fam":"pmrtestes","quando":1,"dados":{"hana_done":"1111"},"soAqui":True}]
        p.evaluate("v=>{ localStorage.setItem('escola_lixeira_alfabetizacao', v); }", json.dumps(lix))
        p.evaluate("(()=>{ const f=()=>ADAPTADOR_CRIANCAS.tirar('p2'); NuvemSync.semVigiar(f); NuvemSync.limparPendencia('p2'); })()")
        s = status_txt(p)
        r.t('Com uma criança só na lixeira: bolinha 🟡 "🗑️ 1 CRIANÇA TIRADA(S) GUARDADA(S) SÓ NESTE CELULAR…" (antes estava %s)' % cor0,
            cor0=='verde' and s['cor']=='amarelo' and 'SÓ NESTE CELULAR' in s['txt'], s)
        p.evaluate("EscolaFamilia.abrir('nuvem')"); p.wait_for_timeout(1500)
        p.locator('.ef-lixeira .ef-mini').first.click(); p.wait_for_timeout(1500)
        fechar_tudo(p); p.evaluate("NuvemSync.sincronizar()"); p.wait_for_timeout(2500)
        s2 = status_txt(p)
        r.t('Trazendo a criança de volta (☁️ Buscar na nuvem › Tiradas deste celular), a bolinha volta a 🟢', s2['cor']=='verde', s2)
        p.evaluate("""v=>{ localStorage.setItem('escola_lixeira_alfabetizacao', v); }""", json.dumps([dict(lix[0], soAqui=False), {k:v for k,v in lix[0].items() if k!='soAqui'}]))
        p.evaluate("EscolaFamilia.atualizar && EscolaFamilia.atualizar(true)")
        r.t('Cópia de reserva (soAqui:false, ex.: depois de "juntar repetidas") e cópia antiga da v122/v122b (sem a marca) não deixam a bolinha amarela', status_txt(p)['cor']=='verde', status_txt(p))
        ctx.close()
        res.append(r.fim())

        # ================= 4) abertura =================
        r = R('4) Abertura: a trilha de leitura sai idêntica à da v122')
        ctx, fb = novo_contexto(b, storage=st_criancas([('1','Hina','🐰')]))
        p = abrir(ctx); p.wait_for_timeout(1500)
        t = p.evaluate("JSON.stringify(construirTrilha())")
        r.t('construirTrilha() igual à da v122 (md5 %s)' % TRILHA_V122[:8], hashlib.md5(t.encode()).hexdigest()==TRILHA_V122, hashlib.md5(t.encode()).hexdigest())
        n = p.evaluate("_CAT_SIL.size")
        r.t('A classificação guarda cada combinação uma vez só (≈ 2,6 mil, em vez de calcular 22 mil vezes): %d' % n, 50 < n < 5000)
        ctx.close()
        res.append(r.fim())
        b.close()
    return res

if __name__=='__main__':
    res = main()
    ok = sum(a for a,_ in res); tot = sum(t for _,t in res)
    print('\nV123: %d/%d' % (ok,tot))
    sys.exit(0 if ok==tot else 1)
