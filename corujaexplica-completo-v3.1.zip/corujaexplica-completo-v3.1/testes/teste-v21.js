/* [passagem 14/10/2026] caminhos ajustáveis: por padrão este teste usa a pasta ../pacote-netlify
   e grava capturas em ./saida (ver COMO_RODAR.md). A lógica do teste não mudou. */
/* Camada 2c: as correções da v2.1, medidas no navegador real.
   - marca-texto dentro do pop-up do dicionário
   - margem direita alinhada (com teto de espaço)
   - leitura girada (celular em pé): marca-texto e margem continuam certos
   - respiro entre Ler e a linha de botões */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const ROOT = process.env.CORUJA_ROOT || require('path').join(__dirname, '..', 'pacote-netlify');
const PORT = Number(process.env.CORUJA_PORT || 8981);
const OUT = process.env.CORUJA_OUT || require('path').join(__dirname, 'saida'); require('fs').mkdirSync(OUT, { recursive: true });
const CRUZEIRO = fs.readFileSync(path.join(__dirname, 'fixture-cruzeiro.txt'), 'utf8');
const MIME = { '.html':'text/html','.js':'application/javascript','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };

function serve(){
  return http.createServer((req,res)=>{
    let p = req.url.split('?')[0]; if (p === '/') p = '/index.html';
    fs.readFile(path.join(ROOT,p),(e,d)=>{
      if (e){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200,{'Content-Type': MIME[path.extname(p)] || 'application/octet-stream'});
      res.end(d);
    });
  }).listen(PORT);
}
let total = 0, falhas = 0;
function ok(nome, cond, det){
  total++;
  if (cond) console.log('✅', nome, det ? '— ' + det : '');
  else { falhas++; console.log('❌', nome, det ? '— ' + det : ''); }
}
const TEXTOS = [{ id:'t1', titulo:'Cruzeiro', texto: CRUZEIRO, criadoEm:'2026-09-20T10:00:00.000Z' }];

/* mede, em coordenadas do texto (desfazendo giro/escala), cada linha de cada
   bloco: onde termina, onde é a margem, e quanto cada espaço cresceu */
const MEDIR = () => {
  const box = document.getElementById('detTexto');
  const m = mapaLocal(box);
  const res = { linhas: 0, rentes: 0, passou: 0, maxExtraEm: 0, porBloco: [] };
  blocosDeTexto(box).forEach(b => {
    const L = linhasDoBloco(b, m);
    const cs = getComputedStyle(b), f = parseFloat(cs.fontSize);
    const dir = m.ret(b.getBoundingClientRect()).r - parseFloat(cs.paddingRight || 0);
    res.porBloco.push(L.length);
    L.forEach((l, i) => {
      if (l.dir > dir + 1) res.passou++;
      if (i < L.length - 1){ res.linhas++; if (dir - l.dir <= 2) res.rentes++; }
    });
    b.querySelectorAll('.wsp').forEach(sp => {
      const mr = parseFloat(sp.style.marginRight || 0);
      if (mr / f > res.maxExtraEm) res.maxExtraEm = mr / f;
    });
  });
  res.ovf = box.scrollWidth - box.clientWidth;
  return res;
};

async function abrir(browser, vp, cfg, erros){
  const ctx = await browser.newContext({ viewport: vp, hasTouch: true });
  await require('./_usuario-teste.js')(ctx);
  const page = await ctx.newPage();
  page.on('pageerror', e => erros.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/favicon/i.test(m.text() + ((m.location() && m.location().url) || ''))) erros.push('console: ' + m.text()); });
  await page.goto(`http://localhost:${PORT}/index.html`);
  await page.evaluate(([t, c]) => { localStorage.clear(); localStorage.setItem('explica_p1_textos', JSON.stringify(t));
    if (c) localStorage.setItem('explica_p1_config', JSON.stringify(c)); }, [TEXTOS, cfg]);
  await page.reload(); await page.waitForTimeout(250);
  return { ctx, page };
}
async function abrirLeitura(page){
  await page.evaluate(() => abrirLeitura(carregarTextos()[0]));
  await page.waitForTimeout(650);
}

(async () => {
  const server = serve();
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const erros = [];

  /* ========== 1. Marca-texto no dicionário ========== */
  console.log('\n### 1. Marca-texto dentro do pop-up do dicionário\n');
  let { ctx, page } = await abrir(browser, { width: 915, height: 412 }, null, erros);
  await abrirLeitura(page);
  // abre a palavra do dicionário com a explicação mais comprida
  const info = await page.evaluate(() => {
    const gs = [...document.querySelectorAll('#detTexto .w.gloss')];
    let melhor = null, tam = 0;
    gs.forEach(g => { g.click(); const n = document.getElementById('glossDef').textContent.length; if (n > tam){ tam = n; melhor = g; } fecharGloss(); });
    melhor.click();
    const def = document.getElementById('glossDef');
    return { palavras: def.querySelectorAll('.w').length, glossDentro: def.querySelectorAll('.gloss').length,
             texto: def.textContent, linhas: new Set([...def.querySelectorAll('.w')].map(w => Math.round(w.getBoundingClientRect().top))).size };
  });
  ok('A explicação do dicionário vira palavras tocáveis', info.palavras > 5, `${info.palavras} palavras, ${info.linhas} linhas`);
  ok('Sem "dicionário dentro do dicionário" (nenhuma palavra sublinhada no pop-up)', info.glossDentro === 0);
  ok('O texto da explicação continua o mesmo', /[A-Z]/.test(info.texto) && !/­/.test(info.texto));
  ok('Explicação tem mais de uma linha (para o teste valer)', info.linhas >= 2, String(info.linhas));
  const toqueDef = await page.evaluate(() => {
    const def = document.getElementById('glossDef');
    const ws = [...def.querySelectorAll('.w')];
    const tops = [...new Set(ws.map(w => Math.round(w.getBoundingClientRect().top)))].sort((a, b) => a - b);
    const naSegunda = ws.filter(w => Math.round(w.getBoundingClientRect().top) === tops[1]);
    const alvo = naSegunda[0].getBoundingClientRect();
    def.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1, clientX: alvo.left + 2, clientY: (alvo.top + alvo.bottom) / 2 }));
    const bar = def.querySelector('.lineHi');
    const br = bar.getBoundingClientRect();
    const esq = Math.min(...naSegunda.map(w => w.getBoundingClientRect().left));
    const dir = Math.max(...naSegunda.map(w => w.getBoundingClientRect().right));
    return { on: bar.classList.contains('on'), barTop: br.top, barBot: br.bottom, lt: alvo.top, lb: alvo.bottom,
             cobreLargura: br.left <= esq && br.right >= dir, aberto: document.getElementById('glossOv').classList.contains('open') };
  });
  ok('Tocar na 2ª linha da explicação pinta a 2ª linha', toqueDef.on && toqueDef.barTop <= toqueDef.lt + 3 && toqueDef.barBot >= toqueDef.lb - 3 && (toqueDef.barBot - toqueDef.barTop) < 2 * (toqueDef.lb - toqueDef.lt), JSON.stringify(toqueDef));
  ok('A faixa cobre a linha inteira da explicação', toqueDef.cobreLargura);
  ok('Tocar na explicação NÃO fecha o dicionário', toqueDef.aberto);
  await page.screenshot({ path: path.join(OUT, 'v21-dicionario-marcado.png') });
  const reab = await page.evaluate(() => { fecharGloss(); document.querySelector('#detTexto .w.gloss').click();
    return document.getElementById('glossDef').querySelectorAll('.lineHi.on').length; });
  ok('Abrir outra palavra começa sem linha marcada', reab === 0);
  ok('Toque "de mentira" (posição 0,0) marca a linha da própria palavra, não a 1ª linha', await page.evaluate(() => {
    fecharGloss();
    const box = document.getElementById('detTexto');
    const w = [...box.querySelectorAll('p:nth-of-type(3) .w')].filter(x => x.getClientRects().length === 1)[3];
    w.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 0, clientX: 0, clientY: 0 }));
    const bar = box.querySelector('.lineHi').getBoundingClientRect(), r = w.getBoundingClientRect();
    return bar.top <= r.top + 3 && bar.bottom >= r.bottom - 3;
  }));
  await page.evaluate(() => fecharGloss());
  // tocar fora continua fechando
  await page.evaluate(() => document.querySelector('#detTexto .w.gloss').click());
  await page.mouse.click(15, 15); await page.waitForTimeout(100);
  ok('Com a voz ligada, o marca-texto da explicação respeita a regra do texto (não pinta)', await page.evaluate(() => {
    document.querySelector('#detTexto .w.gloss').click();
    toggleVoz();
    const def = document.getElementById('glossDef'); const w = def.querySelector('.w'); const r = w.getBoundingClientRect();
    def.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1, clientX: r.left + 2, clientY: (r.top + r.bottom) / 2 }));
    const pintou = !!def.querySelector('.lineHi.on');
    toggleVoz(); fecharGloss(); pararVoz();
    return !pintou;
  }));
  ok('Tocar fora do pop-up continua fechando o dicionário', await page.evaluate(() => !document.getElementById('glossOv').classList.contains('open')));
  await ctx.close();

  /* ========== 2. Margem direita ========== */
  console.log('\n### 2. Margem direita alinhada\n');
  ({ ctx, page } = await abrir(browser, { width: 915, height: 412 }, { fsizeIdx: 3, capsMode: true, fontIdx: 0, silabasOn: true }, erros));
  await abrirLeitura(page);
  ok('Ajuste antigo com sílabas ligadas vira a opção "Sílabas" (com a margem alinhada)', await page.evaluate(() => modoMargem === 'silabas' && silabasOn === true));
  let com = await page.evaluate(MEDIR);
  await page.evaluate(() => { modoMargem = 'normal'; ajustaMargemDireita(); });
  let sem = await page.evaluate(MEDIR);
  await page.evaluate(() => { modoMargem = 'silabas'; ajustaMargemDireita(); });
  ok('26px + sílabas: com o ajuste, bem mais linhas ficam rentes à margem', com.rentes / com.linhas >= 0.6 && com.rentes > sem.rentes * 3,
     `rentes ${com.rentes}/${com.linhas} (sem ajuste: ${sem.rentes}/${sem.linhas})`);
  ok('Nenhuma linha passa da margem direita', com.passou === 0 && com.ovf <= 1, `passou=${com.passou} ovf=${com.ovf}`);
  ok('Nenhum espaço cresce mais que o teto (0,20 da letra)', com.maxExtraEm <= 0.2001, com.maxExtraEm.toFixed(3) + 'em');
  ok('O ajuste não muda a quebra das linhas (mesmo número de linhas)', JSON.stringify(com.porBloco) === JSON.stringify(sem.porBloco));
  ok('Conferência independente (sem as funções do app): nenhum pedaço de palavra invade a margem', await page.evaluate(() => {
    const box = document.getElementById('detTexto');
    const lim = box.getBoundingClientRect().right - parseFloat(getComputedStyle(box).paddingRight) + 0.5;
    return [...box.querySelectorAll('.w')].every(w => [...w.getClientRects()].every(r => r.right <= lim));
  }));
  ok('A última linha de cada parágrafo não é esticada', await page.evaluate(() => {
    const box = document.getElementById('detTexto'), m = mapaLocal(box);
    return blocosDeTexto(box).every(b => { const L = linhasDoBloco(b, m); if (!L.length) return true;
      return L[L.length - 1].espacos.every(sp => !sp.style.marginRight); });
  }));
  await page.evaluate(() => { document.getElementById('detTexto').scrollTop = 300; });
  await page.screenshot({ path: path.join(OUT, 'v21-margem-26px.png') });

  // desligar pela chave
  await page.click('#btnAjustes'); await page.waitForTimeout(150);
  ok('Nos ajustes, a opção "Sílabas" aparece marcada', await page.evaluate(() => document.querySelector('.opcaoMargem.sel').getAttribute('data-modo') === 'silabas'));
  await page.click('.opcaoMargem[data-modo="normal"]'); await page.waitForTimeout(150);
  ok('"Normal" tira todo o ajuste e os tracinhos, e fica guardado', await page.evaluate(() =>
    document.querySelectorAll('#detTexto .wsp.aj').length === 0 && !document.getElementById('detTexto').textContent.includes('\u00AD') &&
    JSON.parse(localStorage.getItem('explica_p1_config')).modoMargem === 'normal'));
  await page.click('.opcaoMargem[data-modo="silabas"]'); await page.waitForTimeout(150);
  await page.click('.pcardAjustes .ok'); await page.waitForTimeout(100);

  // mudar tamanho refaz
  for (let i = 0; i < 6; i++){ await page.click('#btnFontMais'); await page.waitForTimeout(40); }
  com = await page.evaluate(MEDIR);
  ok('64px: depois de mudar o tamanho o ajuste é refeito, sem passar da margem', com.passou === 0 && com.ovf <= 1 && com.maxExtraEm <= 0.2001,
     `rentes ${com.rentes}/${com.linhas}, maior espaço extra ${com.maxExtraEm.toFixed(3)}em`);
  await page.evaluate(() => { modoMargem = 'normal'; ajustaMargemDireita(); });
  sem = await page.evaluate(MEDIR);
  await page.evaluate(() => { modoMargem = 'silabas'; ajustaMargemDireita(); });
  ok('64px: a margem fica mais reta que sem o ajuste', com.rentes > sem.rentes, `${com.rentes} × ${sem.rentes}`);
  await page.evaluate(() => { document.getElementById('detTexto').scrollTop = 600; });
  await page.screenshot({ path: path.join(OUT, 'v21-margem-64px.png') });

  // trocar a letra refaz
  await page.evaluate(() => escolherFonte(1)); await page.waitForTimeout(300);
  com = await page.evaluate(MEDIR);
  ok('Sassoon: ajuste refeito, sem passar da margem', com.passou === 0 && com.ovf <= 1 && com.maxExtraEm <= 0.2001, `rentes ${com.rentes}/${com.linhas}`);
  // girar / redimensionar refaz
  await page.setViewportSize({ width: 1024, height: 600 }); await page.waitForTimeout(400);
  com = await page.evaluate(MEDIR);
  ok('Mudou o tamanho da tela: ajuste refeito, sem passar da margem', com.passou === 0 && com.ovf <= 1 && com.rentes > 0, `rentes ${com.rentes}/${com.linhas}`);
  // caixa baixa (Aa) refaz
  await page.evaluate(() => toggleCase()); await page.waitForTimeout(150);
  com = await page.evaluate(MEDIR);
  ok('Letras minúsculas (Aa): ajuste refeito, sem passar da margem', com.passou === 0 && com.rentes > 0, `rentes ${com.rentes}/${com.linhas}`);
  // modo Normal: nenhum espaço é esticado
  await page.evaluate(() => { toggleCase(); escolherModoMargem('normal'); }); await page.waitForTimeout(150);
  ok('Modo "Normal": nenhum espaço é esticado', await page.evaluate(() => document.querySelectorAll('#detTexto .wsp.aj').length === 0));
  await page.evaluate(() => { escolherModoMargem('silabas'); }); await page.waitForTimeout(150);
  ok('Voltando para "Sílabas", o ajuste volta sozinho', await page.evaluate(() => document.querySelectorAll('#detTexto .wsp.aj').length > 0));
  await page.evaluate(() => { escolherModoMargem('espacos'); }); await page.waitForTimeout(150);
  // marca-texto continua certo com o ajuste
  const faixa = await page.evaluate(() => {
    const box = document.getElementById('detTexto');
    const w = [...box.querySelectorAll('p .w')][12]; const r = w.getBoundingClientRect();
    w.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1, clientX: r.left + 3, clientY: (r.top + r.bottom) / 2 }));
    const bar = box.querySelector('.lineHi').getBoundingClientRect();
    const br = box.getBoundingClientRect();
    return { ok: bar.top <= r.top + 3 && bar.bottom >= r.bottom - 3 && bar.right <= br.right + 1 };
  });
  ok('Marca-texto continua pintando a linha certa com a margem ajustada', faixa.ok);
  await page.evaluate(() => fecharGloss());
  await ctx.close();

  /* ========== 3. Leitura girada (celular em pé) ========== */
  /* ========== 2b. Modo "Espaços" (v3.1) ========== */
  console.log('\n### 2b. Margem direita: modo "Espaços" (sem sílabas)\n');
  const ESPACO = () => { const m = mapaLocal(document.getElementById('detTexto'));
    const sp = [...document.querySelectorAll('#detTexto p .wsp')].map(x => { const r = x.getClientRects()[0]; if (!r) return 0; const q = m.ret(r); return q.r - q.l; }).filter(w => w > 0).sort((a, b) => a - b);
    const f = parseFloat(getComputedStyle(document.querySelector('#detTexto p')).fontSize); return sp[sp.length >> 1] / f; };
  for (const [vp, px, fonte, nome] of [[{ width: 915, height: 412 }, 22, 0, '22px Bastão'], [{ width: 915, height: 412 }, 64, 0, '64px Bastão (TV)'],
                                       [{ width: 915, height: 412 }, 28, 1, '28px Sassoon'], [{ width: 360, height: 640 }, 26, 0, '26px girado (em pé)']]){
    ({ ctx, page } = await abrir(browser, vp, { fsize: px, capsMode: true, fontIdx: fonte, modoMargem: 'espacos' }, erros));
    await abrirLeitura(page);
    const com2 = await page.evaluate(MEDIR);
    const hif2 = await page.evaluate(() => document.getElementById('detTexto').textContent.includes('­'));
    await page.evaluate(() => { modoMargem = 'normal'; ajustaMargemDireita(); });
    const esp0 = await page.evaluate(ESPACO);
    const sem2 = await page.evaluate(MEDIR);
    await page.evaluate(() => { modoMargem = 'espacos'; ajustaMargemDireita(); });
    ok(`Espaços, ${nome}: nenhuma palavra cortada, mais linhas rentes, nada passa da margem, mesmas quebras de linha`,
      !hif2 && com2.rentes > sem2.rentes && com2.passou === 0 && com2.ovf <= 1 && JSON.stringify(com2.porBloco) === JSON.stringify(sem2.porBloco),
      `rentes ${com2.rentes}/${com2.linhas} (normal: ${sem2.rentes})`);
    ok(`Espaços, ${nome}: nenhum espaço cresce mais que 75% do espaço normal (fica ≤ 1,75×)`, com2.maxExtraEm <= esp0 * 0.75 + 0.002,
      `maior extra ${com2.maxExtraEm.toFixed(3)}em · espaço normal ${esp0.toFixed(3)}em → ${(1 + com2.maxExtraEm / esp0).toFixed(2)}×`);
    if (px === 22 && fonte === 0) await page.screenshot({ path: path.join(OUT, 'v31-espacos-22px.png') });
    if (px === 64) await page.screenshot({ path: path.join(OUT, 'v31-espacos-64px.png') });
    await ctx.close();
  }

  console.log('\n### 3. Celular em pé (cartão girado)\n');
  ({ ctx, page } = await abrir(browser, { width: 360, height: 640 }, { fsizeIdx: 5, capsMode: true, fontIdx: 0, silabasOn: true }, erros));
  await abrirLeitura(page);
  const girado = await page.evaluate(() => /matrix|rotate/.test(getComputedStyle(document.getElementById('detCard')).transform));
  ok('Neste tamanho o cartão de leitura está mesmo girado (o teste vale)', girado);
  com = await page.evaluate(MEDIR);
  await page.evaluate(() => { modoMargem = 'normal'; ajustaMargemDireita(); });
  sem = await page.evaluate(MEDIR);
  await page.evaluate(() => { modoMargem = 'silabas'; ajustaMargemDireita(); });
  ok('Girado: margem ajustada (bem mais linhas rentes) e nada passa da margem',
     com.rentes > sem.rentes * 3 && com.passou === 0 && com.ovf <= 1 && com.maxExtraEm <= 0.2001 &&
     JSON.stringify(com.porBloco) === JSON.stringify(sem.porBloco),
     `rentes ${com.rentes}/${com.linhas} (sem ajuste: ${sem.rentes})`);
  const faixaG = await page.evaluate(() => {
    const box = document.getElementById('detTexto'), m = mapaLocal(box);
    /* uma palavra inteira (não cortada em duas linhas), do meio do parágrafo */
    const ws = [...box.querySelectorAll('p:nth-of-type(2) .w')].filter(x => x.getClientRects().length === 1);
    const w = ws[Math.floor(ws.length / 2)];
    const r = w.getBoundingClientRect();
    w.dispatchEvent(new MouseEvent('click', { bubbles: true, detail: 1, clientX: (r.left + r.right) / 2, clientY: (r.top + r.bottom) / 2 }));
    const bar = box.querySelector('.lineHi');
    const bt = parseFloat(bar.style.top), bh = parseFloat(bar.style.height), bw = parseFloat(bar.style.width);
    const q = m.ret(w.getClientRects()[0]);
    return { dentro: bt <= q.t + 3 && bt + bh >= q.b - 3, altura: bh, alturaPalavra: q.b - q.t, largura: bw, larguraBox: box.clientWidth };
  });
  ok('Girado: tocar numa palavra pinta a linha DELA (não uma coluna)', faixaG.dentro && faixaG.altura < faixaG.alturaPalavra * 1.8 && faixaG.largura > faixaG.larguraBox * 0.3,
     JSON.stringify(faixaG));
  await page.evaluate(() => fecharGloss());
  await page.screenshot({ path: path.join(OUT, 'v21-girado.png') });
  // dicionário girado? o pop-up não gira — continua valendo
  await ctx.close();

  /* ========== 4. Respiro nos cards ========== */
  console.log('\n### 4. Respiro entre Ler e os botões de baixo\n');
  ({ ctx, page } = await abrir(browser, { width: 412, height: 915 }, null, erros));
  await page.evaluate(() => entrarLer()); await page.waitForTimeout(200);
  const gap = await page.evaluate(() => {
    const c = document.querySelector('#listaBiblioteca .cardTexto');
    return c.querySelector('.cardAcoes').getBoundingClientRect().top - c.querySelector('.cardLer').getBoundingClientRect().bottom;
  });
  ok('Espaço entre Ler e Editar/Lido/Excluir é de pelo menos 16px (antes 8px)', gap >= 16, gap + 'px');
  await page.screenshot({ path: path.join(OUT, 'v21-cards.png') });
  await ctx.close();

  console.log('\n===== ERROS DE CONSOLE/JAVASCRIPT =====');
  console.log(erros.length ? erros.join('\n') : '(nenhum)');
  ok('Nenhum erro de JavaScript', erros.length === 0);
  console.log(`\n${total - falhas}/${total} verificações da v2.1 — ${falhas ? '❌ HÁ FALHAS' : '✅ TUDO CERTO'}`);
  await browser.close(); server.close();
  process.exit(falhas ? 1 : 0);
})().catch(e => { console.error('ERRO NO TESTE:', e); process.exit(2); });
