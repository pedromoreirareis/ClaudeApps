# Relatório do revisor B (telas, crianças e celular) — v122b, rodada 1

Data: 07/10/2026 · Revisor independente B · Pasta própria: `/home/claude/revB2/` · Capturas: `/home/claude/revB2/capturas/` (515 imagens; `novo_*` = v122b, `base_*` = v122 publicada)

---

## Resumo em 1 minuto

- **Quase tudo que o Pedro pediu foi feito e ficou bem melhor.** Com o teclado aberto, a caixa do código agora fica **no meio** entre o topo e o teclado (antes ficava grudada em cima). As **Configurações** deitado ocupam a tela quase toda (925 px em vez de 480 px), com as opções em 2 colunas, e a parte "☁️ Família e nuvem" ficou com **texto à esquerda e botões numa linha à direita**, sem nada empilhado. As telas "Quem vai estudar hoje?", "Famílias neste celular", perguntas e "Anote o código" ficaram com respiro.
- **Nada do funcionamento quebrou.** Todas as suítes passaram (detalhes abaixo). Os arquivos do pacote estão certos.
- **Mas encontrei 2 problemas novos que o Pedro vai ver no celular dele:**
  1. 🟠 **"🎉 ACHEI A SUA FAMÍLIA!" corta os nomes das crianças** no celular deitado: "MARIA EDUARDA" vira "MARIA …", "JOÃO PEDRO" vira "JOÃO P…". Com duas Marias ou dois Joãos, **fica impossível saber quem é quem** — exatamente a reclamação do Pedro ("se tiver três, quatro usuários não vai dar para entender nada"). Na v122 os nomes apareciam inteiros. Acontece mesmo com 1 criança só e o pop-up com muito espaço sobrando dos lados.
  2. 🟠 **No site de teste do Pedro aparece agora uma faixa roxa "🧪 SITE DE TESTE" por cima da barra de cima do app**, cobrindo metade dos botões 🏠 📅 🗺️ HINA ⚙️ ⛶ e **escondendo a bolinha da nuvem** em cima do ⚙️. Ela sempre existiu no código, mas antes o endereço do Pedro não era reconhecido; com a mudança 5 ela passa a aparecer. O Pedro pediu respiro e vai ver uma faixa nova por cima de tudo.
- O item 7 (aviso do Chrome "Para sair da tela cheia, arraste…") está certo **no código e no meu teste**, mas **só vale para o app aberto pelo ícone**. Só o celular de verdade confirma que o aviso sumiu.
- Os dois 🟠 são correções pequenas de desenho (CSS), sem risco para os dados.

---

## Tabela: pedido do Pedro → atendido? → prova

| Pedido do Pedro | Atendido? | Prova (o que rodei / qual captura) |
|---|---|---|
| Com o teclado aberto, a caixa "digitar/procurar família" deve ficar **no meio entre o teclado e o topo**, não encostada no topo | ✅ Sim | Rodei em 7 tamanhos, foco no campo e **depois** reduzi a janela (984x432→984x125 e 984x190), 3 voltas seguidas. Sobra em cima = sobra embaixo em todos (ex.: 30/30 px e 63/63 px), campo **continua com foco**, digitar e Enter funcionam. Na v122 era 4 px em cima e 26–91 px embaixo. Capturas: `novo_T2_teclado_984x125.png`, `novo_T2_teclado_984x190.png`, `novo_T3_teclado_*`, `novo_T5_teclado_*`; comparar com `base_T2_teclado_984x125.png` |
| Pop-up de **Configurações** deve aproveitar o espaço lateral | ✅ Sim | 984x432: 925 px de largura (v122: 480). 2 colunas a partir de 700 px. Sem rolagem para o lado. `novo_cfg_1fam_984x432_p0..p3.png` × `base_cfg_codigo_mostrado_fim_984x432.png` |
| "Família e nuvem": botões **muito apertados, um em cima do outro**, sem respiro | ✅ Sim | Cada linha com 72 px, texto à esquerda, botões à direita, todos com 48 px de altura e longe uns dos outros (984, 937, 740 e tablet). Em 640 e 568 px os botões descem para uma 2ª linha, mas organizados. Com 1 e 2 famílias, sem internet (texto amarelo longo) e com o código mostrado. `novo_cfg_1fam_984x432_p3.png`, `novo_semnet_cfg_740x360.png`, `novo_cfg_1fam_familia_568x320.png` |
| Botões do adulto (segurar 3 s) | ✅ Sim | "◯ 👨 ABRIR ▶" e "◯ 👨 👁 MOSTRAR" numa linha; toque rápido mostra "PEÇA PARA UM ADULTO SEGURAR O BOTÃO POR 3 SEGUNDOS" e **não** mostra o código; segurar 3 s mostra. Testado em todos os tamanhos. |
| Busca da família na nuvem: informações **apertadas**, pop-up pequeno, **com 3–4 crianças não dá para entender nada** | ⚠️ **Em parte** | O pop-up ficou largo (945 px), o campo e os botões de baixo somem, os 3 botões ficam embaixo e separados — **bom**. **Porém os nomes das crianças ficam cortados** em todos os tamanhos de celular deitado (984, 937, 740, 640, 568). Ver achado 🟠 1. `novo_achei_marias_984x432.png`, `novo_achei4_984x432.png`, `novo_achei6_984x432.png` × `base_achei4_984x432.png` |
| Aviso do Chrome "Para sair da tela cheia, arraste…" não aparecer | ✅ No código / ❓ no celular | Meu teste conta os pedidos de tela cheia: aberto pelo ícone (fullscreen) = **0 pedidos** ao abrir e ao tocar (só gira para deitado); no navegador continua pedindo como antes; no app instalado antigo ("standalone") continua pedindo. Só o celular confirma o aviso. Ver seção própria. |
| "No geral todas as telas com respiro, aproveitar a largura deitado" | ✅ Quase todas | T1, T3 "anote", T5, T6, T8, Cópias, perguntas: ok. **"Quem vai estudar hoje?"** ficou com os cartões no meio e o rodapé melhor, mas os cartões ficaram **mais estreitos** que na v122 em 568–740 px ("NOVA CRIA…", "MARIA EDUA…") — achado 🟡. |

---

## Achados

### 🟠 1. "Achei a sua família": nomes das crianças cortados com "…" no celular deitado (novo nesta versão)

- **O que acontece:** no celular deitado (altura até 440 px — todos os celulares do Pedro), cada criança vira um cartãozinho de 158 px com o bichinho à esquerda e o nome à direita numa linha só, cortado com "…". Sobra só ~82 px para o nome. "MARIA EDUARDA" → "MARIA …", "MARIA CLARA" → "MARIA …", "JOÃO PEDRO" → "JOÃO P…", "ANA CAROLINA" → "ANA C…", "PEDRO HENRIQUE" → "PEDRO…". Com nomes parecidos, **não dá para saber quem é quem** antes de tocar em ESCOLHER/TRAZER TODAS. Acontece até com **1 criança só** e o pop-up com 700 px sobrando.
- **Na v122** os nomes apareciam inteiros (`base_achei4_984x432.png`). No tablet 1280x800 da v122b também aparecem inteiros (lá não entra o modo compacto).
- **Onde no código:** `escola-familia.js`, CSS do "achei":
  - `.ef-achou .ef-mini .ef-nome{…overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`
  - `@media (max-height:440px){.ef-achou .ef-cartoes{grid-template-columns:repeat(auto-fit,158px)} …}`
- **Como reproduzir:** família com "MARIA EDUARDA", "MARIA CLARA", "JOÃO PEDRO", "JOÃO MIGUEL"; 984x432; T1 → JÁ TENHO CADASTRO → `pmrtestes` → PROCURAR. Script: `/home/claude/revB2/scripts/s7_marias.py` (mede `scrollWidth 145 > clientWidth 82`). Captura: `novo_achei_marias_984x432.png`.
- **Por que o teste do autor não pegou:** `teste_desenho.py` confere "nomes inteiros", mas usa só nomes curtos (Hina, Renata, Bia, Caio, Lu, Ana).
- **Sugestão:** deixar os cartões mais largos e o nome quebrar em 2 linhas, por exemplo no bloco `max-height:440px`: `.ef-achou .ef-cartoes{grid-template-columns:repeat(auto-fit,minmax(210px,250px))}` e `.ef-achou .ef-mini .ef-nome{white-space:normal;overflow-wrap:anywhere;line-height:1.15;text-overflow:clip}`. E acrescentar ao `teste_desenho.py` uma família com "MARIA EDUARDA" + "MARIA CLARA" + "PEDRO HENRIQUE".

### 🟠 2. Site de teste: faixa roxa nova por cima da barra de cima do app (aparece por causa da mudança 5)

- **O que acontece:** como agora qualquer endereço com "teste" é reconhecido, no `escolasaopedrotestes.netlify.app` aparece a faixa fixa "🧪 SITE DE TESTE — USE SÓ O CÓDIGO DE TESTE" (23 px, roxa, no topo, **em todas as telas**). Ela fica **por cima** da metade de cima dos botões 🏠 📅 🗺️, do chip "HINA", do ⚙️ e do ⛶, e **esconde a bolinha verde/amarela/vermelha da nuvem** que fica em cima do ⚙️. Também corta o topo do cabeçalho das Configurações. Os toques continuam funcionando (a faixa deixa o toque passar), mas visualmente é uma faixa nova por cima de tudo — o contrário do respiro pedido. Na v122 o Pedro **nunca** viu essa faixa (o endereço dele não era reconhecido).
- **Onde no código:** `escola-familia.js` linhas ~515–516 (`.ef-teste{position:fixed;left:0;right:0;top:0;…}`) e `iniciar()` (~linha 1730).
- **Como reproduzir:** `/home/claude/revB2/scripts/s5_host_fs.py` (abre o app "no endereço" `https://escolasaopedrotestes.netlify.app/`). Capturas: `novo_siteteste_app_984x432.png`, `novo_siteteste_T4_984x432.png`, `novo_siteteste_cfg_740x360.png`. O script lista o que fica embaixo da faixa: `btnHub, btnConq, btnLvl, ef-chip, btnCfg, fs`.
- **No site de verdade** (`escolasaopedroalfabetizacao`) a faixa **não** aparece — conferido.
- **Sugestão:** mostrar a faixa **só nas telas onde se digita o código** (T1, T2, T3), por exemplo `body:not(:has(#efRaiz .ef-t1,#efRaiz .ef-t2,#efRaiz .ef-t3)) .ef-teste{display:none}`; ou transformá-la numa etiqueta pequena num canto que não tenha botão.

### 🟡 3. "Quem vai estudar hoje?": cartões mais estreitos que na v122 (nomes cortados mais vezes)

- A grade passou a ter colunas de largura fixa `clamp(130px,17vw,230px)` centralizadas. Em 740, 640 e 568 px os cartões ficam com 130 px (na v122 esticavam e ocupavam a largura). Resultado: "MARIA EDUA…", "JOÃO PEDR…" e até **"NOVA CRIA…"** no cartão ➕ (`novo_T4_740x360.png`, `novo_semnet_T4_568x320.png` × `base_T4_740x360.png`, `base_semnet_T4_568x320.png`). No celular do Pedro (984/937) os cartões locais cabem, mas o cartão da nuvem "MARIA EDUARDA ☁️" fica cortado (na v122, a 984 px, aparecia inteiro).
- **Onde:** `escola-familia.js`, `.ef-grade{grid-template-columns:repeat(auto-fit,clamp(130px,17vw,230px))…}`.
- **Sugestão:** `repeat(auto-fit,minmax(160px,210px))` ou permitir o nome em 2 linhas.

### 🟡 4. "Achei a sua família" não tem mais "✕ CANCELAR"

- Na tela do "achei" só ficam [← OUTRO CÓDIGO] [ESCOLHER] [TRAZER TODAS]. Para desistir é preciso tocar "← OUTRO CÓDIGO" e depois "✕ CANCELAR", ou usar o voltar do Android (testado: fecha o pop-up e volta para a tela de boas-vindas, sem perder nada). Funciona, mas um adulto pode procurar o ✕. Sugestão: um "✕" pequeno no canto do cartão.

### 🟡 5. App instalado: o botão ⛶ ainda pede a tela cheia do navegador

- Aberto pelo ícone, o app não pede mais a tela cheia sozinho (certo). Mas se alguém tocar no **⛶** (barra de cima e "Quem vai estudar hoje?"), ele pede, e o aviso do Chrome aparece de novo. É um toque do próprio usuário, então é aceitável; sugestão: esconder o ⛶ quando `JA_TELA_CHEIA_DO_APP` for verdadeiro (lá ele não tem utilidade).

### 🟡 6. 568x320 (celular pequeno), "Quem vai estudar hoje?" sem internet

- Com o texto amarelo longo ("📴 SEM INTERNET: 1 CRIANÇA ESPERANDO. NÃO LIMPE OS DADOS DO NAVEGADOR."), o rodapé fica com 3 linhas e encosta/passa 3 px da borda de baixo (`novo_semnet_T4_568x320.png`). Na v122 era pior em outro ponto (o botão 🔑 FAMÍLIA saía da tela). Não acontece nos tamanhos do Pedro (984/937/740).

### 🟡 7. "Achei" com 6 crianças a 984 px fica 5 + 1

- Duas fileiras (cabe sem rolar), mas uma fileira de 5 e outra de 1 (`novo_achei6_984x432.png`). Com a sugestão do achado 1 fica 3 + 3 ou 4 + 2.

### Coisas antigas (já estavam na v122, NÃO foram criadas agora — só para registro)

- Depois de segurar "👁 MOSTRAR" nas Configurações, o código aparece mas o botão MOSTRAR continua lá até a tela se redesenhar (`novo_cfg_codigo_mostrado_fim_984x432.png`, igual em `base_…`).
- Com o teclado aberto, os bichinhos da T5 ficam com 30 px (125 px de tela) e 42 px (190 px) — menos que 48 px; igual na v122.
- T2 sem teclado: um espaço vazio entre o campo e os botões (igual na v122).
- Nas Configurações, as letras das opções do próprio app (ex.: "Pastel", "20", títulos "📺 TELA", "💾 BACKUP") têm 11–13 px; igual na v122. As telas da família têm sempre 14 px ou mais (conferido).
- "Quem vai estudar hoje?" com muitas crianças: a 2ª fileira (e o ➕) fica escondida dentro da rolagem, só aparece a pontinha do cartão.

---

## Conferências de arquivos (item 4 da missão)

| Conferência | Resultado |
|---|---|
| `nuvem-config.js` do pacote (md5) | ✅ `1d5f060a5ae8339921d3d58498807971` (pacote-netlify e zip do Netlify). O de `testes/` é o falso, de propósito. |
| `escola-pwa.js` igual ao da v122 | ✅ md5 `ec31bf4a…` nos dois |
| `nuvem-sync.js` igual ao da v122 | ✅ md5 `c953cfd3…` nos dois (e em `compartilhados/`) |
| Zip do Netlify | ✅ 9 arquivos, todos na raiz (index.html, sw.js, manifest.webmanifest, icon-192.png, icon-512.png, nuvem-config.js, nuvem-sync.js, escola-pwa.js, escola-familia.js) |
| `compartilhados/` = `pacote-netlify/` = `testes/` = zip do Netlify | ✅ md5 iguais para index.html, sw.js, escola-familia.js, escola-pwa.js, nuvem-sync.js, manifest e ícones |
| `sw.js` com cache novo | ✅ `const C='esforco-vence-v122b';` e lista de arquivos inclui `escola-familia.js` |
| O que mudou no `index.html` | Só 3 coisas: CSS das Configurações deitado, a condição `JA_TELA_CHEIA_DO_APP` antes de `tentarTelaCheia()` e `telaCheia: !JA_TELA_CHEIA_DO_APP` no `EscolaPWA.iniciar`. Conferido com `diff`. |

---

## Item 7 (tela cheia) — o que li, o que testei, o que só o celular confirma

- **Li no código:** `index.html` calcula uma vez, ao abrir, `JA_TELA_CHEIA_DO_APP = matchMedia('(display-mode: fullscreen)').matches`. Se verdadeiro: não chama `tentarTelaCheia()` ao abrir e passa `telaCheia:false` ao `escola-pwa.js`, que então não pede a tela cheia a cada toque (`pedirTelaCheia` sai na hora). A orientação deitada continua travada por `if(isStandalone()) setTimeout(lockLandscape,150)`. O `escola-pwa.js` não foi alterado.
- **Testei (s5_host_fs.py):** troquei `requestFullscreen` e `screen.orientation.lock` por contadores e simulei o modo de exibição:
  - navegador: 1 pedido ao abrir e 1 a cada toque (igual à v122);
  - **instalado em tela cheia: 0 pedidos ao abrir e 0 depois de 4 toques**; 1 trava de "deitado"; tocar no ⛶ faz 1 pedido (achado 🟡 5);
  - instalado antigo em "standalone": continua pedindo (de propósito, para ter tela cheia).
- **Só o celular de verdade confirma:**
  1. Se o Chrome do Motorola de fato informa `display-mode: fullscreen` no app aberto pelo ícone (se o app foi instalado quando o manifest ainda era "standalone", pode ser preciso **desinstalar e instalar de novo**).
  2. Se o aviso "Para sair da tela cheia, arraste…" some de verdade nesse caso.
  3. **Se o Pedro abrir pelo Chrome (aba do navegador), o aviso vai continuar aparecendo** — isso é regra de segurança do Chrome e nenhum site consegue esconder. A captura do Pedro não deixa claro se era o app instalado ou a aba do navegador.
  4. Se a tela fica deitada travada no app instalado sem a tela cheia do navegador.

---

## O que eu RODEI de verdade

Tudo com Chromium + Firebase de mentira, na minha pasta `/home/claude/revB2/novo/testes` (e a v122 em `/home/claude/base122/testes`, só lendo, sem gravar nada lá).

| Suíte | Resultado |
|---|---|
| Testes Node (`node testes/rodar_testes.js`) | ✅ Tudo passou (12 arquivos) |
| `teste_familia.py` | ✅ 130/130 rodando sozinha. Na 1ª rodada, com 5 suítes ao mesmo tempo, deu 129/130 (o item "tirar criança: as chaves somem" é de tempo: espera 3,5 s); rodando sozinha passou. Fica o aviso de que esse item é sensível a máquina lenta. |
| `teste_revisao.py` | ✅ 59/59 |
| `teste_desenho.py` (novo do autor) | ✅ 108/108 |
| `teste_cadastro.py` | ✅ 72/72 |
| `teste_fonte.py` | 57/58 — a falha antiga desta máquina ("Ler 412x915 em pé tamanho 24"), a mesma da v122 |
| `teste_pwa.py` | ✅ 34/34 |
| `teste_nuvem.py` | ✅ 81/81 |

Meus scripts (em `/home/claude/revB2/scripts/`), rodados na v122b e, para comparar, na v122:

- `s1_teclado.py` — teclado abrindo depois do toque (T2, T3, T5), 7 tamanhos, 2 alturas de teclado, 3 voltas; digitar e Enter com teclado aberto.
- `s2_achei.py` — "Achei" com 1, 2, 3, 4 e 6 crianças, nomes longos, crianças em 1 a 7 apps, 7 tamanhos; "← OUTRO CÓDIGO" (volta o campo com foco, e com teclado fica no meio: 30/30 px); voltar do Android; ESCOLHER.
- `s3_config.py` — Configurações inteiras roladas até o fim, 1 e 2 famílias, sem internet, toque rápido e segurar 3 s, 7 tamanhos.
- `s4_telas.py` — T1, T3 "anote", T4, T7 arrumar, pergunta "tirar", T6, T8 (1 e 2 famílias, código mostrado em CAIXA ALTA: "PMRTESTES"), Cópias, T5 depois do "anote".
- `s5_host_fs.py` — endereço do site de teste e do site real; código sem "teste" recusado no site de teste ("…QUE TENHA A PALAVRA TESTE…") e aceito no real; contagem de pedidos de tela cheia.
- `s6_semnet.py` — sem internet com 1 criança esperando (texto amarelo longo) na T4 e nas Configurações.
- `s7_marias.py` — o caso das duas Marias e dois Joãos.
- Em todas as telas medi: letra menor que 14 px, botão menor que 48 px, botão fora da tela, botões encostados, texto cortado, rolagem para o lado. Nas telas da família: **nenhuma letra abaixo de 14 px, nenhum botão abaixo de 48 px (fora os bichinhos com teclado, que já eram assim), nada saindo pelo lado**.

## O que eu só LI (não rodei)

- O caminho do teclado do Chrome no modo "resizes-visual" (quando só a parte visível encolhe e a página não): o código trata isso por `visualViewport`, mas no Chromium de teste só consegui simular a página inteira encolhendo. Como na v122 o cartão já acompanhava a área visível no Motorola (capturas do Pedro), a mudança é só centralizar dentro dessa mesma área.
- Que nenhum endereço de produção contém "teste" (conferi a lista dos 7 sites: nenhum tem).

## O que só o celular de verdade confirma

1. O cartão do código no meio da área acima do teclado (com a barra de senhas/cartões do Chrome que aparece em cima do teclado na captura do Pedro, a área livre real fica perto de 120 px).
2. O aviso do Chrome da tela cheia (ver seção do item 7).
3. Como a faixa roxa do site de teste fica sobre a barra de cima no Motorola (achado 🟠 2).
4. Legibilidade na TV a 3 m (os textos das telas da família têm 14–17 px; os títulos maiores).

---

## Pastas e arquivos

- Relatório: `/home/claude/revisao/RELATORIO_B_v122b_rodada1.md`
- Capturas: `/home/claude/revB2/capturas/` (destaques: `novo_achei_marias_984x432.png`, `novo_siteteste_app_984x432.png`, `novo_T2_teclado_984x125.png`, `novo_cfg_1fam_984x432_p3.png`, `base_achei4_984x432.png`, `base_T2_teclado_984x125.png`)
- Scripts: `/home/claude/revB2/scripts/`
- Logs: `/home/claude/revB2/log_*.txt`, `/home/claude/revB2/s*_novo.txt`, `/home/claude/revB2/s*_base.txt`

❌ Não pode publicar: no "Achei a sua família" os nomes das crianças ficam cortados ("MARIA …", "JOÃO P…") no celular deitado — o próprio problema que o Pedro pediu para resolver — e no site de teste aparece uma faixa roxa nova por cima da barra de cima, escondendo a bolinha da nuvem; ambos são correções pequenas de CSS.
