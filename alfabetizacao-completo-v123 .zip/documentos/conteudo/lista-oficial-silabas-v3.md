# Lista oficial de palavras — app Sílabas  ·  v3.0

Duas listas independentes, como você pediu:

| | Conteúdo | Palavras |
|---|---|---:|
| **Parte I** | Sílabas simples (CV), organizadas por **bloco de som** | 341 |
| **Parte I-B** | Exceções que você aprovou (vogal isolada, ditongo, nasal, Ç, X, 4 sílabas) | 63 |
| **Parte II** | Sílabas complexas: R, L, dígrafos, travadas e nasais | 304 |

Inclui as 13 palavras aprovadas do banco v2.1.0 e as 14 que você sugeriu.

---

## Como as partes se encaixam

A Parte I é a base: a criança só encontra sílabas CV, então qualquer palavra que ela
veja pode ser decomposta inteira. A Parte I-B são palavras que valem o custo de uma
exceção porque são frequentes demais (LUA, PÃO, LEITE, MAMÃE). A Parte II é a etapa
seguinte, e só deve aparecer depois que a Parte I estiver consolidada.

---

# PARTE I — Sílabas simples

Legenda: `V` sílaba só de vogal · `ação` verbo · `s=z` o S soa /z/ ·
`r brando` R entre vogais · `no meio` a sílaba-alvo não está no início · `novo · v3` entrou nesta versão.

## Bloco 1 — consoantes de som estável

> Um som, uma letra. É por aqui que se começa.

### Família do B

**BA** — 9 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🤤 | **BABA** | BA·BA | 2 | — |
| 👩‍🍼 | **BABÁ** | BA·BÁ | 2 | — |
| 😮‍💨 | **BAFO** | BA·FO | 2 | novo · v3 |
| 🍬 | **BALA** | BA·LA | 2 | — |
| 👊 | **BATE** | BA·TE | 2 | ação |
| 🍌 | **BANANA** | BA·NA·NA | 3 | — |
| 🪳 | **BARATA** | BA·RA·TA | 3 | r brando |
| 🥔 | **BATATA** | BA·TA·TA | 3 | — |
| 🥤 | **BATIDA** | BA·TI·DA | 3 | — |

**BE** — 7 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🥤 | **BEBE** | BE·BE | 2 | ação |
| 🥛 | **BEBO** | BE·BO | 2 | ação · seu |
| 👶 | **BEBÊ** | BE·BÊ | 2 | — |
| 🏚️ | **BECO** | BE·CO | 2 | — |
| 👸 | **BELA** | BE·LA | 2 | seu |
| 👦 | **BETO** | BE·TO | 2 | nome · seu |
| 💅 | **BELEZA** | BE·LE·ZA | 3 | — |

**BI** — 8 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🚗 | **BIBI** | BI·BI | 2 | seu |
| 🚰 | **BICA** | BI·CA | 2 | seu |
| 🐦 | **BICO** | BI·CO | 2 | — |
| 🥩 | **BIFE** | BI·FE | 2 | — |
| 👧 | **BINA** | BI·NA | 2 | nome · seu |
| 🐔 | **BICADA** | BI·CA·DA | 3 | — |
| 🥸 | **BIGODE** | BI·GO·DE | 3 | — |
| 🌬️ | **BIRUTA** | BI·RU·TA | 3 | r brando |

**BO** — 10 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🤪 | **BOBO** | BO·BO | 2 | — |
| 👄 | **BOCA** | BO·CA | 2 | — |
| 🐐 | **BODE** | BO·DE | 2 | — |
| ⚽ | **BOLA** | BO·LA | 2 | — |
| 🎂 | **BOLO** | BO·LO | 2 | — |
| 🧢 | **BONÉ** | BO·NÉ | 2 | — |
| 👢 | **BOTA** | BO·TA | 2 | — |
| 🪆 | **BONECA** | BO·NE·CA | 3 | — |
| 🌸 | **BONITA** | BO·NI·TA | 3 | — |
| 🌻 | **BONITO** | BO·NI·TO | 3 | — |

**BU** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧘 | **BUDA** | BU·DA | 2 | seu |
| 💊 | **BULA** | BU·LA | 2 | seu |
| 🫖 | **BULE** | BU·LE | 2 | — |
| 🕳️ | **BURACO** | BU·RA·CO | 3 | r brando |
| 📢 | **BUZINA** | BU·ZI·NA | 3 | — |
| 🐃 | **BÚFALO** | BÚ·FA·LO | 3 | acento na 1ª |

### Família do D

**DA** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🎲 | **DADO** | DA·DO | 2 | — |
| ♟️ | **DAMA** | DA·MA | 2 | — |
| 📅 | **DATA** | DA·TA | 2 | abstrato |

**DE** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👆 | **DEDO** | DE·DO | 2 | — |
| 🔟 | **DEZENA** | DE·ZE·NA | 3 | abstrato |

**DI** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ☀️ | **DIA** | DI·A | 2 | V |
| 🦕 | **DINO** | DI·NO | 2 | novo · v3 |
| 📏 | **MEDIDA** | ME·DI·DA | 3 | no meio |
| 🙏 | **PEDIDO** | PE·DI·DO | 3 | no meio |

**DO** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🍬 | **DOCE** | DO·CE | 2 | — |
| 👩 | **DONA** | DO·NA | 2 | — |
| 1️⃣2️⃣ | **DOZE** | DO·ZE | 2 | — |
| 🁢 | **DOMINÓ** | DO·MI·NÓ | 3 | — |

**DU** — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👧 | **DUDA** | DU·DA | 2 | nome · seu |
| 👦 | **DUDU** | DU·DU | 2 | nome · seu |
| 🏜️ | **DUNA** | DU·NA | 2 | seu |
| ⚔️ | **DUELO** | DU·E·LO | 3 | V |
| 🍌 | **MADURO** | MA·DU·RO | 3 | no meio · r brando |

### Família do F

**FA** — 7 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🔪 | **FACA** | FA·CA | 2 | — |
| 🧚 | **FADA** | FA·DA | 2 | — |
| 🗣️ | **FALA** | FA·LA | 2 | ação |
| 🫘 | **FAVA** | FA·VA | 2 | — |
| 🍚 | **FAROFA** | FA·RO·FA | 3 | r brando |
| 🍕 | **FATIA** | FA·TI·A | 3 | V |
| 🏘️ | **FAVELA** | FA·VE·LA | 3 | — |

**FE** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 💩 | **FEDE** | FE·DE | 2 | ação |
| 🦁 | **FERA** | FE·RA | 2 | seu · r brando |
| 🩹 | **FERIDA** | FE·RI·DA | 3 | r brando |

**FI** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🍇 | **FIGO** | FI·GO | 2 | — |
| 🚶 | **FILA** | FI·LA | 2 | — |
| 🧵 | **FIO** | FI·O | 2 | V |
| 🎀 | **FITA** | FI·TA | 2 | — |
| 🖼️ | **FIGURA** | FI·GU·RA | 3 | r brando |
| 🪢 | **FIVELA** | FI·VE·LA | 3 | — |

**FO** — 7 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🦭 | **FOCA** | FO·CA | 2 | — |
| 🧸 | **FOFO** | FO·FO | 2 | — |
| 🔥 | **FOGO** | FO·GO | 2 | — |
| 🍽️ | **FOME** | FO·ME | 2 | — |
| 🎧 | **FONE** | FO·NE | 2 | — |
| 📷 | **FOTO** | FO·TO | 2 | — |
| 🗣️ | **FOFOCA** | FO·FO·CA | 3 | — |

**FU** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🌽 | **FUBÁ** | FU·BÁ | 2 | — |
| 🕳️ | **FURA** | FU·RA | 2 | ação · r brando |

### Família do J

**JA** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🥭 | **JACA** | JA·CA | 2 | novo · v3 |
| ✈️ | **JATO** | JA·TO | 2 | — |
| 🐢 | **JABUTI** | JA·BU·TI | 3 | — |
| 🐊 | **JACARÉ** | JA·CA·RÉ | 3 | — |
| 🪟 | **JANELA** | JA·NE·LA | 3 | — |
| 🐗 | **JAVALI** | JA·VA·LI | 3 | — |

**JE** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧱 | **LAJE** | LA·JE | 2 | no meio |
| ✈️ | **VIAJE** | VI·A·JE | 3 | no meio · V |

**JI** — 1 palavra

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🫑 | **JILÓ** | JI·LÓ | 2 | — |

**JO** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ⚽ | **JOGA** | JO·GA | 2 | ação |
| 🎮 | **JOGO** | JO·GO | 2 | — |

**JU** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🦁 | **JUBA** | JU·BA | 2 | — |
| 👦 | **JUCA** | JU·CA | 2 | nome |
| 🥋 | **JUDÔ** | JU·DÔ | 2 | — |
| 🍬 | **JUJUBA** | JU·JU·BA | 3 | — |

### Família do L

**LA** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ↔️ | **LADO** | LA·DO | 2 | abstrato |
| 🏞️ | **LAGO** | LA·GO | 2 | — |
| 🧱 | **LAJE** | LA·JE | 2 | — |
| 🟤 | **LAMA** | LA·MA | 2 | — |
| 🥫 | **LATA** | LA·TA | 2 | — |
| 🧼 | **LAVA** | LA·VA | 2 | ação |

**LE** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🚢 | **LEME** | LE·ME | 2 | seu |
| 📦 | **LEVA** | LE·VA | 2 | ação · seu |
| 🪶 | **LEVE** | LE·VE | 2 | — |
| 🥕 | **LEGUME** | LE·GU·ME | 3 | — |

**LI** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 💪 | **LIDA** | LI·DA | 2 | — |
| 🔛 | **LIGA** | LI·GA | 2 | ação |
| 🍋 | **LIMA** | LI·MA | 2 | — |

**LO** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐺 | **LOBO** | LO·BO | 2 | — |
| 🟩 | **LODO** | LO·DO | 2 | — |
| 🏪 | **LOJA** | LO·JA | 2 | — |

**LU** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🌙 | **LUA** | LU·A | 2 | V |
| 🦑 | **LULA** | LU·LA | 2 | — |
| 🔍 | **LUPA** | LU·PA | 2 | — |
| 🧤 | **LUVA** | LU·VA | 2 | — |

### Família do M

**MA** — 9 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧳 | **MALA** | MA·LA | 2 | — |
| 🗺️ | **MAPA** | MA·PA | 2 | — |
| 🌊 | **MARÉ** | MA·RÉ | 2 | r brando |
| 🌿 | **MATO** | MA·TO | 2 | — |
| 🐒 | **MACACO** | MA·CA·CO | 3 | — |
| 🧸 | **MACIO** | MA·CI·O | 3 | V |
| 🍌 | **MADURO** | MA·DU·RO | 3 | r brando |
| 🤪 | **MALUCO** | MA·LU·CO | 3 | — |
| 😏 | **MAROTO** | MA·RO·TO | 3 | r brando |

**ME** — 7 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 😨 | **MEDO** | ME·DO | 2 | — |
| 🪑 | **MESA** | ME·SA | 2 | s=z |
| 📏 | **MEDIDA** | ME·DI·DA | 3 | abstrato |
| 🍯 | **MELADO** | ME·LA·DO | 3 | — |
| 👧 | **MENINA** | ME·NI·NA | 3 | — |
| 👦 | **MENINO** | ME·NI·NO | 3 | — |
| ➗ | **METADE** | ME·TA·DE | 3 | abstrato |

**MI** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐒 | **MICO** | MI·CO | 2 | — |
| ⏱️ | **MINUTO** | MI·NU·TO | 3 | abstrato |
| 🍞 | **MIOLO** | MI·O·LO | 3 | V |

**MO** — 7 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👗 | **MODA** | MO·DA | 2 | — |
| 🌀 | **MOLA** | MO·LA | 2 | — |
| 🍮 | **MOLE** | MO·LE | 2 | — |
| 🏍️ | **MOTO** | MO·TO | 2 | — |
| 👗 | **MODELO** | MO·DE·LO | 3 | — |
| 🪙 | **MOEDA** | MO·E·DA | 3 | V |
| 🐰 | **MÔNICA** | MÔ·NI·CA | 3 | nome · acento na 1ª |

**MU** — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🌱 | **MUDA** | MU·DA | 2 | — |
| 🤐 | **MUDO** | MU·DO | 2 | — |
| 🫏 | **MULA** | MU·LA | 2 | — |
| 🧱 | **MURO** | MU·RO | 2 | r brando |
| 🎵 | **MÚSICA** | MÚ·SI·CA | 3 | s=z · acento na 1ª |

### Família do N

**NA** — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🥬 | **NABO** | NA·BO | 2 | — |
| 🏊 | **NADA** | NA·DA | 2 | ação |
| 🥛 | **NATA** | NA·TA | 2 | — |
| 🚀 | **NAVE** | NA·VE | 2 | — |
| 🚢 | **NAVIO** | NA·VI·O | 3 | V |

**NE** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👶 | **NENÊ** | NE·NÊ | 2 | — |
| 👧 | **NETA** | NE·TA | 2 | — |
| 👦 | **NETO** | NE·TO | 2 | — |
| ❄️ | **NEVE** | NE·VE | 2 | — |

**NI** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👶 | **NINA** | NI·NA | 2 | nome / ação |
| 🌻 | **BONITO** | BO·NI·TO | 3 | no meio |
| 👧 | **MENINA** | ME·NI·NA | 3 | no meio |
| 👦 | **MENINO** | ME·NI·NO | 3 | no meio |
| 🐰 | **MÔNICA** | MÔ·NI·CA | 3 | no meio |
| 🚽 | **PENICO** | PE·NI·CO | 3 | no meio |

**NO** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🏷️ | **NOME** | NO·ME | 2 | abstrato |
| ✨ | **NOVA** | NO·VA | 2 | — |
| 9️⃣ | **NOVE** | NO·VE | 2 | — |
| 🧶 | **NOVELO** | NO·VE·LO | 3 | — |

**NU** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 💆 | **NUCA** | NU·CA | 2 | — |
| 🔢 | **NÚMERO** | NÚ·ME·RO | 3 | r brando · acento na 1ª |

### Família do P

**PA** — 8 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧻 | **PANO** | PA·NO | 2 | — |
| 🐾 | **PATA** | PA·TA | 2 | — |
| 🦆 | **PATO** | PA·TO | 2 | — |
| ✋ | **TAPA** | TA·PA | 2 | ação |
| 📦 | **PACOTE** | PA·CO·TE | 3 | — |
| 🪵 | **PALITO** | PA·LI·TO | 3 | — |
| 🍳 | **PANELA** | PA·NE·LA | 3 | — |
| 🧱 | **PAREDE** | PA·RE·DE | 3 | r brando |

**PE** — 8 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🖐️ | **PELE** | PE·LE | 2 | — |
| 🪶 | **PENA** | PE·NA | 2 | — |
| 🍐 | **PERA** | PE·RA | 2 | r brando |
| 🦃 | **PERU** | PE·RU | 2 | r brando |
| 🙏 | **PEDIDO** | PE·DI·DO | 3 | — |
| 🚽 | **PENICO** | PE·NI·CO | 3 | — |
| 🥒 | **PEPINO** | PE·PI·NO | 3 | — |
| 💇 | **PERUCA** | PE·RU·CA | 3 | r brando |

**PI** — 6 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🪁 | **PIPA** | PI·PA | 2 | — |
| 🟫 | **PISO** | PI·SO | 2 | novo · v3 |
| 🍦 | **PICOLÉ** | PI·CO·LÉ | 3 | — |
| 🩱 | **PIJAMA** | PI·JA·MA | 3 | — |
| 🍿 | **PIPOCA** | PI·PO·CA | 3 | — |
| 🏴‍☠️ | **PIRATA** | PI·RA·TA | 3 | r brando |

**PO** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🫙 | **POTE** | PO·TE | 2 | — |
| 👨‍👩‍👧‍👦 | **POVO** | PO·VO | 2 | abstrato |
| 🧴 | **POMADA** | PO·MA·DA | 3 | — |

**PU** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🤸 | **PULA** | PU·LA | 2 | ação |
| 🦘 | **PULO** | PU·LO | 2 | — |
| 🐆 | **PUMA** | PU·MA | 2 | novo · v3 |
| 🥔 | **PURÊ** | PU·RÊ | 2 | r brando |

### Família do T

**TA** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ✋ | **TAPA** | TA·PA | 2 | — |
| 🦔 | **TATU** | TA·TU | 2 | — |
| 🧶 | **TAPETE** | TA·PE·TE | 3 | — |
| 📝 | **TAREFA** | TA·RE·FA | 3 | r brando |

**TE** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 📺 | **TELA** | TE·LA | 2 | — |
| 🏠 | **TETO** | TE·TO | 2 | — |
| 🧵 | **TECIDO** | TE·CI·DO | 3 | — |

**TI** — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👩 | **TIA** | TI·A | 2 | V |
| ⚽ | **TIME** | TI·ME | 2 | — |
| 👨 | **TIO** | TI·O | 2 | V |
| 🥣 | **TIGELA** | TI·GE·LA | 3 | — |
| 🧱 | **TIJOLO** | TI·JO·LO | 3 | — |

**TO** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🕳️ | **TOCA** | TO·CA | 2 | — |
| 🔌 | **TOMADA** | TO·MA·DA | 3 | — |
| 🍅 | **TOMATE** | TO·MA·TE | 3 | — |
| 💇 | **TOPETE** | TO·PE·TE | 3 | — |

**TU** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧪 | **TUBO** | TU·BO | 2 | — |
| 🦜 | **TUCANO** | TU·CA·NO | 3 | — |
| 🌷 | **TULIPA** | TU·LI·PA | 3 | — |

### Família do V

**VA** — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐄 | **VACA** | VA·CA | 2 | — |
| 🎣 | **VARA** | VA·RA | 2 | novo · v3 |
| 🏺 | **VASO** | VA·SO | 2 | s=z |
| 🪄 | **VARETA** | VA·RE·TA | 3 | r brando |

**VE** — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🕯️ | **VELA** | VE·LA | 2 | — |
| 🧸 | **VELUDO** | VE·LU·DO | 3 | — |

**VI** — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🌱 | **VIDA** | VI·DA | 2 | abstrato |
| 🏘️ | **VILA** | VI·LA | 2 | — |
| 🔃 | **VIRA** | VI·RA | 2 | ação · r brando |
| ✈️ | **VIAJE** | VI·A·JE | 3 | V |
| 🎻 | **VIOLA** | VI·O·LA | 3 | V |

**VO** — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🕊️ | **VOA** | VO·A | 2 | V · ação |
| 👵 | **VOVÓ** | VO·VÓ | 2 | — |
| 👴 | **VOVÔ** | VO·VÔ | 2 | — |

**VU** — 0 palavras

> ⚠️ Sem palavra que atenda ao critério.

---

## Bloco 2 — C e G com som DURO

> CA CO CU soam /k/ · GA GO GU soam /g/. Ensinar juntos, longe do Bloco 3.

### CA — 17 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧩 | **CACO** | CA·CO | 2 | — |
| ☕ | **CAFÉ** | CA·FÉ | 2 | — |
| 🥭 | **CAJU** | CA·JU | 2 | — |
| 🛏️ | **CAMA** | CA·MA | 2 | — |
| 🦸 | **CAPA** | CA·PA | 2 | — |
| 🙂 | **CARA** | CA·RA | 2 | r brando |
| 🏠 | **CASA** | CA·SA | 2 | s=z |
| 🛖 | **CABANA** | CA·BA·NA | 3 | — |
| 🧷 | **CABIDE** | CA·BI·DE | 3 | — |
| 🐕 | **CADELA** | CA·DE·LA | 3 | — |
| 🐫 | **CAMELO** | CA·ME·LO | 3 | — |
| 👕 | **CAMISA** | CA·MI·SA | 3 | s=z |
| 🥛 | **CANECA** | CA·NE·CA | 3 | — |
| 🖊️ | **CANETA** | CA·NE·TA | 3 | — |
| 🥤 | **CANUDO** | CA·NU·DO | 3 | — |
| 😝 | **CARETA** | CA·RE·TA | 3 | r brando |
| 🐴 | **CAVALO** | CA·VA·LO | 3 | — |

### CO — 11 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🥥 | **COCO** | CO·CO | 2 | — |
| 🧴 | **COLA** | CO·LA | 2 | — |
| 🚧 | **CONE** | CO·NE | 2 | novo · v3 |
| 🥤 | **COPO** | CO·PO | 2 | — |
| 🕳️ | **COVA** | CO·VA | 2 | — |
| 🧑‍🤝‍🧑 | **COLEGA** | CO·LE·GA | 3 | — |
| ☄️ | **COMETA** | CO·ME·TA | 3 | — |
| 🍽️ | **COMIDA** | CO·MI·DA | 3 | — |
| 👑 | **COROA** | CO·RO·A | 3 | V · r brando |
| 🦉 | **CORUJA** | CO·RU·JA | 3 | r brando |
| 🍲 | **COZIDO** | CO·ZI·DO | 3 | — |

### CU — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧊 | **CUBO** | CU·BO | 2 | — |
| 🍰 | **CUCA** | CU·CA | 2 | — |
| 🩲 | **CUECA** | CU·E·CA | 3 | V |
| 👉 | **CUTUCA** | CU·TU·CA | 3 | ação |

### GA — 9 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐄 | **GADO** | GA·DO | 2 | — |
| 🐓 | **GALO** | GA·LO | 2 | — |
| 🧹 | **GARI** | GA·RI | 2 | novo · v3 |
| 🐈 | **GATA** | GA·TA | 2 | novo · v3 |
| 🐱 | **GATO** | GA·TO | 2 | — |
| 🐎 | **GALOPE** | GA·LO·PE | 3 | — |
| 👧 | **GAROTA** | GA·RO·TA | 3 | r brando |
| 👦 | **GAROTO** | GA·RO·TO | 3 | r brando |
| 🗄️ | **GAVETA** | GA·VE·TA | 3 | — |

### GO — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👔 | **GOLA** | GO·LA | 2 | — |
| 🍬 | **GOMA** | GO·MA | 2 | — |
| 💧 | **GOTA** | GO·TA | 2 | — |

### GU — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🔮 | **GUDE** | GU·DE | 2 | — |
| 😋 | **GULOSO** | GU·LO·SO | 3 | s=z |

---

## Bloco 3 — C e G com som BRANDO

> CE CI soam /s/ · GE GI soam /j/. Mesma letra, outro som — outro momento.

### CE — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ⏰ | **CEDO** | CE·DO | 2 | abstrato |
| 🦯 | **CEGO** | CE·GO | 2 | — |
| 🕯️ | **CERA** | CE·RA | 2 | r brando |
| 🧅 | **CEBOLA** | CE·BO·LA | 3 | — |

### CI — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| ⬆️ | **CIMA** | CI·MA | 2 | abstrato |
| 🌿 | **CIPÓ** | CI·PÓ | 2 | — |
| 🏙️ | **CIDADE** | CI·DA·DE | 3 | — |
| 🎬 | **CINEMA** | CI·NE·MA | 3 | — |

### GE — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧊 | **GELO** | GE·LO | 2 | — |
| 🥚 | **GEMA** | GE·MA | 2 | — |
| 🍦 | **GELADO** | GE·LA·DO | 3 | — |

### GI — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 📖 | **GIBI** | GI·BI | 2 | — |
| 🔄 | **GIRA** | GI·RA | 2 | ação · r forte |
| 🦒 | **GIRAFA** | GI·RA·FA | 3 | r forte |

---

## Bloco 4 — R com dois sons

> R no início da palavra = som forte (de CARRO). R entre vogais = som brando (de CARA).

### RA — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐕 | **RABO** | RA·BO | 2 | R forte |
| 🕳️ | **RALO** | RA·LO | 2 | novo · v3 |
| 🌿 | **RAMO** | RA·MO | 2 | R forte |
| 🐭 | **RATO** | RA·TO | 2 | R forte |
| 🦊 | **RAPOSA** | RA·PO·SA | 3 | R forte · s=z |

### RE — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🕸️ | **REDE** | RE·DE | 2 | R forte |
| 🚿 | **REGA** | RE·GA | 2 | R forte · ação |
| 🚣 | **REMO** | RE·MO | 2 | R forte |
| 💬 | **RECADO** | RE·CA·DO | 3 | R forte |

### RI — 4 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 💰 | **RICO** | RI·CO | 2 | R forte |
| 🎵 | **RIMA** | RI·MA | 2 | R forte |
| 🏞️ | **RIO** | RI·O | 2 | R forte · V |
| 😄 | **RISADA** | RI·SA·DA | 3 | R forte · s=z |

### RO — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🤖 | **ROBÔ** | RO·BÔ | 2 | R forte |
| 🛞 | **RODA** | RO·DA | 2 | R forte |
| 🧻 | **ROLO** | RO·LO | 2 | R forte |
| 🌹 | **ROSA** | RO·SA | 2 | R forte · s=z |
| 🍅 | **RODELA** | RO·DE·LA | 3 | R forte |

### RU — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🦃 | **PERU** | PE·RU | 2 | no meio · r brando |
| 🛣️ | **RUA** | RU·A | 2 | R forte · V |
| 🦉 | **CORUJA** | CO·RU·JA | 3 | no meio · r brando |
| ⚓ | **MARUJO** | MA·RU·JO | 3 | no meio · r brando |
| 💇 | **PERUCA** | PE·RU·CA | 3 | no meio · r brando |

---

## Bloco 5 — Z e o S que soa /z/

> Z sempre soa /z/. O S entre vogais também — cuidado ao misturar.

### ZA — 1 palavra

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 💅 | **BELEZA** | BE·LE·ZA | 3 | no meio |

### ZE — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🐂 | **ZEBU** | ZE·BU | 2 | novo · v3 |
| 0️⃣ | **ZERO** | ZE·RO | 2 | r brando |
| 🔟 | **DEZENA** | DE·ZE·NA | 3 | no meio |

### ZI — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 📢 | **BUZINA** | BU·ZI·NA | 3 | no meio |
| 🍲 | **COZIDO** | CO·ZI·DO | 3 | no meio |

### ZO — 0 palavras

> ⚠️ Sem palavra que atenda ao critério. Confirmado por dois bancos independentes.

### ZU — 0 palavras

> ⚠️ Sem palavra que atenda ao critério. Confirmado por dois bancos independentes.

### SA — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🛍️ | **SACO** | SA·CO | 2 | — |
| 🛋️ | **SALA** | SA·LA | 2 | — |
| 🐸 | **SAPO** | SA·PO | 2 | — |
| 🥗 | **SALADA** | SA·LA·DA | 3 | — |
| 👞 | **SAPATO** | SA·PA·TO | 3 | — |

### SE — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧣 | **SEDA** | SE·DA | 2 | — |
| 🥵 | **SEDE** | SE·DE | 2 | — |
| 📮 | **SELO** | SE·LO | 2 | — |
| 7️⃣ | **SETE** | SE·TE | 2 | — |
| 📆 | **SEMANA** | SE·MA·NA | 3 | abstrato |

### SI — 3 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🔔 | **SINO** | SI·NO | 2 | — |
| 🦀 | **SIRI** | SI·RI | 2 | novo · v3 |
| 🚨 | **SIRENE** | SI·RE·NE | 3 | r brando |

### SO — 5 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 👊 | **SOCO** | SO·CO | 2 | — |
| 🛋️ | **SOFÁ** | SO·FÁ | 2 | — |
| ➕ | **SOMA** | SO·MA | 2 | abstrato |
| 😴 | **SONO** | SO·NO | 2 | novo · v3 |
| 🍲 | **SOPA** | SO·PA | 2 | — |

### SU — 2 palavras

| Emoji | Palavra | Divisão | Síl. | Obs |
|:---:|---|---|:---:|---|
| 🧃 | **SUCO** | SU·CO | 2 | — |
| 🫧 | **SUJO** | SU·JO | 2 | — |

---

## Famílias sem solução: VU · ZO · ZU

Busquei a sílaba no início e no meio da palavra, em dois bancos independentes.
Não existe substantivo infantil em português para essas três. Sugestão para o app:
apresentá-las apenas no modo de som (a criança ouve VU · ZO · ZU e repete),
sem tela de palavras.

---

# PARTE I-B — Exceções aprovadas por você

Cada bloco quebra **um** critério. Mantidos separados para você poder ligar e
desligar por categoria dentro do app.

## Sílaba só de vogal (V) — a mais simples que existe — 18

| Emoji | Palavra | Divisão |
|:---:|---|---|
| 🌙 | **LUA** | LU·A |
| 🛣️ | **RUA** | RU·A |
| 👩 | **TIA** | TI·A |
| 👨 | **TIO** | TI·O |
| ☀️ | **DIA** | DI·A |
| 🧵 | **FIO** | FI·O |
| 🏞️ | **RIO** | RI·O |
| 🕊️ | **VOA** | VO·A |
| 🚢 | **NAVIO** | NA·VI·O |
| 🎻 | **VIOLA** | VI·O·LA |
| 🩲 | **CUECA** | CU·E·CA |
| 🪙 | **MOEDA** | MO·E·DA |
| 👑 | **COROA** | CO·RO·A |
| 🍞 | **MIOLO** | MI·O·LO |
| ⚔️ | **DUELO** | DU·E·LO |
| 🍕 | **FATIA** | FA·TI·A |
| 🧸 | **MACIO** | MA·CI·O |
| ✈️ | **VIAJE** | VI·A·JE |

## Letra X (som /ʃ/, como CH) — 6

| Emoji | Palavra | Divisão |
|:---:|---|---|
| 🗑️ | **LIXO** | LI·XO |
| 🪵 | **LIXA** | LI·XA |
| 🪢 | **PUXA** | PU·XA |
| 🟣 | **ROXO** | RO·XO |
| ☕ | **XÍCARA** | XÍ·CA·RA |
| 🍗 | **COXA** | CO·XA |

## Ditongo — duas vogais na mesma sílaba — 10

| Emoji | Palavra | Divisão |
|:---:|---|---|
| 👨 | **PAPAI** | PA·PAI |
| 🐂 | **BOI** | BOI |
| 🧦 | **MEIA** | MEI·A |
| 🥛 | **LEITE** | LEI·TE |
| 🐋 | **BALEIA** | BA·LEI·A |
| 👵 | **VOVÔ E VOVÓ** | — |
| 🪑 | **CADEIRA** | CA·DEI·RA |
| 🐟 | **PEIXE** | PEI·XE |
| 🥕 | **CENOURA** | CE·NOU·RA |
| 🍐 | **GOIABA** | GOI·A·BA |

## Vogal nasal Ã / ÃO — 10

| Emoji | Palavra | Divisão |
|:---:|---|---|
| 👩 | **MAMÃE** | MA·MÃE |
| 🎈 | **BALÃO** | BA·LÃO |
| 🍋 | **LIMÃO** | LI·MÃO |
| 🍈 | **MELÃO** | ME·LÃO |
| 🧼 | **SABÃO** | SA·BÃO |
| 🍞 | **PÃO** | PÃO |
| 🦁 | **LEÃO** | LE·ÃO |
| 🍎 | **MAÇÃ** | MA·ÇÃ |
| 👦 | **IRMÃO** | IR·MÃO |
| ❤️ | **CORAÇÃO** | CO·RA·ÇÃO |

## 100% CV, mas com 4 sílabas — 9

| Emoji | Palavra | Divisão |
|:---:|---|---|
| ☎️ | **TELEFONE** | TE·LE·FO·NE |
| 🍭 | **PIRULITO** | PI·RU·LI·TO |
| 🦫 | **CAPIVARA** | CA·PI·VA·RA |
| 🦋 | **MARIPOSA** | MA·RI·PO·SA |
| 💪 | **COTOVELO** | CO·TO·VE·LO |
| 🔩 | **PARAFUSO** | PA·RA·FU·SO |
| 🔪 | **CANIVETE** | CA·NI·VE·TE |
| 💊 | **VITAMINA** | VI·TA·MI·NA |
| 🔭 | **BINÓCULO** | BI·NÓ·CU·LO |

## Ç — letra simples, som /s/ — 10

| Emoji | Palavra | Divisão |
|:---:|---|---|
| 🧠 | **CABEÇA** | CA·BE·ÇA |
| 🎀 | **LAÇO** | LA·ÇO |
| 👩 | **MOÇA** | MO·ÇA |
| 💧 | **POÇA** | PO·ÇA |
| 🍰 | **PEDAÇO** | PE·DA·ÇO |
| 💨 | **FUMAÇA** | FU·MA·ÇA |
| 🥭 | **CAROÇO** | CA·RO·ÇO |
| 👨 | **MOÇO** | MO·ÇO |
| 🧩 | **PEÇA** | PE·ÇA |
| 🕳️ | **POÇO** | PO·ÇO |

---

# PARTE II — Sílabas complexas

Etapa seguinte. A ordem abaixo é a que costuma funcionar: primeiro o R travando a
sílaba, depois o RR, depois os encontros consonantais, e os dígrafos ao longo do caminho.

## 1. R — a prioridade

### 1.1 · R FORTE no início da palavra (som de CARRO)

> Estrutura CV simples, mas o som é o R forte. Já estão no Bloco 4 da Parte I.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🐭 | **RATO** | RA·TO | — |
| 📏 | **RÉGUA** | RÉ·GUA | gua |
| 🛞 | **RODA** | RO·DA | — |
| 🏞️ | **RIO** | RI·O | — |
| 🛣️ | **RUA** | RU·A | — |
| 🤴 | **REI** | REI | ditongo |
| 👕 | **ROUPA** | ROU·PA | ditongo |
| ⏰ | **RELÓGIO** | RE·LÓ·GIO | gio |

### 1.2 · RR entre vogais — som forte

> Dígrafo. Duas letras, um som só — o mesmo R de RATO.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🚗 | **CARRO** | CAR·RO | — |
| 🌍 | **TERRA** | TER·RA | — |
| 🏺 | **JARRA** | JAR·RA | — |
| ⚙️ | **FERRO** | FER·RO | — |
| 🪚 | **SERRA** | SER·RA | — |
| 🫏 | **BURRO** | BUR·RO | — |
| ⛰️ | **MORRO** | MOR·RO | — |
| 🟤 | **BARRO** | BAR·RO | — |
| ❌ | **ERRO** | ER·RO | — |
| 🏃 | **CORRE** | COR·RE | ação |
| 🤰 | **BARRIGA** | BAR·RI·GA | — |
| 🍾 | **GARRAFA** | GAR·RA·FA | — |
| 🦗 | **CIGARRA** | CI·GAR·RA | — |
| 🐄 | **BEZERRO** | BE·ZER·RO | — |
| 🦆 | **MARRECO** | MAR·RE·CO | — |
| ⛺ | **BARRACA** | BAR·RA·CA | — |
| 🆘 | **SOCORRO** | SO·COR·RO | — |

### 1.3 · R travando a sílaba — PAR, POR, VER

> A sílaba termina em R. É a primeira sílaba complexa que costuma aparecer.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🚪 | **PORTA** | POR·TA | — |
| ✉️ | **CARTA** | CAR·TA | — |
| ⛵ | **BARCO** | BAR·CO | — |
| 🟩 | **VERDE** | VER·DE | — |
| 🦵 | **PERNA** | PER·NA | — |
| 🍴 | **GARFO** | GAR·FO | — |
| 🎪 | **CIRCO** | CIR·CO | — |
| 🐻 | **URSO** | UR·SO | — |
| 🪢 | **CORDA** | COR·DA | — |
| 🪱 | **VERME** | VER·ME | — |
| 🌇 | **TARDE** | TAR·DE | — |
| 🥩 | **CARNE** | CAR·NE | — |
| 🐷 | **PORCO** | POR·CO | — |
| 🧔 | **BARBA** | BAR·BA | — |
| 📍 | **PERTO** | PER·TO | — |
| 🔨 | **MARTELO** | MAR·TE·LO | — |
| 🐜 | **FORMIGA** | FOR·MI·GA | — |
| 🐛 | **LAGARTA** | LA·GAR·TA | — |
| 🦋 | **BORBOLETA** | BOR·BO·LE·TA | 4 sílabas |
| 🐢 | **TARTARUGA** | TAR·TA·RU·GA | 4 sílabas |

### 1.4 · R no encontro consonantal — PRA, BRA, TRA…

> Duas consoantes coladas antes da vogal. Costuma ser a etapa mais difícil.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 💪 | **BRAÇO** | BRA·ÇO | BR |
| ⚪ | **BRANCO** | BRAN·CO | BR |
| 💍 | **BRINCO** | BRIN·CO | BR |
| 🧙 | **BRUXA** | BRU·XA | BR |
| 😠 | **BRIGA** | BRI·GA | BR |
| 🐍 | **COBRA** | CO·BRA | BR |
| 🐐 | **CABRA** | CA·BRA | BR |
| 🦓 | **ZEBRA** | ZE·BRA | BR |
| 🐇 | **LEBRE** | LE·BRE | BR |
| 🌑 | **SOMBRA** | SOM·BRA | BR |
| 🤗 | **ABRAÇO** | A·BRA·ÇO | BR |
| 🌷 | **CRAVO** | CRA·VO | CR |
| 🍦 | **CREME** | CRE·ME | CR |
| 🏫 | **CRECHE** | CRE·CHE | CR |
| 👶 | **CRIANÇA** | CRI·AN·ÇA | CR |
| ✍️ | **ESCREVE** | ES·CRE·VE | CR |
| 🐉 | **DRAGÃO** | DRA·GÃO | DR |
| 🪨 | **PEDRA** | PE·DRA | DR |
| 🪟 | **VIDRO** | VI·DRO | DR |
| 🖼️ | **QUADRO** | QUA·DRO | DR |
| 🦹 | **LADRÃO** | LA·DRÃO | DR |
| 🙏 | **PADRE** | PA·DRE | DR |
| 🍎 | **FRUTA** | FRU·TA | FR |
| 🥶 | **FRIO** | FRI·O | FR |
| 🍗 | **FRANGO** | FRAN·GO | FR |
| 🧷 | **FRALDA** | FRAL·DA | FR |
| 🛑 | **FREIO** | FREI·O | FR |
| 🔐 | **COFRE** | CO·FRE | FR |
| 🌱 | **GRAMA** | GRA·MA | GR |
| 🔠 | **GRANDE** | GRAN·DE | GR |
| 🦗 | **GRILO** | GRI·LO | GR |
| 😱 | **GRITA** | GRI·TA | GR |
| 🐅 | **TIGRE** | TI·GRE | GR |
| 🦴 | **MAGRO** | MA·GRO | GR |
| 😄 | **ALEGRE** | A·LE·GRE | GR |
| 📏 | **REGRA** | RE·GRA | GR |
| 👔 | **GRAVATA** | GRA·VA·TA | GR |
| 🍽️ | **PRATO** | PRA·TO | PR |
| 🏖️ | **PRAIA** | PRAI·A | PR |
| 👦 | **PRIMO** | PRI·MO | PR |
| 👧 | **PRIMA** | PRI·MA | PR |
| ⚫ | **PRETO** | PRE·TO | PR |
| 🥈 | **PRATA** | PRA·TA | PR |
| 🛒 | **COMPRA** | COM·PRA | PR |
| 🎁 | **PRESENTE** | PRE·SEN·TE | PR |
| 3️⃣ | **TRÊS** | TRÊS | TR |
| 🚂 | **TREM** | TREM | TR |
| 🌾 | **TRIGO** | TRI·GO | TR |
| 🥅 | **TRAVE** | TRA·VE | TR |
| 🛷 | **TRENÓ** | TRE·NÓ | TR |
| 🔤 | **LETRA** | LE·TRA | TR |
| 📦 | **DENTRO** | DEN·TRO | TR |
| ➡️ | **OUTRO** | OU·TRO | TR |
| ⭐ | **ESTRELA** | ES·TRE·LA | TR |
| 📕 | **LIVRO** | LI·VRO | VR |
| 🕊️ | **LIVRE** | LI·VRE | VR |
| 💬 | **PALAVRA** | PA·LA·VRA | VR |

### 1.5 · R no fim da palavra

> Aparece muito nos verbos no infinitivo.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🌊 | **MAR** | MAR | — |
| 🎨 | **COR** | COR | — |
| 🤕 | **DOR** | DOR | — |
| ❤️ | **AMOR** | A·MOR | — |
| ☀️ | **CALOR** | CA·LOR | — |
| 🍽️ | **COMER** | CO·MER | — |
| 😴 | **DORMIR** | DOR·MIR | — |
| 🤸 | **PULAR** | PU·LAR | — |
| 🎤 | **CANTAR** | CAN·TAR | — |
| ⚽ | **JOGAR** | JO·GAR | — |
| 📍 | **LUGAR** | LU·GAR | — |
| 👩 | **MULHER** | MU·LHER | + LH |

---

## 2. L complexo

### 2.1 · L travando a sílaba — AL, EL, OL

> No fim da sílaba o L costuma soar como U (SOU-U, PAPÉ-U).

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| ☀️ | **SOL** | SOL | — |
| 🍯 | **MEL** | MEL | — |
| 💍 | **ANEL** | A·NEL | — |
| 📄 | **PAPEL** | PA·PEL | — |
| 🔵 | **AZUL** | A·ZUL | — |
| ⚗️ | **FUNIL** | FU·NIL | — |
| 📏 | **ALTO** | AL·TO | — |
| 🔄 | **VOLTA** | VOL·TA | — |
| 👠 | **SALTO** | SAL·TO | — |
| 🍲 | **CALDO** | CAL·DO | — |
| ❓ | **FALTA** | FAL·TA | — |
| 👜 | **BOLSA** | BOL·SA | — |
| 👖 | **CALÇA** | CAL·ÇA | + Ç |
| 🏡 | **QUINTAL** | QUIN·TAL | + QU |

### 2.2 · L no encontro consonantal — BLA, CLA, FLA…

> Menos comum que o R, mas aparece em palavras que a criança usa.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🧱 | **BLOCO** | BLO·CO | BL |
| 👚 | **BLUSA** | BLU·SA | BL |
| 📱 | **TABLET** | TA·BLET | BL |
| 💡 | **CLARO** | CLA·RO | CL |
| 📎 | **CLIPE** | CLI·PE | CL |
| 🏟️ | **CLUBE** | CLU·BE | CL |
| ⌨️ | **TECLADO** | TE·CLA·DO | CL |
| 🚲 | **BICICLETA** | BI·CI·CLE·TA | CL · 4 sílabas |
| 🌸 | **FLOR** | FLOR | FL |
| 🪈 | **FLAUTA** | FLAU·TA | FL |
| ❄️ | **FLOCO** | FLO·CO | FL |
| 🏹 | **FLECHA** | FLE·CHA | FL · + CH |
| 🌳 | **FLORESTA** | FLO·RES·TA | FL |
| 🌐 | **GLOBO** | GLO·BO | GL |
| 🧊 | **IGLU** | I·GLU | GL |
| 🔤 | **SIGLA** | SI·GLA | GL |
| 🌿 | **PLANTA** | PLAN·TA | PL |
| 🪧 | **PLACA** | PLA·CA | PL |
| 🪶 | **PLUMA** | PLU·MA | PL |
| 🪐 | **PLANETA** | PLA·NE·TA | PL |
| 🧴 | **PLÁSTICO** | PLÁS·TI·CO | PL |
| 🏃 | **ATLETA** | A·TLE·TA | TL · raro |

---

## 3. Dígrafos

### 3.1 · CH — som /ʃ/

> Duas letras, um som. Igual ao X de LIXO.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🔑 | **CHAVE** | CHA·VE | — |
| 🌧️ | **CHUVA** | CHU·VA | — |
| 🍵 | **CHÁ** | CHÁ | — |
| ⬇️ | **CHÃO** | CHÃO | — |
| 🩴 | **CHINELO** | CHI·NE·LO | — |
| 🎩 | **CHAPÉU** | CHA·PÉU | — |
| 🍼 | **CHUPETA** | CHU·PE·TA | — |
| 🎒 | **MOCHILA** | MO·CHI·LA | — |
| 🍪 | **BOLACHA** | BO·LA·CHA | — |
| 🚪 | **FECHA** | FE·CHA | ação |
| 🤕 | **MACHUCA** | MA·CHU·CA | ação |
| 🐕 | **CACHORRO** | CA·CHOR·RO | + RR |
| 🍫 | **CHOCOLATE** | CHO·CO·LA·TE | 4 sílabas |

### 3.2 · LH — som /ʎ/

> Muito frequente em palavras do dia a dia da criança.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 👧 | **FILHA** | FI·LHA | — |
| 👦 | **FILHO** | FI·LHO | — |
| 🌽 | **MILHO** | MI·LHO | — |
| 🍃 | **FOLHA** | FO·LHA | — |
| 🌿 | **GALHO** | GA·LHO | — |
| 👴 | **VELHO** | VE·LHO | — |
| 🔋 | **PILHA** | PI·LHA | — |
| 🍅 | **MOLHO** | MO·LHO | — |
| 👂 | **ORELHA** | O·RE·LHA | — |
| 🦵 | **JOELHO** | JO·E·LHO | — |
| 🐰 | **COELHO** | CO·E·LHO | — |
| 🐝 | **ABELHA** | A·BE·LHA | — |
| 🧻 | **TOALHA** | TO·A·LHA | — |
| 🤡 | **PALHAÇO** | PA·LHA·ÇO | + Ç |
| 🥄 | **COLHER** | CO·LHER | — |
| 🪞 | **ESPELHO** | ES·PE·LHO | — |
| 🪡 | **AGULHA** | A·GU·LHA | — |
| 👩 | **MULHER** | MU·LHER | — |

### 3.3 · NH — som /ɲ/

> Também muito frequente. Foi o que barrou BANHO na lista simples.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🛁 | **BANHO** | BA·NHO | — |
| 💅 | **UNHA** | U·NHA | — |
| 💭 | **SONHO** | SO·NHO | — |
| 🧵 | **LINHA** | LI·NHA | — |
| 🪹 | **NINHO** | NI·NHO | — |
| 🪵 | **LENHA** | LE·NHA | — |
| 🐔 | **GALINHA** | GA·LI·NHA | — |
| 🪱 | **MINHOCA** | MI·NHO·CA | — |
| 🕷️ | **ARANHA** | A·RA·NHA | — |
| 👸 | **RAINHA** | RA·I·NHA | — |
| 🛤️ | **CAMINHO** | CA·MI·NHO | — |
| 🤗 | **CARINHO** | CA·RI·NHO | — |
| 🏘️ | **VIZINHO** | VI·ZI·NHO | — |
| 💰 | **DINHEIRO** | DI·NHEI·RO | + ditongo |
| 🚽 | **BANHEIRO** | BA·NHEI·RO | + ditongo |
| ⛰️ | **MONTANHA** | MON·TA·NHA | — |
| 🚚 | **CAMINHÃO** | CA·MI·NHÃO | + nasal |

### 3.4 · SS — som /s/ entre vogais

> Duas letras para não deixar o S soar /z/.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🍝 | **MASSA** | MAS·SA | — |
| 🦴 | **OSSO** | OS·SO | — |
| 🍞 | **ASSA** | AS·SA | ação |
| 🙋 | **POSSO** | POS·SO | — |
| 🏫 | **CLASSE** | CLAS·SE | + CL |
| 🧍 | **PESSOA** | PES·SO·A | — |
| 🐦 | **PÁSSARO** | PÁS·SA·RO | — |
| 🧹 | **VASSOURA** | VAS·SOU·RA | + ditongo |
| 🚶 | **PASSEIO** | PAS·SEI·O | + ditongo |
| 👩‍🏫 | **PROFESSORA** | PRO·FES·SO·RA | 4 sílabas |

### 3.5 · QU com U mudo — QUE, QUI (som /k/)

> O U não é pronunciado. É o mesmo som de CA CO CU.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🧀 | **QUEIJO** | QUEI·JO | — |
| 🔥 | **QUENTE** | QUEN·TE | — |
| 🙏 | **QUERO** | QUE·RO | — |
| 📍 | **AQUI** | A·QUI | — |
| 🏡 | **QUINTAL** | QUIN·TAL | — |
| ⚙️ | **MÁQUINA** | MÁ·QUI·NA | — |
| 🐜 | **PEQUENO** | PE·QUE·NO | — |
| 🏞️ | **PARQUE** | PAR·QUE | + R travado |
| 🌲 | **BOSQUE** | BOS·QUE | — |
| 🎾 | **RAQUETE** | RA·QUE·TE | — |
| 🐿️ | **ESQUILO** | ES·QUI·LO | — |
| 🦟 | **MOSQUITO** | MOS·QUI·TO | — |
| 🛢️ | **TANQUE** | TAN·QUE | — |

### 3.6 · QU com U pronunciado — QUA, QUO (som /kw/)

> Aqui o U soa. Mesma dupla de letras, outro som — vale separar.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 4️⃣ | **QUATRO** | QUA·TRO | + TR |
| 🖼️ | **QUADRO** | QUA·DRO | + DR |
| ➗ | **QUASE** | QUA·SE | — |
| ⏰ | **QUANDO** | QUAN·DO | — |
| 🛏️ | **QUARTO** | QUAR·TO | + R travado |

### 3.7 · GU com U mudo — GUE, GUI (som /g/)

> Mesmo som de GA GO GU. Foi o que barrou FOGUETE da lista simples.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🚀 | **FOGUETE** | FO·GUE·TE | — |
| 🎸 | **GUITARRA** | GUI·TAR·RA | + RR |
| ⚔️ | **GUERRA** | GUER·RA | + RR |
| 🫏 | **JEGUE** | JE·GUE | — |
| 🩸 | **SANGUE** | SAN·GUE | — |
| 🗺️ | **GUIA** | GUI·A | — |
| 🦅 | **ÁGUIA** | Á·GUIA | — |
| 🥭 | **MANGUEIRA** | MAN·GUEI·RA | + ditongo |
| 🐜 | **FORMIGUEIRO** | FOR·MI·GUEI·RO | 4 sílabas |

### 3.8 · GU com U pronunciado — GUA (som /gw/)

> Aqui o U soa. Inclui a palavra mais usada de todas: ÁGUA.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 💧 | **ÁGUA** | Á·GUA | — |
| 💂 | **GUARDA** | GUAR·DA | + R travado |
| 🟰 | **IGUAL** | I·GUAL | — |
| 👅 | **LÍNGUA** | LÍN·GUA | — |
| 📏 | **RÉGUA** | RÉ·GUA | — |

### 3.9 · SC / XC — som /s/ (raro)

> Aparece pouco, mas vale conhecer.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🐣 | **NASCE** | NAS·CE | — |
| ⬇️ | **DESCE** | DES·CE | — |
| 📈 | **CRESCE** | CRES·CE | + CR |
| 🏊 | **PISCINA** | PIS·CI·NA | S + C separados |

---

## 4. Sílaba travada por S

### 4.1 · S no fim da sílaba — AS, ES, IS, OS, US

> Muito comum. Foi o que barrou LÁPIS da lista simples.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🎉 | **FESTA** | FES·TA | — |
| 🧺 | **CESTA** | CES·TA | — |
| 📁 | **PASTA** | PAS·TA | — |
| 🪰 | **MOSCA** | MOS·CA | — |
| 🎣 | **ISCA** | IS·CA | — |
| ✏️ | **LÁPIS** | LÁ·PIS | — |
| 🏫 | **ESCOLA** | ES·CO·LA | — |
| 👗 | **VESTIDO** | VES·TI·DO | — |
| 🏰 | **CASTELO** | CAS·TE·LO | — |
| 😋 | **GOSTOSO** | GOS·TO·SO | — |
| 🍪 | **BISCOITO** | BIS·COI·TO | + ditongo |

---

## 5. Sílaba nasal — M e N travando

### 5.1 · AM, EM, IM, OM, UM / AN, EN, IN, ON, UN

> A vogal fica nasal. É a base para depois entender ÃO e ÃE.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🏕️ | **CAMPO** | CAM·PO | — |
| ⏰ | **TEMPO** | TEM·PO | — |
| 🌉 | **PONTE** | PON·TE | — |
| 🦷 | **DENTE** | DEN·TE | — |
| 💇 | **PENTE** | PEN·TE | — |
| 🎨 | **TINTA** | TIN·TA | — |
| 🐤 | **PINTO** | PIN·TO | — |
| 🥭 | **MANGA** | MAN·GA | — |
| 🌊 | **ONDA** | ON·DA | — |
| 🏦 | **BANCO** | BAN·CO | — |
| 💨 | **VENTO** | VEN·TO | — |
| 🌍 | **MUNDO** | MUN·DO | — |
| 🎤 | **CANTA** | CAN·TA | ação |
| 🍽️ | **JANTA** | JAN·TA | ação |
| 💄 | **BATOM** | BA·TOM | — |
| 🍮 | **PUDIM** | PU·DIM | — |
| ☁️ | **NUVEM** | NU·VEM | — |
| 🌷 | **JARDIM** | JAR·DIM | + R travado |
| 🍬 | **BOMBOM** | BOM·BOM | — |
| 🍊 | **LARANJA** | LA·RAN·JA | — |
| 🌱 | **SEMENTE** | SE·MEN·TE | — |
| 💡 | **LÂMPADA** | LÂM·PA·DA | — |
| 🥁 | **TAMBOR** | TAM·BOR | + R final |

---

## 6. Ç e X

### 6.1 · Ç — som /s/ antes de A, O, U

> Letra simples, mas som que confunde com o S e o C brando.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🧠 | **CABEÇA** | CA·BE·ÇA | — |
| 🎀 | **LAÇO** | LA·ÇO | — |
| 👩 | **MOÇA** | MO·ÇA | — |
| 💧 | **POÇA** | PO·ÇA | — |
| 🍰 | **PEDAÇO** | PE·DA·ÇO | — |
| 💨 | **FUMAÇA** | FU·MA·ÇA | — |
| 🥭 | **CAROÇO** | CA·RO·ÇO | — |
| 🍎 | **MAÇÃ** | MA·ÇÃ | + nasal |
| 🍼 | **BERÇO** | BER·ÇO | + R travado |
| 👖 | **CALÇA** | CAL·ÇA | + L travado |
| 💃 | **DANÇA** | DAN·ÇA | + nasal |
| 🍬 | **AÇÚCAR** | A·ÇÚ·CAR | + R final |

### 6.2 · X com som de CH (/ʃ/)

> O caso mais comum do X. Já aprovado por você na lista simples.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🗑️ | **LIXO** | LI·XO | — |
| 🪵 | **LIXA** | LI·XA | — |
| 🟣 | **ROXO** | RO·XO | — |
| 🪢 | **PUXA** | PU·XA | ação |
| ☕ | **XÍCARA** | XÍ·CA·RA | — |
| ♟️ | **XADREZ** | XA·DREZ | + DR |
| 📦 | **CAIXA** | CAI·XA | + ditongo |
| 🐟 | **PEIXE** | PEI·XE | + ditongo |
| 🧙 | **BRUXA** | BRU·XA | + BR |
| 🍍 | **ABACAXI** | A·BA·CA·XI | 4 sílabas |

### 6.3 · X com outros sons

> Mesma letra, sons diferentes. Deixar para o fim.

| Emoji | Palavra | Divisão | Obs |
|:---:|---|---|---|
| 🚕 | **TÁXI** | TÁ·XI | som /ks/ |
| 📅 | **SEXTA** | SEX·TA | som /s/ |
| 🩺 | **EXAME** | E·XA·ME | som /z/ |
| ➡️ | **PRÓXIMO** | PRÓ·XI·MO | som /s/ · + PR |

---

# Alertas de som

1. **S entre vogais soa /z/** — CASA, MESA, ROSA, VASO, RAPOSA, CAMISA, MÚSICA, RISADA, GULOSO, PISO. A criança vê SA e ouve /za/.
2. **R forte × R brando** — RATO, RODA, RUA têm o R de CARRO. CARA, PERA, MURO têm o R brando. Mesma letra, dois sons: por isso o Bloco 4 existe.
3. **C e G mudam de som** — CA CO CU /k/ × CE CI /s/ · GA GO GU /g/ × GE GI /j/. Blocos 2 e 3 separados, como você pediu.
4. **QU e GU têm duas versões** — QUE/QUI e GUE/GUI com U mudo; QUA e GUA com U pronunciado. Separados nas seções 3.5 a 3.8.
5. **X tem quatro sons** — LIXO /ʃ/, TÁXI /ks/, EXAME /z/, PRÓXIMO /s/. Só o primeiro grupo entrou na Parte I-B.
6. **L no fim da sílaba soa U** — SOL, PAPEL, AZUL. Vale avisar o adulto que conduz a atividade.

---

# JSON para o app

```json
{
 "versao": "3.0",
 "simples": {
  "BA": [
   {
    "p": "BALA",
    "s": [
     "BA",
     "LA"
    ],
    "e": "🍬",
    "obs": ""
   },
   {
    "p": "BABÁ",
    "s": [
     "BA",
     "BÁ"
    ],
    "e": "👩‍🍼",
    "obs": ""
   },
   {
    "p": "BABA",
    "s": [
     "BA",
     "BA"
    ],
    "e": "🤤",
    "obs": ""
   },
   {
    "p": "BATE",
    "s": [
     "BA",
     "TE"
    ],
    "e": "👊",
    "obs": "ação"
   },
   {
    "p": "BANANA",
    "s": [
     "BA",
     "NA",
     "NA"
    ],
    "e": "🍌",
    "obs": ""
   },
   {
    "p": "BATATA",
    "s": [
     "BA",
     "TA",
     "TA"
    ],
    "e": "🥔",
    "obs": ""
   },
   {
    "p": "BARATA",
    "s": [
     "BA",
     "RA",
     "TA"
    ],
    "e": "🪳",
    "obs": "r brando"
   },
   {
    "p": "BATIDA",
    "s": [
     "BA",
     "TI",
     "DA"
    ],
    "e": "🥤",
    "obs": ""
   },
   {
    "p": "BAFO",
    "s": [
     "BA",
     "FO"
    ],
    "e": "😮‍💨",
    "obs": "novo · v3"
   }
  ],
  "BE": [
   {
    "p": "BEBÊ",
    "s": [
     "BE",
     "BÊ"
    ],
    "e": "👶",
    "obs": ""
   },
   {
    "p": "BEBE",
    "s": [
     "BE",
     "BE"
    ],
    "e": "🥤",
    "obs": "ação"
   },
   {
    "p": "BEBO",
    "s": [
     "BE",
     "BO"
    ],
    "e": "🥛",
    "obs": "ação · seu"
   },
   {
    "p": "BELA",
    "s": [
     "BE",
     "LA"
    ],
    "e": "👸",
    "obs": "seu"
   },
   {
    "p": "BETO",
    "s": [
     "BE",
     "TO"
    ],
    "e": "👦",
    "obs": "nome · seu"
   },
   {
    "p": "BECO",
    "s": [
     "BE",
     "CO"
    ],
    "e": "🏚️",
    "obs": ""
   },
   {
    "p": "BELEZA",
    "s": [
     "BE",
     "LE",
     "ZA"
    ],
    "e": "💅",
    "obs": ""
   }
  ],
  "BI": [
   {
    "p": "BICO",
    "s": [
     "BI",
     "CO"
    ],
    "e": "🐦",
    "obs": ""
   },
   {
    "p": "BIFE",
    "s": [
     "BI",
     "FE"
    ],
    "e": "🥩",
    "obs": ""
   },
   {
    "p": "BICA",
    "s": [
     "BI",
     "CA"
    ],
    "e": "🚰",
    "obs": "seu"
   },
   {
    "p": "BIBI",
    "s": [
     "BI",
     "BI"
    ],
    "e": "🚗",
    "obs": "seu"
   },
   {
    "p": "BINA",
    "s": [
     "BI",
     "NA"
    ],
    "e": "👧",
    "obs": "nome · seu"
   },
   {
    "p": "BIGODE",
    "s": [
     "BI",
     "GO",
     "DE"
    ],
    "e": "🥸",
    "obs": ""
   },
   {
    "p": "BICADA",
    "s": [
     "BI",
     "CA",
     "DA"
    ],
    "e": "🐔",
    "obs": ""
   },
   {
    "p": "BIRUTA",
    "s": [
     "BI",
     "RU",
     "TA"
    ],
    "e": "🌬️",
    "obs": "r brando"
   }
  ],
  "BO": [
   {
    "p": "BOCA",
    "s": [
     "BO",
     "CA"
    ],
    "e": "👄",
    "obs": ""
   },
   {
    "p": "BOLA",
    "s": [
     "BO",
     "LA"
    ],
    "e": "⚽",
    "obs": ""
   },
   {
    "p": "BOLO",
    "s": [
     "BO",
     "LO"
    ],
    "e": "🎂",
    "obs": ""
   },
   {
    "p": "BOTA",
    "s": [
     "BO",
     "TA"
    ],
    "e": "👢",
    "obs": ""
   },
   {
    "p": "BODE",
    "s": [
     "BO",
     "DE"
    ],
    "e": "🐐",
    "obs": ""
   },
   {
    "p": "BONÉ",
    "s": [
     "BO",
     "NÉ"
    ],
    "e": "🧢",
    "obs": ""
   },
   {
    "p": "BOBO",
    "s": [
     "BO",
     "BO"
    ],
    "e": "🤪",
    "obs": ""
   },
   {
    "p": "BONECA",
    "s": [
     "BO",
     "NE",
     "CA"
    ],
    "e": "🪆",
    "obs": ""
   },
   {
    "p": "BONITO",
    "s": [
     "BO",
     "NI",
     "TO"
    ],
    "e": "🌻",
    "obs": ""
   },
   {
    "p": "BONITA",
    "s": [
     "BO",
     "NI",
     "TA"
    ],
    "e": "🌸",
    "obs": ""
   }
  ],
  "BU": [
   {
    "p": "BULE",
    "s": [
     "BU",
     "LE"
    ],
    "e": "🫖",
    "obs": ""
   },
   {
    "p": "BULA",
    "s": [
     "BU",
     "LA"
    ],
    "e": "💊",
    "obs": "seu"
   },
   {
    "p": "BUDA",
    "s": [
     "BU",
     "DA"
    ],
    "e": "🧘",
    "obs": "seu"
   },
   {
    "p": "BUZINA",
    "s": [
     "BU",
     "ZI",
     "NA"
    ],
    "e": "📢",
    "obs": ""
   },
   {
    "p": "BURACO",
    "s": [
     "BU",
     "RA",
     "CO"
    ],
    "e": "🕳️",
    "obs": "r brando"
   },
   {
    "p": "BÚFALO",
    "s": [
     "BÚ",
     "FA",
     "LO"
    ],
    "e": "🐃",
    "obs": "acento na 1ª"
   }
  ],
  "DA": [
   {
    "p": "DADO",
    "s": [
     "DA",
     "DO"
    ],
    "e": "🎲",
    "obs": ""
   },
   {
    "p": "DAMA",
    "s": [
     "DA",
     "MA"
    ],
    "e": "♟️",
    "obs": ""
   },
   {
    "p": "DATA",
    "s": [
     "DA",
     "TA"
    ],
    "e": "📅",
    "obs": "abstrato"
   }
  ],
  "DE": [
   {
    "p": "DEDO",
    "s": [
     "DE",
     "DO"
    ],
    "e": "👆",
    "obs": ""
   },
   {
    "p": "DEZENA",
    "s": [
     "DE",
     "ZE",
     "NA"
    ],
    "e": "🔟",
    "obs": "abstrato"
   }
  ],
  "DI": [
   {
    "p": "DIA",
    "s": [
     "DI",
     "A"
    ],
    "e": "☀️",
    "obs": "V"
   },
   {
    "p": "MEDIDA",
    "s": [
     "ME",
     "DI",
     "DA"
    ],
    "e": "📏",
    "obs": "no meio"
   },
   {
    "p": "PEDIDO",
    "s": [
     "PE",
     "DI",
     "DO"
    ],
    "e": "🙏",
    "obs": "no meio"
   },
   {
    "p": "DINO",
    "s": [
     "DI",
     "NO"
    ],
    "e": "🦕",
    "obs": "novo · v3"
   }
  ],
  "DO": [
   {
    "p": "DOCE",
    "s": [
     "DO",
     "CE"
    ],
    "e": "🍬",
    "obs": ""
   },
   {
    "p": "DOZE",
    "s": [
     "DO",
     "ZE"
    ],
    "e": "1️⃣2️⃣",
    "obs": ""
   },
   {
    "p": "DONA",
    "s": [
     "DO",
     "NA"
    ],
    "e": "👩",
    "obs": ""
   },
   {
    "p": "DOMINÓ",
    "s": [
     "DO",
     "MI",
     "NÓ"
    ],
    "e": "🁢",
    "obs": ""
   }
  ],
  "DU": [
   {
    "p": "DUDU",
    "s": [
     "DU",
     "DU"
    ],
    "e": "👦",
    "obs": "nome · seu"
   },
   {
    "p": "DUDA",
    "s": [
     "DU",
     "DA"
    ],
    "e": "👧",
    "obs": "nome · seu"
   },
   {
    "p": "DUNA",
    "s": [
     "DU",
     "NA"
    ],
    "e": "🏜️",
    "obs": "seu"
   },
   {
    "p": "MADURO",
    "s": [
     "MA",
     "DU",
     "RO"
    ],
    "e": "🍌",
    "obs": "no meio · r brando"
   },
   {
    "p": "DUELO",
    "s": [
     "DU",
     "E",
     "LO"
    ],
    "e": "⚔️",
    "obs": "V"
   }
  ],
  "FA": [
   {
    "p": "FACA",
    "s": [
     "FA",
     "CA"
    ],
    "e": "🔪",
    "obs": ""
   },
   {
    "p": "FADA",
    "s": [
     "FA",
     "DA"
    ],
    "e": "🧚",
    "obs": ""
   },
   {
    "p": "FALA",
    "s": [
     "FA",
     "LA"
    ],
    "e": "🗣️",
    "obs": "ação"
   },
   {
    "p": "FAVA",
    "s": [
     "FA",
     "VA"
    ],
    "e": "🫘",
    "obs": ""
   },
   {
    "p": "FAROFA",
    "s": [
     "FA",
     "RO",
     "FA"
    ],
    "e": "🍚",
    "obs": "r brando"
   },
   {
    "p": "FAVELA",
    "s": [
     "FA",
     "VE",
     "LA"
    ],
    "e": "🏘️",
    "obs": ""
   },
   {
    "p": "FATIA",
    "s": [
     "FA",
     "TI",
     "A"
    ],
    "e": "🍕",
    "obs": "V"
   }
  ],
  "FE": [
   {
    "p": "FERA",
    "s": [
     "FE",
     "RA"
    ],
    "e": "🦁",
    "obs": "seu · r brando"
   },
   {
    "p": "FEDE",
    "s": [
     "FE",
     "DE"
    ],
    "e": "💩",
    "obs": "ação"
   },
   {
    "p": "FERIDA",
    "s": [
     "FE",
     "RI",
     "DA"
    ],
    "e": "🩹",
    "obs": "r brando"
   }
  ],
  "FI": [
   {
    "p": "FITA",
    "s": [
     "FI",
     "TA"
    ],
    "e": "🎀",
    "obs": ""
   },
   {
    "p": "FIGO",
    "s": [
     "FI",
     "GO"
    ],
    "e": "🍇",
    "obs": ""
   },
   {
    "p": "FILA",
    "s": [
     "FI",
     "LA"
    ],
    "e": "🚶",
    "obs": ""
   },
   {
    "p": "FIO",
    "s": [
     "FI",
     "O"
    ],
    "e": "🧵",
    "obs": "V"
   },
   {
    "p": "FIVELA",
    "s": [
     "FI",
     "VE",
     "LA"
    ],
    "e": "🪢",
    "obs": ""
   },
   {
    "p": "FIGURA",
    "s": [
     "FI",
     "GU",
     "RA"
    ],
    "e": "🖼️",
    "obs": "r brando"
   }
  ],
  "FO": [
   {
    "p": "FOCA",
    "s": [
     "FO",
     "CA"
    ],
    "e": "🦭",
    "obs": ""
   },
   {
    "p": "FOGO",
    "s": [
     "FO",
     "GO"
    ],
    "e": "🔥",
    "obs": ""
   },
   {
    "p": "FOFO",
    "s": [
     "FO",
     "FO"
    ],
    "e": "🧸",
    "obs": ""
   },
   {
    "p": "FOME",
    "s": [
     "FO",
     "ME"
    ],
    "e": "🍽️",
    "obs": ""
   },
   {
    "p": "FONE",
    "s": [
     "FO",
     "NE"
    ],
    "e": "🎧",
    "obs": ""
   },
   {
    "p": "FOTO",
    "s": [
     "FO",
     "TO"
    ],
    "e": "📷",
    "obs": ""
   },
   {
    "p": "FOFOCA",
    "s": [
     "FO",
     "FO",
     "CA"
    ],
    "e": "🗣️",
    "obs": ""
   }
  ],
  "FU": [
   {
    "p": "FUBÁ",
    "s": [
     "FU",
     "BÁ"
    ],
    "e": "🌽",
    "obs": ""
   },
   {
    "p": "FURA",
    "s": [
     "FU",
     "RA"
    ],
    "e": "🕳️",
    "obs": "ação · r brando"
   }
  ],
  "JA": [
   {
    "p": "JATO",
    "s": [
     "JA",
     "TO"
    ],
    "e": "✈️",
    "obs": ""
   },
   {
    "p": "JACARÉ",
    "s": [
     "JA",
     "CA",
     "RÉ"
    ],
    "e": "🐊",
    "obs": ""
   },
   {
    "p": "JANELA",
    "s": [
     "JA",
     "NE",
     "LA"
    ],
    "e": "🪟",
    "obs": ""
   },
   {
    "p": "JABUTI",
    "s": [
     "JA",
     "BU",
     "TI"
    ],
    "e": "🐢",
    "obs": ""
   },
   {
    "p": "JAVALI",
    "s": [
     "JA",
     "VA",
     "LI"
    ],
    "e": "🐗",
    "obs": ""
   },
   {
    "p": "JACA",
    "s": [
     "JA",
     "CA"
    ],
    "e": "🥭",
    "obs": "novo · v3"
   }
  ],
  "JE": [
   {
    "p": "LAJE",
    "s": [
     "LA",
     "JE"
    ],
    "e": "🧱",
    "obs": "no meio"
   },
   {
    "p": "VIAJE",
    "s": [
     "VI",
     "A",
     "JE"
    ],
    "e": "✈️",
    "obs": "no meio · V"
   }
  ],
  "JI": [
   {
    "p": "JILÓ",
    "s": [
     "JI",
     "LÓ"
    ],
    "e": "🫑",
    "obs": ""
   }
  ],
  "JO": [
   {
    "p": "JOGO",
    "s": [
     "JO",
     "GO"
    ],
    "e": "🎮",
    "obs": ""
   },
   {
    "p": "JOGA",
    "s": [
     "JO",
     "GA"
    ],
    "e": "⚽",
    "obs": "ação"
   }
  ],
  "JU": [
   {
    "p": "JUBA",
    "s": [
     "JU",
     "BA"
    ],
    "e": "🦁",
    "obs": ""
   },
   {
    "p": "JUDÔ",
    "s": [
     "JU",
     "DÔ"
    ],
    "e": "🥋",
    "obs": ""
   },
   {
    "p": "JUCA",
    "s": [
     "JU",
     "CA"
    ],
    "e": "👦",
    "obs": "nome"
   },
   {
    "p": "JUJUBA",
    "s": [
     "JU",
     "JU",
     "BA"
    ],
    "e": "🍬",
    "obs": ""
   }
  ],
  "LA": [
   {
    "p": "LAGO",
    "s": [
     "LA",
     "GO"
    ],
    "e": "🏞️",
    "obs": ""
   },
   {
    "p": "LATA",
    "s": [
     "LA",
     "TA"
    ],
    "e": "🥫",
    "obs": ""
   },
   {
    "p": "LAMA",
    "s": [
     "LA",
     "MA"
    ],
    "e": "🟤",
    "obs": ""
   },
   {
    "p": "LADO",
    "s": [
     "LA",
     "DO"
    ],
    "e": "↔️",
    "obs": "abstrato"
   },
   {
    "p": "LAVA",
    "s": [
     "LA",
     "VA"
    ],
    "e": "🧼",
    "obs": "ação"
   },
   {
    "p": "LAJE",
    "s": [
     "LA",
     "JE"
    ],
    "e": "🧱",
    "obs": ""
   }
  ],
  "LE": [
   {
    "p": "LEME",
    "s": [
     "LE",
     "ME"
    ],
    "e": "🚢",
    "obs": "seu"
   },
   {
    "p": "LEVA",
    "s": [
     "LE",
     "VA"
    ],
    "e": "📦",
    "obs": "ação · seu"
   },
   {
    "p": "LEVE",
    "s": [
     "LE",
     "VE"
    ],
    "e": "🪶",
    "obs": ""
   },
   {
    "p": "LEGUME",
    "s": [
     "LE",
     "GU",
     "ME"
    ],
    "e": "🥕",
    "obs": ""
   }
  ],
  "LI": [
   {
    "p": "LIMA",
    "s": [
     "LI",
     "MA"
    ],
    "e": "🍋",
    "obs": ""
   },
   {
    "p": "LIGA",
    "s": [
     "LI",
     "GA"
    ],
    "e": "🔛",
    "obs": "ação"
   },
   {
    "p": "LIDA",
    "s": [
     "LI",
     "DA"
    ],
    "e": "💪",
    "obs": ""
   }
  ],
  "LO": [
   {
    "p": "LOBO",
    "s": [
     "LO",
     "BO"
    ],
    "e": "🐺",
    "obs": ""
   },
   {
    "p": "LOJA",
    "s": [
     "LO",
     "JA"
    ],
    "e": "🏪",
    "obs": ""
   },
   {
    "p": "LODO",
    "s": [
     "LO",
     "DO"
    ],
    "e": "🟩",
    "obs": ""
   }
  ],
  "LU": [
   {
    "p": "LULA",
    "s": [
     "LU",
     "LA"
    ],
    "e": "🦑",
    "obs": ""
   },
   {
    "p": "LUVA",
    "s": [
     "LU",
     "VA"
    ],
    "e": "🧤",
    "obs": ""
   },
   {
    "p": "LUPA",
    "s": [
     "LU",
     "PA"
    ],
    "e": "🔍",
    "obs": ""
   },
   {
    "p": "LUA",
    "s": [
     "LU",
     "A"
    ],
    "e": "🌙",
    "obs": "V"
   }
  ],
  "MA": [
   {
    "p": "MALA",
    "s": [
     "MA",
     "LA"
    ],
    "e": "🧳",
    "obs": ""
   },
   {
    "p": "MAPA",
    "s": [
     "MA",
     "PA"
    ],
    "e": "🗺️",
    "obs": ""
   },
   {
    "p": "MATO",
    "s": [
     "MA",
     "TO"
    ],
    "e": "🌿",
    "obs": ""
   },
   {
    "p": "MARÉ",
    "s": [
     "MA",
     "RÉ"
    ],
    "e": "🌊",
    "obs": "r brando"
   },
   {
    "p": "MACACO",
    "s": [
     "MA",
     "CA",
     "CO"
    ],
    "e": "🐒",
    "obs": ""
   },
   {
    "p": "MALUCO",
    "s": [
     "MA",
     "LU",
     "CO"
    ],
    "e": "🤪",
    "obs": ""
   },
   {
    "p": "MADURO",
    "s": [
     "MA",
     "DU",
     "RO"
    ],
    "e": "🍌",
    "obs": "r brando"
   },
   {
    "p": "MAROTO",
    "s": [
     "MA",
     "RO",
     "TO"
    ],
    "e": "😏",
    "obs": "r brando"
   },
   {
    "p": "MACIO",
    "s": [
     "MA",
     "CI",
     "O"
    ],
    "e": "🧸",
    "obs": "V"
   }
  ],
  "ME": [
   {
    "p": "MESA",
    "s": [
     "ME",
     "SA"
    ],
    "e": "🪑",
    "obs": "s=z"
   },
   {
    "p": "MEDO",
    "s": [
     "ME",
     "DO"
    ],
    "e": "😨",
    "obs": ""
   },
   {
    "p": "MENINA",
    "s": [
     "ME",
     "NI",
     "NA"
    ],
    "e": "👧",
    "obs": ""
   },
   {
    "p": "MENINO",
    "s": [
     "ME",
     "NI",
     "NO"
    ],
    "e": "👦",
    "obs": ""
   },
   {
    "p": "MELADO",
    "s": [
     "ME",
     "LA",
     "DO"
    ],
    "e": "🍯",
    "obs": ""
   },
   {
    "p": "METADE",
    "s": [
     "ME",
     "TA",
     "DE"
    ],
    "e": "➗",
    "obs": "abstrato"
   },
   {
    "p": "MEDIDA",
    "s": [
     "ME",
     "DI",
     "DA"
    ],
    "e": "📏",
    "obs": "abstrato"
   }
  ],
  "MI": [
   {
    "p": "MICO",
    "s": [
     "MI",
     "CO"
    ],
    "e": "🐒",
    "obs": ""
   },
   {
    "p": "MINUTO",
    "s": [
     "MI",
     "NU",
     "TO"
    ],
    "e": "⏱️",
    "obs": "abstrato"
   },
   {
    "p": "MIOLO",
    "s": [
     "MI",
     "O",
     "LO"
    ],
    "e": "🍞",
    "obs": "V"
   }
  ],
  "MO": [
   {
    "p": "MOTO",
    "s": [
     "MO",
     "TO"
    ],
    "e": "🏍️",
    "obs": ""
   },
   {
    "p": "MOLA",
    "s": [
     "MO",
     "LA"
    ],
    "e": "🌀",
    "obs": ""
   },
   {
    "p": "MODA",
    "s": [
     "MO",
     "DA"
    ],
    "e": "👗",
    "obs": ""
   },
   {
    "p": "MOLE",
    "s": [
     "MO",
     "LE"
    ],
    "e": "🍮",
    "obs": ""
   },
   {
    "p": "MODELO",
    "s": [
     "MO",
     "DE",
     "LO"
    ],
    "e": "👗",
    "obs": ""
   },
   {
    "p": "MOEDA",
    "s": [
     "MO",
     "E",
     "DA"
    ],
    "e": "🪙",
    "obs": "V"
   },
   {
    "p": "MÔNICA",
    "s": [
     "MÔ",
     "NI",
     "CA"
    ],
    "e": "🐰",
    "obs": "nome · acento na 1ª"
   }
  ],
  "MU": [
   {
    "p": "MULA",
    "s": [
     "MU",
     "LA"
    ],
    "e": "🫏",
    "obs": ""
   },
   {
    "p": "MURO",
    "s": [
     "MU",
     "RO"
    ],
    "e": "🧱",
    "obs": "r brando"
   },
   {
    "p": "MUDO",
    "s": [
     "MU",
     "DO"
    ],
    "e": "🤐",
    "obs": ""
   },
   {
    "p": "MUDA",
    "s": [
     "MU",
     "DA"
    ],
    "e": "🌱",
    "obs": ""
   },
   {
    "p": "MÚSICA",
    "s": [
     "MÚ",
     "SI",
     "CA"
    ],
    "e": "🎵",
    "obs": "s=z · acento na 1ª"
   }
  ],
  "NA": [
   {
    "p": "NABO",
    "s": [
     "NA",
     "BO"
    ],
    "e": "🥬",
    "obs": ""
   },
   {
    "p": "NADA",
    "s": [
     "NA",
     "DA"
    ],
    "e": "🏊",
    "obs": "ação"
   },
   {
    "p": "NAVE",
    "s": [
     "NA",
     "VE"
    ],
    "e": "🚀",
    "obs": ""
   },
   {
    "p": "NATA",
    "s": [
     "NA",
     "TA"
    ],
    "e": "🥛",
    "obs": ""
   },
   {
    "p": "NAVIO",
    "s": [
     "NA",
     "VI",
     "O"
    ],
    "e": "🚢",
    "obs": "V"
   }
  ],
  "NE": [
   {
    "p": "NENÊ",
    "s": [
     "NE",
     "NÊ"
    ],
    "e": "👶",
    "obs": ""
   },
   {
    "p": "NETO",
    "s": [
     "NE",
     "TO"
    ],
    "e": "👦",
    "obs": ""
   },
   {
    "p": "NETA",
    "s": [
     "NE",
     "TA"
    ],
    "e": "👧",
    "obs": ""
   },
   {
    "p": "NEVE",
    "s": [
     "NE",
     "VE"
    ],
    "e": "❄️",
    "obs": ""
   }
  ],
  "NI": [
   {
    "p": "NINA",
    "s": [
     "NI",
     "NA"
    ],
    "e": "👶",
    "obs": "nome / ação"
   },
   {
    "p": "PENICO",
    "s": [
     "PE",
     "NI",
     "CO"
    ],
    "e": "🚽",
    "obs": "no meio"
   },
   {
    "p": "MENINA",
    "s": [
     "ME",
     "NI",
     "NA"
    ],
    "e": "👧",
    "obs": "no meio"
   },
   {
    "p": "MENINO",
    "s": [
     "ME",
     "NI",
     "NO"
    ],
    "e": "👦",
    "obs": "no meio"
   },
   {
    "p": "BONITO",
    "s": [
     "BO",
     "NI",
     "TO"
    ],
    "e": "🌻",
    "obs": "no meio"
   },
   {
    "p": "MÔNICA",
    "s": [
     "MÔ",
     "NI",
     "CA"
    ],
    "e": "🐰",
    "obs": "no meio"
   }
  ],
  "NO": [
   {
    "p": "NOVE",
    "s": [
     "NO",
     "VE"
    ],
    "e": "9️⃣",
    "obs": ""
   },
   {
    "p": "NOME",
    "s": [
     "NO",
     "ME"
    ],
    "e": "🏷️",
    "obs": "abstrato"
   },
   {
    "p": "NOVA",
    "s": [
     "NO",
     "VA"
    ],
    "e": "✨",
    "obs": ""
   },
   {
    "p": "NOVELO",
    "s": [
     "NO",
     "VE",
     "LO"
    ],
    "e": "🧶",
    "obs": ""
   }
  ],
  "NU": [
   {
    "p": "NUCA",
    "s": [
     "NU",
     "CA"
    ],
    "e": "💆",
    "obs": ""
   },
   {
    "p": "NÚMERO",
    "s": [
     "NÚ",
     "ME",
     "RO"
    ],
    "e": "🔢",
    "obs": "r brando · acento na 1ª"
   }
  ],
  "PA": [
   {
    "p": "PATO",
    "s": [
     "PA",
     "TO"
    ],
    "e": "🦆",
    "obs": ""
   },
   {
    "p": "PATA",
    "s": [
     "PA",
     "TA"
    ],
    "e": "🐾",
    "obs": ""
   },
   {
    "p": "PANO",
    "s": [
     "PA",
     "NO"
    ],
    "e": "🧻",
    "obs": ""
   },
   {
    "p": "TAPA",
    "s": [
     "TA",
     "PA"
    ],
    "e": "✋",
    "obs": "ação"
   },
   {
    "p": "PANELA",
    "s": [
     "PA",
     "NE",
     "LA"
    ],
    "e": "🍳",
    "obs": ""
   },
   {
    "p": "PALITO",
    "s": [
     "PA",
     "LI",
     "TO"
    ],
    "e": "🪵",
    "obs": ""
   },
   {
    "p": "PAREDE",
    "s": [
     "PA",
     "RE",
     "DE"
    ],
    "e": "🧱",
    "obs": "r brando"
   },
   {
    "p": "PACOTE",
    "s": [
     "PA",
     "CO",
     "TE"
    ],
    "e": "📦",
    "obs": ""
   }
  ],
  "PE": [
   {
    "p": "PENA",
    "s": [
     "PE",
     "NA"
    ],
    "e": "🪶",
    "obs": ""
   },
   {
    "p": "PERA",
    "s": [
     "PE",
     "RA"
    ],
    "e": "🍐",
    "obs": "r brando"
   },
   {
    "p": "PELE",
    "s": [
     "PE",
     "LE"
    ],
    "e": "🖐️",
    "obs": ""
   },
   {
    "p": "PERU",
    "s": [
     "PE",
     "RU"
    ],
    "e": "🦃",
    "obs": "r brando"
   },
   {
    "p": "PEPINO",
    "s": [
     "PE",
     "PI",
     "NO"
    ],
    "e": "🥒",
    "obs": ""
   },
   {
    "p": "PERUCA",
    "s": [
     "PE",
     "RU",
     "CA"
    ],
    "e": "💇",
    "obs": "r brando"
   },
   {
    "p": "PENICO",
    "s": [
     "PE",
     "NI",
     "CO"
    ],
    "e": "🚽",
    "obs": ""
   },
   {
    "p": "PEDIDO",
    "s": [
     "PE",
     "DI",
     "DO"
    ],
    "e": "🙏",
    "obs": ""
   }
  ],
  "PI": [
   {
    "p": "PIPA",
    "s": [
     "PI",
     "PA"
    ],
    "e": "🪁",
    "obs": ""
   },
   {
    "p": "PIPOCA",
    "s": [
     "PI",
     "PO",
     "CA"
    ],
    "e": "🍿",
    "obs": ""
   },
   {
    "p": "PICOLÉ",
    "s": [
     "PI",
     "CO",
     "LÉ"
    ],
    "e": "🍦",
    "obs": ""
   },
   {
    "p": "PIRATA",
    "s": [
     "PI",
     "RA",
     "TA"
    ],
    "e": "🏴‍☠️",
    "obs": "r brando"
   },
   {
    "p": "PIJAMA",
    "s": [
     "PI",
     "JA",
     "MA"
    ],
    "e": "🩱",
    "obs": ""
   },
   {
    "p": "PISO",
    "s": [
     "PI",
     "SO"
    ],
    "e": "🟫",
    "obs": "novo · v3"
   }
  ],
  "PO": [
   {
    "p": "POTE",
    "s": [
     "PO",
     "TE"
    ],
    "e": "🫙",
    "obs": ""
   },
   {
    "p": "POVO",
    "s": [
     "PO",
     "VO"
    ],
    "e": "👨‍👩‍👧‍👦",
    "obs": "abstrato"
   },
   {
    "p": "POMADA",
    "s": [
     "PO",
     "MA",
     "DA"
    ],
    "e": "🧴",
    "obs": ""
   }
  ],
  "PU": [
   {
    "p": "PULA",
    "s": [
     "PU",
     "LA"
    ],
    "e": "🤸",
    "obs": "ação"
   },
   {
    "p": "PULO",
    "s": [
     "PU",
     "LO"
    ],
    "e": "🦘",
    "obs": ""
   },
   {
    "p": "PURÊ",
    "s": [
     "PU",
     "RÊ"
    ],
    "e": "🥔",
    "obs": "r brando"
   },
   {
    "p": "PUMA",
    "s": [
     "PU",
     "MA"
    ],
    "e": "🐆",
    "obs": "novo · v3"
   }
  ],
  "SA": [
   {
    "p": "SAPO",
    "s": [
     "SA",
     "PO"
    ],
    "e": "🐸",
    "obs": ""
   },
   {
    "p": "SACO",
    "s": [
     "SA",
     "CO"
    ],
    "e": "🛍️",
    "obs": ""
   },
   {
    "p": "SALA",
    "s": [
     "SA",
     "LA"
    ],
    "e": "🛋️",
    "obs": ""
   },
   {
    "p": "SALADA",
    "s": [
     "SA",
     "LA",
     "DA"
    ],
    "e": "🥗",
    "obs": ""
   },
   {
    "p": "SAPATO",
    "s": [
     "SA",
     "PA",
     "TO"
    ],
    "e": "👞",
    "obs": ""
   }
  ],
  "SE": [
   {
    "p": "SETE",
    "s": [
     "SE",
     "TE"
    ],
    "e": "7️⃣",
    "obs": ""
   },
   {
    "p": "SELO",
    "s": [
     "SE",
     "LO"
    ],
    "e": "📮",
    "obs": ""
   },
   {
    "p": "SEDE",
    "s": [
     "SE",
     "DE"
    ],
    "e": "🥵",
    "obs": ""
   },
   {
    "p": "SEDA",
    "s": [
     "SE",
     "DA"
    ],
    "e": "🧣",
    "obs": ""
   },
   {
    "p": "SEMANA",
    "s": [
     "SE",
     "MA",
     "NA"
    ],
    "e": "📆",
    "obs": "abstrato"
   }
  ],
  "SI": [
   {
    "p": "SINO",
    "s": [
     "SI",
     "NO"
    ],
    "e": "🔔",
    "obs": ""
   },
   {
    "p": "SIRENE",
    "s": [
     "SI",
     "RE",
     "NE"
    ],
    "e": "🚨",
    "obs": "r brando"
   },
   {
    "p": "SIRI",
    "s": [
     "SI",
     "RI"
    ],
    "e": "🦀",
    "obs": "novo · v3"
   }
  ],
  "SO": [
   {
    "p": "SOFÁ",
    "s": [
     "SO",
     "FÁ"
    ],
    "e": "🛋️",
    "obs": ""
   },
   {
    "p": "SOPA",
    "s": [
     "SO",
     "PA"
    ],
    "e": "🍲",
    "obs": ""
   },
   {
    "p": "SOCO",
    "s": [
     "SO",
     "CO"
    ],
    "e": "👊",
    "obs": ""
   },
   {
    "p": "SOMA",
    "s": [
     "SO",
     "MA"
    ],
    "e": "➕",
    "obs": "abstrato"
   },
   {
    "p": "SONO",
    "s": [
     "SO",
     "NO"
    ],
    "e": "😴",
    "obs": "novo · v3"
   }
  ],
  "SU": [
   {
    "p": "SUCO",
    "s": [
     "SU",
     "CO"
    ],
    "e": "🧃",
    "obs": ""
   },
   {
    "p": "SUJO",
    "s": [
     "SU",
     "JO"
    ],
    "e": "🫧",
    "obs": ""
   }
  ],
  "TA": [
   {
    "p": "TATU",
    "s": [
     "TA",
     "TU"
    ],
    "e": "🦔",
    "obs": ""
   },
   {
    "p": "TAPA",
    "s": [
     "TA",
     "PA"
    ],
    "e": "✋",
    "obs": ""
   },
   {
    "p": "TAPETE",
    "s": [
     "TA",
     "PE",
     "TE"
    ],
    "e": "🧶",
    "obs": ""
   },
   {
    "p": "TAREFA",
    "s": [
     "TA",
     "RE",
     "FA"
    ],
    "e": "📝",
    "obs": "r brando"
   }
  ],
  "TE": [
   {
    "p": "TETO",
    "s": [
     "TE",
     "TO"
    ],
    "e": "🏠",
    "obs": ""
   },
   {
    "p": "TELA",
    "s": [
     "TE",
     "LA"
    ],
    "e": "📺",
    "obs": ""
   },
   {
    "p": "TECIDO",
    "s": [
     "TE",
     "CI",
     "DO"
    ],
    "e": "🧵",
    "obs": ""
   }
  ],
  "TI": [
   {
    "p": "TIME",
    "s": [
     "TI",
     "ME"
    ],
    "e": "⚽",
    "obs": ""
   },
   {
    "p": "TIA",
    "s": [
     "TI",
     "A"
    ],
    "e": "👩",
    "obs": "V"
   },
   {
    "p": "TIO",
    "s": [
     "TI",
     "O"
    ],
    "e": "👨",
    "obs": "V"
   },
   {
    "p": "TIGELA",
    "s": [
     "TI",
     "GE",
     "LA"
    ],
    "e": "🥣",
    "obs": ""
   },
   {
    "p": "TIJOLO",
    "s": [
     "TI",
     "JO",
     "LO"
    ],
    "e": "🧱",
    "obs": ""
   }
  ],
  "TO": [
   {
    "p": "TOCA",
    "s": [
     "TO",
     "CA"
    ],
    "e": "🕳️",
    "obs": ""
   },
   {
    "p": "TOMATE",
    "s": [
     "TO",
     "MA",
     "TE"
    ],
    "e": "🍅",
    "obs": ""
   },
   {
    "p": "TOMADA",
    "s": [
     "TO",
     "MA",
     "DA"
    ],
    "e": "🔌",
    "obs": ""
   },
   {
    "p": "TOPETE",
    "s": [
     "TO",
     "PE",
     "TE"
    ],
    "e": "💇",
    "obs": ""
   }
  ],
  "TU": [
   {
    "p": "TUBO",
    "s": [
     "TU",
     "BO"
    ],
    "e": "🧪",
    "obs": ""
   },
   {
    "p": "TUCANO",
    "s": [
     "TU",
     "CA",
     "NO"
    ],
    "e": "🦜",
    "obs": ""
   },
   {
    "p": "TULIPA",
    "s": [
     "TU",
     "LI",
     "PA"
    ],
    "e": "🌷",
    "obs": ""
   }
  ],
  "VA": [
   {
    "p": "VACA",
    "s": [
     "VA",
     "CA"
    ],
    "e": "🐄",
    "obs": ""
   },
   {
    "p": "VASO",
    "s": [
     "VA",
     "SO"
    ],
    "e": "🏺",
    "obs": "s=z"
   },
   {
    "p": "VARETA",
    "s": [
     "VA",
     "RE",
     "TA"
    ],
    "e": "🪄",
    "obs": "r brando"
   },
   {
    "p": "VARA",
    "s": [
     "VA",
     "RA"
    ],
    "e": "🎣",
    "obs": "novo · v3"
   }
  ],
  "VE": [
   {
    "p": "VELA",
    "s": [
     "VE",
     "LA"
    ],
    "e": "🕯️",
    "obs": ""
   },
   {
    "p": "VELUDO",
    "s": [
     "VE",
     "LU",
     "DO"
    ],
    "e": "🧸",
    "obs": ""
   }
  ],
  "VI": [
   {
    "p": "VILA",
    "s": [
     "VI",
     "LA"
    ],
    "e": "🏘️",
    "obs": ""
   },
   {
    "p": "VIDA",
    "s": [
     "VI",
     "DA"
    ],
    "e": "🌱",
    "obs": "abstrato"
   },
   {
    "p": "VIRA",
    "s": [
     "VI",
     "RA"
    ],
    "e": "🔃",
    "obs": "ação · r brando"
   },
   {
    "p": "VIOLA",
    "s": [
     "VI",
     "O",
     "LA"
    ],
    "e": "🎻",
    "obs": "V"
   },
   {
    "p": "VIAJE",
    "s": [
     "VI",
     "A",
     "JE"
    ],
    "e": "✈️",
    "obs": "V"
   }
  ],
  "VO": [
   {
    "p": "VOVÔ",
    "s": [
     "VO",
     "VÔ"
    ],
    "e": "👴",
    "obs": ""
   },
   {
    "p": "VOVÓ",
    "s": [
     "VO",
     "VÓ"
    ],
    "e": "👵",
    "obs": ""
   },
   {
    "p": "VOA",
    "s": [
     "VO",
     "A"
    ],
    "e": "🕊️",
    "obs": "V · ação"
   }
  ],
  "ZA": [
   {
    "p": "BELEZA",
    "s": [
     "BE",
     "LE",
     "ZA"
    ],
    "e": "💅",
    "obs": "no meio"
   }
  ],
  "ZE": [
   {
    "p": "ZERO",
    "s": [
     "ZE",
     "RO"
    ],
    "e": "0️⃣",
    "obs": "r brando"
   },
   {
    "p": "DEZENA",
    "s": [
     "DE",
     "ZE",
     "NA"
    ],
    "e": "🔟",
    "obs": "no meio"
   },
   {
    "p": "ZEBU",
    "s": [
     "ZE",
     "BU"
    ],
    "e": "🐂",
    "obs": "novo · v3"
   }
  ],
  "ZI": [
   {
    "p": "BUZINA",
    "s": [
     "BU",
     "ZI",
     "NA"
    ],
    "e": "📢",
    "obs": "no meio"
   },
   {
    "p": "COZIDO",
    "s": [
     "CO",
     "ZI",
     "DO"
    ],
    "e": "🍲",
    "obs": "no meio"
   }
  ],
  "CA": [
   {
    "p": "CASA",
    "s": [
     "CA",
     "SA"
    ],
    "e": "🏠",
    "obs": "s=z"
   },
   {
    "p": "CAMA",
    "s": [
     "CA",
     "MA"
    ],
    "e": "🛏️",
    "obs": ""
   },
   {
    "p": "CAFÉ",
    "s": [
     "CA",
     "FÉ"
    ],
    "e": "☕",
    "obs": ""
   },
   {
    "p": "CAPA",
    "s": [
     "CA",
     "PA"
    ],
    "e": "🦸",
    "obs": ""
   },
   {
    "p": "CACO",
    "s": [
     "CA",
     "CO"
    ],
    "e": "🧩",
    "obs": ""
   },
   {
    "p": "CAJU",
    "s": [
     "CA",
     "JU"
    ],
    "e": "🥭",
    "obs": ""
   },
   {
    "p": "CANECA",
    "s": [
     "CA",
     "NE",
     "CA"
    ],
    "e": "🥛",
    "obs": ""
   },
   {
    "p": "CANETA",
    "s": [
     "CA",
     "NE",
     "TA"
    ],
    "e": "🖊️",
    "obs": ""
   },
   {
    "p": "CABIDE",
    "s": [
     "CA",
     "BI",
     "DE"
    ],
    "e": "🧷",
    "obs": ""
   },
   {
    "p": "CAVALO",
    "s": [
     "CA",
     "VA",
     "LO"
    ],
    "e": "🐴",
    "obs": ""
   },
   {
    "p": "CAMISA",
    "s": [
     "CA",
     "MI",
     "SA"
    ],
    "e": "👕",
    "obs": "s=z"
   },
   {
    "p": "CANUDO",
    "s": [
     "CA",
     "NU",
     "DO"
    ],
    "e": "🥤",
    "obs": ""
   },
   {
    "p": "CADELA",
    "s": [
     "CA",
     "DE",
     "LA"
    ],
    "e": "🐕",
    "obs": ""
   },
   {
    "p": "CAMELO",
    "s": [
     "CA",
     "ME",
     "LO"
    ],
    "e": "🐫",
    "obs": ""
   },
   {
    "p": "CABANA",
    "s": [
     "CA",
     "BA",
     "NA"
    ],
    "e": "🛖",
    "obs": ""
   },
   {
    "p": "CARETA",
    "s": [
     "CA",
     "RE",
     "TA"
    ],
    "e": "😝",
    "obs": "r brando"
   },
   {
    "p": "CARA",
    "s": [
     "CA",
     "RA"
    ],
    "e": "🙂",
    "obs": "r brando"
   }
  ],
  "CO": [
   {
    "p": "COCO",
    "s": [
     "CO",
     "CO"
    ],
    "e": "🥥",
    "obs": ""
   },
   {
    "p": "COLA",
    "s": [
     "CO",
     "LA"
    ],
    "e": "🧴",
    "obs": ""
   },
   {
    "p": "COPO",
    "s": [
     "CO",
     "PO"
    ],
    "e": "🥤",
    "obs": ""
   },
   {
    "p": "COVA",
    "s": [
     "CO",
     "VA"
    ],
    "e": "🕳️",
    "obs": ""
   },
   {
    "p": "COMIDA",
    "s": [
     "CO",
     "MI",
     "DA"
    ],
    "e": "🍽️",
    "obs": ""
   },
   {
    "p": "COMETA",
    "s": [
     "CO",
     "ME",
     "TA"
    ],
    "e": "☄️",
    "obs": ""
   },
   {
    "p": "COLEGA",
    "s": [
     "CO",
     "LE",
     "GA"
    ],
    "e": "🧑‍🤝‍🧑",
    "obs": ""
   },
   {
    "p": "COZIDO",
    "s": [
     "CO",
     "ZI",
     "DO"
    ],
    "e": "🍲",
    "obs": ""
   },
   {
    "p": "CORUJA",
    "s": [
     "CO",
     "RU",
     "JA"
    ],
    "e": "🦉",
    "obs": "r brando"
   },
   {
    "p": "COROA",
    "s": [
     "CO",
     "RO",
     "A"
    ],
    "e": "👑",
    "obs": "V · r brando"
   },
   {
    "p": "CONE",
    "s": [
     "CO",
     "NE"
    ],
    "e": "🚧",
    "obs": "novo · v3"
   }
  ],
  "CU": [
   {
    "p": "CUBO",
    "s": [
     "CU",
     "BO"
    ],
    "e": "🧊",
    "obs": ""
   },
   {
    "p": "CUCA",
    "s": [
     "CU",
     "CA"
    ],
    "e": "🍰",
    "obs": ""
   },
   {
    "p": "CUTUCA",
    "s": [
     "CU",
     "TU",
     "CA"
    ],
    "e": "👉",
    "obs": "ação"
   },
   {
    "p": "CUECA",
    "s": [
     "CU",
     "E",
     "CA"
    ],
    "e": "🩲",
    "obs": "V"
   }
  ],
  "GA": [
   {
    "p": "GATO",
    "s": [
     "GA",
     "TO"
    ],
    "e": "🐱",
    "obs": ""
   },
   {
    "p": "GALO",
    "s": [
     "GA",
     "LO"
    ],
    "e": "🐓",
    "obs": ""
   },
   {
    "p": "GADO",
    "s": [
     "GA",
     "DO"
    ],
    "e": "🐄",
    "obs": ""
   },
   {
    "p": "GAVETA",
    "s": [
     "GA",
     "VE",
     "TA"
    ],
    "e": "🗄️",
    "obs": ""
   },
   {
    "p": "GALOPE",
    "s": [
     "GA",
     "LO",
     "PE"
    ],
    "e": "🐎",
    "obs": ""
   },
   {
    "p": "GAROTA",
    "s": [
     "GA",
     "RO",
     "TA"
    ],
    "e": "👧",
    "obs": "r brando"
   },
   {
    "p": "GAROTO",
    "s": [
     "GA",
     "RO",
     "TO"
    ],
    "e": "👦",
    "obs": "r brando"
   },
   {
    "p": "GARI",
    "s": [
     "GA",
     "RI"
    ],
    "e": "🧹",
    "obs": "novo · v3"
   },
   {
    "p": "GATA",
    "s": [
     "GA",
     "TA"
    ],
    "e": "🐈",
    "obs": "novo · v3"
   }
  ],
  "GO": [
   {
    "p": "GOTA",
    "s": [
     "GO",
     "TA"
    ],
    "e": "💧",
    "obs": ""
   },
   {
    "p": "GOLA",
    "s": [
     "GO",
     "LA"
    ],
    "e": "👔",
    "obs": ""
   },
   {
    "p": "GOMA",
    "s": [
     "GO",
     "MA"
    ],
    "e": "🍬",
    "obs": ""
   }
  ],
  "GU": [
   {
    "p": "GUDE",
    "s": [
     "GU",
     "DE"
    ],
    "e": "🔮",
    "obs": ""
   },
   {
    "p": "GULOSO",
    "s": [
     "GU",
     "LO",
     "SO"
    ],
    "e": "😋",
    "obs": "s=z"
   }
  ],
  "CE": [
   {
    "p": "CEBOLA",
    "s": [
     "CE",
     "BO",
     "LA"
    ],
    "e": "🧅",
    "obs": ""
   },
   {
    "p": "CERA",
    "s": [
     "CE",
     "RA"
    ],
    "e": "🕯️",
    "obs": "r brando"
   },
   {
    "p": "CEDO",
    "s": [
     "CE",
     "DO"
    ],
    "e": "⏰",
    "obs": "abstrato"
   },
   {
    "p": "CEGO",
    "s": [
     "CE",
     "GO"
    ],
    "e": "🦯",
    "obs": ""
   }
  ],
  "CI": [
   {
    "p": "CIDADE",
    "s": [
     "CI",
     "DA",
     "DE"
    ],
    "e": "🏙️",
    "obs": ""
   },
   {
    "p": "CINEMA",
    "s": [
     "CI",
     "NE",
     "MA"
    ],
    "e": "🎬",
    "obs": ""
   },
   {
    "p": "CIPÓ",
    "s": [
     "CI",
     "PÓ"
    ],
    "e": "🌿",
    "obs": ""
   },
   {
    "p": "CIMA",
    "s": [
     "CI",
     "MA"
    ],
    "e": "⬆️",
    "obs": "abstrato"
   }
  ],
  "GE": [
   {
    "p": "GELO",
    "s": [
     "GE",
     "LO"
    ],
    "e": "🧊",
    "obs": ""
   },
   {
    "p": "GEMA",
    "s": [
     "GE",
     "MA"
    ],
    "e": "🥚",
    "obs": ""
   },
   {
    "p": "GELADO",
    "s": [
     "GE",
     "LA",
     "DO"
    ],
    "e": "🍦",
    "obs": ""
   }
  ],
  "GI": [
   {
    "p": "GIBI",
    "s": [
     "GI",
     "BI"
    ],
    "e": "📖",
    "obs": ""
   },
   {
    "p": "GIRA",
    "s": [
     "GI",
     "RA"
    ],
    "e": "🔄",
    "obs": "ação · r forte"
   },
   {
    "p": "GIRAFA",
    "s": [
     "GI",
     "RA",
     "FA"
    ],
    "e": "🦒",
    "obs": "r forte"
   }
  ],
  "RA": [
   {
    "p": "RATO",
    "s": [
     "RA",
     "TO"
    ],
    "e": "🐭",
    "obs": "R forte"
   },
   {
    "p": "RABO",
    "s": [
     "RA",
     "BO"
    ],
    "e": "🐕",
    "obs": "R forte"
   },
   {
    "p": "RAMO",
    "s": [
     "RA",
     "MO"
    ],
    "e": "🌿",
    "obs": "R forte"
   },
   {
    "p": "RAPOSA",
    "s": [
     "RA",
     "PO",
     "SA"
    ],
    "e": "🦊",
    "obs": "R forte · s=z"
   },
   {
    "p": "RALO",
    "s": [
     "RA",
     "LO"
    ],
    "e": "🕳️",
    "obs": "novo · v3"
   }
  ],
  "RE": [
   {
    "p": "REDE",
    "s": [
     "RE",
     "DE"
    ],
    "e": "🕸️",
    "obs": "R forte"
   },
   {
    "p": "REMO",
    "s": [
     "RE",
     "MO"
    ],
    "e": "🚣",
    "obs": "R forte"
   },
   {
    "p": "REGA",
    "s": [
     "RE",
     "GA"
    ],
    "e": "🚿",
    "obs": "R forte · ação"
   },
   {
    "p": "RECADO",
    "s": [
     "RE",
     "CA",
     "DO"
    ],
    "e": "💬",
    "obs": "R forte"
   }
  ],
  "RI": [
   {
    "p": "RICO",
    "s": [
     "RI",
     "CO"
    ],
    "e": "💰",
    "obs": "R forte"
   },
   {
    "p": "RIMA",
    "s": [
     "RI",
     "MA"
    ],
    "e": "🎵",
    "obs": "R forte"
   },
   {
    "p": "RIO",
    "s": [
     "RI",
     "O"
    ],
    "e": "🏞️",
    "obs": "R forte · V"
   },
   {
    "p": "RISADA",
    "s": [
     "RI",
     "SA",
     "DA"
    ],
    "e": "😄",
    "obs": "R forte · s=z"
   }
  ],
  "RO": [
   {
    "p": "ROBÔ",
    "s": [
     "RO",
     "BÔ"
    ],
    "e": "🤖",
    "obs": "R forte"
   },
   {
    "p": "ROSA",
    "s": [
     "RO",
     "SA"
    ],
    "e": "🌹",
    "obs": "R forte · s=z"
   },
   {
    "p": "RODA",
    "s": [
     "RO",
     "DA"
    ],
    "e": "🛞",
    "obs": "R forte"
   },
   {
    "p": "ROLO",
    "s": [
     "RO",
     "LO"
    ],
    "e": "🧻",
    "obs": "R forte"
   },
   {
    "p": "RODELA",
    "s": [
     "RO",
     "DE",
     "LA"
    ],
    "e": "🍅",
    "obs": "R forte"
   }
  ],
  "RU": [
   {
    "p": "RUA",
    "s": [
     "RU",
     "A"
    ],
    "e": "🛣️",
    "obs": "R forte · V"
   },
   {
    "p": "PERU",
    "s": [
     "PE",
     "RU"
    ],
    "e": "🦃",
    "obs": "no meio · r brando"
   },
   {
    "p": "CORUJA",
    "s": [
     "CO",
     "RU",
     "JA"
    ],
    "e": "🦉",
    "obs": "no meio · r brando"
   },
   {
    "p": "PERUCA",
    "s": [
     "PE",
     "RU",
     "CA"
    ],
    "e": "💇",
    "obs": "no meio · r brando"
   },
   {
    "p": "MARUJO",
    "s": [
     "MA",
     "RU",
     "JO"
    ],
    "e": "⚓",
    "obs": "no meio · r brando"
   }
  ]
 },
 "aceitaveis": {
  "Sílaba só de vogal (V) — a mais simples que existe": [
   {
    "p": "LUA",
    "s": [
     "LU",
     "A"
    ],
    "e": "🌙"
   },
   {
    "p": "RUA",
    "s": [
     "RU",
     "A"
    ],
    "e": "🛣️"
   },
   {
    "p": "TIA",
    "s": [
     "TI",
     "A"
    ],
    "e": "👩"
   },
   {
    "p": "TIO",
    "s": [
     "TI",
     "O"
    ],
    "e": "👨"
   },
   {
    "p": "DIA",
    "s": [
     "DI",
     "A"
    ],
    "e": "☀️"
   },
   {
    "p": "FIO",
    "s": [
     "FI",
     "O"
    ],
    "e": "🧵"
   },
   {
    "p": "RIO",
    "s": [
     "RI",
     "O"
    ],
    "e": "🏞️"
   },
   {
    "p": "VOA",
    "s": [
     "VO",
     "A"
    ],
    "e": "🕊️"
   },
   {
    "p": "NAVIO",
    "s": [
     "NA",
     "VI",
     "O"
    ],
    "e": "🚢"
   },
   {
    "p": "VIOLA",
    "s": [
     "VI",
     "O",
     "LA"
    ],
    "e": "🎻"
   },
   {
    "p": "CUECA",
    "s": [
     "CU",
     "E",
     "CA"
    ],
    "e": "🩲"
   },
   {
    "p": "MOEDA",
    "s": [
     "MO",
     "E",
     "DA"
    ],
    "e": "🪙"
   },
   {
    "p": "COROA",
    "s": [
     "CO",
     "RO",
     "A"
    ],
    "e": "👑"
   },
   {
    "p": "MIOLO",
    "s": [
     "MI",
     "O",
     "LO"
    ],
    "e": "🍞"
   },
   {
    "p": "DUELO",
    "s": [
     "DU",
     "E",
     "LO"
    ],
    "e": "⚔️"
   },
   {
    "p": "FATIA",
    "s": [
     "FA",
     "TI",
     "A"
    ],
    "e": "🍕"
   },
   {
    "p": "MACIO",
    "s": [
     "MA",
     "CI",
     "O"
    ],
    "e": "🧸"
   },
   {
    "p": "VIAJE",
    "s": [
     "VI",
     "A",
     "JE"
    ],
    "e": "✈️"
   }
  ],
  "Letra X (som /ʃ/, como CH)": [
   {
    "p": "LIXO",
    "s": [
     "LI",
     "XO"
    ],
    "e": "🗑️"
   },
   {
    "p": "LIXA",
    "s": [
     "LI",
     "XA"
    ],
    "e": "🪵"
   },
   {
    "p": "PUXA",
    "s": [
     "PU",
     "XA"
    ],
    "e": "🪢"
   },
   {
    "p": "ROXO",
    "s": [
     "RO",
     "XO"
    ],
    "e": "🟣"
   },
   {
    "p": "XÍCARA",
    "s": [
     "XÍ",
     "CA",
     "RA"
    ],
    "e": "☕"
   },
   {
    "p": "COXA",
    "s": [
     "CO",
     "XA"
    ],
    "e": "🍗"
   }
  ],
  "Ditongo — duas vogais na mesma sílaba": [
   {
    "p": "PAPAI",
    "s": [
     "PA",
     "PAI"
    ],
    "e": "👨"
   },
   {
    "p": "BOI",
    "s": [
     "BOI"
    ],
    "e": "🐂"
   },
   {
    "p": "MEIA",
    "s": [
     "MEI",
     "A"
    ],
    "e": "🧦"
   },
   {
    "p": "LEITE",
    "s": [
     "LEI",
     "TE"
    ],
    "e": "🥛"
   },
   {
    "p": "BALEIA",
    "s": [
     "BA",
     "LEI",
     "A"
    ],
    "e": "🐋"
   },
   {
    "p": "VOVÔ E VOVÓ",
    "s": [
     "—"
    ],
    "e": "👵"
   },
   {
    "p": "CADEIRA",
    "s": [
     "CA",
     "DEI",
     "RA"
    ],
    "e": "🪑"
   },
   {
    "p": "PEIXE",
    "s": [
     "PEI",
     "XE"
    ],
    "e": "🐟"
   },
   {
    "p": "CENOURA",
    "s": [
     "CE",
     "NOU",
     "RA"
    ],
    "e": "🥕"
   },
   {
    "p": "GOIABA",
    "s": [
     "GOI",
     "A",
     "BA"
    ],
    "e": "🍐"
   }
  ],
  "Vogal nasal Ã / ÃO": [
   {
    "p": "MAMÃE",
    "s": [
     "MA",
     "MÃE"
    ],
    "e": "👩"
   },
   {
    "p": "BALÃO",
    "s": [
     "BA",
     "LÃO"
    ],
    "e": "🎈"
   },
   {
    "p": "LIMÃO",
    "s": [
     "LI",
     "MÃO"
    ],
    "e": "🍋"
   },
   {
    "p": "MELÃO",
    "s": [
     "ME",
     "LÃO"
    ],
    "e": "🍈"
   },
   {
    "p": "SABÃO",
    "s": [
     "SA",
     "BÃO"
    ],
    "e": "🧼"
   },
   {
    "p": "PÃO",
    "s": [
     "PÃO"
    ],
    "e": "🍞"
   },
   {
    "p": "LEÃO",
    "s": [
     "LE",
     "ÃO"
    ],
    "e": "🦁"
   },
   {
    "p": "MAÇÃ",
    "s": [
     "MA",
     "ÇÃ"
    ],
    "e": "🍎"
   },
   {
    "p": "IRMÃO",
    "s": [
     "IR",
     "MÃO"
    ],
    "e": "👦"
   },
   {
    "p": "CORAÇÃO",
    "s": [
     "CO",
     "RA",
     "ÇÃO"
    ],
    "e": "❤️"
   }
  ],
  "100% CV, mas com 4 sílabas": [
   {
    "p": "TELEFONE",
    "s": [
     "TE",
     "LE",
     "FO",
     "NE"
    ],
    "e": "☎️"
   },
   {
    "p": "PIRULITO",
    "s": [
     "PI",
     "RU",
     "LI",
     "TO"
    ],
    "e": "🍭"
   },
   {
    "p": "CAPIVARA",
    "s": [
     "CA",
     "PI",
     "VA",
     "RA"
    ],
    "e": "🦫"
   },
   {
    "p": "MARIPOSA",
    "s": [
     "MA",
     "RI",
     "PO",
     "SA"
    ],
    "e": "🦋"
   },
   {
    "p": "COTOVELO",
    "s": [
     "CO",
     "TO",
     "VE",
     "LO"
    ],
    "e": "💪"
   },
   {
    "p": "PARAFUSO",
    "s": [
     "PA",
     "RA",
     "FU",
     "SO"
    ],
    "e": "🔩"
   },
   {
    "p": "CANIVETE",
    "s": [
     "CA",
     "NI",
     "VE",
     "TE"
    ],
    "e": "🔪"
   },
   {
    "p": "VITAMINA",
    "s": [
     "VI",
     "TA",
     "MI",
     "NA"
    ],
    "e": "💊"
   },
   {
    "p": "BINÓCULO",
    "s": [
     "BI",
     "NÓ",
     "CU",
     "LO"
    ],
    "e": "🔭"
   }
  ],
  "Ç — letra simples, som /s/": [
   {
    "p": "CABEÇA",
    "s": [
     "CA",
     "BE",
     "ÇA"
    ],
    "e": "🧠"
   },
   {
    "p": "LAÇO",
    "s": [
     "LA",
     "ÇO"
    ],
    "e": "🎀"
   },
   {
    "p": "MOÇA",
    "s": [
     "MO",
     "ÇA"
    ],
    "e": "👩"
   },
   {
    "p": "POÇA",
    "s": [
     "PO",
     "ÇA"
    ],
    "e": "💧"
   },
   {
    "p": "PEDAÇO",
    "s": [
     "PE",
     "DA",
     "ÇO"
    ],
    "e": "🍰"
   },
   {
    "p": "FUMAÇA",
    "s": [
     "FU",
     "MA",
     "ÇA"
    ],
    "e": "💨"
   },
   {
    "p": "CAROÇO",
    "s": [
     "CA",
     "RO",
     "ÇO"
    ],
    "e": "🥭"
   },
   {
    "p": "MOÇO",
    "s": [
     "MO",
     "ÇO"
    ],
    "e": "👨"
   },
   {
    "p": "PEÇA",
    "s": [
     "PE",
     "ÇA"
    ],
    "e": "🧩"
   },
   {
    "p": "POÇO",
    "s": [
     "PO",
     "ÇO"
    ],
    "e": "🕳️"
   }
  ]
 },
 "complexas": {
  "1.1 · R FORTE no início da palavra (som de CARRO)": [
   {
    "p": "RATO",
    "s": [
     "RA",
     "TO"
    ],
    "e": "🐭",
    "obs": ""
   },
   {
    "p": "RÉGUA",
    "s": [
     "RÉ",
     "GUA"
    ],
    "e": "📏",
    "obs": "gua"
   },
   {
    "p": "RODA",
    "s": [
     "RO",
     "DA"
    ],
    "e": "🛞",
    "obs": ""
   },
   {
    "p": "RIO",
    "s": [
     "RI",
     "O"
    ],
    "e": "🏞️",
    "obs": ""
   },
   {
    "p": "RUA",
    "s": [
     "RU",
     "A"
    ],
    "e": "🛣️",
    "obs": ""
   },
   {
    "p": "REI",
    "s": [
     "REI"
    ],
    "e": "🤴",
    "obs": "ditongo"
   },
   {
    "p": "ROUPA",
    "s": [
     "ROU",
     "PA"
    ],
    "e": "👕",
    "obs": "ditongo"
   },
   {
    "p": "RELÓGIO",
    "s": [
     "RE",
     "LÓ",
     "GIO"
    ],
    "e": "⏰",
    "obs": "gio"
   }
  ],
  "1.2 · RR entre vogais — som forte": [
   {
    "p": "CARRO",
    "s": [
     "CAR",
     "RO"
    ],
    "e": "🚗",
    "obs": ""
   },
   {
    "p": "TERRA",
    "s": [
     "TER",
     "RA"
    ],
    "e": "🌍",
    "obs": ""
   },
   {
    "p": "JARRA",
    "s": [
     "JAR",
     "RA"
    ],
    "e": "🏺",
    "obs": ""
   },
   {
    "p": "FERRO",
    "s": [
     "FER",
     "RO"
    ],
    "e": "⚙️",
    "obs": ""
   },
   {
    "p": "SERRA",
    "s": [
     "SER",
     "RA"
    ],
    "e": "🪚",
    "obs": ""
   },
   {
    "p": "BURRO",
    "s": [
     "BUR",
     "RO"
    ],
    "e": "🫏",
    "obs": ""
   },
   {
    "p": "MORRO",
    "s": [
     "MOR",
     "RO"
    ],
    "e": "⛰️",
    "obs": ""
   },
   {
    "p": "BARRO",
    "s": [
     "BAR",
     "RO"
    ],
    "e": "🟤",
    "obs": ""
   },
   {
    "p": "ERRO",
    "s": [
     "ER",
     "RO"
    ],
    "e": "❌",
    "obs": ""
   },
   {
    "p": "CORRE",
    "s": [
     "COR",
     "RE"
    ],
    "e": "🏃",
    "obs": "ação"
   },
   {
    "p": "BARRIGA",
    "s": [
     "BAR",
     "RI",
     "GA"
    ],
    "e": "🤰",
    "obs": ""
   },
   {
    "p": "GARRAFA",
    "s": [
     "GAR",
     "RA",
     "FA"
    ],
    "e": "🍾",
    "obs": ""
   },
   {
    "p": "CIGARRA",
    "s": [
     "CI",
     "GAR",
     "RA"
    ],
    "e": "🦗",
    "obs": ""
   },
   {
    "p": "BEZERRO",
    "s": [
     "BE",
     "ZER",
     "RO"
    ],
    "e": "🐄",
    "obs": ""
   },
   {
    "p": "MARRECO",
    "s": [
     "MAR",
     "RE",
     "CO"
    ],
    "e": "🦆",
    "obs": ""
   },
   {
    "p": "BARRACA",
    "s": [
     "BAR",
     "RA",
     "CA"
    ],
    "e": "⛺",
    "obs": ""
   },
   {
    "p": "SOCORRO",
    "s": [
     "SO",
     "COR",
     "RO"
    ],
    "e": "🆘",
    "obs": ""
   }
  ],
  "1.3 · R travando a sílaba — PAR, POR, VER": [
   {
    "p": "PORTA",
    "s": [
     "POR",
     "TA"
    ],
    "e": "🚪",
    "obs": ""
   },
   {
    "p": "CARTA",
    "s": [
     "CAR",
     "TA"
    ],
    "e": "✉️",
    "obs": ""
   },
   {
    "p": "BARCO",
    "s": [
     "BAR",
     "CO"
    ],
    "e": "⛵",
    "obs": ""
   },
   {
    "p": "VERDE",
    "s": [
     "VER",
     "DE"
    ],
    "e": "🟩",
    "obs": ""
   },
   {
    "p": "PERNA",
    "s": [
     "PER",
     "NA"
    ],
    "e": "🦵",
    "obs": ""
   },
   {
    "p": "GARFO",
    "s": [
     "GAR",
     "FO"
    ],
    "e": "🍴",
    "obs": ""
   },
   {
    "p": "CIRCO",
    "s": [
     "CIR",
     "CO"
    ],
    "e": "🎪",
    "obs": ""
   },
   {
    "p": "URSO",
    "s": [
     "UR",
     "SO"
    ],
    "e": "🐻",
    "obs": ""
   },
   {
    "p": "CORDA",
    "s": [
     "COR",
     "DA"
    ],
    "e": "🪢",
    "obs": ""
   },
   {
    "p": "VERME",
    "s": [
     "VER",
     "ME"
    ],
    "e": "🪱",
    "obs": ""
   },
   {
    "p": "TARDE",
    "s": [
     "TAR",
     "DE"
    ],
    "e": "🌇",
    "obs": ""
   },
   {
    "p": "CARNE",
    "s": [
     "CAR",
     "NE"
    ],
    "e": "🥩",
    "obs": ""
   },
   {
    "p": "PORCO",
    "s": [
     "POR",
     "CO"
    ],
    "e": "🐷",
    "obs": ""
   },
   {
    "p": "BARBA",
    "s": [
     "BAR",
     "BA"
    ],
    "e": "🧔",
    "obs": ""
   },
   {
    "p": "PERTO",
    "s": [
     "PER",
     "TO"
    ],
    "e": "📍",
    "obs": ""
   },
   {
    "p": "MARTELO",
    "s": [
     "MAR",
     "TE",
     "LO"
    ],
    "e": "🔨",
    "obs": ""
   },
   {
    "p": "FORMIGA",
    "s": [
     "FOR",
     "MI",
     "GA"
    ],
    "e": "🐜",
    "obs": ""
   },
   {
    "p": "LAGARTA",
    "s": [
     "LA",
     "GAR",
     "TA"
    ],
    "e": "🐛",
    "obs": ""
   },
   {
    "p": "BORBOLETA",
    "s": [
     "BOR",
     "BO",
     "LE",
     "TA"
    ],
    "e": "🦋",
    "obs": "4 sílabas"
   },
   {
    "p": "TARTARUGA",
    "s": [
     "TAR",
     "TA",
     "RU",
     "GA"
    ],
    "e": "🐢",
    "obs": "4 sílabas"
   }
  ],
  "1.4 · R no encontro consonantal — PRA, BRA, TRA…": [
   {
    "p": "BRAÇO",
    "s": [
     "BRA",
     "ÇO"
    ],
    "e": "💪",
    "obs": "BR"
   },
   {
    "p": "BRANCO",
    "s": [
     "BRAN",
     "CO"
    ],
    "e": "⚪",
    "obs": "BR"
   },
   {
    "p": "BRINCO",
    "s": [
     "BRIN",
     "CO"
    ],
    "e": "💍",
    "obs": "BR"
   },
   {
    "p": "BRUXA",
    "s": [
     "BRU",
     "XA"
    ],
    "e": "🧙",
    "obs": "BR"
   },
   {
    "p": "BRIGA",
    "s": [
     "BRI",
     "GA"
    ],
    "e": "😠",
    "obs": "BR"
   },
   {
    "p": "COBRA",
    "s": [
     "CO",
     "BRA"
    ],
    "e": "🐍",
    "obs": "BR"
   },
   {
    "p": "CABRA",
    "s": [
     "CA",
     "BRA"
    ],
    "e": "🐐",
    "obs": "BR"
   },
   {
    "p": "ZEBRA",
    "s": [
     "ZE",
     "BRA"
    ],
    "e": "🦓",
    "obs": "BR"
   },
   {
    "p": "LEBRE",
    "s": [
     "LE",
     "BRE"
    ],
    "e": "🐇",
    "obs": "BR"
   },
   {
    "p": "SOMBRA",
    "s": [
     "SOM",
     "BRA"
    ],
    "e": "🌑",
    "obs": "BR"
   },
   {
    "p": "ABRAÇO",
    "s": [
     "A",
     "BRA",
     "ÇO"
    ],
    "e": "🤗",
    "obs": "BR"
   },
   {
    "p": "CRAVO",
    "s": [
     "CRA",
     "VO"
    ],
    "e": "🌷",
    "obs": "CR"
   },
   {
    "p": "CREME",
    "s": [
     "CRE",
     "ME"
    ],
    "e": "🍦",
    "obs": "CR"
   },
   {
    "p": "CRECHE",
    "s": [
     "CRE",
     "CHE"
    ],
    "e": "🏫",
    "obs": "CR"
   },
   {
    "p": "CRIANÇA",
    "s": [
     "CRI",
     "AN",
     "ÇA"
    ],
    "e": "👶",
    "obs": "CR"
   },
   {
    "p": "ESCREVE",
    "s": [
     "ES",
     "CRE",
     "VE"
    ],
    "e": "✍️",
    "obs": "CR"
   },
   {
    "p": "DRAGÃO",
    "s": [
     "DRA",
     "GÃO"
    ],
    "e": "🐉",
    "obs": "DR"
   },
   {
    "p": "PEDRA",
    "s": [
     "PE",
     "DRA"
    ],
    "e": "🪨",
    "obs": "DR"
   },
   {
    "p": "VIDRO",
    "s": [
     "VI",
     "DRO"
    ],
    "e": "🪟",
    "obs": "DR"
   },
   {
    "p": "QUADRO",
    "s": [
     "QUA",
     "DRO"
    ],
    "e": "🖼️",
    "obs": "DR"
   },
   {
    "p": "LADRÃO",
    "s": [
     "LA",
     "DRÃO"
    ],
    "e": "🦹",
    "obs": "DR"
   },
   {
    "p": "PADRE",
    "s": [
     "PA",
     "DRE"
    ],
    "e": "🙏",
    "obs": "DR"
   },
   {
    "p": "FRUTA",
    "s": [
     "FRU",
     "TA"
    ],
    "e": "🍎",
    "obs": "FR"
   },
   {
    "p": "FRIO",
    "s": [
     "FRI",
     "O"
    ],
    "e": "🥶",
    "obs": "FR"
   },
   {
    "p": "FRANGO",
    "s": [
     "FRAN",
     "GO"
    ],
    "e": "🍗",
    "obs": "FR"
   },
   {
    "p": "FRALDA",
    "s": [
     "FRAL",
     "DA"
    ],
    "e": "🧷",
    "obs": "FR"
   },
   {
    "p": "FREIO",
    "s": [
     "FREI",
     "O"
    ],
    "e": "🛑",
    "obs": "FR"
   },
   {
    "p": "COFRE",
    "s": [
     "CO",
     "FRE"
    ],
    "e": "🔐",
    "obs": "FR"
   },
   {
    "p": "GRAMA",
    "s": [
     "GRA",
     "MA"
    ],
    "e": "🌱",
    "obs": "GR"
   },
   {
    "p": "GRANDE",
    "s": [
     "GRAN",
     "DE"
    ],
    "e": "🔠",
    "obs": "GR"
   },
   {
    "p": "GRILO",
    "s": [
     "GRI",
     "LO"
    ],
    "e": "🦗",
    "obs": "GR"
   },
   {
    "p": "GRITA",
    "s": [
     "GRI",
     "TA"
    ],
    "e": "😱",
    "obs": "GR"
   },
   {
    "p": "TIGRE",
    "s": [
     "TI",
     "GRE"
    ],
    "e": "🐅",
    "obs": "GR"
   },
   {
    "p": "MAGRO",
    "s": [
     "MA",
     "GRO"
    ],
    "e": "🦴",
    "obs": "GR"
   },
   {
    "p": "ALEGRE",
    "s": [
     "A",
     "LE",
     "GRE"
    ],
    "e": "😄",
    "obs": "GR"
   },
   {
    "p": "REGRA",
    "s": [
     "RE",
     "GRA"
    ],
    "e": "📏",
    "obs": "GR"
   },
   {
    "p": "GRAVATA",
    "s": [
     "GRA",
     "VA",
     "TA"
    ],
    "e": "👔",
    "obs": "GR"
   },
   {
    "p": "PRATO",
    "s": [
     "PRA",
     "TO"
    ],
    "e": "🍽️",
    "obs": "PR"
   },
   {
    "p": "PRAIA",
    "s": [
     "PRAI",
     "A"
    ],
    "e": "🏖️",
    "obs": "PR"
   },
   {
    "p": "PRIMO",
    "s": [
     "PRI",
     "MO"
    ],
    "e": "👦",
    "obs": "PR"
   },
   {
    "p": "PRIMA",
    "s": [
     "PRI",
     "MA"
    ],
    "e": "👧",
    "obs": "PR"
   },
   {
    "p": "PRETO",
    "s": [
     "PRE",
     "TO"
    ],
    "e": "⚫",
    "obs": "PR"
   },
   {
    "p": "PRATA",
    "s": [
     "PRA",
     "TA"
    ],
    "e": "🥈",
    "obs": "PR"
   },
   {
    "p": "COMPRA",
    "s": [
     "COM",
     "PRA"
    ],
    "e": "🛒",
    "obs": "PR"
   },
   {
    "p": "PRESENTE",
    "s": [
     "PRE",
     "SEN",
     "TE"
    ],
    "e": "🎁",
    "obs": "PR"
   },
   {
    "p": "TRÊS",
    "s": [
     "TRÊS"
    ],
    "e": "3️⃣",
    "obs": "TR"
   },
   {
    "p": "TREM",
    "s": [
     "TREM"
    ],
    "e": "🚂",
    "obs": "TR"
   },
   {
    "p": "TRIGO",
    "s": [
     "TRI",
     "GO"
    ],
    "e": "🌾",
    "obs": "TR"
   },
   {
    "p": "TRAVE",
    "s": [
     "TRA",
     "VE"
    ],
    "e": "🥅",
    "obs": "TR"
   },
   {
    "p": "TRENÓ",
    "s": [
     "TRE",
     "NÓ"
    ],
    "e": "🛷",
    "obs": "TR"
   },
   {
    "p": "LETRA",
    "s": [
     "LE",
     "TRA"
    ],
    "e": "🔤",
    "obs": "TR"
   },
   {
    "p": "DENTRO",
    "s": [
     "DEN",
     "TRO"
    ],
    "e": "📦",
    "obs": "TR"
   },
   {
    "p": "OUTRO",
    "s": [
     "OU",
     "TRO"
    ],
    "e": "➡️",
    "obs": "TR"
   },
   {
    "p": "ESTRELA",
    "s": [
     "ES",
     "TRE",
     "LA"
    ],
    "e": "⭐",
    "obs": "TR"
   },
   {
    "p": "LIVRO",
    "s": [
     "LI",
     "VRO"
    ],
    "e": "📕",
    "obs": "VR"
   },
   {
    "p": "LIVRE",
    "s": [
     "LI",
     "VRE"
    ],
    "e": "🕊️",
    "obs": "VR"
   },
   {
    "p": "PALAVRA",
    "s": [
     "PA",
     "LA",
     "VRA"
    ],
    "e": "💬",
    "obs": "VR"
   }
  ],
  "1.5 · R no fim da palavra": [
   {
    "p": "MAR",
    "s": [
     "MAR"
    ],
    "e": "🌊",
    "obs": ""
   },
   {
    "p": "COR",
    "s": [
     "COR"
    ],
    "e": "🎨",
    "obs": ""
   },
   {
    "p": "DOR",
    "s": [
     "DOR"
    ],
    "e": "🤕",
    "obs": ""
   },
   {
    "p": "AMOR",
    "s": [
     "A",
     "MOR"
    ],
    "e": "❤️",
    "obs": ""
   },
   {
    "p": "CALOR",
    "s": [
     "CA",
     "LOR"
    ],
    "e": "☀️",
    "obs": ""
   },
   {
    "p": "COMER",
    "s": [
     "CO",
     "MER"
    ],
    "e": "🍽️",
    "obs": ""
   },
   {
    "p": "DORMIR",
    "s": [
     "DOR",
     "MIR"
    ],
    "e": "😴",
    "obs": ""
   },
   {
    "p": "PULAR",
    "s": [
     "PU",
     "LAR"
    ],
    "e": "🤸",
    "obs": ""
   },
   {
    "p": "CANTAR",
    "s": [
     "CAN",
     "TAR"
    ],
    "e": "🎤",
    "obs": ""
   },
   {
    "p": "JOGAR",
    "s": [
     "JO",
     "GAR"
    ],
    "e": "⚽",
    "obs": ""
   },
   {
    "p": "LUGAR",
    "s": [
     "LU",
     "GAR"
    ],
    "e": "📍",
    "obs": ""
   },
   {
    "p": "MULHER",
    "s": [
     "MU",
     "LHER"
    ],
    "e": "👩",
    "obs": "+ LH"
   }
  ],
  "2.1 · L travando a sílaba — AL, EL, OL": [
   {
    "p": "SOL",
    "s": [
     "SOL"
    ],
    "e": "☀️",
    "obs": ""
   },
   {
    "p": "MEL",
    "s": [
     "MEL"
    ],
    "e": "🍯",
    "obs": ""
   },
   {
    "p": "ANEL",
    "s": [
     "A",
     "NEL"
    ],
    "e": "💍",
    "obs": ""
   },
   {
    "p": "PAPEL",
    "s": [
     "PA",
     "PEL"
    ],
    "e": "📄",
    "obs": ""
   },
   {
    "p": "AZUL",
    "s": [
     "A",
     "ZUL"
    ],
    "e": "🔵",
    "obs": ""
   },
   {
    "p": "FUNIL",
    "s": [
     "FU",
     "NIL"
    ],
    "e": "⚗️",
    "obs": ""
   },
   {
    "p": "ALTO",
    "s": [
     "AL",
     "TO"
    ],
    "e": "📏",
    "obs": ""
   },
   {
    "p": "VOLTA",
    "s": [
     "VOL",
     "TA"
    ],
    "e": "🔄",
    "obs": ""
   },
   {
    "p": "SALTO",
    "s": [
     "SAL",
     "TO"
    ],
    "e": "👠",
    "obs": ""
   },
   {
    "p": "CALDO",
    "s": [
     "CAL",
     "DO"
    ],
    "e": "🍲",
    "obs": ""
   },
   {
    "p": "FALTA",
    "s": [
     "FAL",
     "TA"
    ],
    "e": "❓",
    "obs": ""
   },
   {
    "p": "BOLSA",
    "s": [
     "BOL",
     "SA"
    ],
    "e": "👜",
    "obs": ""
   },
   {
    "p": "CALÇA",
    "s": [
     "CAL",
     "ÇA"
    ],
    "e": "👖",
    "obs": "+ Ç"
   },
   {
    "p": "QUINTAL",
    "s": [
     "QUIN",
     "TAL"
    ],
    "e": "🏡",
    "obs": "+ QU"
   }
  ],
  "2.2 · L no encontro consonantal — BLA, CLA, FLA…": [
   {
    "p": "BLOCO",
    "s": [
     "BLO",
     "CO"
    ],
    "e": "🧱",
    "obs": "BL"
   },
   {
    "p": "BLUSA",
    "s": [
     "BLU",
     "SA"
    ],
    "e": "👚",
    "obs": "BL"
   },
   {
    "p": "TABLET",
    "s": [
     "TA",
     "BLET"
    ],
    "e": "📱",
    "obs": "BL"
   },
   {
    "p": "CLARO",
    "s": [
     "CLA",
     "RO"
    ],
    "e": "💡",
    "obs": "CL"
   },
   {
    "p": "CLIPE",
    "s": [
     "CLI",
     "PE"
    ],
    "e": "📎",
    "obs": "CL"
   },
   {
    "p": "CLUBE",
    "s": [
     "CLU",
     "BE"
    ],
    "e": "🏟️",
    "obs": "CL"
   },
   {
    "p": "TECLADO",
    "s": [
     "TE",
     "CLA",
     "DO"
    ],
    "e": "⌨️",
    "obs": "CL"
   },
   {
    "p": "BICICLETA",
    "s": [
     "BI",
     "CI",
     "CLE",
     "TA"
    ],
    "e": "🚲",
    "obs": "CL · 4 sílabas"
   },
   {
    "p": "FLOR",
    "s": [
     "FLOR"
    ],
    "e": "🌸",
    "obs": "FL"
   },
   {
    "p": "FLAUTA",
    "s": [
     "FLAU",
     "TA"
    ],
    "e": "🪈",
    "obs": "FL"
   },
   {
    "p": "FLOCO",
    "s": [
     "FLO",
     "CO"
    ],
    "e": "❄️",
    "obs": "FL"
   },
   {
    "p": "FLECHA",
    "s": [
     "FLE",
     "CHA"
    ],
    "e": "🏹",
    "obs": "FL · + CH"
   },
   {
    "p": "FLORESTA",
    "s": [
     "FLO",
     "RES",
     "TA"
    ],
    "e": "🌳",
    "obs": "FL"
   },
   {
    "p": "GLOBO",
    "s": [
     "GLO",
     "BO"
    ],
    "e": "🌐",
    "obs": "GL"
   },
   {
    "p": "IGLU",
    "s": [
     "I",
     "GLU"
    ],
    "e": "🧊",
    "obs": "GL"
   },
   {
    "p": "SIGLA",
    "s": [
     "SI",
     "GLA"
    ],
    "e": "🔤",
    "obs": "GL"
   },
   {
    "p": "PLANTA",
    "s": [
     "PLAN",
     "TA"
    ],
    "e": "🌿",
    "obs": "PL"
   },
   {
    "p": "PLACA",
    "s": [
     "PLA",
     "CA"
    ],
    "e": "🪧",
    "obs": "PL"
   },
   {
    "p": "PLUMA",
    "s": [
     "PLU",
     "MA"
    ],
    "e": "🪶",
    "obs": "PL"
   },
   {
    "p": "PLANETA",
    "s": [
     "PLA",
     "NE",
     "TA"
    ],
    "e": "🪐",
    "obs": "PL"
   },
   {
    "p": "PLÁSTICO",
    "s": [
     "PLÁS",
     "TI",
     "CO"
    ],
    "e": "🧴",
    "obs": "PL"
   },
   {
    "p": "ATLETA",
    "s": [
     "A",
     "TLE",
     "TA"
    ],
    "e": "🏃",
    "obs": "TL · raro"
   }
  ],
  "3.1 · CH — som /ʃ/": [
   {
    "p": "CHAVE",
    "s": [
     "CHA",
     "VE"
    ],
    "e": "🔑",
    "obs": ""
   },
   {
    "p": "CHUVA",
    "s": [
     "CHU",
     "VA"
    ],
    "e": "🌧️",
    "obs": ""
   },
   {
    "p": "CHÁ",
    "s": [
     "CHÁ"
    ],
    "e": "🍵",
    "obs": ""
   },
   {
    "p": "CHÃO",
    "s": [
     "CHÃO"
    ],
    "e": "⬇️",
    "obs": ""
   },
   {
    "p": "CHINELO",
    "s": [
     "CHI",
     "NE",
     "LO"
    ],
    "e": "🩴",
    "obs": ""
   },
   {
    "p": "CHAPÉU",
    "s": [
     "CHA",
     "PÉU"
    ],
    "e": "🎩",
    "obs": ""
   },
   {
    "p": "CHUPETA",
    "s": [
     "CHU",
     "PE",
     "TA"
    ],
    "e": "🍼",
    "obs": ""
   },
   {
    "p": "MOCHILA",
    "s": [
     "MO",
     "CHI",
     "LA"
    ],
    "e": "🎒",
    "obs": ""
   },
   {
    "p": "BOLACHA",
    "s": [
     "BO",
     "LA",
     "CHA"
    ],
    "e": "🍪",
    "obs": ""
   },
   {
    "p": "FECHA",
    "s": [
     "FE",
     "CHA"
    ],
    "e": "🚪",
    "obs": "ação"
   },
   {
    "p": "MACHUCA",
    "s": [
     "MA",
     "CHU",
     "CA"
    ],
    "e": "🤕",
    "obs": "ação"
   },
   {
    "p": "CACHORRO",
    "s": [
     "CA",
     "CHOR",
     "RO"
    ],
    "e": "🐕",
    "obs": "+ RR"
   },
   {
    "p": "CHOCOLATE",
    "s": [
     "CHO",
     "CO",
     "LA",
     "TE"
    ],
    "e": "🍫",
    "obs": "4 sílabas"
   }
  ],
  "3.2 · LH — som /ʎ/": [
   {
    "p": "FILHA",
    "s": [
     "FI",
     "LHA"
    ],
    "e": "👧",
    "obs": ""
   },
   {
    "p": "FILHO",
    "s": [
     "FI",
     "LHO"
    ],
    "e": "👦",
    "obs": ""
   },
   {
    "p": "MILHO",
    "s": [
     "MI",
     "LHO"
    ],
    "e": "🌽",
    "obs": ""
   },
   {
    "p": "FOLHA",
    "s": [
     "FO",
     "LHA"
    ],
    "e": "🍃",
    "obs": ""
   },
   {
    "p": "GALHO",
    "s": [
     "GA",
     "LHO"
    ],
    "e": "🌿",
    "obs": ""
   },
   {
    "p": "VELHO",
    "s": [
     "VE",
     "LHO"
    ],
    "e": "👴",
    "obs": ""
   },
   {
    "p": "PILHA",
    "s": [
     "PI",
     "LHA"
    ],
    "e": "🔋",
    "obs": ""
   },
   {
    "p": "MOLHO",
    "s": [
     "MO",
     "LHO"
    ],
    "e": "🍅",
    "obs": ""
   },
   {
    "p": "ORELHA",
    "s": [
     "O",
     "RE",
     "LHA"
    ],
    "e": "👂",
    "obs": ""
   },
   {
    "p": "JOELHO",
    "s": [
     "JO",
     "E",
     "LHO"
    ],
    "e": "🦵",
    "obs": ""
   },
   {
    "p": "COELHO",
    "s": [
     "CO",
     "E",
     "LHO"
    ],
    "e": "🐰",
    "obs": ""
   },
   {
    "p": "ABELHA",
    "s": [
     "A",
     "BE",
     "LHA"
    ],
    "e": "🐝",
    "obs": ""
   },
   {
    "p": "TOALHA",
    "s": [
     "TO",
     "A",
     "LHA"
    ],
    "e": "🧻",
    "obs": ""
   },
   {
    "p": "PALHAÇO",
    "s": [
     "PA",
     "LHA",
     "ÇO"
    ],
    "e": "🤡",
    "obs": "+ Ç"
   },
   {
    "p": "COLHER",
    "s": [
     "CO",
     "LHER"
    ],
    "e": "🥄",
    "obs": ""
   },
   {
    "p": "ESPELHO",
    "s": [
     "ES",
     "PE",
     "LHO"
    ],
    "e": "🪞",
    "obs": ""
   },
   {
    "p": "AGULHA",
    "s": [
     "A",
     "GU",
     "LHA"
    ],
    "e": "🪡",
    "obs": ""
   },
   {
    "p": "MULHER",
    "s": [
     "MU",
     "LHER"
    ],
    "e": "👩",
    "obs": ""
   }
  ],
  "3.3 · NH — som /ɲ/": [
   {
    "p": "BANHO",
    "s": [
     "BA",
     "NHO"
    ],
    "e": "🛁",
    "obs": ""
   },
   {
    "p": "UNHA",
    "s": [
     "U",
     "NHA"
    ],
    "e": "💅",
    "obs": ""
   },
   {
    "p": "SONHO",
    "s": [
     "SO",
     "NHO"
    ],
    "e": "💭",
    "obs": ""
   },
   {
    "p": "LINHA",
    "s": [
     "LI",
     "NHA"
    ],
    "e": "🧵",
    "obs": ""
   },
   {
    "p": "NINHO",
    "s": [
     "NI",
     "NHO"
    ],
    "e": "🪹",
    "obs": ""
   },
   {
    "p": "LENHA",
    "s": [
     "LE",
     "NHA"
    ],
    "e": "🪵",
    "obs": ""
   },
   {
    "p": "GALINHA",
    "s": [
     "GA",
     "LI",
     "NHA"
    ],
    "e": "🐔",
    "obs": ""
   },
   {
    "p": "MINHOCA",
    "s": [
     "MI",
     "NHO",
     "CA"
    ],
    "e": "🪱",
    "obs": ""
   },
   {
    "p": "ARANHA",
    "s": [
     "A",
     "RA",
     "NHA"
    ],
    "e": "🕷️",
    "obs": ""
   },
   {
    "p": "RAINHA",
    "s": [
     "RA",
     "I",
     "NHA"
    ],
    "e": "👸",
    "obs": ""
   },
   {
    "p": "CAMINHO",
    "s": [
     "CA",
     "MI",
     "NHO"
    ],
    "e": "🛤️",
    "obs": ""
   },
   {
    "p": "CARINHO",
    "s": [
     "CA",
     "RI",
     "NHO"
    ],
    "e": "🤗",
    "obs": ""
   },
   {
    "p": "VIZINHO",
    "s": [
     "VI",
     "ZI",
     "NHO"
    ],
    "e": "🏘️",
    "obs": ""
   },
   {
    "p": "DINHEIRO",
    "s": [
     "DI",
     "NHEI",
     "RO"
    ],
    "e": "💰",
    "obs": "+ ditongo"
   },
   {
    "p": "BANHEIRO",
    "s": [
     "BA",
     "NHEI",
     "RO"
    ],
    "e": "🚽",
    "obs": "+ ditongo"
   },
   {
    "p": "MONTANHA",
    "s": [
     "MON",
     "TA",
     "NHA"
    ],
    "e": "⛰️",
    "obs": ""
   },
   {
    "p": "CAMINHÃO",
    "s": [
     "CA",
     "MI",
     "NHÃO"
    ],
    "e": "🚚",
    "obs": "+ nasal"
   }
  ],
  "3.4 · SS — som /s/ entre vogais": [
   {
    "p": "MASSA",
    "s": [
     "MAS",
     "SA"
    ],
    "e": "🍝",
    "obs": ""
   },
   {
    "p": "OSSO",
    "s": [
     "OS",
     "SO"
    ],
    "e": "🦴",
    "obs": ""
   },
   {
    "p": "ASSA",
    "s": [
     "AS",
     "SA"
    ],
    "e": "🍞",
    "obs": "ação"
   },
   {
    "p": "POSSO",
    "s": [
     "POS",
     "SO"
    ],
    "e": "🙋",
    "obs": ""
   },
   {
    "p": "CLASSE",
    "s": [
     "CLAS",
     "SE"
    ],
    "e": "🏫",
    "obs": "+ CL"
   },
   {
    "p": "PESSOA",
    "s": [
     "PES",
     "SO",
     "A"
    ],
    "e": "🧍",
    "obs": ""
   },
   {
    "p": "PÁSSARO",
    "s": [
     "PÁS",
     "SA",
     "RO"
    ],
    "e": "🐦",
    "obs": ""
   },
   {
    "p": "VASSOURA",
    "s": [
     "VAS",
     "SOU",
     "RA"
    ],
    "e": "🧹",
    "obs": "+ ditongo"
   },
   {
    "p": "PASSEIO",
    "s": [
     "PAS",
     "SEI",
     "O"
    ],
    "e": "🚶",
    "obs": "+ ditongo"
   },
   {
    "p": "PROFESSORA",
    "s": [
     "PRO",
     "FES",
     "SO",
     "RA"
    ],
    "e": "👩‍🏫",
    "obs": "4 sílabas"
   }
  ],
  "3.5 · QU com U mudo — QUE, QUI (som /k/)": [
   {
    "p": "QUEIJO",
    "s": [
     "QUEI",
     "JO"
    ],
    "e": "🧀",
    "obs": ""
   },
   {
    "p": "QUENTE",
    "s": [
     "QUEN",
     "TE"
    ],
    "e": "🔥",
    "obs": ""
   },
   {
    "p": "QUERO",
    "s": [
     "QUE",
     "RO"
    ],
    "e": "🙏",
    "obs": ""
   },
   {
    "p": "AQUI",
    "s": [
     "A",
     "QUI"
    ],
    "e": "📍",
    "obs": ""
   },
   {
    "p": "QUINTAL",
    "s": [
     "QUIN",
     "TAL"
    ],
    "e": "🏡",
    "obs": ""
   },
   {
    "p": "MÁQUINA",
    "s": [
     "MÁ",
     "QUI",
     "NA"
    ],
    "e": "⚙️",
    "obs": ""
   },
   {
    "p": "PEQUENO",
    "s": [
     "PE",
     "QUE",
     "NO"
    ],
    "e": "🐜",
    "obs": ""
   },
   {
    "p": "PARQUE",
    "s": [
     "PAR",
     "QUE"
    ],
    "e": "🏞️",
    "obs": "+ R travado"
   },
   {
    "p": "BOSQUE",
    "s": [
     "BOS",
     "QUE"
    ],
    "e": "🌲",
    "obs": ""
   },
   {
    "p": "RAQUETE",
    "s": [
     "RA",
     "QUE",
     "TE"
    ],
    "e": "🎾",
    "obs": ""
   },
   {
    "p": "ESQUILO",
    "s": [
     "ES",
     "QUI",
     "LO"
    ],
    "e": "🐿️",
    "obs": ""
   },
   {
    "p": "MOSQUITO",
    "s": [
     "MOS",
     "QUI",
     "TO"
    ],
    "e": "🦟",
    "obs": ""
   },
   {
    "p": "TANQUE",
    "s": [
     "TAN",
     "QUE"
    ],
    "e": "🛢️",
    "obs": ""
   }
  ],
  "3.6 · QU com U pronunciado — QUA, QUO (som /kw/)": [
   {
    "p": "QUATRO",
    "s": [
     "QUA",
     "TRO"
    ],
    "e": "4️⃣",
    "obs": "+ TR"
   },
   {
    "p": "QUADRO",
    "s": [
     "QUA",
     "DRO"
    ],
    "e": "🖼️",
    "obs": "+ DR"
   },
   {
    "p": "QUASE",
    "s": [
     "QUA",
     "SE"
    ],
    "e": "➗",
    "obs": ""
   },
   {
    "p": "QUANDO",
    "s": [
     "QUAN",
     "DO"
    ],
    "e": "⏰",
    "obs": ""
   },
   {
    "p": "QUARTO",
    "s": [
     "QUAR",
     "TO"
    ],
    "e": "🛏️",
    "obs": "+ R travado"
   }
  ],
  "3.7 · GU com U mudo — GUE, GUI (som /g/)": [
   {
    "p": "FOGUETE",
    "s": [
     "FO",
     "GUE",
     "TE"
    ],
    "e": "🚀",
    "obs": ""
   },
   {
    "p": "GUITARRA",
    "s": [
     "GUI",
     "TAR",
     "RA"
    ],
    "e": "🎸",
    "obs": "+ RR"
   },
   {
    "p": "GUERRA",
    "s": [
     "GUER",
     "RA"
    ],
    "e": "⚔️",
    "obs": "+ RR"
   },
   {
    "p": "JEGUE",
    "s": [
     "JE",
     "GUE"
    ],
    "e": "🫏",
    "obs": ""
   },
   {
    "p": "SANGUE",
    "s": [
     "SAN",
     "GUE"
    ],
    "e": "🩸",
    "obs": ""
   },
   {
    "p": "GUIA",
    "s": [
     "GUI",
     "A"
    ],
    "e": "🗺️",
    "obs": ""
   },
   {
    "p": "ÁGUIA",
    "s": [
     "Á",
     "GUIA"
    ],
    "e": "🦅",
    "obs": ""
   },
   {
    "p": "MANGUEIRA",
    "s": [
     "MAN",
     "GUEI",
     "RA"
    ],
    "e": "🥭",
    "obs": "+ ditongo"
   },
   {
    "p": "FORMIGUEIRO",
    "s": [
     "FOR",
     "MI",
     "GUEI",
     "RO"
    ],
    "e": "🐜",
    "obs": "4 sílabas"
   }
  ],
  "3.8 · GU com U pronunciado — GUA (som /gw/)": [
   {
    "p": "ÁGUA",
    "s": [
     "Á",
     "GUA"
    ],
    "e": "💧",
    "obs": ""
   },
   {
    "p": "GUARDA",
    "s": [
     "GUAR",
     "DA"
    ],
    "e": "💂",
    "obs": "+ R travado"
   },
   {
    "p": "IGUAL",
    "s": [
     "I",
     "GUAL"
    ],
    "e": "🟰",
    "obs": ""
   },
   {
    "p": "LÍNGUA",
    "s": [
     "LÍN",
     "GUA"
    ],
    "e": "👅",
    "obs": ""
   },
   {
    "p": "RÉGUA",
    "s": [
     "RÉ",
     "GUA"
    ],
    "e": "📏",
    "obs": ""
   }
  ],
  "3.9 · SC / XC — som /s/ (raro)": [
   {
    "p": "NASCE",
    "s": [
     "NAS",
     "CE"
    ],
    "e": "🐣",
    "obs": ""
   },
   {
    "p": "DESCE",
    "s": [
     "DES",
     "CE"
    ],
    "e": "⬇️",
    "obs": ""
   },
   {
    "p": "CRESCE",
    "s": [
     "CRES",
     "CE"
    ],
    "e": "📈",
    "obs": "+ CR"
   },
   {
    "p": "PISCINA",
    "s": [
     "PIS",
     "CI",
     "NA"
    ],
    "e": "🏊",
    "obs": "S + C separados"
   }
  ],
  "4.1 · S no fim da sílaba — AS, ES, IS, OS, US": [
   {
    "p": "FESTA",
    "s": [
     "FES",
     "TA"
    ],
    "e": "🎉",
    "obs": ""
   },
   {
    "p": "CESTA",
    "s": [
     "CES",
     "TA"
    ],
    "e": "🧺",
    "obs": ""
   },
   {
    "p": "PASTA",
    "s": [
     "PAS",
     "TA"
    ],
    "e": "📁",
    "obs": ""
   },
   {
    "p": "MOSCA",
    "s": [
     "MOS",
     "CA"
    ],
    "e": "🪰",
    "obs": ""
   },
   {
    "p": "ISCA",
    "s": [
     "IS",
     "CA"
    ],
    "e": "🎣",
    "obs": ""
   },
   {
    "p": "LÁPIS",
    "s": [
     "LÁ",
     "PIS"
    ],
    "e": "✏️",
    "obs": ""
   },
   {
    "p": "ESCOLA",
    "s": [
     "ES",
     "CO",
     "LA"
    ],
    "e": "🏫",
    "obs": ""
   },
   {
    "p": "VESTIDO",
    "s": [
     "VES",
     "TI",
     "DO"
    ],
    "e": "👗",
    "obs": ""
   },
   {
    "p": "CASTELO",
    "s": [
     "CAS",
     "TE",
     "LO"
    ],
    "e": "🏰",
    "obs": ""
   },
   {
    "p": "GOSTOSO",
    "s": [
     "GOS",
     "TO",
     "SO"
    ],
    "e": "😋",
    "obs": ""
   },
   {
    "p": "BISCOITO",
    "s": [
     "BIS",
     "COI",
     "TO"
    ],
    "e": "🍪",
    "obs": "+ ditongo"
   }
  ],
  "5.1 · AM, EM, IM, OM, UM / AN, EN, IN, ON, UN": [
   {
    "p": "CAMPO",
    "s": [
     "CAM",
     "PO"
    ],
    "e": "🏕️",
    "obs": ""
   },
   {
    "p": "TEMPO",
    "s": [
     "TEM",
     "PO"
    ],
    "e": "⏰",
    "obs": ""
   },
   {
    "p": "PONTE",
    "s": [
     "PON",
     "TE"
    ],
    "e": "🌉",
    "obs": ""
   },
   {
    "p": "DENTE",
    "s": [
     "DEN",
     "TE"
    ],
    "e": "🦷",
    "obs": ""
   },
   {
    "p": "PENTE",
    "s": [
     "PEN",
     "TE"
    ],
    "e": "💇",
    "obs": ""
   },
   {
    "p": "TINTA",
    "s": [
     "TIN",
     "TA"
    ],
    "e": "🎨",
    "obs": ""
   },
   {
    "p": "PINTO",
    "s": [
     "PIN",
     "TO"
    ],
    "e": "🐤",
    "obs": ""
   },
   {
    "p": "MANGA",
    "s": [
     "MAN",
     "GA"
    ],
    "e": "🥭",
    "obs": ""
   },
   {
    "p": "ONDA",
    "s": [
     "ON",
     "DA"
    ],
    "e": "🌊",
    "obs": ""
   },
   {
    "p": "BANCO",
    "s": [
     "BAN",
     "CO"
    ],
    "e": "🏦",
    "obs": ""
   },
   {
    "p": "VENTO",
    "s": [
     "VEN",
     "TO"
    ],
    "e": "💨",
    "obs": ""
   },
   {
    "p": "MUNDO",
    "s": [
     "MUN",
     "DO"
    ],
    "e": "🌍",
    "obs": ""
   },
   {
    "p": "CANTA",
    "s": [
     "CAN",
     "TA"
    ],
    "e": "🎤",
    "obs": "ação"
   },
   {
    "p": "JANTA",
    "s": [
     "JAN",
     "TA"
    ],
    "e": "🍽️",
    "obs": "ação"
   },
   {
    "p": "BATOM",
    "s": [
     "BA",
     "TOM"
    ],
    "e": "💄",
    "obs": ""
   },
   {
    "p": "PUDIM",
    "s": [
     "PU",
     "DIM"
    ],
    "e": "🍮",
    "obs": ""
   },
   {
    "p": "NUVEM",
    "s": [
     "NU",
     "VEM"
    ],
    "e": "☁️",
    "obs": ""
   },
   {
    "p": "JARDIM",
    "s": [
     "JAR",
     "DIM"
    ],
    "e": "🌷",
    "obs": "+ R travado"
   },
   {
    "p": "BOMBOM",
    "s": [
     "BOM",
     "BOM"
    ],
    "e": "🍬",
    "obs": ""
   },
   {
    "p": "LARANJA",
    "s": [
     "LA",
     "RAN",
     "JA"
    ],
    "e": "🍊",
    "obs": ""
   },
   {
    "p": "SEMENTE",
    "s": [
     "SE",
     "MEN",
     "TE"
    ],
    "e": "🌱",
    "obs": ""
   },
   {
    "p": "LÂMPADA",
    "s": [
     "LÂM",
     "PA",
     "DA"
    ],
    "e": "💡",
    "obs": ""
   },
   {
    "p": "TAMBOR",
    "s": [
     "TAM",
     "BOR"
    ],
    "e": "🥁",
    "obs": "+ R final"
   }
  ],
  "6.1 · Ç — som /s/ antes de A, O, U": [
   {
    "p": "CABEÇA",
    "s": [
     "CA",
     "BE",
     "ÇA"
    ],
    "e": "🧠",
    "obs": ""
   },
   {
    "p": "LAÇO",
    "s": [
     "LA",
     "ÇO"
    ],
    "e": "🎀",
    "obs": ""
   },
   {
    "p": "MOÇA",
    "s": [
     "MO",
     "ÇA"
    ],
    "e": "👩",
    "obs": ""
   },
   {
    "p": "POÇA",
    "s": [
     "PO",
     "ÇA"
    ],
    "e": "💧",
    "obs": ""
   },
   {
    "p": "PEDAÇO",
    "s": [
     "PE",
     "DA",
     "ÇO"
    ],
    "e": "🍰",
    "obs": ""
   },
   {
    "p": "FUMAÇA",
    "s": [
     "FU",
     "MA",
     "ÇA"
    ],
    "e": "💨",
    "obs": ""
   },
   {
    "p": "CAROÇO",
    "s": [
     "CA",
     "RO",
     "ÇO"
    ],
    "e": "🥭",
    "obs": ""
   },
   {
    "p": "MAÇÃ",
    "s": [
     "MA",
     "ÇÃ"
    ],
    "e": "🍎",
    "obs": "+ nasal"
   },
   {
    "p": "BERÇO",
    "s": [
     "BER",
     "ÇO"
    ],
    "e": "🍼",
    "obs": "+ R travado"
   },
   {
    "p": "CALÇA",
    "s": [
     "CAL",
     "ÇA"
    ],
    "e": "👖",
    "obs": "+ L travado"
   },
   {
    "p": "DANÇA",
    "s": [
     "DAN",
     "ÇA"
    ],
    "e": "💃",
    "obs": "+ nasal"
   },
   {
    "p": "AÇÚCAR",
    "s": [
     "A",
     "ÇÚ",
     "CAR"
    ],
    "e": "🍬",
    "obs": "+ R final"
   }
  ],
  "6.2 · X com som de CH (/ʃ/)": [
   {
    "p": "LIXO",
    "s": [
     "LI",
     "XO"
    ],
    "e": "🗑️",
    "obs": ""
   },
   {
    "p": "LIXA",
    "s": [
     "LI",
     "XA"
    ],
    "e": "🪵",
    "obs": ""
   },
   {
    "p": "ROXO",
    "s": [
     "RO",
     "XO"
    ],
    "e": "🟣",
    "obs": ""
   },
   {
    "p": "PUXA",
    "s": [
     "PU",
     "XA"
    ],
    "e": "🪢",
    "obs": "ação"
   },
   {
    "p": "XÍCARA",
    "s": [
     "XÍ",
     "CA",
     "RA"
    ],
    "e": "☕",
    "obs": ""
   },
   {
    "p": "XADREZ",
    "s": [
     "XA",
     "DREZ"
    ],
    "e": "♟️",
    "obs": "+ DR"
   },
   {
    "p": "CAIXA",
    "s": [
     "CAI",
     "XA"
    ],
    "e": "📦",
    "obs": "+ ditongo"
   },
   {
    "p": "PEIXE",
    "s": [
     "PEI",
     "XE"
    ],
    "e": "🐟",
    "obs": "+ ditongo"
   },
   {
    "p": "BRUXA",
    "s": [
     "BRU",
     "XA"
    ],
    "e": "🧙",
    "obs": "+ BR"
   },
   {
    "p": "ABACAXI",
    "s": [
     "A",
     "BA",
     "CA",
     "XI"
    ],
    "e": "🍍",
    "obs": "4 sílabas"
   }
  ],
  "6.3 · X com outros sons": [
   {
    "p": "TÁXI",
    "s": [
     "TÁ",
     "XI"
    ],
    "e": "🚕",
    "obs": "som /ks/"
   },
   {
    "p": "SEXTA",
    "s": [
     "SEX",
     "TA"
    ],
    "e": "📅",
    "obs": "som /s/"
   },
   {
    "p": "EXAME",
    "s": [
     "E",
     "XA",
     "ME"
    ],
    "e": "🩺",
    "obs": "som /z/"
   },
   {
    "p": "PRÓXIMO",
    "s": [
     "PRÓ",
     "XI",
     "MO"
    ],
    "e": "➡️",
    "obs": "som /s/ · + PR"
   }
  ]
 }
}
```

---

# Validação

- Parte I: 341 palavras, **0 violações**. Toda sílaba casa com `[bcdfgjlmnprstvz][aeiouáéíóúâêô]` ou é vogal isolada.
- Nenhuma divisão silábica diverge do banco v2.1.0 nas 192 palavras em comum.
- Sem duplicatas dentro de cada família.
- Máximo de 3 sílabas na Parte I (as de 4 estão isoladas na Parte I-B).
