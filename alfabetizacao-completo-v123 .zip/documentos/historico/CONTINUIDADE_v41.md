> ⚠️ **DOCUMENTO ANTIGO, guardado só como histórico.** Onde ele contradisser o `documentos/HISTORICO_E_PLANO_alfabetizacao.md`, vale o HISTORICO_E_PLANO (por exemplo: o zip do Netlify leva os 8 arquivos **na raiz**, sem pasta; os testes precisam de `npm install`; hoje são 310 testes; `CHAVES_LEITORA` tem 33 chaves).

# Esforço Vence 🦉 — Documento de Continuidade

**Última atualização:** cache `esforco-vence-v41` · 2039 frases · 37 blocos · 279 testes automatizados passando (67+61+151)

Este documento existe pra qualquer pessoa (ou qualquer instância futura do Claude) conseguir continuar este projeto sem precisar reler a conversa inteira. Ele conta quem é o Pedro, o que ele quer, o que já foi construído, o que falta, e como continuar sem quebrar nada.

---

## 1. Quem é o Pedro e o que ele quer

Pedro é um educador brasileiro, dono e desenvolvedor da **Escola São Pedro**. Ele não é programador profissional — depende do Claude pra escrever todo o código — mas tem visão pedagógica muito clara, testa tudo com crianças reais (incluindo a própria filha, **Hana**, que é a usuária real e a referência constante de "será que uma criança de verdade entenderia isso?"), e dá feedback extremamente específico a partir de prints de tela.

Ele está construindo uma suíte de PWAs educacionais chamada **Coruja 🦉** (o app original se chamava "Esforço Vence", depois ficou como a marca do módulo de leitura dentro da suíte):

- **Esforço Vence / Coruja Leitura** — este app. Alfabetização com sílabas destacadas estilo karaokê, mini-jogos, e agora treino de sílabas dedicado.
- **Coruja Fluência** — teste de fluência de leitura (palavras por minuto), banco de ~5000 palavras com dificuldade fonética × idade.
- **Coruja Historinhas** — 60 histórias com banco de 697 perguntas de interpretação.

### Princípios inegociáveis do Pedro (não violar sem perguntar)

1. **Esforço > nota.** Nunca gamificação vazia, nunca "resposta errada" em pergunta de sentimento/opinião.
2. **Edições cirúrgicas.** Nunca reescrever o que já funciona só porque "ficaria mais elegante".
3. **Pedir autorização antes de construir coisa grande.** Ele já corrigiu o Claude por assumir e construir sem confirmar.
4. **Tudo funciona 100% offline.** PWA instalável, service worker, sem dependência de rede.
5. **Validação é sagrada.** Toda palavra nova passa pelo silabador antes de entrar no app — "verificado por mim mesmo em outra conversa" NÃO é motivo pra pular a validação (isso já pegou erros reais mais de uma vez).
6. **"Mais simples primeiro"** quando há uma lista grande de pedidos.
7. **Honestidade sobre limitação linguística** é preferível a forçar conteúdo ruim só pra preencher uma grade (ex.: sílabas sem palavra comum ficam marcadas como tal, não recebem palavra inventada).

---

## 2. Arquitetura técnica

**Stack:** HTML único (`index.html`, ~800KB), vanilla JS + CSS, zero frameworks, zero build step. Service worker (`sw.js`) + manifest pra funcionar como PWA instalável offline.

**Deploy:** Netlify, pacote zip com `index.html + sw.js + manifest.webmanifest + icon-192.png + icon-512.png`.

### 2.1 As 4 páginas (não são popups — cada uma cobre a tela toda)

| Página | O que faz | Posição própria |
|---|---|---|
| **Ler** | Leitura com sílaba destacada tipo karaokê. É a página "de base", sempre presente por baixo. | `idx` / `hana_idx` |
| **Sílaba Perdida** | Frase com 1 sílaba faltando, a criança escolhe entre 3 opções. | `idxSilaba` / `hana_idx_silaba` |
| **Monta a Frase** | Frase embaralhada em palavras, a criança toca na ordem certa. | `idxMonta` / `hana_idx_monta` |
| **Treinar Sílabas** | Famílias silábicas (Simples pronto, Complexas ainda não). | Não é baseado em frase — é família por família. |

Cada uma das 3 últimas navega pelas 2039 frases **de forma independente** — mudar de posição em uma não afeta as outras. Isso foi um pedido explícito do Pedro depois que elas viravam página.

### 2.2 O hub (🏠) — modo duplo

- **Modo página** (`abrirHub(true)`): a 1ª tela depois de escolher a leitora. Fundo opaco, ocupa a tela toda.
- **Modo popup** (`abrirHub()` sem argumento): quando aperta 🏠 estando **dentro** de um módulo já escolhido. Fundo escuro semitransparente, card pequeno.

Ordem dos 4 botões: **Treinar Sílabas → Ler → Sílaba Perdida → Monta a Frase**.

### 2.3 Sistema de temas

Tudo que precisa mudar de cor por tema usa `var(--nome)`, nunca cor fixa. As variáveis mais importantes:
`--ink` (texto principal), `--bg` (fundo), `--card`, `--starcol` (cor de destaque/estrela), `--navprev`/`--navnext` (botões ◀▶).

**Armadilha já cometida duas vezes:** usar cor fixa (`#333`, `#2f6b2f`) em vez de `var(--ink)` — funciona bem no tema padrão e fica ilegível em temas escuros. Sempre que criar um elemento de texto novo, checar se a cor vem de variável.

### 2.4 Sistema de perfis (múltiplas leitoras no mesmo aparelho)

- Perfil legado `"1"` (Hana) não tem prefixo nas chaves do localStorage. Perfis novos ganham `id` tipo `"p"+timestamp` e um prefixo (`p1234_`) calculado uma vez no boot.
- `Storage.prototype.getItem/setItem/removeItem` são **monkey-patched** pra prefixar automaticamente pela leitora ativa. Isso significa: se você escrever um dado que precisa sobreviver a uma TROCA de leitora (por exemplo, "abra o hub depois do reload, mas já como a leitora nova"), tem que usar `_rawSet`/`_rawGet` com o prefixo explícito da leitora de DESTINO — já vi esse bug (escrever com o prefixo errado) acontecer.

### 2.5 Sistema de nomes de família (tokens)

Dois formatos de token convivem no banco de frases:
- **Ancorado** `{TIA_1}` — sempre ao lado da palavra de parentesco ("a tia {TIA_1}"). Sem nome cadastrado, vira `""` e sobra "a tia".
- **Livre** `{FTIA_1}` — aparece sozinho na frase. Sem nome, vira a palavra do papel (`PAPEL_PALAVRA`); com nome, vira o nome direto.

**Pools:** categorias com "mais de uma pessoa" (tias, tios, primos, primas, irmãs, irmãos, amigos, amigas) usam **1 campo de formulário só**, com nomes separados por `/` ou `;`. Isso é resolvido por `POOL_TOKEN` + `listaPool()`, com **rotação** (menos nomes cadastrados que posições de frase = os nomes existentes se repetem, nunca fica vazio à toa).

Categorias de 1 pessoa só (pai, mãe, os 4 avós) continuam sendo campo único, sem pool — decisão deliberada pela simplicidade pro usuário leigo, mesmo que perca a flexibilidade de "3+ avôs".

**Migração automática:** quem cadastrou no formato antigo (tia1, tia2... campos individuais) continua funcionando — `migrarParentesPool()` converte na hora do carregamento.

### 2.6 O silabador

`silabador.js` (também existe uma cópia idêntica embutida dentro do `index.html`, cuidado pra não deixarem dessincronizar — **isso já aconteceu uma vez e causou um bug real**, "juiz" não separava certo porque a versão embutida estava atrasada em relação ao arquivo de referência).

Regras conhecidas e testadas:
- i/u tônico antes de R Z L M N ou NH = hiato (sa·ir, ra·iz, ju·iz)
- RR e SS sempre dividem no meio (car·ro, pas·so) — é a hifenação oficial do português, não bug
- Y funciona como vogal em nomes (Ryan, Kayky)
- PH/TH/GH/RH são dígrafos
- "atleta" é uma exceção conhecida (A·TLE·TA, herança do grego) — está como palavra-exceção no gabarito, não uma regra geral

### 2.7 Estrutura de dados de Sílabas Simples (`SILABAS_FASE1`)

```js
{fam:'B', nome:'Família do B', notaFamilia:null, silabas:[
  {s:'ba', palavras:[{p:'Bala',e:'🍬'}, ...], nota:null},
  ...
]}
```

**17 famílias** (B C D F G J L M N P R S T V Z, mais C-brando e G-brando no final), **75 sílabas**, **341 palavras**. C e G aparecem **duas vezes**: a versão "duro" (CA/CO/CU, GA/GO/GU) na ordem alfabética normal, e a versão "brando" (CE/CI, GE/GI) no fim da grade, com uma nota explicando a troca de som e a prévia do card mostrando "CE CI" em texto em vez de emoji.

**X não existe como família** — decisão deliberada: tem 4 sons diferentes dependendo da palavra, não forma família limpa como as outras. Confirmado por duas fontes independentes.

**5 sílabas ficam sem nenhuma palavra** (JE, VU, ZI, ZO, ZU) — confirmado que não existe palavra comum real pra elas em português, não é falta de busca. Ficam com nota explicando e o cartão treina só o som.

---

## 3. O que já foi construído (histórico)

Em ordem cronológica aproximada:

1. **Token `{NOME}`** — nome da leitora com silabação automática, substituindo "Ha·na" fixo em 83 frases.
2. **Frentes 2/3** — 800 frases novas com tokens de família livres, organizadas em 8 blocos temáticos (família, casa, brincar, gente que eu amo, bichos, escola, sentimentos, histórias).
3. **Reformulação do cadastro de família** — de campos individuais (tia1...tia6) pra pools com separador. Adição de Primos (não existia). Contagens mínimas subiram pra 3 em irmãs/irmãos/amigas.
4. **Reformulação em 4 páginas** — de "tudo popup" pra páginas reais, com hub de modo duplo.
5. **Treinar Sílabas — Fase 1 (Simples)**: passou por 3 gerações de conteúdo:
   - Primeira curadoria manual (~230 palavras, regra de no máximo 3 sílabas)
   - Expansão pedida pelo Pedro (~266 palavras)
   - Substituição pelo material do arquivo `lista-oficial-silabas-v3.md` que o Pedro enviou (341 palavras, já validado rigorosamente de novo antes de aceitar) — **essa é a versão atual**
6. **Desdobramento C/G** em duro/brando, com banner explicativo e reordenação alfabética.
7. **Marcador "Estudada"** por família — não trava nada, só acompanha progresso, sobrevive a fechar o app.
8. **Sistema de animação** (`voarAtePosicao`) — compartilhado entre Monta-Frase e Sílaba Perdida. Passou por várias iterações:
   - Tentativa de arraste (drag-and-drop) — **testada e revertida** a pedido do Pedro (ver seção 4.3).
   - Correção de bug real: sequência rápida de toques corretos era acusada de erro por engano (o contador só avançava depois da animação terminar).
   - Redesenho visual: sem "achatar pro tamanho da vaga" (parecia desaparecer), cor de acerto virou verde universal fixo (não depende do tema, evita coincidir com tons vermelhos em alguns temas).
9. **Correções de contraste** — `#spFrase`, `.mtSlot` etc. usavam cor fixa (`#333`) em vez de `var(--ink)`, ficavam ilegíveis em temas escuros.
10. **Correções de espaçamento** — a lacuna da sílaba faltante tinha duas "linhas" competindo (texto `"__"` + borda pontilhada do CSS); unificado numa só.
11. **Cores de navegação** — botões ◀▶ novos (Monta-frase, Sílaba Perdida) não tinham a cor vívida de Ler porque a regra de cor era amarrada a IDs específicos, não à classe compartilhada.

### 3.1 Testes automatizados

3 suítes em Node + jsdom, cobrindo comportamento real (não só "o elemento existe"):
- `teste_frente1.js` — 67 testes (silabador, token NOME, sistema de perfis)
- `teste_frentes23.js` — 61 testes (frases novas, tokens de família, migração)
- `teste_hub_silabas.js` — 151 testes (hub, páginas, Sílabas Fase 1, animações, tudo desta fase mais recente)

**Total: 279 testes, todos passando.**

### 3.2 Arquivos de trabalho importantes (em `/home/claude/work/`, não vão pro zip final)

- `silabador.py` / `silabador.js` — o silabador, com gabarito de exceções
- `gabarito_atual.json` — ~1750 palavras já validadas extraídas do próprio app
- `simples_v2_final.json` — o conteúdo atual da Fase 1 (fonte de verdade, antes de virar JS)
- `lista_v3.json` — o material completo (simples + aceitáveis + complexas) extraído do arquivo que o Pedro enviou — **as 304 palavras de sílabas complexas já estão aqui, validadas, esperando serem integradas**
- `validar_lista_v3.py` — script de validação rigorosa (reutilizável pra conferir a Parte II também)
- Vários `index_checkpoint_vNN.html` — snapshots de versões anteriores, úteis se algo precisar ser revertido

---

## 4. O que falta fazer

### 4.1 Sílabas Complexas — o item grande, ainda não iniciado

O roteiro completo (definido em conversa com o Pedro, ele pediu o "universo completo" generalizado por consoante):

| Fase | Conteúdo | Palavras já validadas em `lista_v3.json`? |
|---|---|---|
| 1 | Sílabas simples | ✅ Feito (341 palavras) |
| 2 | C/G/QU com variações + R/S iniciais | ✅ Parte do simples já cobre isso |
| 3 | "O R muda de som" (forte, fraco, RR, travada) | Parcial — está distribuído em várias categorias de `complexas` |
| 4 | "O S muda de som" (mesma lógica) | Parcial — idem |
| 5 | Encontros com R (PRA BRA TRA...) | ✅ Categoria própria em `complexas` |
| 6 | Encontros com L (PLA BLA CLA...) | ✅ Categoria própria em `complexas` |
| 7 | L travando sílaba (generalizado) | ✅ Categoria própria |
| 8 | Nasal travando sílaba (generalizado) | ✅ Categoria própria |

**2 desacordos conhecidos e ainda não resolvidos** entre o silabador e o arquivo do Pedro (ambos em Parte II, não bloqueiam nada):
- "PRAIA" — silabador diz PRAI·A, arquivo diz PRA·IA
- "ATLETA" — arquivo diz A·TLE·TA (aceito como exceção do grego), silabador geral diria AT·LE·TA

**Decisão pendente:** como estruturar a UI de Complexas — provavelmente precisa de uma segunda camada de agrupamento (não é só "família de letra", é "família de padrão", tipo "encontros com R" como uma categoria própria dentro de Complexas, com sub-cards pra cada combinação PRA/BRA/TRA/etc.).

### 4.2 Ideias registradas, mas explicitamente não implementadas ainda

1. **Popup de sílaba isolada** — um botão que abre uma tela cheia mostrando só BA BE BI BO BU (+ BÃO, a 6ª "família" nasal que o Pedro mencionou desde a primeira conversa sobre isso), sem palavra nenhuma, só pra treinar o som puro antes de ver palavras. Tocar em cada sílaba fala ela.
2. **Fonte maior nos cards de palavra do treino**, podendo diminuir o emoji pra abrir espaço.
3. **Pensar o melhor formato geral** da tela de Treinar Sílabas pra ajudar uma criança pré-alfabetizada — pedido aberto do Pedro, não uma especificação fechada.

### 4.3 Coisa que foi tentada e não deve ser repetida sem pedido explícito

- **Arraste (drag-and-drop) no Monta-frase.** Foi implementado, testado, funcionava tecnicamente — mas o Pedro decidiu que **toque sequencial estrito é pedagogicamente melhor** (força a criança a ler a frase antes de saber a ordem certa). Foi revertido de propósito. Não reintroduzir sem o Pedro pedir de novo.

---

## 5. Como continuar — guia prático

### 5.1 Rodando os testes

```bash
cd /home/claude/work
npm install jsdom   # se for sessão nova
node teste_frente1.js
node teste_frentes23.js
node teste_hub_silabas.js
```

Todos devem terminar em `falhou: 0`. Se algo quebrar, o nome do teste já explica o que esperava vs o que aconteceu.

### 5.2 Checando sintaxe antes de rodar testes

```bash
python3 -c "
import re
src=open('index.html',encoding='utf-8').read()
m=re.search(r'<script[^>]*>(.*?)</script>',src,re.S)
open('script_0.js','w',encoding='utf-8').write(m.group(1))
"
node --check script_0.js
```

### 5.3 Empacotando pra entrega

```bash
rm -rf pacote && mkdir -p pacote
cp zipcontent/icon-192.png zipcontent/icon-512.png pacote/
sed "s/esforco-vence-v21/esforco-vence-vNN/" zipcontent/sw.js > pacote/sw.js   # subir o número da versão
sed 's/2003 frases/XXXX frases/' zipcontent/manifest.webmanifest > pacote/manifest.webmanifest
cp index.html pacote/
cd pacote && zip -q -r ../esforco-vence-netlify.zip . && cd ..
```

**Sempre subir o número da versão no cache do `sw.js`** — senão o navegador do usuário final não recebe a atualização (service worker cacheia agressivamente).

### 5.4 Adicionando palavras/frases novas — o pipeline de validação

Nunca adicionar uma palavra "de olho". Sempre:
1. Escrever a lista candidata em Python.
2. Rodar contra `silabador.py` (ou `gabarito_atual.json`, que tem prioridade).
3. Checar: começa com a sílaba certa? Tem o número de sílabas dentro do limite (≤3 pra sílabas simples)? Tem emoji fiel? Não é duplicata?
4. Só depois converter pra JS e colar no `index.html`.

Esse pipeline já pegou dezenas de erros reais — inclusive em material que o próprio Pedro disse ter "verificado em outra conversa". Não pular essa etapa.

### 5.5 Armadilhas já vivenciadas nesta conversa (não repetir)

1. **Regressão silenciosa por checkpoint velho.** Restaurar um `index_backup_vNN.html` pra corrigir uma coisa específica pode reverter outras mudanças feitas depois daquele checkpoint. Já aconteceu duas vezes (formulário de família voltou pra versão antiga sem eu notar). Depois de qualquer restauração de checkpoint, rodar os testes inteiros antes de seguir.
2. **CSS duplicado.** Já aconteceu de escrever uma regra nova (`.spGap`, `.mtW`, `.famCard`) sem checar se já existia uma regra igual em outro lugar do arquivo, criando conflito silencioso. Sempre `grep -n "^\.classe{"` antes de adicionar CSS novo.
3. **Cor fixa em vez de variável de tema.** Sempre checar se um elemento de texto/fundo novo usa `var(--algumacoisa)` e não um hex fixo.
4. **`localStorage` prefixado por leitora.** Uma flag que precisa sobreviver a uma troca de leitora (reload com perfil diferente) tem que ser escrita com `_rawSet(prefixoDe(idDestino)+'chave', valor)`, não `localStorage.setItem` direto.

### 5.6 Estilo de comunicação com o Pedro

- Ele manda prints de tela constantemente — sempre olhar com atenção antes de assumir o que está descrevendo.
- Ele às vezes escreve por voz-pra-texto (erros de autocorretor tipo "paixão" por "posição", "Wolf screen" por "Full screen") — se uma frase não fizer sentido literal, considerar erro de dictation antes de pedir esclarecimento.
- Ele aprecia checklist de "o que ficou pronto, o que falta" no final de cada entrega.
- Quando o pedido é grande, ele mesmo pede "mais simples primeiro" — seguir essa ordem por padrão quando não especificado.
- Se um pedido dele contradiz uma decisão anterior dele mesmo, apontar o conflito e perguntar em vez de escolher silenciosamente um dos dois.
