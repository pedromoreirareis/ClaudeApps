# Pedido para colar numa conversa JÁ EXISTENTE de cada app

**Cadastro padrão Nome + Bichinho · Nuvem (Firebase) · Tela cheia sempre · Tela nunca bloqueia · Convite para instalar**
Versão 3 (modelo: Curiosidades v1.7) · Serve para **Claude ou ChatGPT**

---

## 📌 Como usar (Pedro)

1. Abra a **conversa que você já tem** daquele app (Alfabetização, Matemática, Fluência, Coruja Explica, Provinha ou Historinhas).
2. **Anexe 4 arquivos** (vêm da entrega do Curiosidades v1.7). Anexe sempre as versões novas, mesmo que você já tenha mandado versões antigas nesta conversa:
   - `nuvem-sync.js`
   - `escola-pwa.js` (versão 2: tem a lista oficial dos 8 bichinhos)
   - `REFERENCIA_INTEGRACAO_CURIOSIDADES.md`
   - `PADRAO_CADASTRO_NOME_BICHINHO.md`
   - **Anexe também o `index.html` mais recente do app** se você não tiver certeza de que a conversa está com a última versão que você publicou.
3. Copie **todo** o texto entre **COPIE DAQUI** e **ATÉ AQUI**, cole na mensagem e envie. **Não precisa trocar nada**: o próprio texto tem a tabela com o nome e o ID de cada app.
4. **Não anexe** o seu `nuvem-config.js` preenchido. Ele fica só com você. Quando o app voltar, troque o `nuvem-config.js` vazio pelo seu antes de publicar.

> ⚠️ **Se a conversa daquele app já estiver muito longa** (muitas versões, muitas mensagens), é melhor abrir uma **conversa nova** com o `PEDIDO_NOVA_CONVERSA.md`. Conversa muito cheia faz a IA "esquecer" o começo, e é aí que aparecem erros. Um sinal: se a IA disser que precisa resumir a conversa, ou começar a errar coisas que já estavam certas.

> 🔁 **Já colou uma versão anterior deste pedido nesta conversa?** Pode colar esta nova mesmo assim. A IA deve aplicar só o que falta, principalmente o **cadastro padrão com os 8 bichinhos** (melhoria 0).

---

`========== COPIE DAQUI ==========`

Olá! Agora quero incluir **neste app** as mesmas 6 melhorias que já foram feitas e testadas no app **Curiosidades v1.7**. São 6 melhorias que **todos os 7 apps** da Escola São Pedro devem ter. Se algumas delas já foram feitas nesta conversa, confira se estão iguais ao modelo e aplique só o que falta. Anexei:
- `nuvem-sync.js`: módulo de nuvem PRONTO e testado, igual em todos os apps (não reescreva);
- `escola-pwa.js` (v2): módulo PRONTO e testado, igual em todos os apps (não reescreva). Faz tela sempre acesa, tela cheia e convite para instalar, e guarda a **lista oficial dos 8 bichinhos** (`EscolaPWA.BICHINHOS`);
- `REFERENCIA_INTEGRACAO_CURIOSIDADES.md`: como tudo foi ligado no Curiosidades (use como modelo: HTML, CSS, JavaScript, `sw.js`, `nuvem-config.js` vazio e testes);
- `PADRAO_CADASTRO_NOME_BICHINHO.md`: a **regra oficial** de cadastro, acesso e recuperação por **Nome + Bichinho**. Este app tem que ficar igual a ela.

**Use a versão mais recente deste app que está nesta conversa.** Se eu anexei um `index.html` agora, use o anexo. Se tiver dúvida de qual é a última versão, me pergunte antes de começar.

**ID deste app na nuvem.** Use exatamente o ID da linha deste app na tabela (minúsculo, sem acento, sem espaço):

| App | Endereço | ID |
|---|---|---|
| 📚 Alfabetização | https://escolasaopedroalfabetizacao.netlify.app/ | `alfabetizacao` |
| 🔢 Matemática | https://escolasaopedromatematica.netlify.app/ | `matematica` |
| 📖 Fluência | https://escolasaopedrofluencia.netlify.app/ | `fluencia` |
| 🦉 Coruja Explica | https://escolasaopedrocorujaexplica.netlify.app/ | `corujaexplica` |
| 📝 Provinha | https://escolasaopedroprovinha.netlify.app/ | `provinha` |
| 📕 Historinhas | https://escolasaopedrohistorinhas.netlify.app/ | `historinhas` |
| 🌍 Curiosidades | https://escolasaopedrocuriosidades.netlify.app/ | `curiosidades` (já feito) |

Se não der para saber com certeza qual app é esta conversa, me pergunte antes de começar.

### O foco de tudo: a aprendizagem da criança
Estas mudanças existem para **proteger e dar continuidade à aprendizagem** (leitura, matemática e interpretação):
- **Nada do que mostra o que a criança aprendeu pode se perder.** Isso inclui o que ela fez, leu ou acertou, os erros e as dificuldades (mostram o que ela precisa treinar), os níveis, as estrelas, os recordes e onde parou.
- **Sincronize tudo que é progresso**, não só o mais óbvio.
- **Não mude conteúdo nem o jeito de ensinar.** Sugestões pedagógicas, só no fim e sem implementar.
- **Não atrapalhe a criança:** nada de telas de espera por causa da nuvem nem toques a mais. Erros de nuvem aparecem só nas Configurações e no pontinho da ⚙️.

### As 6 melhorias

**0) Cadastro, acesso e recuperação padrão: NOME + BICHINHO (fazer primeiro).**
Siga **exatamente** o `PADRAO_CADASTRO_NOME_BICHINHO.md`:
- **Os mesmos 8 bichinhos em todos os apps, nesta ordem:** 🦉 Coruja · 🦊 Raposa · 🐰 Coelho · 🐼 Panda · 🦋 Borboleta · 🐨 Coala · 🐯 Tigre · 🐴 Pônei.
  - A lista vem de `EscolaPWA.BICHINHOS`, com uma cópia de reserva idêntica.
  - Não pode faltar, sobrar nem mudar a ordem.
- **Os 8 sempre numa linha só** (nunca em duas), com no mínimo 30 px, em pé, deitado, com e sem teclado.
  - A tela de cadastro não é girada à força.
  - A meta viewport tem `interactive-widget=resizes-content`.
  - Com o teclado aberto, continuam visíveis o nome, os 8 bichinhos e o "Pronto".
- **Textos e ordem da tela:** "🌟 Qual é o seu nome?" → "Digite o seu nome..." → "Escolha o seu bichinho:" → 8 bichinhos → "Você escolheu: 🦋 Borboleta" → "← Voltar" / "Pronto! ✅" / "☁️ Já tenho cadastro".
- **Regras:**
  - nenhum bichinho vem escolhido sozinho;
  - sem nome ou sem bichinho não cadastra;
  - espaços são limpos;
  - Enter confirma se já tem bichinho;
  - mesmo nome + bichinho não cria repetido (abre o existente);
  - mesmo nome com outro bichinho é outra criança;
  - máximo de 6 crianças.
- **Acesso:** nenhuma criança → cadastro; uma → direto; duas ou mais → **"Quem vai estudar hoje?"** ("✏️ Trocar nome ou bichinho", "🗑️ Apagar este usuário", "☁️ Recuperar da nuvem", "➕ Novo usuário").
- **Recuperação:**
  - mesmo nome + bichinho traz o progresso sozinho;
  - "☁️ Já tenho cadastro" / "☁️ Recuperar da nuvem" → tela "☁️ Recuperar cadastro", que lista também crianças de outros apps;
  - "🕘 Versões guardadas".
- **Trocar nome ou bichinho:** o progresso vai junto. Trocar para a identidade de outra criança é bloqueado.
- **Bichinho antigo** (fora dos 8): a criança continua funcionando e nada se perde. Ao editar, o app pede um dos 8, e o progresso vai junto. **Nunca troque o bichinho de ninguém automaticamente.**
- **Este app não é igual ao Curiosidades por dentro.** Não copie às cegas: **adapte** ao jeito que ele guarda as crianças, para que a criança veja e use tudo igual.


**1) A tela NUNCA pode bloquear enquanto o app estiver em uso (muito importante).**
Meu celular bloqueia a tela a cada 1 minuto sem toque, e muitas vezes o app está espelhado na TV. Enquanto o app estiver aberto e na frente, a tela não pode apagar nem bloquear. Quando o app for minimizado, o celular volta ao normal. Faça isso com o `escola-pwa.js`, que usa o Wake Lock do Chrome, entra num modo reserva (vídeo mudo) se o Wake Lock for recusado ou não existir, e confere a cada 15 segundos. Nas Configurações, coloque uma chave "📺 Tela sempre acesa", ligada por padrão, que mostra o modo em uso ("Ligado" / "Ligado (modo reserva)" / aviso se o celular recusar).

**2) O app sempre em tela cheia.**
Durante o uso, o app fica em tela cheia. Se sair, volta no próximo toque, usando o `escola-pwa.js`. Se o app já trava a orientação da tela (deitado ou em pé), passe essa função em `aoEntrarTelaCheia`. A tela cheia não pode atrapalhar campos de digitar, botões que abrem seletor de arquivo nem o convite de instalação. Retire qualquer código antigo que tentava a tela cheia só no primeiro toque, para não ficar duplicado.

**3) Sempre aparecer o convite (pop-up) para instalar o app.**
Quem abre o site pelo navegador vê um pop-up oferecendo instalar o app (PWA), sempre que abrir pelo navegador, até ele ser instalado. Isso é feito pelo `escola-pwa.js`:
- Se o Chrome permitir, aparece o botão "📲 Instalar agora". Se não, aparece o passo a passo.
- Aberto pelo ícone instalado, o convite não aparece.
- Coloque também uma linha "📲 Instalar" nas Configurações, que some quando o app é aberto como app instalado.

Confira se o app é instalável: `manifest.webmanifest` com `name`, `short_name`, `start_url`, `display`, ícones 192 e 512, e `sw.js` com `fetch`. Se faltar algo, corrija.

**4) Histórico na nuvem (Firebase). EXTREMAMENTE IMPORTANTE.**
- O celular continua sendo o dono dos dados (localStorage). O jeito atual de salvar não pode piorar.
- **O histórico que já existe no celular das crianças não pode se perder nesta atualização.**
- Toda gravação de dado de um leitor vira pendência e sobe sozinha quando tiver internet. Sem internet, fica na fila (pré-sincronização).
- Identidade da criança na nuvem = **nome + bichinho (emoji)**, igual em todos os apps.
- Use `NuvemSync.iniciar({ app: '<ID da tabela>', usuarios, idDaChave, exportar, mesclar })`, como no modelo.
- Regra de ouro da função `mesclar`: **nunca perder progresso**.
  - O que foi lido, feito ou acertado em qualquer lado continua valendo.
  - Listas e favoritos se juntam.
  - Contadores e recordes ficam com o maior valor.
  - As preferências do celular mandam, exceto numa recuperação ou quando o leitor ainda não tem nada neste celular.
- Recuperação:
  - Botão "☁️ Já tenho cadastro" no cadastro.
  - "☁️ Recuperar da nuvem" em "Quem vai estudar hoje?" e nas Configurações.
  - Cadastrar alguém com o mesmo nome + bichinho que já existe na nuvem traz o progresso sozinho.
- Configurações ganham a seção "☁️ Nuvem" (Situação, Código da família, Recuperar) e o pontinho de status na ⚙️ da tela inicial, como no Curiosidades.
- O `nuvem-config.js` volta **VAZIO** no pacote, igual ao modelo da referência. Eu troco pelo meu, que é o mesmo em todos os apps.

**5) Histórico de versões e proteção contra dados apagados.**
- **Histórico de versões:** o `nuvem-sync.js` v3 guarda, a cada envio, uma **cópia do dia** em `.../apps/<ID>/versoes/AAAA-MM-DD`. Neste app:
  - coloque o botão **"🕘 Versões guardadas"** na tela de recuperação (como no Curiosidades), listando os dias do leitor atual com um resumo do progresso de cada dia;
  - tocar num dia **junta** aquela versão com a atual (`NuvemSync.juntarVersao`): volta o que faltava e **nada é apagado**.
- **Regra da `mesclar`, por tipo de dado:**
  - feito, lido ou acertado em qualquer lado continua feito;
  - listas e conjuntos se juntam (união);
  - contadores, pontos, estrelas, recordes e níveis ficam com o **maior** valor;
  - tentativas e erros por item ficam com o **maior** de cada item;
  - onde parou e preferências: o celular manda, exceto numa recuperação.
- **Limpar histórico, cache, cookies ou dados do navegador:** garanta o máximo e **seja honesto sobre o limite**:
  - limpar histórico ou cache não perde nada;
  - limpar dados de sites/cookies: tudo que já subiu tem que voltar pela recuperação;
  - o único risco real é limpar **sem internet** com alteração ainda não enviada. Reduza ao mínimo: envio em ~1,5 s, tentar enviar ao minimizar, armazenamento persistente (já no módulo), pontinho laranja e o aviso **"⚠️ Não limpe os dados do navegador até conectar na internet"** quando houver fila sem internet, e manter o Exportar backup (se o app não tiver, me pergunte).
- Regras do Firestore (eu colo; é só para você saber): `usuarios`, `apps` e `versoes` com `allow read, create, update: if request.auth != null;`, sem delete. Sem `versoes` nas regras, o principal continua subindo e o app avisa.

### Como trabalhar

1. **Primeiro estude o app** e me explique em poucas linhas:
   - como ele guarda os leitores e o progresso no localStorage (quais chaves);
   - o que você vai sincronizar e como vai misturar;
   - como está o **cadastro** hoje: tem cadastro? Quais e quantos bichinhos? Em quantas linhas aparecem? Tem recuperação? Pode haver crianças com bichinho fora dos 8?
   - como está a parte de tela cheia, orientação e instalação hoje.

   **Se o app não tiver cadastro de crianças, pare e me proponha como fazer (item 8 do `PADRAO_CADASTRO_NOME_BICHINHO.md`) antes de implementar.** O progresso que já existe vira da primeira criança cadastrada. Se tiver cadastro, pode seguir direto.
2. Faça **edições cirúrgicas**: não reescreva o app e não quebre nada que já funciona.
3. **Não altere `nuvem-sync.js` nem `escola-pwa.js`.** Se for realmente necessário, explique antes, porque eles são compartilhados por todos os apps.
4. No `sw.js`:
   - suba a versão do cache;
   - não intercepte pedidos de outros endereços (Firebase);
   - coloque `nuvem-sync.js` e `escola-pwa.js` no cache de instalação;
   - busque `nuvem-config.js` na internet primeiro (como no modelo).
5. **Checagem tripla com testes automáticos.** Se você (IA) não conseguir rodar testes neste ambiente, confira no código item por item, diga **com clareza** o que foi testado de verdade e o que só foi conferido, e me passe um roteiro curto para testar no celular. **Nunca diga que testou o que não testou.** Use Playwright e um Firebase de mentira que intercepte `identitytoolkit`, `securetoken` e `firestore.googleapis.com`, com suporte a `currentDocument.updateTime` e `currentDocument.exists`. Os testes devem cobrir no mínimo:
   - **cadastro padrão, as 3 conferências do item 9 do `PADRAO_CADASTRO_NOME_BICHINHO.md`:**
     - funcionamento: os 8 oficiais na ordem, nenhum pré-escolhido, sem nome ou bichinho não cadastra, sem repetido, Enter, reabrir mantém, acesso, trocar leva o progresso, bichinho antigo funciona;
     - celular: os 8 numa linha, inteiros, com pelo menos 30 px e tocáveis, em 740×360, 640×360, 568×320, 1024×600, 360×740, 320×568, 412×915 e com teclado em 740×170, 640×150, 568×140, 360×420 e 320×300;
     - padronização igual ao documento;
   - app sem configuração funciona igual e não chama a nuvem;
   - o histórico antigo do celular sobe na primeira sincronização;
   - fila offline e envio quando a internet volta;
   - desmarcar ou alterar também sobe;
   - recuperação num celular limpo, pela tela;
   - recuperação automática ao cadastrar o mesmo nome + bichinho, sem apagar a nuvem;
   - mistura com dados de outro celular, inclusive outro celular gravando no meio do envio e relógio atrasado;
   - erro de regras mostrado em português;
   - regra da `mesclar` para cada tipo de dado de aprendizagem;
   - histórico de versões: cópia do dia criada, lista aparece, e juntar uma versão antiga traz o que faltava sem apagar o de hoje;
   - regras sem `versoes`: o principal sobe e o app avisa;
   - aviso "Não limpe os dados..." quando há fila sem internet;
   - tela acesa pedida ao abrir e de novo quando o sistema solta;
   - modo reserva quando o Wake Lock é recusado ou não existe;
   - convite de instalação: passo a passo manual, botão "Instalar agora", e sumir quando instalado ou aberto pelo ícone;
   - tela cheia no toque, sem atrapalhar campos de digitar nem o convite;
   - funcionamento offline com o service worker real;
   - os testes de regressão principais deste app.

   Mostre o resultado dos testes.
6. **Entregue:**
   - o zip pronto para o Netlify (index.html, sw.js, manifest, ícones, `nuvem-sync.js`, `escola-pwa.js` e `nuvem-config.js` vazio);
   - o `PROMPT_CONTINUACAO.md` deste app atualizado;
   - um checklist ✅/⬜ em português no fim, incluindo o que eu preciso fazer: trocar o `nuvem-config.js`, publicar, instalar pelo convite, digitar o código da família, conferir o pontinho verde, ver se a tela não bloqueia com o celular parado por 2 minutos, ver os 8 bichinhos numa linha acima do teclado (deitado e em pé) e trocar para um dos 8 o bichinho de quem ainda tiver um antigo.

Explique tudo em português simples.

`========== ATÉ AQUI ==========`

---

## ✅ Acompanhamento (conversas existentes)

| App | Pedido colado | 8 bichinhos numa linha | Zip recebido e testes ok | `nuvem-config.js` trocado | Publicado | Instalado pelo convite | Código digitado | Pontinho verde | Tela não bloqueia |
|---|---|---|---|---|---|---|---|---|---|
| 📚 Alfabetização | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| 🔢 Matemática | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| 📖 Fluência | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| 🦉 Coruja Explica | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| 📝 Provinha | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
| 📕 Historinhas | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ | ⬜ |
