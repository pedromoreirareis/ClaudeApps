# Relatório do Revisor A (Dados e nuvem): rodada 2

**App:** 📚 Alfabetização v122, zip corrigido (`zip_novo_r2`)
**Data:** 07/10/2026
**Pasta usada:** `/home/claude/revA/novo_r2`. Conferi que os 82 arquivos são idênticos aos do zip.

Não abri nenhum `documentos/RELATORIO_*`. Não confiei na lista de mudanças do autor: li as diferenças no código e rodei os testes de novo.

---

## Resumo em 1 minuto

- **Os 4 problemas 🟠 da rodada 1 foram corrigidos (A1 a A4).** Provei cada um rodando os mesmos testes que antes falhavam.
- **Os 🟡 conferidos também foram corrigidos (1, 2, 3, 5, 7, 8 e 10),** além do "AGORA NÃO", que agora vale 1 dia.
  - Para os 🟡 1, 2, 3 e 8 e para o "AGORA NÃO", o meu teste novo falha no zip da rodada 1 e passa no da rodada 2. Isso prova que o teste pega o problema e que a correção é real.
  - O 🟡 10 foi conferido só lendo o código.
- **Nada do que já funcionava quebrou:**
  - todos os testes do zip passam;
  - os meus testes de migração, de ida e volta ao v121, dos 2 celulares (v3 e v4), de tirar criança e da lixeira passam.
- **As correções criaram 3 pontos 🟡 novos, nenhum 🔴 ou 🟠.**

---

## Achados da rodada 1: corrigidos?

| Achado | Situação | Prova (RODADO) |
|---|---|---|
| 🟠 **A1** A ficha antiga virava uma 2ª criança ☁️ na T4 | ✅ **Corrigido** | `t6_mudar_varios_apps.py`: 2/2 (antes 1/2). A T4 não mostra mais o cartão `hana_1f98a`. O `teste_revisao.py` "A1/A3" passa. No código, `fichasVisiveis()` esconde qualquer ficha com `movidoPara`, o `trazer()` vai até o fim da cadeia e a T4 esconde a ficha nova quando a criança deste celular ainda está com o nome antigo (o aviso "MUDOU PARA" decide). |
| 🟠 **A2** Progresso da lixeira esquecido quando a criança volta pela nuvem | ✅ **Corrigido** | `t5_lixeira_e_nuvem.py`: 7/7 (antes 5/7). Pelo cartão ☁️ e pelo cadastro do mesmo nome + bichinho, a Bia volta com **5 frases** e a lixeira esvazia. No código, o novo `juntarLixeira()` é chamado no `trazer()` e no `criarNova()`. |
| 🟠 **A3** A T6 escondia de vez a ficha antiga; "AGORA NÃO" valia para sempre | ✅ **Corrigido** | `t1_compat_v3_v4.py`, parte 3: a ficha antiga agora aparece na T6 em "📦 Nomes antigos" (`aparece=1`; antes `0`). `t8_r2_leves.py`: o "AGORA NÃO" esconde o aviso no mesmo dia e o aviso volta depois de 1 dia, sem a ficha 🐰 virar uma 2ª criança ☁️ nesse meio-tempo. |
| 🟠 **A4** O `nuvem-sync.js` v4 jogava a fila fora se a lista desse erro | ✅ **Corrigido** | `t7_usuarios_erro.py`: na v122 agora fica a fila `['1']` e a nuvem chega a 2 frases, igual à v121 (antes: fila `[]` e nuvem com 1). No código, o novo `usuariosParaEnviar()` lança o erro, `sincronizar` e `checarNuvem` param no estado de erro e a fila não é mexida. |
| 🟡 1 Backup 👧 criava uma 2ª Hana | ✅ Corrigido | `t8`: junta na leitora "1" (10 + 2 = 12 frases, uma Hana só). No zip da rodada 1, o mesmo teste falha. |
| 🟡 2 O backup juntava numa criança de outra família | ✅ Corrigido | `t8`: a Lia da familia-bbb fica intacta (`11`) e o backup cria uma Lia na família atual. Na rodada 1, falha. |
| 🟡 3 `migrar()` apagava ligações se o `listar()` desse erro | ✅ Corrigido | `t8`: com o `listar()` falhando na abertura, a Lia continua ligada à familia-bbb. Na rodada 1, falha. |
| 🟡 5 Código não conferido ia para o `nuvem_familia` | ✅ Corrigido | `t3_bordas.py` e): o `nuvem_familia` não recebe o código não conferido, e ao voltar ao v121 nada sobe para o código errado (`subiu=False`; antes `True`). |
| 🟡 7 Lista da nuvem guardada por 60 s | ✅ Corrigido | Código: `buscarNuvemT4` usa `listaNuvem(f.c, true)`, ou seja, recarrega sempre ao abrir a T4. |
| 🟡 8 `marcarMovido` zerava a cadeia B→C | ✅ Corrigido | `t8`: A→B mantém B→C, e se B apontava de volta para A, zera (sem ciclo). Na rodada 1, falha. |
| 🟡 10 `tirarFamilia` desligava quem deu erro | ✅ Corrigido (só LIDO) | No código, `catch(e){ return; }` não tira a ligação nem a fila de quem deu erro, e `if(daFamilia(c).length)` mantém a família se alguém não saiu. |

## Problemas NOVOS (criados ou deixados pelas correções)

Nenhum é 🔴 ou 🟠.

1. 🟡 **O `sw.js` não mudou entre a rodada 1 e a rodada 2.** O md5 é o mesmo (`490e29fb…`) e o cache continua `esforco-vence-v122`, mas o `index.html`, o `escola-familia.js` e o `nuvem-sync.js` mudaram.
   - Se o zip da rodada 1 já tiver sido posto no site de teste, os celulares que já abriram o site **continuam com os arquivos da rodada 1 guardados**: o service worker não se atualiza quando o `sw.js` é idêntico.
   - Não perde dados, mas o teste no celular estaria testando o código velho.
   - **Sugestão:** a cada novo zip, mudar o nome do cache (ex.: `esforco-vence-v122-2`), ou garantir que a rodada 1 nunca foi publicada.
2. 🟡 **A lixeira continua parada se a criança voltar com outro nome.** O `juntarLixeira()` procura pelo nome + bichinho da criança que volta. Exemplo: a Hana 🦊 foi tirada com cópia e depois mudou para 🐰 em outro app. Quando ela volta como 🐰 (o `trazer()` vai até o fim da cadeia), a cópia guardada como 🦊 fica na lixeira. Continua recuperável em "🗑️ Tiradas deste celular". (LIDO.)
3. 🟡 **Com a família atual ainda "a conferir", o `nuvem_familia` não acompanha.** Agora o `salvar()` só grava o `nuvem_familia` com família conferida.
   - Se a família atual é "a conferir" (ex.: depois de tirar a única família conferida), o `nuvem_familia` continua com o código da família que saiu. Voltando ao v121 nessa janela, ele subiria para essa família.
   - Na mesma janela, um código digitado no v121 não "vence" ao voltar (caso H), porque `ultimoNuvemFamilia` fica vazio.
   - Só acontece voltando ao zip anterior durante a janela "a conferir". (LIDO.)

## O que eu RODEI de verdade (rodada 2)

**Arquivos (md5):**
- Os 82 arquivos da pasta batem com o zip.
- `nuvem-config.js` e `escola-pwa.js` são idênticos aos da v121.
- `compartilhados/escola-familia.js` e `compartilhados/nuvem-sync.js` são idênticos aos do `pacote-netlify`, do zip do Netlify (9 arquivos) e de `testes/`.

**Sintaxe:** `node --check` em todos os `.js`: OK.

**Testes do zip:**

| Teste | Resultado |
|---|---|
| Testes do Node | 89/89 |
| `teste_cadastro.py` | 72/72 |
| `teste_nuvem.py` | 81/81 |
| `teste_pwa.py` | 34/34 |
| `teste_familia.py` | 128/128 |
| `teste_revisao.py` (novo) | 46/46 |

Rodei com `PORTA=8801` a `8805`. Não rodei de novo o `teste_fonte.py`: a falha dele é do ambiente desta máquina (falha igual na v121) e é assunto do Revisor B.

**Meus testes contra a rodada 2:**

| Teste | Resultado |
|---|---|
| `t1_compat_v3_v4.py` | 21/21 |
| `t2_tirar.py` | 23/24 |
| `t3_bordas.py` | 8/10 |
| `t4_migracao_real.py` | 10/10 |
| `t5_lixeira_e_nuvem.py` | 7/7 |
| `t6_mudar_varios_apps.py` | 2/2 |
| `t7_usuarios_erro.py` | fila mantida |
| `t8_r2_leves.py` (novo) | 7/7 na rodada 2; 1/7 na rodada 1 (controle) |

As falhas que sobraram são do **meu** teste, não do app:
- `t2` d: o app grava o "dia/hoje" da criança aberta, o que é normal (já explicado na rodada 1).
- `t3` c: eu esperava 10 frases. Agora são 12 porque o backup **juntou**, que é a correção do 🟡 1.
- `t3` e: eu esperava o comportamento antigo do `nuvem_familia` (a correção do 🟡 5).

## O que eu só LI
- O 🟡 7 e o 🟡 10.
- Os 🟡 novos 2 e 3.
- O texto da pergunta "JUNTAR AS DUAS?" no "mudar" (T5): conferi no código; o teste do autor cobre.
- As mudanças de tela do `index.html` (barra de cima, chip): são do Revisor B.

## O que só um celular de verdade pode confirmar
- Dois celulares reais na família `teste-pedro-2026`: mudar o bichinho de uma criança que **também está em outro app**. A T4 não pode mostrar a criança antiga como ☁️, e ela deve aparecer só na T6 em "📦 Nomes antigos".
- Modo avião real: tirar com cópia, voltar a internet e trazer a criança pelo cartão ☁️. Ela tem que voltar com tudo.
- Que o celular está mesmo com os arquivos da rodada 2. Se o site de teste já tinha a rodada 1, veja o 🟡 novo 1.

---

✅ Pode publicar
