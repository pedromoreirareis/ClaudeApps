/* Confere que o sistema de backup/restauração por leitora (exportar pra
   arquivo .json, restaurar depois) continua incluindo as chaves NOVAS
   (hana_monta_ok, hana_silaba_ok) — se uma chave nova não entrar em
   CHAVES_LEITORA, ela não é exportada no backup nem limpa ao trocar/
   apagar leitora, e o progresso "vaza" ou fica orfão silenciosamente. */
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_07_backup_por_leitora');
  const dom = carregarApp();
  const { window } = dom;
  await esperar(300);

  t('coletarDadosBackup() inclui hana_monta_ok e hana_silaba_ok quando têm dado salvo', () => {
    window.marcarConcluida('monta', 3);
    window.marcarConcluida('silaba', 4);
    const dados = window.eval('coletarDadosBackup()');
    assert('hana_monta_ok' in dados, 'backup não incluiu hana_monta_ok — a chave está mesmo em CHAVES_LEITORA?');
    assert('hana_silaba_ok' in dados, 'backup não incluiu hana_silaba_ok');
    assert(JSON.parse(dados.hana_monta_ok).indexOf(3) >= 0, 'valor de hana_monta_ok no backup não bate com o que foi marcado');
  });

  t('validarBackup() aceita um objeto no formato certo e rejeita um objeto qualquer', () => {
    const bom = window.eval(`validarBackup({appId: APP_ID, dados: {}})`);
    const ruim = window.eval(`validarBackup({foo: 1})`);
    assertEq(bom, true, 'backup no formato certo devia ser válido');
    assertEq(ruim, false, 'objeto qualquer não devia passar como backup válido');
  });

  // v122 (decisão D14 do PLANO_CADASTRO_FAMILIA): importar backup JUNTA, não apaga mais.
  t('aplicarBackup() JUNTA: a marcação de antes (77) continua e a do backup (5) entra (nada é apagado)', () => {
    window.marcarConcluida('monta', 77); // progresso que já estava no celular
    window.eval(`
      window.location.reload = function(){}; // aplicarBackup recarrega no fim — vira no-op só pro teste
      aplicarBackup({appId: APP_ID, dados: {
        ev_perfis: JSON.stringify({perfis:[{id:'1',nome:'Hana',av:'🦊'}],atual:'1'}),
        hana_monta_ok: JSON.stringify([5])
      }});
    `);
    assertEq(window.estaConcluida('monta', 77), true, 'aplicarBackup apagou a marcação que já estava no celular (índice 77)');
    assertEq(window.estaConcluida('monta', 5), true, 'aplicarBackup não trouxe a marcação do backup (índice 5)');
  });

  t('Nenhuma chave de CHAVES_LEITORA está fora do padrão "hana_" (a prefixação por leitora só cobre hana_*)', () => {
    const chaves = window.eval('CHAVES_LEITORA');
    const foraDoPadrao = chaves.filter(k => k.indexOf('hana_') !== 0);
    assert(foraDoPadrao.length === 0, 'chaves fora do padrão hana_: ' + JSON.stringify(foraDoPadrao));
  });

  resumo();
})();
