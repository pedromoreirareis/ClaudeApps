# Relatório do revisor B (telas, crianças e celular) — v122b, rodada 2

Data: 07/10/2026 · Zip conferido: `/home/claude/revisao/v122b_r2/` · Minha pasta: `/home/claude/revB2/novo_r2/` · Capturas novas: `/home/claude/revB2/capturas/r2_*` · Scripts: `/home/claude/revB2/scripts/` (os mesmos da rodada 1 + `s8_r2_site.py`)

## Resumo em 1 minuto

- **Os dois problemas 🟠 da rodada 1 foram corrigidos de verdade.**
  - "🎉 Achei a sua família": **nenhum nome cortado** em nenhum dos 7 tamanhos, com 1, 2, 3, 4 e 6 crianças. "MARIA EDUARDA" e "PEDRO HENRIQUE" vão para 2 linhas; "MARIA CLARA" e "MARIA EDUARDA" agora dá para diferenciar.
  - Faixa roxa do site de teste: **não aparece mais na tela de estudo nem nas Configurações do app**. Só aparece com as telas da família abertas, e lá **não cobre nenhum botão, título nem campo**.
- Os 🟡 3, 4 e 5 também foram corrigidos: nomes inteiros na "Quem vai estudar hoje?", ✕ no "Achei" e o ⛶ não pede mais a tela cheia no app instalado.
- **Nada do funcionamento mudou.** Todas as suítes passaram; só o item "tirar criança" da `teste_familia` falha quando a máquina está carregada, e passa rodando sozinha (130/130). É o mesmo da rodada 1 e é só tempo de espera.
- Problemas novos: só 3 coisas 🟡 leves, nenhuma nos tamanhos do celular deitado do Pedro que atrapalhe o uso.

## Conferência dos achados da rodada 1

| Achado | Resultado | Prova |
|---|---|---|
| 🟠 1. "Achei": nomes cortados | ✅ **Corrigido** | `s2_achei.py` em 7 tamanhos × 1/2/3/4/6 crianças: nenhum nome com texto escondido (largura do texto = largura da caixa), letras ≥ 14 px, botões ≥ 48 px. `s7_marias.py`: "MARIA EDUARDA" 124/124 px, "MARIA CLARA" 112/112. Capturas: `r2_achei_marias_984x432.png` (2 Marias + 2 Joãos lado a lado, todos inteiros), `r2_achei6_984x432.png` (6 crianças em 3 + 3), `r2_achei4_937x411.png`, `r2_achei6_568x320.png`, `r2_achei6_360x740.png`. |
| 🟠 2. Faixa roxa por cima da barra de cima | ✅ **Corrigido** | `s8_r2_site.py` abre o app no endereço `escolasaopedrotestes.netlify.app` em 5 tamanhos: na tela de estudo e nas Configurações do app a faixa está **escondida** (`r2_site_app_984x432.png`: bolinha da nuvem no ⚙️ visível). Nas telas da família (T2, Achei, Quem vai estudar, Famílias, Buscar na nuvem, Cópias, Nova criança) ela aparece e o script procurou embaixo dela qualquer botão, título, campo, chip ou bolinha: **nada** (`r2_site_quem_984x432.png`, `r2_site_achei_568x320.png`, `r2_site_nova_568x320.png`). Com teclado aberto ela some e o cartão fica no meio (30/30 px). No site real a faixa não aparece e o código sem "teste" é aceito. |
| 🟡 3. "Quem vai estudar hoje?": cartões estreitos, nomes cortados | ✅ Corrigido | Nomes inteiros em 2 linhas ("MARIA / EDUARDA ☁️", "NOVA / CRIANÇA"): `r2_T4_740x360.png`, `r2_T4_568x320.png`, `r2_T4_984x432.png`. Nenhum texto cortado na medição. |
| 🟡 4. "Achei" sem cancelar | ✅ Corrigido | ✕ de 48 × 48 px no canto do cartão; tocar fecha o pop-up e **não muda nada** na família (conferido no estado salvo) — em 984, 937, 740, 568 e 360. Deitado não encosta no título. |
| 🟡 5. ⛶ no app instalado pedia a tela cheia | ✅ Corrigido | Contando os pedidos com o app "aberto pelo ícone" (tela cheia): ao abrir 0, depois de tocar na tela 0, no ⛶ da barra 0, no ⛶ da "Quem vai estudar" 0, tecla F 0. No navegador continua pedindo como antes (1 → 3 → 5 → 6). A trava de "deitado" continua (1 chamada). |
| 🟡 6. 568x320 sem internet (3 px) | Deixado de propósito | Igual à rodada 1 (`r2_semnet_T4_568x320.png`). Não acontece nos celulares do Pedro. |
| 🟡 7. 6 crianças a 984 px em 5 + 1 | ✅ Corrigido | Agora 3 + 3 (`r2_achei6_984x432.png`). |

## Problemas NOVOS (todos 🟡, leves)

1. 🟡 **No segundo Motorola do Pedro (937x411), 4 crianças no "Achei" ficam em 3 + 1**, não "todas numa fileira" como o autor disse (`r2_achei4_937x411.png`). Motivo: 4 cartões de 200 px + espaços precisam de ~862 px e sobram ~856 px dentro do cartão. Tudo continua legível e inteiro. Se quiser 4 numa fileira: cartão de 196 px ou espaço menor entre os cartões no modo deitado. Em 984x432 os 4 ficam numa fileira só.
2. 🟡 **Em pé (360x740), o ✕ do "Achei" encosta no "!" do título** "🎉 ACHEI A SUA FAMÍLIA!" (`r2_achei6_360x740.png`). Só em pé; deitado não encosta em nenhum tamanho. Sugestão: dar uns 40 px de margem lateral ao título quando o ✕ está à vista.
3. 🟡 **Só no site de teste:** as telas da família ganharam 30 px em cima (para a faixa). No celular pequeno de 568x320, na "Quem vai estudar hoje?", o texto da nuvem no rodapé passa um pouco da borda de baixo ("(ÀS 18:46)" fica meio cortado) (`r2_site_quem_568x320.png`). Nos tamanhos do Pedro (984x432, 937x411) e em 740x360 cabe (`r2_site_quem_937x411.png`, `r2_site_quem_740x360.png`). No site de verdade isso não existe (sem faixa, sem os 30 px).

Observação (não é problema): na "Quem vai estudar hoje?" os nomes vão até 2 linhas; um nome de 3 palavras longas (ex.: "MARIA EDUARDA CRISTINA") ganharia "…" na 3ª linha. No "Achei" não há limite de linhas.

## Conferência dos arquivos

| Conferência | Resultado |
|---|---|
| `nuvem-config.js` (pacote e zip do Netlify) | ✅ md5 `1d5f060a5ae8339921d3d58498807971` |
| `escola-pwa.js` e `nuvem-sync.js` iguais aos da v122 | ✅ `ec31bf4a…` e `c953cfd3…` |
| Zip do Netlify | ✅ 9 arquivos na raiz |
| `compartilhados/` = `pacote-netlify/` = `testes/` = zip | ✅ md5 iguais em todos os arquivos do app |
| `sw.js` | ✅ `esforco-vence-v122b` (igual ao da rodada 1, que **não** foi publicada; a v122 publicada usa `esforco-vence-v122`, então o celular vai trocar o cache) |
| O que mudou da rodada 1 para a 2 | Conferido com `diff`: `escola-familia.js` só CSS + o ✕ + `--cols` + a classe `ef-no-site-teste` + a constante `VERSAO='1.1'`; `index.html` só 3 linhas no `toggleFs()` (não pede tela cheia se já está em tela cheia do app). Nenhuma mudança em lógica de dados. |

## O que eu RODEI

| Suíte (pasta `novo_r2/testes`) | Resultado |
|---|---|
| Testes Node | ✅ tudo passou |
| `teste_desenho.py` (ampliado) | ✅ 121/121 |
| `teste_cadastro.py` | ✅ 72/72 |
| `teste_revisao.py` | ✅ 59/59 |
| `teste_pwa.py` | ✅ 34/34 |
| `teste_nuvem.py` | ✅ 81/81 |
| `teste_familia.py` | ✅ 130/130 rodando sozinha; 129/130 rodando junto com outras suítes (item "tirar criança: as chaves somem", que só espera 3,5 s — igual à rodada 1; a lógica de tirar não foi tocada) |
| `teste_fonte.py` | 57/58 — a falha antiga desta máquina, igual na v122 |

Meus scripts na rodada 2: `s1_teclado.py` (teclado depois do toque, 7 tamanhos, 3 voltas: no meio, com foco — igual à rodada 1), `s2_achei.py`, `s7_marias.py`, `s3_config.py` (984, 937, 568: igual à rodada 1, nada fora da linha), `s4_telas.py` (T1, T3 "anote", T4, arrumar, pergunta, T6, T8, Cópias, T5), `s5_host_fs.py` e `s8_r2_site.py` (site de teste, faixa, ✕, ⛶), `s6_semnet.py` (sem internet).

## O que só o celular de verdade confirma

1. O aviso do Chrome "Para sair da tela cheia, arraste…" sumir **no app aberto pelo ícone** (talvez seja preciso desinstalar e instalar de novo se o app foi instalado com o manifest antigo). **Na aba do Chrome ele continua** — é regra do Chrome.
2. O cartão do código no meio da área acima do teclado de verdade (com a barra de senhas do Chrome).
3. Como fica a faixa roxa no Motorola (agora só nas telas da família).

✅ Pode publicar
