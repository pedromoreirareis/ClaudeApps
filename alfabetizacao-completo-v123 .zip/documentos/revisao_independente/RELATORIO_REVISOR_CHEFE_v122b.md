# Relatório do revisor-chefe (camada 3) — 📚 Alfabetização v122b (SITE DE TESTE)

Data: 07/10/2026 · Revisor-chefe independente (não participou do trabalho) · Minha pasta: `/home/claude/revC2/` (zip final extraído em `final/` e `netlify/`; capturas em `capturas/`; scripts em `scripts/`; registros em `logs/`)

---

## Resumo em 1 minuto

- **Os 5 pedidos do Pedro foram atendidos** e eu conferi com os meus próprios olhos e scripts nos 7 tamanhos (984×432, 937×411, 740×360, 640×360, 568×320, 1280×800, 360×740):
  - teclado aberto: a caixa do código fica **no meio** (ex.: 937×411 com teclado: 27 px em cima e 27 px embaixo), o campo continua com o cursor;
  - Configurações deitado usam a largura (880 px no Motorola de 937; 924 px no de 984), opções em 2 colunas; "☁️ Família e nuvem" com texto à esquerda e botões numa linha à direita;
  - "🎉 Achei a sua família": largo, **4 crianças numa fileira** nos 2 Motorolas, 6 crianças em 3 + 3, nomes compridos inteiros (MARIA EDUARDA, PEDRO HENRIQUE em 2 linhas), ✕ no canto sem encostar no título (nem em pé);
  - aviso do Chrome: explicado com honestidade (na aba do Chrome **nenhum site** consegue esconder); com o app instalado o app deixa de pedir a tela cheia;
  - respiro geral: "Quem vai estudar hoje?", "Famílias", perguntas, nova criança — tudo sem nada cortado, letras ≥ 14 px e botões ≥ 48 px nas telas da família (fora os bichinhos em pé, que já eram assim).
- **A reconstrução da v122 é verdadeira:** os 9 arquivos de `base122/pacote-netlify/` são **idênticos byte a byte** aos baixados do site de teste (o `index.html` difere só pela linha que o Netlify injeta).
- **Todos os testes rodaram de novo aqui, sobre o zip final: 643/644** — iguais aos números do autor. A única falha é a antiga da fonte (desta máquina, igual na v121/v122).
- **O item instável da família (C1) é mesmo o C1 antigo, e a v122 publicada tem o mesmo comportamento**: medi as chaves sendo apagadas e, ~40 ms depois, regravadas pela função `nuvemMesclar` do `index.html`, **nas duas versões** (com a máquina carregada: v122 em 7 de 10 vezes, v122b em 3 de 10). Não tem relação com o desenho.
- **Achei 1 coisa nova, pequena (🟡):** na **aba do Chrome** (sem instalar), depois que o app entra em tela cheia, o botão ⛶ (e a tecla F) **não tira mais** da tela cheia — na v122 tirava. Não perde nada e, na prática, o app já volta à tela cheia no toque seguinte; corrige com 1 linha. Mais 3 🟡 leves (um caso de teclado que só o celular confirma, lacunas no teste novo e frases velhas nos documentos).
- **Nenhum 🔴 e nenhum 🟠.** Pacote certo (9 arquivos na raiz, `nuvem-config.js` do Pedro, cache novo `esforco-vence-v122b`, LEIA-ME com os 94 md5 batendo).

**Veredito (para o SITE DE TESTE): ✅ Pode publicar.** (última linha)

---

## 1. Conferência da reconstrução da v122 (a máquina do autor foi reciclada)

Comparei `base122/pacote-netlify/*` com `revisao/anterior/v122_publicado/*` (baixados do site de teste do Pedro) por md5 — **rodado**:

| Arquivo | v122 reconstruída | v122 do site | v122b (final) |
|---|---|---|---|
| `escola-familia.js` | `8872b010…` | `8872b010…` ✅ igual | `dc8b9860…` (1.1, mudou) |
| `nuvem-sync.js` | `c953cfd3…` | igual ✅ | igual ✅ |
| `escola-pwa.js` | `ec31bf4a…` | igual ✅ | igual ✅ |
| `nuvem-config.js` | `1d5f060a…` | igual ✅ | igual ✅ |
| `manifest.webmanifest`, `icon-192.png`, `icon-512.png` | — | iguais ✅ | iguais ✅ |
| `sw.js` | `490e29fb…` (`esforco-vence-v122`) | igual ✅ | `da2e1db3…` (`esforco-vence-v122b`) |
| `index.html` | `c0e7f845…` (6720 linhas) | 6721 linhas; **tirando só** a linha `<script … /.netlify/scripts/hud …>` o md5 dá `c0e7f845…` ✅ | `a925c555…` |

Conclusão: o que o autor usou como "v122" é exatamente o que está publicado. O `trabalho/versoes_anteriores/index_v122.html` do zip também tem `c0e7f845…`.

---

## 2. Achados da camada 2 (revisor B) — estão corrigidos no zip FINAL?

Também conferi com `diff` que, da rodada 2 do B para o zip final, **só o `escola-familia.js` mudou, e só em 2 linhas de CSS** (margem de 54 px no título do "Achei" e espaço fixo de 14 px entre cartões). Os outros 8 arquivos são idênticos.

| Achado do B | Situação no zip final | Prova (minha) |
|---|---|---|
| R1 🟠1 nomes cortados no "Achei" | ✅ corrigido | `revc.py`: MARIA EDUARDA, MARIA CLARA, PEDRO HENRIQUE, JOÃO PEDRO inteiros nos 7 tamanhos (nenhum texto escondido); capturas `937x411_achei4longos.png`, `568x320_achei4longos.png`, `360x740_achei4longos.png` |
| R1 🟠2 faixa roxa por cima da barra do app | ✅ corrigido | no endereço `escolasaopedrotestes.netlify.app`: depois de TRAZER TODAS a faixa **não** aparece no app (984 e 937); no "Achei" ela não cobre o ✕ (`site_937x411_achei.png`) |
| R1 🟡3 cartões estreitos na "Quem vai estudar" | ✅ corrigido | `937x411_T4.png`, `568x320_T4.png`: nomes compridos em 2 linhas, sem "…" |
| R1 🟡4 "Achei" sem cancelar | ✅ corrigido | ✕ de 48 px no canto; fecha sem mudar nada (teste do autor) |
| R1 🟡5 ⛶ no app instalado pedia tela cheia | ✅ corrigido **no app instalado** — mas veja o meu achado 🟡 A (efeito colateral na aba do Chrome) | `fs_real.py` |
| R1 🟡6 568×320 sem internet (3 px) | ⬜ deixado de propósito (documentado) | — |
| R1 🟡7 6 crianças em 5 + 1 | ✅ corrigido | 6 crianças em **3 + 3** em 984×432 e 937×411 |
| R2 🟡1 4 crianças em 3 + 1 no 937×411 | ✅ corrigido (mudança depois da rodada 2) | **4 numa fileira** em 937×411 e 984×432 (`937x411_achei4longos.png`) |
| R2 🟡2 ✕ encostando no título em pé | ✅ corrigido (mudança depois da rodada 2) | `360x740_achei4longos.png`: o título quebra em 2 linhas e fica longe do ✕ |
| R2 🟡3 site de teste + 568×320: rodapé da "Quem vai estudar" | ⬜ deixado (documentado nas pendências; só site de teste e celular pequeno) | — |

---

## 3. Matriz "pedido → prova" do autor, conferida

| Pedido | Teste citado existe? | Passa no zip final (rodei)? | Prova o que diz? |
|---|---|---|---|
| Teclado: caixa no meio | ✅ `teste_desenho` 1 e `teste_cadastro` | ✅ 121/121 e 72/72 | ✅ Sim (mede sobra em cima = embaixo ±12 px, foco, sem sobra no cartão). Limite: simula o teclado encolhendo a janela inteira; o modo do Chrome que só encolhe a "parte visível" não dá para simular aqui (o B já disse isso). |
| Configurações usam a largura | ✅ `teste_desenho` 3 | ✅ | ✅ Sim (largura ≥ 90%, 2 colunas, nada para o lado) |
| "Família e nuvem" sem botões empilhados | ✅ `teste_desenho` 3 + trava do adulto | ✅ | ✅ Sim. Eu acrescentei: segurar só 1,5 s **não** libera MOSTRAR, ABRIR, ENTRAR/CRIAR/TIRAR família; 3,3 s libera |
| "Achei" legível com 3–4 crianças | ✅ `teste_desenho` 2, `teste_familia` 2 | ✅ 121/121 e 130/130 | ✅ quase tudo. **Lacunas** (achado 🟡 C): o teste não confere "4 crianças numa fileira em 937 px" nem o ✕ em pé (as 2 últimas mudanças) — **eu conferi à mão: estão certas** |
| Aviso do Chrome | ✅ `teste_desenho` 7 | ✅ | ✅ **no que diz** (app instalado = 0 pedidos). Mas o teste troca o `requestFullscreen` e o `matchMedia` por imitações, por isso **não pega** o efeito na aba do Chrome (achado 🟡 A) |
| Respiro em todas as telas | ✅ `teste_desenho` 4 + capturas | ✅ | ✅ Sim; minhas medições nos 7 tamanhos não acharam letra < 14 px, botão < 48 px (fora os bichinhos em pé), nada fora da tela nem rolagem para o lado nas telas da família |
| Site de teste do Pedro reconhecido | ✅ `teste_familia` 2, `teste_desenho` 6 | ✅ | ✅ Sim. Eu rodei o fluxo inteiro no endereço dele com `PMRTESTES` → "Achei" → TRAZER TODAS: trouxe as crianças, família `pmrtestes`, faixa some no app; "SOU NOVO" sugere `teste-tigre-9521` |
| Nada do funcionamento muda | "todas as suítes passam" | ✅ 643/644 | ✅ para dados/nuvem/família. ⚠️ Uma exceção pequena fora dos dados: o ⛶ na aba do Chrome (achado 🟡 A) |
| Cache novo | ✅ `teste_pwa` | ✅ 34/34 | ✅ |
| Arquivos compartilhados | md5 | ✅ (eu conferi) | ✅ |

Não marquei nenhum ✅ do autor como "sem prova".

---

## 4. O que mudou entre a v122 e a v122b (li o `diff` inteiro)

- `nuvem-sync.js`, `escola-pwa.js`, `nuvem-config.js`, `manifest`, ícones: **idênticos** (md5).
- `sw.js`: só o comentário e o nome do cache (`esforco-vence-v122b`).
- `index.html` (3 trechos): CSS das Configurações; `JA_TELA_CHEIA_DO_APP` (não pede a tela cheia ao abrir nem passa `telaCheia` ao `escola-pwa.js` quando aberto pelo ícone); 1 linha no `toggleFs` (⛶).
- `escola-familia.js` (1 → 1.1): quase tudo CSS. O que **não** é só CSS, e está explicado nos documentos:
  1. `siteDeTeste()`: agora qualquer endereço com "teste" (o do Pedro passa a ser reconhecido). Conferi que nenhum dos 7 endereços de verdade tem "teste".
  2. No site de teste, o código precisa **conter** "teste" (antes: começar com). `pmrtestes` passa.
  3. Botões novos no "Achei": **← OUTRO CÓDIGO** (limpa o resultado e volta o cursor ao campo) e **✕** (o mesmo "fechar" do CANCELAR); ESCOLHER e TRAZER TODAS trocaram de lugar (mesmas ações).
  4. Botão do adulto "curto" (sem o "PEÇA PARA UM ADULTO" embaixo; o toque rápido mostra o aviso). A trava de 3 s é a mesma função.
  5. O código da família aparece em CAIXA ALTA (só aparência; o código é guardado em minúsculas e o que se digita é convertido).
  - Nada mexe em gravar/ler progresso, tirar criança, migração ou nuvem.

---

## 5. Meus achados

### 🟡 A. Na aba do Chrome, o ⛶ (e a tecla F) não tira mais da tela cheia

- **O que acontece:** a mudança no `toggleFs()` (`index.html` linha ~6348) pergunta ao navegador "estou em `display-mode: fullscreen`?" **na hora do toque**. No Chromium, essa pergunta passa a responder "sim" também quando a **própria página** entrou em tela cheia (pelo toque, como o app faz na aba). Então, na aba, o ⛶ vira um botão que não faz nada.
- **Prova (RODADO, Chromium daqui, sem imitações):** `scripts/fs_real.py`
  - v122 publicada: tocar na tela → tela cheia; tocar no ⛶ → **sai** da tela cheia.
  - v122b: tocar na tela → tela cheia; tocar no ⛶ → **continua** em tela cheia; tecla F → continua.
- **Por que é leve:** não perde nada; na aba, o `escola-pwa.js` já volta para a tela cheia no toque seguinte (então, na v122, sair pelo ⛶ durava só até o próximo toque); o "voltar" do Android continua tirando da tela cheia. No app instalado (o caso que importava) está certo.
- **Só o celular confirma** se o Chrome do Android responde do mesmo jeito que o do computador.
- **Por que o teste não pegou:** o `teste_desenho` 7 troca o `requestFullscreen` por um contador, e a página nunca entra de verdade em tela cheia.
- **Sugestão (1 linha, para a v123):** no `toggleFs()`, trocar `if(window.matchMedia('(display-mode: fullscreen)').matches) return;` por `if(JA_TELA_CHEIA_DO_APP) return;` (o valor medido **ao abrir**, quando a página ainda não pediu tela cheia). E um teste sem imitação, como o `fs_real.py`.
- **Documento:** o HISTORICO 3.11 diz "nem pelos botões ⛶" (certo para o app instalado), mas o relatório diz "nada do funcionamento muda" — vale registrar esta pequena exceção.

### 🟡 B. Teclado aberto + tecla azul de "buscar" do teclado → "Achei" pode aparecer cortado (só o celular confirma)

- **O que vi:** no Chromium, com a janela reduzida como se o teclado estivesse aberto (984×125), apertar Enter mostra o "Achei" com os cartões e os botões **abaixo da área visível** (`984x432_achei_comteclado.png`). O campo some, e o cursor sai dele (vai para o corpo da página) — no celular de verdade isso **deve** fechar o teclado sozinho, e aí tudo aparece inteiro (como na captura normal).
- **Pedro, confira:** digite `pmrtestes` e aperte a **lupa azul do teclado** (não o botão verde). O teclado tem que fechar e o "Achei" aparecer inteiro. Se o teclado ficar aberto e esconder os botões, é 🟠 para a v123.
- **Sugestão:** ao mostrar o "Achei", tirar o cursor do campo de propósito (`campo.blur()`), por garantia.

### 🟡 C. O teste novo não cobre as 2 últimas mudanças e usa uma chave de nuvem fora do formato

- `teste_desenho.py` não confere "4 crianças numa fileira em 937 e 984" nem "✕ longe do título em pé" (as 2 mudanças feitas depois do B). Eu conferi à mão e **estão certas**, mas falta o teste para não voltar.
- Na parte dos nomes compridos, o teste grava na nuvem de mentira `mariaeduarda_1f430`, mas o app procura `maria-eduarda_1f430` (com tracinho). Não muda o que o teste mede (os nomes aparecem no "Achei"), mas se alguém usar esses dados para testar o TRAZER TODAS vai ver crianças repetidas — eu caí nisso e conferi de novo com a chave certa: tudo certo (5 frases cada, sem repetição; `937x411_T4_trazido_certo.png`).

### 🟡 D. Documentos com frases velhas (nenhuma engana sobre o que vai para o site)

- `HISTORICO` 9.2 ainda diz `CADASTRO: 55/55`, `NUVEM: 75/75`, `PWA: 33/33` (hoje 72, 81, 34) e "Não há `package-lock.json`" (há, em `testes/`). Já estava assim na v122.
- `HISTORICO` capítulo 1, no aviso sobre documentos antigos: "o zip do Netlify leva os **8** arquivos" e "hoje são **310** testes" (hoje 9 e 644). Já estava assim na v122.
- `PROMPT_CONTINUACAO`: "644 testes (… fonte 58 …)" sem dizer que, nesta máquina, a fonte dá 57/58 (o HISTORICO 9.5 e o relatório dizem certo).
- `RELATORIO_CHECAGEM` parte 5 manda ler `revisao_independente/RELATORIO_REVISOR_CHEFE_v122b.md`, que ainda não está no zip. Ao colocar este relatório lá, **refazer o `LEIA-ME.txt`** (lista de md5) e o zip completo — o zip do Netlify não muda.
- `INSTRUCOES` §1.4 "como saber se pegou": o sinal mais fácil é a **faixa roxa** nas telas da família (ou as Configurações largas), não o "Achei" (que exige procurar a família).

### Confirmado (sem achado)

- **C1 / item instável do `teste_familia`:** a explicação do autor se sustenta. Com o meu `scripts/c1c.py` (repete "tirar a Bia" e registra cada gravação no armazenamento do celular): as 22 chaves `p2_…` são apagadas e, **~40 ms depois**, 3 delas (`p2_hana_done`, `p2_hana_fav`, `p2_hana_trilha_v2`) são regravadas por `nuvemMesclar` (`index.html` linha 6508 na v122 = 6519 na v122b, a mesma função; as 11 linhas de diferença são o CSS novo). Com a máquina carregada: **v122 publicada 7/10, v122b 3/10**; sem carga: 0/10 nas duas. Mesmo comportamento → não foi o desenho. A criança não volta para a lista e não se perde nada (são os dados que já estão na nuvem). Continua valendo corrigir **antes** de levar o módulo para a Matemática e o Fluência.
- **Trava do adulto nos botões curtos:** toque rápido mostra "PEÇA PARA UM ADULTO…" e não abre; segurar 1,5 s não abre; 3,3 s abre (MOSTRAR, ABRIR das cópias, ENTRAR/CRIAR/TIRAR família).
- **Voltar do Android no "Achei":** fecha e volta para "Olá! Vamos começar?", sem mudar nada guardado (984 e 937).
- **← OUTRO CÓDIGO e procurar de novo:** o campo volta com o cursor; um código que não existe mostra "não achei"; procurar `pmrtestes` de novo mostra as 4 crianças; TRAZER TODAS traz as 4. Em todos os 7 tamanhos.
- **Teclado abrindo depois do toque:** toquei no campo com a tela inteira e só depois encolhi (2 alturas de teclado, 6 tamanhos deitado): sempre no meio, com o cursor no campo.
- **App instalado sem pedir tela cheia:** a tela sempre acesa continua (o `telaCheia:false` só desliga o pedido de tela cheia no `escola-pwa.js`; conferido no código), e a trava de "deitado" continua ao abrir.

### Observação (não é do app)

- Nas capturas do Pedro aparece um selo **"Powered by Netlify"** no canto de baixo à direita (por cima do botão "SOU NOVO" e perto do teclado). Ele vem do próprio Netlify (é a linha `…/.netlify/scripts/hud…` que o Netlify coloca no `index.html` publicado), não do app — o app não consegue tirar. Não sei dizer se há uma opção no painel do Netlify para desligá-lo.

### Coisas antigas (já eram assim na v122; só para registro)

- Nas Configurações, os valores das opções do app ("Pastel", "20", "ABC · bastão") têm letra de 11–13 px.
- Em pé (360×740), os bichinhos da "nova criança" têm 37 px de altura (menos que 48 px).

---

## 6. Pacote (rodado)

| Item | Resultado |
|---|---|
| Zip do Netlify: 9 arquivos, todos na raiz | ✅ `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`, `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js`, `escola-familia.js` |
| `nuvem-config.js` md5 `1d5f060a5ae8339921d3d58498807971` | ✅ (zip do Netlify e `pacote-netlify/`; o de `testes/` é o falso, de propósito) |
| `sw.js` com `esforco-vence-v122b` (publicado: `esforco-vence-v122`) | ✅ diferente → o celular troca o que guardou |
| `compartilhados/` = `pacote-netlify/` = `testes/` = zip do Netlify (arquivos do app) | ✅ md5 iguais |
| `nuvem-sync.js` e `escola-pwa.js` iguais aos da v122 | ✅ |
| `LEIA-ME.txt`: 94 arquivos listados, 94 no zip, todos com tamanho e md5 batendo | ✅ (conferido um por um) |

---

## 7. O que eu RODEI × só LI

**Rodei de verdade** (Chromium sem tela + Firebase de mentira; nunca o real; portas 8910–8983):

| Suíte (zip final) | Resultado |
|---|---|
| rápidos (Node) | **89/89** |
| `teste_desenho.py` | **121/121** |
| `teste_familia.py` | **130/130** |
| `teste_cadastro.py` | **72/72** |
| `teste_nuvem.py` | **81/81** |
| `teste_pwa.py` | **34/34** |
| `teste_revisao.py` | **59/59** |
| `teste_fonte.py` | **57/58** (a falha antiga: Ler 412×915 em pé, tamanho 24, 86% em vez de 90%) |
| **Total** | **643/644** — igual ao do autor |

Meus scripts (`/home/claude/revC2/scripts/`):
- `revc.py` — os 7 tamanhos: boas-vindas, código, teclado (2 alturas), Enter com teclado, "Achei" com 4 nomes compridos, ← OUTRO CÓDIGO, "não achei", procurar de novo, TRAZER TODAS, "Quem vai estudar", Configurações (topo, "Família e nuvem", fim), Famílias, nova criança; medição de letra, botão, texto cortado, fora da tela e rolagem para o lado; 6 crianças nos 2 Motorolas; voltar do Android; trava do adulto (rápido / 1,5 s / 3,3 s); site de teste com `PMRTESTES`. Saída: `logs/revc.txt`; 101 capturas em `capturas/`.
- `fs_real.py` — tela cheia de verdade (sem imitação), na v122 e na v122b.
- `c1.py`, `c1b.py`, `c1c.py` — o C1, nas duas versões, com e sem carga, com registro de cada gravação.
- `trazer.py` — TRAZER TODAS com as chaves no formato certo.
- md5 de tudo; `diff` v122 → v122b e rodada 2 do B → final.

**Só li (não rodei):** o modo do teclado do Chrome que encolhe só a parte visível; se o Chrome do Android trata `display-mode` igual ao do computador; o `escola-pwa.js` (que não mudou) quanto à tela sempre acesa no app instalado.

---

## 8. O que só o celular de verdade confirma

1. **App instalado** (ícone): o aviso "Para sair da tela cheia, arraste…" não aparece mais (talvez precise apagar o ícone e instalar de novo). **Na aba do Chrome ele continua** — regra do Chrome.
2. Na **aba do Chrome**: o ⛶ ainda tira da tela cheia? (achado 🟡 A — aqui no computador, não tira mais).
3. Teclado de verdade (com a barra de senhas do Chrome): a caixa no meio do espaço que sobra.
4. **Lupa azul do teclado** no código: o teclado fecha e o "Achei" aparece inteiro (achado 🟡 B).
5. "Achei" com 3–4 crianças de teste, e as letras das telas da família na TV a 3 m.

---

## 9. Para o autor (antes da v123, nada bloqueia o site de teste)

- 🟡 A: `toggleFs` usar `JA_TELA_CHEIA_DO_APP` + teste sem imitação.
- 🟡 B: `campo.blur()` ao mostrar o "Achei".
- 🟡 C: testes para "4 numa fileira em 937/984" e "✕ em pé"; chaves com tracinho nos nomes compridos.
- 🟡 D: acertar as frases velhas do HISTORICO (9.2 e capítulo 1) e do PROMPT; colocar este relatório no zip e refazer o `LEIA-ME.txt`.
- C1 a C5 continuam como estão no capítulo 11.

✅ Pode publicar
