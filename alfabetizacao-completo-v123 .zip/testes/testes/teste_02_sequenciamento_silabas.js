/* Pedido do Pedro: a trilha "Próxima sílaba" nunca pode morrer no fim
   de uma família/grupo — tem que seguir pra próxima letra/família.
   Aqui testamos calcularProximaSilaba() nos 3 casos: meio da família
   (avança normal), fim da família (pula pra próxima letra) e fim de
   TUDO (não existe próxima — deve devolver null sem quebrar). */
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_02_sequenciamento_silabas');
  const dom = carregarApp();
  const { window } = dom;
  await esperar(300);

  t('Sílabas Simples — no MEIO da família, avança pra próxima sílaba da mesma família', () => {
    const r = window.eval(`
      (function(){
        var fam = SILABAS_FASE1[0];
        _lpAncora = {tipo:'simples', fam:fam.fam, sil:fam.silabas[0].s};
        var info = calcularProximaSilaba();
        return {ok: !!info, novaFamilia: info && info.proximo.novaFamilia, rotulo: info && info.proximo.rotulo};
      })()
    `);
    assert(r.ok, 'esperava info não-nulo no meio da família');
    assert(!r.novaFamilia, 'não devia marcar novaFamilia no meio da família (rotulo=' + r.rotulo + ')');
  });

  t('Sílabas Simples — família do P, última palavra (PÃO), pula pra T · TA (caso literal do Pedro)', () => {
    const r = window.eval(`
      (function(){
        var fam = SILABAS_FASE1.find(function(x){ return x.fam === 'P'; });
        var last = fam.silabas[fam.silabas.length - 1];
        _lpAncora = {tipo:'simples', fam:fam.fam, sil:last.s};
        var info = calcularProximaSilaba();
        return {ultimaSil: last.s, info: info};
      })()
    `);
    assertEq(r.ultimaSil, 'pão', 'esperava que a última sílaba da família do P fosse "pão" (mudou a ordem dos dados?)');
    assert(r.info, 'esperava sugestão de próxima família ao terminar o P');
    assert(r.info.proximo.novaFamilia === true, 'esperava novaFamilia=true ao cruzar de família');
    assert(/^T\s*·\s*TA$/i.test(r.info.proximo.rotulo), 'esperava rótulo "T · TA", veio "' + r.info.proximo.rotulo + '"');
  });

  t('Sílabas Simples — na ÚLTIMA família de todas (a última do array), não quebra e devolve null', () => {
    const r = window.eval(`
      (function(){
        var fam = SILABAS_FASE1[SILABAS_FASE1.length - 1];
        var last = fam.silabas[fam.silabas.length - 1];
        _lpAncora = {tipo:'simples', fam:fam.fam, sil:last.s};
        var info = calcularProximaSilaba();
        return {fam: fam.fam, info: info};
      })()
    `);
    assertEq(r.info, null, 'esperava null na última sílaba da última família (fam=' + r.fam + '), veio ' + JSON.stringify(r.info));
  });

  t('Sílabas Complexas — no MEIO do grupo, avança pro próximo padrão do mesmo grupo', () => {
    const r = window.eval(`
      (function(){
        var m0 = SILABAS_COMPLEXAS_MACRO[0];
        var grupo = SILABAS_COMPLEXAS_GRUPOS[m0.id];
        if(grupo.padroes.length < 2) return {pulo:true};
        _lpAncora = {tipo:'complexas', grupoId:m0.id, padraoId:grupo.padroes[0].id};
        var info = calcularProximaSilaba();
        return {ok: !!info, novaFamilia: info && info.proximo.novaFamilia};
      })()
    `);
    if(!r.pulo){
      assert(r.ok, 'esperava info não-nulo no meio do grupo');
      assert(!r.novaFamilia, 'não devia marcar novaFamilia no meio do grupo');
    }
  });

  t('Sílabas Complexas — no último padrão do último grupo, não quebra e devolve null', () => {
    const r = window.eval(`
      (function(){
        var mLast = SILABAS_COMPLEXAS_MACRO[SILABAS_COMPLEXAS_MACRO.length - 1];
        var grupo = SILABAS_COMPLEXAS_GRUPOS[mLast.id];
        var lastPd = grupo.padroes[grupo.padroes.length - 1];
        _lpAncora = {tipo:'complexas', grupoId:mLast.id, padraoId:lastPd.id};
        var info = calcularProximaSilaba();
        return {grupoId: mLast.id, info: info};
      })()
    `);
    assertEq(r.info, null, 'esperava null no fim do último grupo complexas (grupo=' + r.grupoId + ')');
  });

  t('Mensagem do popup varia quando cruza de família (novaFamilia=true) vs quando não cruza', () => {
    // Reproduz a lógica de perguntarProximaSilaba sem abrir o modal de
    // verdade — só confere que a string monta como esperado nos 2 casos.
    const linhaComCruzamento = window.eval(`
      (function(){
        var info = {rotuloAtual:'PÃO', proximo:{rotulo:'T · TA', novaFamilia:true}};
        return info.proximo.novaFamilia
          ? 'Terminou "'+info.rotuloAtual+'" e toda a família! Quer repassar ou começar "'+info.proximo.rotulo+'"?'
          : 'Terminou "'+info.rotuloAtual+'"! Quer repassar a família ou seguir pra "'+info.proximo.rotulo+'"?';
      })()
    `);
    assert(linhaComCruzamento.indexOf('toda a família') >= 0, 'mensagem de cruzamento de família devia mencionar "toda a família"');
  });

  resumo();
})();
