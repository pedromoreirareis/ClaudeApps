# Os cinco pedidos do Coruja Explica (v1.9)

Cópia exata do que o botão 🤖 PROMPT e o menu ▾ colocam na área de
transferência. Gerado a partir do próprio código do aplicativo, então não tem
como estar diferente do que o app copia.

| # | Pedido | Quando usar | Tamanho do texto |
|---|--------|-------------|------------------|
| 1 | 📖 **Leitura do dia** | O uso diário. É o que o botão grande copia. | 650 a 950 palavras (10 a 15 min de leitura) |
| 2 | 🧠 **Entender de verdade** | Quando o assunto precisa ficar entendido inteiro. | Livre — do tamanho que o assunto pedir |
| 3 | 🔄 **Adaptar um texto pronto** | Você já tem um texto e quer no formato do app. | Segue o original |
| 4 | ➡️ **Continuar o mesmo assunto** | Mais uma parte do tema, na mesma conversa com a IA. | Livre |
| 5 | 🛠️ **Consertar formato** | A IA respondeu fora do formato combinado. | — |

Todos os cinco terminam com uma **conferência final**: a IA precisa reler e
corrigir o próprio texto antes de responder, sem comentar a conferência.

---

## 1. 📖 Leitura do dia — botão 🤖 PROMPT

Uma leitura de 10 a 15 minutos. Substitua o trecho entre colchetes pelo assunto.

```
Você vai escrever um texto para uma criança ler em voz alta junto com o pai.
O texto será colado num aplicativo de leitura, então siga EXATAMENTE o formato
que está no final deste pedido.

ASSUNTO: [escreva aqui o assunto, com o máximo de detalhes que quiser]
IDADE: 6 anos
NÍVEL DE LEITURA: lê bem, como uma criança de 12 anos

O OBJETIVO
Este é o texto do dia: uma leitura gostosa de dez a quinze minutos, que a
criança termina sabendo alguma coisa nova de verdade — e com vontade de ler
outro amanhã.

O TAMANHO: DE DEZ A QUINZE MINUTOS DE LEITURA
1. Escreva entre 650 e 950 palavras na parte do TEXTO. Lendo em voz alta e
   parando para tocar nas palavras difíceis e comentar a pontuação, isso dá
   entre dez e quinze minutos, que é o tempo de atenção confortável nessa
   idade.
2. Conte as palavras antes de enviar. Passou de 950? Corte o que menos ensina.
   Ficou abaixo de 650? Provavelmente falta explicação, e não enfeite.
3. Se o assunto for grande demais para caber nessa conta, NÃO acelere nem
   passe por cima de tudo: escolha uma parte do assunto e explique essa parte
   inteira, bem explicada. Vale mais entender um pedaço do que passar os
   olhos pelo todo.
4. Cada parágrafo precisa ensinar alguma coisa nova. Parágrafo que só repete,
   enfeita ou enrola é justamente o que faz a criança largar o texto no meio.
   Corte sem dó.

O QUE FAZ O TEXTO PRENDER A ATENÇÃO
Um texto correto mas sem graça falhou. Escreva como quem conta uma coisa
fascinante para alguém de quem gosta muito — não como quem explica matéria.
— Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
  criança consiga sentir no próprio corpo ou ver dentro da própria casa.
  Nunca comece com "Neste texto vamos aprender sobre...".
— Coloque pelo menos dois momentos de "nossa, eu não sabia disso!": fatos
  verdadeiros e surpreendentes, contados de um jeito que dê vontade de sair
  contando para outra pessoa.
— Transforme números e tamanhos em coisas imagináveis. "Caberia um milhão de
  Terras dentro do Sol" vale muito mais do que "o Sol tem 1,4 milhão de
  quilômetros de diâmetro".
— Toda explicação difícil vem junto com uma comparação com o mundo dela:
  cozinha, banho, escola, bicicleta, futebol, bichos, comida, chuva, o
  próprio corpo, o quintal, o interior do Brasil.
— Uma ideia de cada vez: apresente, explique, compare — e só então siga em
  frente. Nunca empilhe três conceitos novos no mesmo parágrafo.
— Fale diretamente com a criança, usando "você".
— Termine com uma ideia que ela leve para a vida ou que a faça olhar para
  algo do dia a dia com outros olhos. Sem lição de moral pesada.

SINAIS DA ESCRITA QUE O TEXTO DEVE CONTER
A criança está aprendendo os sinais da escrita, e o pai aponta cada um durante
a leitura. Por isso eles precisam aparecer de forma natural — nunca forçada.
Se algum não couber com naturalidade neste assunto, deixe de fora.
— Ponto final, vírgula, interrogação e exclamação.
— Dois-pontos, abrindo uma fala ou uma explicação.
— Reticências, marcando uma pausa ou uma ideia que fica no ar.
— Um diálogo curto (2 a 4 falas) usando travessão. Cada fala fica sozinha na
  sua própria linha, com uma linha em branco antes e depois.
— Aspas, num pensamento ou numa fala repetida do jeito exato.
— Parênteses, com uma explicação extra que cabe dentro da frase.
— Pelo menos uma palavra com hífen (bem-estar, guarda-chuva).
— Palavras com acento agudo, com circunflexo e com til.
— Pelo menos uma crase (à), num lugar em que ela seja realmente correta.
— Uma lista de 3 itens, cada item numa linha começando com o sinal •
— Cada parágrafo é uma ideia, separado por uma linha em branco.

COMO ESCREVER AS FRASES
— Português do Brasil, com ortografia, acentuação e pontuação impecáveis. A
  criança aprende a escrever certo lendo este texto — um erro aqui ensina
  errado.
— Frases de tamanho variado, a maioria entre 8 e 18 palavras. Uma ideia por
  frase. Evite frases com mais de 25 palavras.
— Números até vinte, escreva por extenso.

PALAVRAS NOVAS — O DICIONÁRIO DO APLICATIVO
No aplicativo a criança toca numa palavra e aparece só a explicação dela, sem
o texto em volta. Então cada explicação precisa se sustentar sozinha.
— Inclua TODAS as palavras que uma criança de 6 anos provavelmente
  não conhece. Na dúvida, inclua.
— O tamanho da explicação acompanha a DIFICULDADE da palavra, e nada mais:

    • Palavra fácil, do dia a dia, que ela só talvez não saiba: UMA frase
      curta e direta. Não alongue.
      Exemplo: alerta = quando o corpo fica ligado e pronto para agir.

    • Palavra difícil ou ideia abstrata, que exige imaginar algo novo: 2 ou 3
      linhas, nesta ordem — o que é em palavras simples, uma comparação com
      algo que ela conhece, e onde ela vê isso na vida dela.
      Exemplo: atmosfera = é a camada de ar que fica em volta de um planeta
      inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar
      que você respira e que faz as estrelas cadentes brilharem antes de
      chegar aqui embaixo.

— Explicação comprida numa palavra fácil cansa, e a criança para de tocar
  nas palavras. Explicação curta numa palavra difícil deixa ela sem entender.
  Meça pelo esforço que a palavra exige dela.
— Nunca explique uma palavra difícil usando outra palavra difícil.
— Escreva sempre no formato:  palavra = explicação

TAGS — PARA ACHAR O TEXTO DEPOIS
— Escreva de 5 a 8 palavras-chave, separadas por vírgula, que o pai digitaria
  para reencontrar este texto daqui a seis meses: o assunto principal, a área
  (corpo humano, espaço, animais, história, plantas...) e as palavras que ele
  provavelmente lembraria.
— As tags não aparecem para a criança — servem só para a busca.

PERGUNTAS — O QUIZ DO FINAL
Terminada a leitura, o aplicativo mostra perguntas para a criança responder
tocando na resposta. Elas medem se ela ENTENDEU, não se decorou.
— Faça exatamente 3 perguntas, na ordem em que os assuntos aparecem no texto.
— Cada pergunta tem 3 alternativas. Marque a certa com um asterisco no fim.
— As alternativas erradas precisam ser possíveis — enganos que uma criança
  realmente cometeria. Nada de alternativa boba ou de brincadeira: isso ensina
  a chutar em vez de pensar.
— Depois das alternativas, escreva uma linha começando com > explicando, com
  carinho, por que a resposta certa é a certa. É o que a criança lê quando
  erra, então essa linha precisa ensinar, não corrigir.
— Pelo menos uma das perguntas deve exigir juntar duas partes diferentes do
  texto, e não só achar uma frase pronta.

CUIDADOS COM O CONTEÚDO
— Seja fiel à ciência. Não invente fatos, números, nomes nem datas. Se algo
  ainda não se sabe, escreva que os cientistas continuam estudando.
— Deixe claro, com respeito, a diferença entre ciência comprovada, crença ou
  tradição (astrologia, signos, simpatias) e lenda. Use frases como "os
  cientistas descobriram que...", "algumas pessoas acreditam que..." e
  "uma lenda antiga conta que...".
— Religiões: conte como cada uma acredita, com respeito, sem dizer qual é a
  certa.
— Saúde e corpo: explique como o corpo funciona. Não fale de remédios, doses,
  diagnósticos nem tratamentos. Lembre que quem cuida disso é o médico junto
  com a família.
— Temas difíceis (doença, morte, guerra, desastres): conte a verdade com
  carinho, sem detalhes assustadores, e termine acolhendo.
— Coisas perigosas (fogo, eletricidade, remédios, produtos de limpeza, bichos
  peçonhentos): explique e lembre que só se mexe nisso com um adulto.
— Nada de propaganda, marcas ou opinião política.

REGRAS DE FORMATAÇÃO (o aplicativo depende delas)
— Não use negrito, itálico, asteriscos, #, tabelas, listas numeradas, links
  nem "Fonte:". O único asterisco permitido é o que marca a alternativa
  certa nas PERGUNTAS.
— Emoji, só na linha do TÍTULO. Nunca dentro do texto.
— Letras normais: maiúscula só no começo das frases e nos nomes próprios.
  NÃO escreva nada todo em maiúsculas.
— Uma linha em branco entre cada parágrafo, entre cada fala do diálogo e
  antes de cada item da lista com •

FORMATO DA RESPOSTA

Primeiro, escreva para o pai (o aplicativo ignora tudo o que vier antes de
TÍTULO:):

PARA O PAI: [em até 6 linhas, quais sinais da escrita aparecem no texto e em
qual frase cada um está, para ele saber o que apontar durante a leitura]

Depois, escreva o bloco do texto, com os rótulos exatamente assim:

TÍTULO: [um emoji] [título curto, de preferência uma pergunta curiosa]

TAGS: [de 5 a 8 palavras-chave separadas por vírgula]

TEXTO:
[os parágrafos, o diálogo com travessão e a lista com •, tudo separado por
linhas em branco]

PALAVRAS NOVAS:
[uma palavra por linha, com a explicação no tamanho certo para a dificuldade
dela, assim:]
palavra = explicação

PERGUNTAS:
[exatamente 3 perguntas, cada uma neste formato:]
1) [a pergunta]
a) [alternativa]
b) [alternativa certa] *
c) [alternativa]
> [por que a certa é a certa, com carinho]

2) [a pergunta]
a) [alternativa certa] *
b) [alternativa]
c) [alternativa]
> [por que a certa é a certa]

PARA PENSAR:
[uma ou duas perguntas abertas, de conversa com o pai, que não têm resposta
certa ou errada]

Não escreva mais nada depois de PARA PENSAR.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia tudo o que você escreveu e corrija o que não passar nos pontos abaixo.
Não escreva sobre a conferência na resposta e não comente o que mudou:
entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu SÓ este texto conseguiria explicar o
   assunto para outra pessoa? Se ficou faltando um passo, acrescente. Se ficou
   sobrando enfeite, corte.
b) Todo fato é verdadeiro? Não há número, nome, data nem explicação inventada?
   Onde a ciência ainda não sabe, o texto diz isso?
c) Alguma frase passou de vinte e cinco palavras? Algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou no texto alguma palavra difícil que não está em PALAVRAS NOVAS?
   Inclua. Alguma explicação do dicionário usa outra palavra difícil? Troque.
e) Cada explicação do dicionário está no tamanho certo para a dificuldade
   daquela palavra — curta nas fáceis, com comparação nas difíceis?
f) As perguntas podem mesmo ser respondidas por quem leu o texto? Cada
   alternativa errada é um engano possível, e não uma bobagem? A alternativa
   certa está marcada com o asterisco? Cada pergunta tem a linha começando
   com > explicando o porquê?
g) A ortografia, a acentuação e a pontuação estão impecáveis? Este texto é o
   modelo de escrita que a criança vai copiar — um erro aqui ensina errado.
h) Os sinais da escrita pedidos aparecem de forma natural, sem nenhum parecer
   enfiado à força?
i) O formato está exatamente como pedido: os rótulos certos e na ordem certa,
   linha em branco entre os parágrafos, sem negrito, sem #, e emoji só na
   linha do TÍTULO?
j) Você repetiu alguma ideia com outras palavras só para alongar? Corte.
k) A parte do TEXTO está entre 650 e 950 palavras? Conte de verdade. Se
   passou, corte o parágrafo que menos ensina; se faltou, veja qual
   explicação ficou pela metade.

Só então envie a resposta.
```

---

## 2. 🧠 Entender de verdade — menu ▾

Sem limite de tamanho: o que vale é a criança terminar conseguindo explicar o
assunto. Pode gerar textos curtos ou de duas mil palavras.

```
Você vai escrever um texto para uma criança ler em voz alta junto com o pai.
O texto será colado num aplicativo de leitura, então siga EXATAMENTE o formato
que está no final deste pedido.

ASSUNTO: [escreva aqui o assunto, com o máximo de detalhes que quiser]
IDADE: 6 anos
NÍVEL DE LEITURA: lê bem, como uma criança de 12 anos

O OBJETIVO
Aqui vale uma coisa só: ao terminar, a criança precisa ter ENTENDIDO o
assunto de verdade, inteiro, sem buraco nenhum. Não é para ela ter ouvido
falar do assunto — é para ela conseguir explicar o assunto para outra pessoa,
com as palavras dela.

O TAMANHO NÃO IMPORTA — O ENTENDIMENTO IMPORTA
1. Não existe limite de palavras nem de parágrafos. Se o assunto se resolve
   em quatrocentas palavras, pare nas quatrocentas. Se precisa de duas mil
   para ficar realmente entendido, escreva as duas mil.
2. O que não pode é pular etapa: nunca use uma ideia antes de tê-la explicado.
3. Comece do zero. Parta do que a criança já viu na vida dela, não do que se
   aprende na escola. Não suponha que ela já sabe alguma coisa do assunto.
4. Vá em degraus pequenos: cada parágrafo dá UM passo a mais, e esse passo
   precisa caber na cabeça de quem acabou de ler o parágrafo anterior.
5. A cada duas ou três ideias novas, escreva um parágrafo curto recapitulando,
   com outras palavras, o que já ficou entendido até ali. Depois siga.
6. Quando a ideia for difícil, explique DUAS vezes, de jeitos diferentes:
   primeiro com uma comparação do dia a dia, depois direto ao ponto. Ver a
   mesma coisa por dois caminhos é o que faz a ficha cair.
7. Comprido não é a mesma coisa que bem explicado. Encher linguiça continua
   proibido: todo parágrafo tem de acrescentar entendimento, não volume.
8. Antes do fim, pergunte-se onde uma criança ainda ficaria com dúvida — e
   responda essa dúvida no próprio texto.

O QUE FAZ O TEXTO PRENDER A ATENÇÃO
Um texto correto mas sem graça falhou. Escreva como quem conta uma coisa
fascinante para alguém de quem gosta muito — não como quem explica matéria.
— Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
  criança consiga sentir no próprio corpo ou ver dentro da própria casa.
  Nunca comece com "Neste texto vamos aprender sobre...".
— Coloque pelo menos dois momentos de "nossa, eu não sabia disso!": fatos
  verdadeiros e surpreendentes, contados de um jeito que dê vontade de sair
  contando para outra pessoa.
— Transforme números e tamanhos em coisas imagináveis. "Caberia um milhão de
  Terras dentro do Sol" vale muito mais do que "o Sol tem 1,4 milhão de
  quilômetros de diâmetro".
— Toda explicação difícil vem junto com uma comparação com o mundo dela:
  cozinha, banho, escola, bicicleta, futebol, bichos, comida, chuva, o
  próprio corpo, o quintal, o interior do Brasil.
— Uma ideia de cada vez: apresente, explique, compare — e só então siga em
  frente. Nunca empilhe três conceitos novos no mesmo parágrafo.
— Fale diretamente com a criança, usando "você".
— Termine com uma ideia que ela leve para a vida ou que a faça olhar para
  algo do dia a dia com outros olhos. Sem lição de moral pesada.

SINAIS DA ESCRITA QUE O TEXTO DEVE CONTER
A criança está aprendendo os sinais da escrita, e o pai aponta cada um durante
a leitura. Por isso eles precisam aparecer de forma natural — nunca forçada.
Se algum não couber com naturalidade neste assunto, deixe de fora.
— Ponto final, vírgula, interrogação e exclamação.
— Dois-pontos, abrindo uma fala ou uma explicação.
— Reticências, marcando uma pausa ou uma ideia que fica no ar.
— Um diálogo curto (2 a 4 falas) usando travessão. Cada fala fica sozinha na
  sua própria linha, com uma linha em branco antes e depois.
— Aspas, num pensamento ou numa fala repetida do jeito exato.
— Parênteses, com uma explicação extra que cabe dentro da frase.
— Pelo menos uma palavra com hífen (bem-estar, guarda-chuva).
— Palavras com acento agudo, com circunflexo e com til.
— Pelo menos uma crase (à), num lugar em que ela seja realmente correta.
— Uma lista de 3 itens, cada item numa linha começando com o sinal •
— Cada parágrafo é uma ideia, separado por uma linha em branco.

COMO ESCREVER AS FRASES
— Português do Brasil, com ortografia, acentuação e pontuação impecáveis. A
  criança aprende a escrever certo lendo este texto — um erro aqui ensina
  errado.
— Frases de tamanho variado, a maioria entre 8 e 18 palavras. Uma ideia por
  frase. Evite frases com mais de 25 palavras.
— Números até vinte, escreva por extenso.

PALAVRAS NOVAS — O DICIONÁRIO DO APLICATIVO
No aplicativo a criança toca numa palavra e aparece só a explicação dela, sem
o texto em volta. Então cada explicação precisa se sustentar sozinha.
— Inclua TODAS as palavras que uma criança de 6 anos provavelmente
  não conhece. Na dúvida, inclua.
— O tamanho da explicação acompanha a DIFICULDADE da palavra, e nada mais:

    • Palavra fácil, do dia a dia, que ela só talvez não saiba: UMA frase
      curta e direta. Não alongue.
      Exemplo: alerta = quando o corpo fica ligado e pronto para agir.

    • Palavra difícil ou ideia abstrata, que exige imaginar algo novo: 2 ou 3
      linhas, nesta ordem — o que é em palavras simples, uma comparação com
      algo que ela conhece, e onde ela vê isso na vida dela.
      Exemplo: atmosfera = é a camada de ar que fica em volta de um planeta
      inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar
      que você respira e que faz as estrelas cadentes brilharem antes de
      chegar aqui embaixo.

— Explicação comprida numa palavra fácil cansa, e a criança para de tocar
  nas palavras. Explicação curta numa palavra difícil deixa ela sem entender.
  Meça pelo esforço que a palavra exige dela.
— Nunca explique uma palavra difícil usando outra palavra difícil.
— Escreva sempre no formato:  palavra = explicação

TAGS — PARA ACHAR O TEXTO DEPOIS
— Escreva de 5 a 8 palavras-chave, separadas por vírgula, que o pai digitaria
  para reencontrar este texto daqui a seis meses: o assunto principal, a área
  (corpo humano, espaço, animais, história, plantas...) e as palavras que ele
  provavelmente lembraria.
— As tags não aparecem para a criança — servem só para a busca.

PERGUNTAS — O QUIZ DO FINAL
Terminada a leitura, o aplicativo mostra perguntas para a criança responder
tocando na resposta. Elas medem se ela ENTENDEU, não se decorou.
— Faça de 3 a 6 perguntas, uma para cada parte importante do assunto, na ordem em que os assuntos aparecem no texto.
— Cada pergunta tem 3 alternativas. Marque a certa com um asterisco no fim.
— As alternativas erradas precisam ser possíveis — enganos que uma criança
  realmente cometeria. Nada de alternativa boba ou de brincadeira: isso ensina
  a chutar em vez de pensar.
— Depois das alternativas, escreva uma linha começando com > explicando, com
  carinho, por que a resposta certa é a certa. É o que a criança lê quando
  erra, então essa linha precisa ensinar, não corrigir.
— Pelo menos uma das perguntas deve exigir juntar duas partes diferentes do
  texto, e não só achar uma frase pronta.

CUIDADOS COM O CONTEÚDO
— Seja fiel à ciência. Não invente fatos, números, nomes nem datas. Se algo
  ainda não se sabe, escreva que os cientistas continuam estudando.
— Deixe claro, com respeito, a diferença entre ciência comprovada, crença ou
  tradição (astrologia, signos, simpatias) e lenda. Use frases como "os
  cientistas descobriram que...", "algumas pessoas acreditam que..." e
  "uma lenda antiga conta que...".
— Religiões: conte como cada uma acredita, com respeito, sem dizer qual é a
  certa.
— Saúde e corpo: explique como o corpo funciona. Não fale de remédios, doses,
  diagnósticos nem tratamentos. Lembre que quem cuida disso é o médico junto
  com a família.
— Temas difíceis (doença, morte, guerra, desastres): conte a verdade com
  carinho, sem detalhes assustadores, e termine acolhendo.
— Coisas perigosas (fogo, eletricidade, remédios, produtos de limpeza, bichos
  peçonhentos): explique e lembre que só se mexe nisso com um adulto.
— Nada de propaganda, marcas ou opinião política.

REGRAS DE FORMATAÇÃO (o aplicativo depende delas)
— Não use negrito, itálico, asteriscos, #, tabelas, listas numeradas, links
  nem "Fonte:". O único asterisco permitido é o que marca a alternativa
  certa nas PERGUNTAS.
— Emoji, só na linha do TÍTULO. Nunca dentro do texto.
— Letras normais: maiúscula só no começo das frases e nos nomes próprios.
  NÃO escreva nada todo em maiúsculas.
— Uma linha em branco entre cada parágrafo, entre cada fala do diálogo e
  antes de cada item da lista com •

FORMATO DA RESPOSTA

Primeiro, escreva para o pai (o aplicativo ignora tudo o que vier antes de
TÍTULO:):

PARA O PAI: [em até 6 linhas, quais sinais da escrita aparecem no texto e em
qual frase cada um está, para ele saber o que apontar durante a leitura]

Depois, escreva o bloco do texto, com os rótulos exatamente assim:

TÍTULO: [um emoji] [título curto, de preferência uma pergunta curiosa]

TAGS: [de 5 a 8 palavras-chave separadas por vírgula]

TEXTO:
[os parágrafos, o diálogo com travessão e a lista com •, tudo separado por
linhas em branco]

PALAVRAS NOVAS:
[uma palavra por linha, com a explicação no tamanho certo para a dificuldade
dela, assim:]
palavra = explicação

PERGUNTAS:
[de 3 a 6 perguntas, cada uma neste formato:]
1) [a pergunta]
a) [alternativa]
b) [alternativa certa] *
c) [alternativa]
> [por que a certa é a certa, com carinho]

2) [a pergunta]
a) [alternativa certa] *
b) [alternativa]
c) [alternativa]
> [por que a certa é a certa]

PARA PENSAR:
[uma ou duas perguntas abertas, de conversa com o pai, que não têm resposta
certa ou errada]

Não escreva mais nada depois de PARA PENSAR.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia tudo o que você escreveu e corrija o que não passar nos pontos abaixo.
Não escreva sobre a conferência na resposta e não comente o que mudou:
entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu SÓ este texto conseguiria explicar o
   assunto para outra pessoa? Se ficou faltando um passo, acrescente. Se ficou
   sobrando enfeite, corte.
b) Todo fato é verdadeiro? Não há número, nome, data nem explicação inventada?
   Onde a ciência ainda não sabe, o texto diz isso?
c) Alguma frase passou de vinte e cinco palavras? Algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou no texto alguma palavra difícil que não está em PALAVRAS NOVAS?
   Inclua. Alguma explicação do dicionário usa outra palavra difícil? Troque.
e) Cada explicação do dicionário está no tamanho certo para a dificuldade
   daquela palavra — curta nas fáceis, com comparação nas difíceis?
f) As perguntas podem mesmo ser respondidas por quem leu o texto? Cada
   alternativa errada é um engano possível, e não uma bobagem? A alternativa
   certa está marcada com o asterisco? Cada pergunta tem a linha começando
   com > explicando o porquê?
g) A ortografia, a acentuação e a pontuação estão impecáveis? Este texto é o
   modelo de escrita que a criança vai copiar — um erro aqui ensina errado.
h) Os sinais da escrita pedidos aparecem de forma natural, sem nenhum parecer
   enfiado à força?
i) O formato está exatamente como pedido: os rótulos certos e na ordem certa,
   linha em branco entre os parágrafos, sem negrito, sem #, e emoji só na
   linha do TÍTULO?
j) Você repetiu alguma ideia com outras palavras só para alongar? Corte.
k) Tem alguma passagem em que o texto usa uma ideia antes de explicá-la?
   Traga a explicação para antes.
l) Para cada ideia difícil, existe mesmo uma comparação com o dia a dia E uma
   explicação direta?
m) Se a criança parasse em qualquer parágrafo e alguém perguntasse "o que
   você entendeu até aqui?", ela saberia responder?

Só então envie a resposta.
```

---

## 3. 🔄 Adaptar um texto pronto — menu ▾

O aplicativo cola o texto original no lugar indicado, automaticamente.

```
Reescreva o texto do final para uma criança de 6 anos ler em voz alta
junto com o pai. Não é para resumir: é para contar de novo, de um jeito que
prenda a atenção dela e que ela entenda de verdade.

COMO REESCREVER
1. Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
   criança consiga sentir no corpo ou ver dentro de casa.
2. Toda explicação difícil vem com uma comparação com o mundo dela: cozinha,
   banho, escola, bicicleta, bichos, comida, chuva, o próprio corpo.
3. Uma ideia por parágrafo, frases entre 8 e 18 palavras, falando com "você".
4. O tamanho quem decide é o assunto: não encha linguiça nem corte no meio.
   Ao terminar, a criança precisa conseguir explicar o assunto para alguém.
5. Mantenha apenas as ideias que estão no texto original e que são corretas.
   Não acrescente fatos novos que não estejam lá.

SINAIS DA ESCRITA (de forma natural, nunca forçada)
6. Um diálogo curto com travessão, cada fala sozinha na sua linha, com linha
   em branco antes e depois; aspas; parênteses; reticências; dois-pontos; uma
   palavra com hífen; acentos agudo, circunflexo e til; uma crase; e uma lista
   de 3 itens, cada um numa linha começando com •

PALAVRAS NOVAS (o dicionário do aplicativo)
7. Inclua TODAS as palavras que uma criança de 6 anos provavelmente
   não conhece. Na dúvida, inclua.
8. O tamanho da explicação acompanha a dificuldade da palavra:
   • fácil: uma frase curta e direta. Ex.: alerta = quando o corpo fica ligado
     e pronto para agir.
   • difícil ou abstrata: 2 ou 3 linhas — o que é em palavras simples, uma
     comparação com algo conhecido e onde ela vê isso na vida dela.
9. Nunca explique uma palavra difícil usando outra palavra difícil.

TAGS
10. De 5 a 8 palavras-chave separadas por vírgula, para o pai reencontrar este
    texto depois. Não aparecem para a criança.

PERGUNTAS
11. Exatamente 3 perguntas de interpretação, cada uma com 3 alternativas. A
    certa leva um asterisco no fim. As erradas precisam ser enganos possíveis,
    nunca alternativas bobas. Depois das alternativas, uma linha começando com
    > explicando com carinho por que a certa é a certa.

FORMATAÇÃO
12. Sem negrito, sem #, sem listas numeradas e sem emoji fora do TÍTULO. Uma
    linha em branco entre cada parágrafo. O único asterisco permitido é o que
    marca a alternativa certa.

Responda somente com este bloco, nesta ordem: PARA O PAI, TÍTULO, TAGS, TEXTO,
PALAVRAS NOVAS, PERGUNTAS e PARA PENSAR, exatamente com esses rótulos. Nas
PERGUNTAS use o formato:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa

Não escreva nada depois de PARA PENSAR.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia o que você escreveu e corrija o que não passar nestes pontos.
Não comente a conferência na resposta: entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu só este texto conseguiria explicar o
   assunto para outra pessoa?
b) Todo fato é verdadeiro, sem número, nome ou data inventada?
c) Alguma frase passou de vinte e cinco palavras, ou algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou palavra difícil fora de PALAVRAS NOVAS? Alguma explicação usa outra
   palavra difícil? E o tamanho de cada explicação combina com a dificuldade
   da palavra?
e) As perguntas podem ser respondidas por quem leu o texto, as alternativas
   erradas são enganos possíveis e a certa está marcada com o asterisco?
f) Ortografia, acentuação e pontuação impecáveis?
g) O formato está exato: rótulos certos, linha em branco entre parágrafos, sem
   negrito, sem #, emoji só no TÍTULO?
h) As ideias continuam sendo as do texto original, sem nenhum fato novo que
   não estava lá?

Só então envie a resposta.

TEXTO ORIGINAL:
[o texto que você colar na caixinha entra aqui]
```

---

## 4. ➡️ Continuar o mesmo assunto — menu ▾

Para usar na MESMA conversa com a IA, logo depois de um texto pronto.

```
Continue o mesmo assunto explicando agora [a próxima pergunta que você digitar],
com as mesmas regras e exatamente o mesmo formato de antes, incluindo TAGS e
PERGUNTAS. Não repita o que já foi explicado.

Lembretes: comece com um gancho que dê curiosidade; toda explicação difícil
vem com uma comparação com o mundo da criança; o tamanho quem decide é o
assunto; em PALAVRAS NOVAS o tamanho da explicação acompanha a dificuldade da
palavra (fácil = uma frase; difícil = 2 ou 3 linhas com comparação); e as 3
perguntas do final precisam ter alternativas erradas que sejam enganos
possíveis, com a linha > explicando a certa.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia o que você escreveu e corrija o que não passar nestes pontos.
Não comente a conferência na resposta: entregue apenas o texto já corrigido.
a) Uma criança que leu só esta continuação entende a parte nova do assunto?
b) Todo fato é verdadeiro, sem número, nome ou data inventada?
c) Você repetiu algo que já tinha sido explicado antes? Corte.
d) Alguma frase passou de vinte e cinco palavras, ou algum parágrafo ficou com
   mais de uma ideia? Quebre.
e) Sobrou palavra difícil fora de PALAVRAS NOVAS? O tamanho de cada explicação
   combina com a dificuldade da palavra?
f) As perguntas podem ser respondidas por quem leu o texto, as alternativas
   erradas são enganos possíveis e a certa está marcada com o asterisco?
g) Ortografia, acentuação e pontuação impecáveis?
h) O formato está exato: rótulos certos, linha em branco entre parágrafos, sem
   negrito, sem #, emoji só no TÍTULO?

Só então envie a resposta.
```

---

## 5. 🛠️ Consertar o formato — menu ▾

Para quando a IA responder fora do formato combinado.

```
Sua resposta saiu do formato combinado. Reescreva exatamente no formato
PARA O PAI / TÍTULO / TAGS / TEXTO / PALAVRAS NOVAS / PERGUNTAS / PARA PENSAR,
com uma linha em branco entre os parágrafos e entre cada fala do diálogo, sem
negrito, sem #, sem listas numeradas, sem emoji fora do TÍTULO e sem escrever
nada depois de PARA PENSAR.

Nas PERGUNTAS use exatamente este formato, com 3 perguntas:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Antes de responder, confira o que você reescreveu e corrija o que estiver
fora. Não comente a conferência: entregue apenas o texto corrigido.
a) Os sete rótulos estão presentes, escritos exatamente assim e nesta ordem:
   PARA O PAI, TÍTULO, TAGS, TEXTO, PALAVRAS NOVAS, PERGUNTAS, PARA PENSAR?
b) Há uma linha em branco entre cada parágrafo e entre cada fala do diálogo?
c) Não sobrou negrito, asterisco fora das alternativas certas, #, lista
   numerada nem emoji fora da linha do TÍTULO?
d) Cada pergunta tem 3 alternativas, uma marcada com asterisco e uma linha
   começando com > logo depois?
e) O conteúdo do texto continua o mesmo — você só arrumou o formato?

Só então envie a resposta.
```
