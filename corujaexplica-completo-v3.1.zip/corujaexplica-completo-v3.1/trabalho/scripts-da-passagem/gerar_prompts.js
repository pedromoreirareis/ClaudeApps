// Gera documentos/PROMPTS_IA_v3.1.md rodando a função montarPrompt do index.html (usado na passagem de 14/10/2026).
// Uso: node gerar_prompts.js <pasta-do-zip>
const R = process.argv[2] || require('path').join(__dirname, '..', '..');
const C = require(R + '/testes/_carrega.js')(R + '/pacote-netlify/index.html');
const tipos = [['leitura','📖 Leitura do dia (botão 🤖 PROMPT)',{}],['entender','🧠 Entender de verdade',{}],
  ['adaptar','🔄 Adaptar um texto pronto',{texto:'[AQUI ENTRA O TEXTO QUE O PAI COLOU NO CAMPO]'}],
  ['continuar','➡️ Continuar o mesmo assunto',{pergunta:'[AQUI ENTRA A PRÓXIMA PERGUNTA QUE O PAI ESCREVEU]'}],['consertar','🛠️ Consertar formato',{}]];
let out = '# Pedidos à IA (prompts) do Coruja Explica — exatamente como o app copia (v3.1)\n\nGerado em 14/10/2026 rodando a função montarPrompt do index.html da v3.1 (pacote-netlify). Os textos são idênticos aos da v2.1 e da v3.0. Nos pedidos Adaptar e Continuar, o trecho entre colchetes é onde entra o que o pai digita.\n\n';
for (const [t, n, d] of tipos){ const p = C.montarPrompt(t, d); out += '## ' + n + '\n\n(' + p.split(/\s+/).filter(Boolean).length + ' palavras)\n\n```text\n' + p + '\n```\n\n'; }
require('fs').writeFileSync(R + '/documentos/PROMPTS_IA_v3.1.md', out);
