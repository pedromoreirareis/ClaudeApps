# 🧪 Atualizar o SITE DE TESTE para a v122b (só desenho)

**Site de teste do Pedro:** https://escolasaopedrotestes.netlify.app/ · **família de teste:** `pmrtestes`
**Data:** 07/10/2026 · **O que muda:** só o desenho das telas da família (pedido do Pedro depois do teste nos 2 Motorolas). O funcionamento (nuvem, família, crianças, progresso) é o mesmo da v122.

> ## ⚠️ NUNCA digite o código da família de verdade no site de teste.
> Continue usando **só** `pmrtestes`. A partir da v122b o próprio site de teste recusa qualquer código que **não tenha a palavra "teste"** (o `pmrtestes` tem, por isso é aceito). Mas não conte só com isso.

---

## 1. Publicar por cima do site de teste (o mesmo endereço)

1. Netlify → abra o site **escolasaopedrotestes** → aba **Deploys**.
2. Arraste o arquivo **`alfabetizacao-v122b-SITE-DE-TESTE-netlify.zip`** na área "Drag and drop your project folder here".
3. Espere aparecer **Published**.
4. Nos 2 celulares, abra o site **duas vezes** (feche a aba e abra de novo). Na 2ª vez o celular já pega a v122b (o nome guardado mudou para `esforco-vence-v122b`).
   - Como saber se pegou: em **"🎉 ACHEI A SUA FAMÍLIA!"** agora aparecem os botões **← OUTRO CÓDIGO · ESCOLHER · TRAZER TODAS** num pop-up largo.
   - Se continuar o desenho antigo: feche o Chrome por completo e abra de novo.
5. **Novidade:** nas telas da família (Olá / Código / Quem vai estudar hoje? …) aparece no alto uma faixa roxa **"🧪 SITE DE TESTE — USE SÓ O CÓDIGO DE TESTE"**. Ela não aparecia antes porque o app só reconhecia endereços terminados em `-teste`; agora reconhece qualquer endereço com "teste". Ela **some** quando a criança está estudando (não fica por cima da barra de cima) e some com o teclado aberto. No site de verdade ela **nunca** aparece.

Nada é apagado: as crianças, a família `pmrtestes` e o progresso continuam como estavam.

## 2. O que olhar (deitado, que é como as meninas usam)

1. **Teclado:** no Chrome, menu ⋮ → **Nova guia anônima** e abra o site de teste nela (a guia anônima começa vazia, como um celular novo, e não mexe nos dados do site). Aparece **🦉 OLÁ! VAMOS COMEÇAR?** → **🔑 JÁ TENHO CADASTRO** → toque no campo: a caixa do código tem que ficar **no meio** entre o topo e o teclado (não mais grudada em cima), sem espaço vazio embaixo dela.
2. **"Achei a sua família":** na mesma guia anônima, digite `pmrtestes` → **🔑 PROCURAR A FAMÍLIA**. O pop-up fica largo, com as crianças lado a lado (com espaço entre elas) e os botões embaixo: **← OUTRO CÓDIGO** (corrige o código), **ESCOLHER** e **TRAZER TODAS**. O ✕ no canto cancela.
   - Se quiser ver com mais crianças: cadastre 3 ou 4 crianças de teste no 1º celular (ex.: TESTE ANA, TESTE BIA, TESTE CAIO, TESTE MARIA EDUARDA) e procure de novo no 2º. Os nomes não podem aparecer cortados (nome comprido vai para 2 linhas).
3. **Configurações:** ⚙️. O pop-up agora usa quase toda a largura, com as opções do app em 2 colunas. Role até **☁️ FAMÍLIA E NUVEM**: cada linha tem o texto à esquerda e os botões à direita, numa linha só, com espaço entre eles. Os botões que pedem um adulto ficam numa linha: **◯ 👨 ABRIR ▶** (cópias de cada dia) e **◯ 👨 👁 MOSTRAR** (o código). Um toque rápido mostra o aviso "PEÇA PARA UM ADULTO SEGURAR O BOTÃO POR 3 SEGUNDOS"; segurando 3 s, funciona.
4. **"Quem vai estudar hoje?"** (toque no bichinho ao lado da ⚙️): os cartões ficam no meio da tela; embaixo, a frase da nuvem inteira à esquerda e **🔑 FAMÍLIA PMR••••** à direita.
5. **Famílias neste celular:** cada família numa linha só; o código aparece em letra maiúscula (PMR••••), igual às outras telas.

## 3. O aviso do Chrome "Para sair da tela cheia, arraste…"

- Esse aviso é **do próprio Chrome**, não do app. Ele aparece **toda vez** que um site entra em tela cheia, por segurança (para ninguém imitar a tela do celular). **Nenhum site consegue esconder, encurtar ou diminuir** esse aviso dentro da aba do Chrome.
- **O que resolve:** usar o app **instalado** (o ícone na tela inicial do celular). Aberto pelo ícone, o app já abre em tela cheia sozinho, e a partir da v122b ele **não pede mais** a tela cheia do Chrome, que era o que fazia o aviso aparecer.
  - Para instalar: ⚙️ → **📲 Instalar o app** (ou, no menu ⋮ do Chrome, **Instalar app / Adicionar à tela inicial**).
  - Se o ícone já estava instalado de antes e o aviso continuar aparecendo, apague o ícone e instale de novo (alguns celulares guardam o jeito antigo de abrir).
- Na aba do Chrome (sem instalar), o aviso continua aparecendo quando o app entra em tela cheia. Isso aparece mais vezes porque o botão **voltar** do Android, em tela cheia, primeiro **sai** da tela cheia; no próximo toque o app volta para a tela cheia e o Chrome mostra o aviso de novo.

## 4. Quando terminar

Me diga o que achou do novo desenho (prints ajudam). Depois disso seguimos para o zip do **site de verdade** (v123), que ainda tem as correções 🟡 C1 a C5 da revisão e o teste da migração com o seu backup de verdade.

*(O roteiro completo de testes do cadastro, da v122, está em `documentos/historico/INSTRUCOES_SITE_DE_TESTE_v122.md`; lá o nome do site e o código eram outros: valem os desta página.)*
