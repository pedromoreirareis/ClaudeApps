# Coruja Explica v2.1 — os cinco pedidos (prompts)

Gerado direto do aplicativo — é exatamente o texto que o app copia.

Mudanças da v2.1: diálogo entre personagens que combinem com o assunto (pai e filha é só uma possibilidade) e sempre presente; na Leitura do dia, parágrafos de 3 a 4 linhas (5 só quando não houver outro jeito).

## 📖 Leitura do dia (botão PROMPT)

```
Você vai escrever um texto para uma criança ler em voz alta junto com o pai.
O texto será colado num aplicativo de leitura, então siga EXATAMENTE o formato
que está no final deste pedido.

ASSUNTO: [escreva aqui o assunto, com o máximo de detalhes que quiser]
IDADE: 6 anos
NÍVEL DE LEITURA: lê bem, como uma criança de 12 anos

O OBJETIVO
Este é o texto do dia. A criança vai ler, reler as partes que precisar e
depois explicar, com as próprias palavras, o que entendeu. Nos dias
seguintes, ela vai conversar de novo sobre o assunto. O objetivo não é
terminar a leitura: é entender, lembrar e conseguir explicar. Por isso, a
ordem de prioridade deste texto é:
   1º COMPREENSÃO — ela entende tudo o que leu;
   2º RETENÇÃO — ela lembra do assunto depois;
   3º RECONTO — ela consegue explicar com as próprias palavras;
   4º só depois de tudo isso, a QUANTIDADE de informação.

O TAMANHO: TEXTO CURTO, PARA LER, RELER E RECONTAR
1. A parte do TEXTO fica entre 300 e 500 palavras. Pode ficar um pouco
   abaixo ou acima quando o assunto pedir — não é uma regra rígida —, mas
   texto comprido atrapalha: ler, reler e recontar precisa caber em uns
   vinte minutos.
2. NÃO tente colocar o máximo de informação possível. Escolha as 3 ou 4
   ideias mais importantes e mais interessantes do assunto e explique bem
   só essas. O resto fica para outro dia.
3. Reduza escolhendo e resumindo — nunca cortando uma explicação no meio.
   Vale mais entender e lembrar um pedaço do que passar os olhos pelo todo.
4. Para ajudar a lembrar: apresente as ideias numa ordem clara; no último
   parágrafo, retome a ideia principal com frases simples, que a criança
   consiga repetir; e use só os números e nomes que importam.
5. Mesmo curto, o texto mantém tudo o que faz a leitura boa: o gancho do
   começo, o diálogo, a lista com nomes em destaque, as palavras novas, as
   perguntas do final e o Para Pensar.
6. Conte as palavras antes de enviar. Passou muito de 500? Tire a ideia que
   menos ensina. Ficou bem abaixo de 300? Provavelmente falta explicação.

O QUE FAZ O TEXTO PRENDER A ATENÇÃO
Um texto correto mas sem graça falhou. Escreva como quem conta uma coisa
fascinante para alguém de quem gosta muito — não como quem explica matéria.
— Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
  criança consiga sentir no próprio corpo ou ver dentro da própria casa.
  Nunca comece com "Neste texto vamos aprender sobre...".
— Coloque pelo menos dois momentos de "nossa, eu não sabia disso!": fatos
  verdadeiros e surpreendentes, contados de um jeito que dê vontade de sair
  contando para outra pessoa.
— Transforme números e tamanhos em coisas imagináveis. "Caberia um milhão de
  Terras dentro do Sol" vale muito mais do que "o Sol tem 1,4 milhão de
  quilômetros de diâmetro".
— Toda explicação difícil vem junto com uma comparação com o mundo dela:
  cozinha, banho, escola, bicicleta, futebol, bichos, comida, chuva, o
  próprio corpo, o quintal, o interior do Brasil.
— Uma ideia de cada vez: apresente, explique, compare — e só então siga em
  frente. Nunca empilhe três conceitos novos no mesmo parágrafo.
— Fale diretamente com a criança, usando "você".
— Termine com uma ideia que ela leve para a vida ou que a faça olhar para
  algo do dia a dia com outros olhos. Sem lição de moral pesada.

SINAIS DA ESCRITA QUE O TEXTO DEVE CONTER
A criança está aprendendo os sinais da escrita, e o pai aponta cada um durante
a leitura. Por isso eles precisam aparecer de forma natural — nunca forçada.
Se algum não couber com naturalidade neste assunto, deixe de fora — menos o
diálogo, que sempre aparece.
— Ponto final, vírgula, interrogação e exclamação.
— Dois-pontos, abrindo uma fala ou uma explicação.
— Reticências, marcando uma pausa ou uma ideia que fica no ar.
— Um diálogo curto (2 a 4 falas), usando travessão, entre personagens que
  combinem com o assunto: num texto sobre navegação, um marinheiro e o
  capitão; sobre ciência, uma cientista e uma aluna; também pode ser a filha
  e o pai. O importante é TER o diálogo — quem conversa depende da história;
  se o assunto não tiver personagens, crie uma cena curta em que alguém
  pergunta e outro responde. Encaixe a conversa no ponto em que alguém faria
  mesmo aquela pergunta, de forma natural. Cada fala fica sozinha na sua
  própria linha, com uma linha em branco antes e depois.
— Aspas, num pensamento ou numa fala repetida do jeito exato.
— Parênteses, com uma explicação extra que cabe dentro da frase.
— Pelo menos uma palavra com hífen (bem-estar, guarda-chuva).
— Palavras com acento agudo, com circunflexo e com til.
— Pelo menos uma crase (à), num lugar em que ela seja realmente correta.
— A lista com • e nomes em destaque (veja LISTA COM NOMES EM DESTAQUE).
— Cada parágrafo é uma ideia, separado por uma linha em branco.

LISTA COM NOMES EM DESTAQUE (a parte de que a criança mais gosta)
No aplicativo, cada linha que começa com • vira um cartão colorido, e o nome
que vem antes dos dois-pontos aparece em destaque, com uma cor só dele. É o
recurso que mais prende a atenção da criança e ajuda a guardar os nomes
importantes. Use sempre que o assunto tiver nomes, partes, tipos, etapas ou
exemplos que valham a pena lembrar.
— Faça uma lista de 3 a 5 itens (duas listas, se o assunto pedir e couber no tamanho).
— Cada item fica numa linha própria e começa com • seguido do NOME EM
  DESTAQUE, de dois-pontos e de uma explicação curta (uma ou duas frases):
  • Acrux: a estrela mais brilhante do Cruzeiro do Sul.
  • Mimosa: outra estrela muito brilhante da mesma cruz.
— O nome em destaque tem no máximo três palavras.
— A frase que vem logo antes da lista apresenta a lista e termina com
  dois-pontos, sem ponto depois (por exemplo: "As mais fáceis de achar são:").

COMO ESCREVER AS FRASES
— Português do Brasil, com ortografia, acentuação e pontuação impecáveis. A
  criança aprende a escrever certo lendo este texto — um erro aqui ensina
  errado.
— Frases de tamanho variado, a maioria entre 8 e 18 palavras. Uma ideia por
  frase. Evite frases com mais de 25 palavras.
— Parágrafos de três a quatro linhas (na prática, duas ou três frases, entre
  30 e 45 palavras). Cinco linhas, só quando não houver mesmo outro jeito.
  Podem ser mais curtos só: as falas do diálogo, os itens da lista e a frase
  que apresenta a lista. Parágrafo comprido cansa quem está aprendendo a ler.
— Números até vinte, escreva por extenso.

PALAVRAS NOVAS — O DICIONÁRIO DO APLICATIVO
No aplicativo a criança toca numa palavra e aparece só a explicação dela, sem
o texto em volta. Então cada explicação precisa se sustentar sozinha.
— Inclua TODAS as palavras que uma criança de 6 anos provavelmente
  não conhece. Na dúvida, inclua.
— O tamanho da explicação acompanha a DIFICULDADE da palavra, e nada mais:

    • Palavra fácil, do dia a dia, que ela só talvez não saiba: UMA frase
      curta e direta. Não alongue.
      Exemplo: alerta = quando o corpo fica ligado e pronto para agir.

    • Palavra difícil ou ideia abstrata, que exige imaginar algo novo: 2 ou 3
      linhas, nesta ordem — o que é em palavras simples, uma comparação com
      algo que ela conhece, e onde ela vê isso na vida dela.
      Exemplo: atmosfera = é a camada de ar que fica em volta de um planeta
      inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar
      que você respira e que faz as estrelas cadentes brilharem antes de
      chegar aqui embaixo.

— Explicação comprida numa palavra fácil cansa, e a criança para de tocar
  nas palavras. Explicação curta numa palavra difícil deixa ela sem entender.
  Meça pelo esforço que a palavra exige dela.
— Nunca explique uma palavra difícil usando outra palavra difícil.
— Escreva sempre no formato:  palavra = explicação

TAGS — PARA ACHAR O TEXTO DEPOIS
— Escreva de 5 a 8 palavras-chave, separadas por vírgula, que o pai digitaria
  para reencontrar este texto daqui a seis meses: o assunto principal, a área
  (corpo humano, espaço, animais, história, plantas...) e as palavras que ele
  provavelmente lembraria.
— As tags não aparecem para a criança — servem só para a busca.

PERGUNTAS — O QUIZ DO FINAL
Terminada a leitura, o aplicativo mostra perguntas para a criança responder
tocando na resposta. Elas medem se ela ENTENDEU, não se decorou.
— Faça exatamente 3 perguntas, na ordem em que os assuntos aparecem no texto.
— Cada pergunta tem 3 alternativas. Marque a certa com um asterisco no fim.
— As alternativas erradas precisam ser possíveis — enganos que uma criança
  realmente cometeria. Nada de alternativa boba ou de brincadeira: isso ensina
  a chutar em vez de pensar.
— Depois das alternativas, escreva uma linha começando com > explicando, com
  carinho, por que a resposta certa é a certa. É o que a criança lê quando
  erra, então essa linha precisa ensinar, não corrigir.
— Pelo menos uma das perguntas deve exigir juntar duas partes diferentes do
  texto, e não só achar uma frase pronta.

CUIDADOS COM O CONTEÚDO
— Seja fiel à ciência. Não invente fatos, números, nomes nem datas. Se algo
  ainda não se sabe, escreva que os cientistas continuam estudando.
— Deixe claro, com respeito, a diferença entre ciência comprovada, crença ou
  tradição (astrologia, signos, simpatias) e lenda. Use frases como "os
  cientistas descobriram que...", "algumas pessoas acreditam que..." e
  "uma lenda antiga conta que...".
— Religiões: conte como cada uma acredita, com respeito, sem dizer qual é a
  certa.
— Saúde e corpo: explique como o corpo funciona. Não fale de remédios, doses,
  diagnósticos nem tratamentos. Lembre que quem cuida disso é o médico junto
  com a família.
— Temas difíceis (doença, morte, guerra, desastres): conte a verdade com
  carinho, sem detalhes assustadores, e termine acolhendo.
— Coisas perigosas (fogo, eletricidade, remédios, produtos de limpeza, bichos
  peçonhentos): explique e lembre que só se mexe nisso com um adulto.
— Nada de propaganda, marcas ou opinião política.

REGRAS DE FORMATAÇÃO (o aplicativo depende delas)
— Não use negrito, itálico, asteriscos, #, tabelas, listas numeradas, links
  nem "Fonte:". O único asterisco permitido é o que marca a alternativa
  certa nas PERGUNTAS.
— Emoji, só na linha do TÍTULO. Nunca dentro do texto.
— Letras normais: maiúscula só no começo das frases e nos nomes próprios.
  NÃO escreva nada todo em maiúsculas.
— Uma linha em branco entre cada parágrafo, entre cada fala do diálogo e
  antes de cada item da lista com •

FORMATO DA RESPOSTA

Primeiro, escreva para o pai (o aplicativo ignora tudo o que vier antes de
TÍTULO:):

PARA O PAI: [em até 6 linhas, quais sinais da escrita aparecem no texto e em
qual frase cada um está, para ele saber o que apontar durante a leitura]

Depois, escreva o bloco do texto, com os rótulos exatamente assim:

TÍTULO: [um emoji] [título curto, de preferência uma pergunta curiosa]

TAGS: [de 5 a 8 palavras-chave separadas por vírgula]

TEXTO:
[os parágrafos, o diálogo com travessão e a lista com •, tudo separado por
linhas em branco]

PALAVRAS NOVAS:
[uma palavra por linha, com a explicação no tamanho certo para a dificuldade
dela, assim:]
palavra = explicação

PERGUNTAS:
[exatamente 3 perguntas, cada uma neste formato:]
1) [a pergunta]
a) [alternativa]
b) [alternativa certa] *
c) [alternativa]
> [por que a certa é a certa, com carinho]

2) [a pergunta]
a) [alternativa certa] *
b) [alternativa]
c) [alternativa]
> [por que a certa é a certa]

PARA PENSAR:
[uma ou duas perguntas abertas, de conversa com o pai, que não têm resposta
certa ou errada]

Não escreva mais nada depois de PARA PENSAR.

REVISÃO TRIPLA OBRIGATÓRIA — FAÇA ANTES DA CONFERÊNCIA FINAL
Depois de escrever, revise o texto três vezes, cada vez com um olhar
diferente. Um texto NÃO está pronto só porque está gramaticalmente correto:
ele precisa ser fácil de ler, gostoso de acompanhar, bem dividido na tela e,
principalmente, ensinar de um jeito que fique na memória. O objetivo é o
equilíbrio entre facilidade de leitura, envolvimento e aprendizagem real.

1ª REVISÃO — LEITURA
Leia como uma criança de 6 anos leria, em voz alta, junto com o pai.
— Ela consegue ler e acompanhar cada frase com facilidade, sem se perder?
— Alguma frase ficou longa ou enrolada? Divida.
— Cada parágrafo tem de três a quatro linhas (30 a 45 palavras)? Passou,
  divida em dois; ficou com uma linha só, junte com o vizinho — menos as
  falas do diálogo, os itens da lista e a frase que apresenta a lista.
  Cinco linhas, só se não houver outro jeito.
— Os parágrafos estão curtos e visualmente confortáveis para a leitura?

2ª REVISÃO — COMPREENSÃO E ENVOLVIMENTO
Leia como a criança que está curiosa sobre o assunto.
— O começo desperta curiosidade? O texto mantém a atenção até o fim?
— Cada parágrafo traz uma ideia só, e a divisão em parágrafos ajuda a
  entender cada ideia?
— As comparações são com coisas que ela conhece de verdade?
— Existe algum trecho em que ela ficaria entediada ou perdida? Reescreva.

3ª REVISÃO — CONHECIMENTO
Leia como quem quer ter certeza de que a criança aprendeu.
— O texto ensina de verdade o assunto pedido? As informações essenciais
  estão todas lá, e só as essenciais?
— A explicação segue uma ordem que faz sentido, com começo, meio e fim?
— Depois de ler, ela conseguiria recontar o assunto com as próprias
  palavras — hoje e também daqui a alguns dias? Se não, deixe mais claro o
  que é essencial.

Só depois de passar pelas três revisões o texto segue para a conferência
final.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia tudo o que você escreveu e corrija o que não passar nos pontos abaixo.
Não escreva sobre a conferência na resposta e não comente o que mudou:
entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu SÓ este texto conseguiria explicar o
   assunto para outra pessoa? Se ficou faltando um passo, acrescente. Se ficou
   sobrando enfeite, corte.
b) Todo fato é verdadeiro? Não há número, nome, data nem explicação inventada?
   Onde a ciência ainda não sabe, o texto diz isso?
c) Alguma frase passou de vinte e cinco palavras? Algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou no texto alguma palavra difícil que não está em PALAVRAS NOVAS?
   Inclua. Alguma explicação do dicionário usa outra palavra difícil? Troque.
e) Cada explicação do dicionário está no tamanho certo para a dificuldade
   daquela palavra — curta nas fáceis, com comparação nas difíceis?
f) As perguntas podem mesmo ser respondidas por quem leu o texto? Cada
   alternativa errada é um engano possível, e não uma bobagem? A alternativa
   certa está marcada com o asterisco? Cada pergunta tem a linha começando
   com > explicando o porquê?
g) A ortografia, a acentuação e a pontuação estão impecáveis? Este texto é o
   modelo de escrita que a criança vai copiar — um erro aqui ensina errado.
h) Os sinais da escrita pedidos aparecem de forma natural, sem nenhum parecer
   enfiado à força?
i) O formato está exatamente como pedido: os rótulos certos e na ordem certa,
   linha em branco entre os parágrafos, sem negrito, sem #, e emoji só na
   linha do TÍTULO? Cada item da lista começa com • e o nome em destaque
   seguido de dois-pontos? A frase que abre a lista termina com dois-pontos,
   sem ponto depois?
j) Você repetiu alguma ideia com outras palavras só para alongar? Corte.
k) A parte do TEXTO tem entre 300 e 500 palavras? Conte de verdade. Se
   passou muito, tire a ideia que menos ensina; se ficou bem abaixo, veja
   qual explicação ficou pela metade.
l) Mesmo curto, ficaram as 3 ou 4 ideias essenciais bem explicadas, o
   diálogo (com personagens que combinam com o assunto), a lista com nomes
   em destaque e as três perguntas com a explicação da resposta?
   Os parágrafos ficaram com três a quatro linhas (fora as falas do diálogo
   e os itens da lista)?
m) O último parágrafo retoma a ideia principal de um jeito que a criança
   consiga repetir?

Só então envie a resposta.
```

## 🧠 Entender de verdade

```
Você vai escrever um texto para uma criança ler em voz alta junto com o pai.
O texto será colado num aplicativo de leitura, então siga EXATAMENTE o formato
que está no final deste pedido.

ASSUNTO: [escreva aqui o assunto, com o máximo de detalhes que quiser]
IDADE: 6 anos
NÍVEL DE LEITURA: lê bem, como uma criança de 12 anos

O OBJETIVO
Aqui vale uma coisa só: ao terminar, a criança precisa ter ENTENDIDO o
assunto de verdade, inteiro, sem buraco nenhum. Não é para ela ter ouvido
falar do assunto — é para ela conseguir explicar o assunto para outra pessoa,
com as palavras dela.

O TAMANHO NÃO IMPORTA — O ENTENDIMENTO IMPORTA
1. Não existe limite de palavras nem de parágrafos. Se o assunto se resolve
   em quatrocentas palavras, pare nas quatrocentas. Se precisa de duas mil
   para ficar realmente entendido, escreva as duas mil.
2. O que não pode é pular etapa: nunca use uma ideia antes de tê-la explicado.
3. Comece do zero. Parta do que a criança já viu na vida dela, não do que se
   aprende na escola. Não suponha que ela já sabe alguma coisa do assunto.
4. Vá em degraus pequenos: cada parágrafo dá UM passo a mais, e esse passo
   precisa caber na cabeça de quem acabou de ler o parágrafo anterior.
5. A cada duas ou três ideias novas, escreva um parágrafo curto recapitulando,
   com outras palavras, o que já ficou entendido até ali. Depois siga.
6. Quando a ideia for difícil, explique DUAS vezes, de jeitos diferentes:
   primeiro com uma comparação do dia a dia, depois direto ao ponto. Ver a
   mesma coisa por dois caminhos é o que faz a ficha cair.
7. Comprido não é a mesma coisa que bem explicado. Encher linguiça continua
   proibido: todo parágrafo tem de acrescentar entendimento, não volume.
8. Antes do fim, pergunte-se onde uma criança ainda ficaria com dúvida — e
   responda essa dúvida no próprio texto.
9. Completo, mas sem cansar. Como referência, o tamanho que tem funcionado
   bem é de umas 700 a 1.000 palavras na parte do TEXTO. Passe disso só
   quando o assunto realmente exigir para ser entendido — nunca para encher.

O QUE FAZ O TEXTO PRENDER A ATENÇÃO
Um texto correto mas sem graça falhou. Escreva como quem conta uma coisa
fascinante para alguém de quem gosta muito — não como quem explica matéria.
— Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
  criança consiga sentir no próprio corpo ou ver dentro da própria casa.
  Nunca comece com "Neste texto vamos aprender sobre...".
— Coloque pelo menos dois momentos de "nossa, eu não sabia disso!": fatos
  verdadeiros e surpreendentes, contados de um jeito que dê vontade de sair
  contando para outra pessoa.
— Transforme números e tamanhos em coisas imagináveis. "Caberia um milhão de
  Terras dentro do Sol" vale muito mais do que "o Sol tem 1,4 milhão de
  quilômetros de diâmetro".
— Toda explicação difícil vem junto com uma comparação com o mundo dela:
  cozinha, banho, escola, bicicleta, futebol, bichos, comida, chuva, o
  próprio corpo, o quintal, o interior do Brasil.
— Uma ideia de cada vez: apresente, explique, compare — e só então siga em
  frente. Nunca empilhe três conceitos novos no mesmo parágrafo.
— Fale diretamente com a criança, usando "você".
— Termine com uma ideia que ela leve para a vida ou que a faça olhar para
  algo do dia a dia com outros olhos. Sem lição de moral pesada.

SINAIS DA ESCRITA QUE O TEXTO DEVE CONTER
A criança está aprendendo os sinais da escrita, e o pai aponta cada um durante
a leitura. Por isso eles precisam aparecer de forma natural — nunca forçada.
Se algum não couber com naturalidade neste assunto, deixe de fora — menos o
diálogo, que sempre aparece.
— Ponto final, vírgula, interrogação e exclamação.
— Dois-pontos, abrindo uma fala ou uma explicação.
— Reticências, marcando uma pausa ou uma ideia que fica no ar.
— Um diálogo curto (2 a 4 falas), usando travessão, entre personagens que
  combinem com o assunto: num texto sobre navegação, um marinheiro e o
  capitão; sobre ciência, uma cientista e uma aluna; também pode ser a filha
  e o pai. O importante é TER o diálogo — quem conversa depende da história;
  se o assunto não tiver personagens, crie uma cena curta em que alguém
  pergunta e outro responde. Encaixe a conversa no ponto em que alguém faria
  mesmo aquela pergunta, de forma natural. Cada fala fica sozinha na sua
  própria linha, com uma linha em branco antes e depois.
— Aspas, num pensamento ou numa fala repetida do jeito exato.
— Parênteses, com uma explicação extra que cabe dentro da frase.
— Pelo menos uma palavra com hífen (bem-estar, guarda-chuva).
— Palavras com acento agudo, com circunflexo e com til.
— Pelo menos uma crase (à), num lugar em que ela seja realmente correta.
— A lista com • e nomes em destaque (veja LISTA COM NOMES EM DESTAQUE).
— Cada parágrafo é uma ideia, separado por uma linha em branco.

LISTA COM NOMES EM DESTAQUE (a parte de que a criança mais gosta)
No aplicativo, cada linha que começa com • vira um cartão colorido, e o nome
que vem antes dos dois-pontos aparece em destaque, com uma cor só dele. É o
recurso que mais prende a atenção da criança e ajuda a guardar os nomes
importantes. Use sempre que o assunto tiver nomes, partes, tipos, etapas ou
exemplos que valham a pena lembrar.
— Faça de uma a três listas de 3 a 5 itens, sempre que o assunto tiver nomes, partes, tipos ou etapas.
— Cada item fica numa linha própria e começa com • seguido do NOME EM
  DESTAQUE, de dois-pontos e de uma explicação curta (uma ou duas frases):
  • Acrux: a estrela mais brilhante do Cruzeiro do Sul.
  • Mimosa: outra estrela muito brilhante da mesma cruz.
— O nome em destaque tem no máximo três palavras.
— A frase que vem logo antes da lista apresenta a lista e termina com
  dois-pontos, sem ponto depois (por exemplo: "As mais fáceis de achar são:").

COMO ESCREVER AS FRASES
— Português do Brasil, com ortografia, acentuação e pontuação impecáveis. A
  criança aprende a escrever certo lendo este texto — um erro aqui ensina
  errado.
— Frases de tamanho variado, a maioria entre 8 e 18 palavras. Uma ideia por
  frase. Evite frases com mais de 25 palavras.
— Parágrafos curtos e confortáveis para os olhos: no máximo quatro linhas
  (na prática, até três frases, umas 45 palavras). Cinco linhas, só em caso
  excepcional. Parágrafo comprido cansa quem está aprendendo a ler.
— Números até vinte, escreva por extenso.

PALAVRAS NOVAS — O DICIONÁRIO DO APLICATIVO
No aplicativo a criança toca numa palavra e aparece só a explicação dela, sem
o texto em volta. Então cada explicação precisa se sustentar sozinha.
— Inclua TODAS as palavras que uma criança de 6 anos provavelmente
  não conhece. Na dúvida, inclua.
— O tamanho da explicação acompanha a DIFICULDADE da palavra, e nada mais:

    • Palavra fácil, do dia a dia, que ela só talvez não saiba: UMA frase
      curta e direta. Não alongue.
      Exemplo: alerta = quando o corpo fica ligado e pronto para agir.

    • Palavra difícil ou ideia abstrata, que exige imaginar algo novo: 2 ou 3
      linhas, nesta ordem — o que é em palavras simples, uma comparação com
      algo que ela conhece, e onde ela vê isso na vida dela.
      Exemplo: atmosfera = é a camada de ar que fica em volta de um planeta
      inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar
      que você respira e que faz as estrelas cadentes brilharem antes de
      chegar aqui embaixo.

— Explicação comprida numa palavra fácil cansa, e a criança para de tocar
  nas palavras. Explicação curta numa palavra difícil deixa ela sem entender.
  Meça pelo esforço que a palavra exige dela.
— Nunca explique uma palavra difícil usando outra palavra difícil.
— Escreva sempre no formato:  palavra = explicação

TAGS — PARA ACHAR O TEXTO DEPOIS
— Escreva de 5 a 8 palavras-chave, separadas por vírgula, que o pai digitaria
  para reencontrar este texto daqui a seis meses: o assunto principal, a área
  (corpo humano, espaço, animais, história, plantas...) e as palavras que ele
  provavelmente lembraria.
— As tags não aparecem para a criança — servem só para a busca.

PERGUNTAS — O QUIZ DO FINAL
Terminada a leitura, o aplicativo mostra perguntas para a criança responder
tocando na resposta. Elas medem se ela ENTENDEU, não se decorou.
— Faça de 3 a 6 perguntas, uma para cada parte importante do assunto, na ordem em que os assuntos aparecem no texto.
— Cada pergunta tem 3 alternativas. Marque a certa com um asterisco no fim.
— As alternativas erradas precisam ser possíveis — enganos que uma criança
  realmente cometeria. Nada de alternativa boba ou de brincadeira: isso ensina
  a chutar em vez de pensar.
— Depois das alternativas, escreva uma linha começando com > explicando, com
  carinho, por que a resposta certa é a certa. É o que a criança lê quando
  erra, então essa linha precisa ensinar, não corrigir.
— Pelo menos uma das perguntas deve exigir juntar duas partes diferentes do
  texto, e não só achar uma frase pronta.

CUIDADOS COM O CONTEÚDO
— Seja fiel à ciência. Não invente fatos, números, nomes nem datas. Se algo
  ainda não se sabe, escreva que os cientistas continuam estudando.
— Deixe claro, com respeito, a diferença entre ciência comprovada, crença ou
  tradição (astrologia, signos, simpatias) e lenda. Use frases como "os
  cientistas descobriram que...", "algumas pessoas acreditam que..." e
  "uma lenda antiga conta que...".
— Religiões: conte como cada uma acredita, com respeito, sem dizer qual é a
  certa.
— Saúde e corpo: explique como o corpo funciona. Não fale de remédios, doses,
  diagnósticos nem tratamentos. Lembre que quem cuida disso é o médico junto
  com a família.
— Temas difíceis (doença, morte, guerra, desastres): conte a verdade com
  carinho, sem detalhes assustadores, e termine acolhendo.
— Coisas perigosas (fogo, eletricidade, remédios, produtos de limpeza, bichos
  peçonhentos): explique e lembre que só se mexe nisso com um adulto.
— Nada de propaganda, marcas ou opinião política.

REGRAS DE FORMATAÇÃO (o aplicativo depende delas)
— Não use negrito, itálico, asteriscos, #, tabelas, listas numeradas, links
  nem "Fonte:". O único asterisco permitido é o que marca a alternativa
  certa nas PERGUNTAS.
— Emoji, só na linha do TÍTULO. Nunca dentro do texto.
— Letras normais: maiúscula só no começo das frases e nos nomes próprios.
  NÃO escreva nada todo em maiúsculas.
— Uma linha em branco entre cada parágrafo, entre cada fala do diálogo e
  antes de cada item da lista com •

FORMATO DA RESPOSTA

Primeiro, escreva para o pai (o aplicativo ignora tudo o que vier antes de
TÍTULO:):

PARA O PAI: [em até 6 linhas, quais sinais da escrita aparecem no texto e em
qual frase cada um está, para ele saber o que apontar durante a leitura]

Depois, escreva o bloco do texto, com os rótulos exatamente assim:

TÍTULO: [um emoji] [título curto, de preferência uma pergunta curiosa]

TAGS: [de 5 a 8 palavras-chave separadas por vírgula]

TEXTO:
[os parágrafos, o diálogo com travessão e a lista com •, tudo separado por
linhas em branco]

PALAVRAS NOVAS:
[uma palavra por linha, com a explicação no tamanho certo para a dificuldade
dela, assim:]
palavra = explicação

PERGUNTAS:
[de 3 a 6 perguntas, cada uma neste formato:]
1) [a pergunta]
a) [alternativa]
b) [alternativa certa] *
c) [alternativa]
> [por que a certa é a certa, com carinho]

2) [a pergunta]
a) [alternativa certa] *
b) [alternativa]
c) [alternativa]
> [por que a certa é a certa]

PARA PENSAR:
[uma ou duas perguntas abertas, de conversa com o pai, que não têm resposta
certa ou errada]

Não escreva mais nada depois de PARA PENSAR.

REVISÃO TRIPLA OBRIGATÓRIA — FAÇA ANTES DA CONFERÊNCIA FINAL
Depois de escrever, revise o texto três vezes, cada vez com um olhar
diferente. Um texto NÃO está pronto só porque está gramaticalmente correto:
ele precisa ser fácil de ler, gostoso de acompanhar, bem dividido na tela e,
principalmente, ensinar de um jeito que fique na memória. O objetivo é o
equilíbrio entre facilidade de leitura, envolvimento e aprendizagem real.

1ª REVISÃO — LEITURA
Leia como uma criança de 6 anos leria, em voz alta, junto com o pai.
— Ela consegue ler e acompanhar cada frase com facilidade, sem se perder?
— Alguma frase ficou longa ou enrolada? Divida.
— Algum parágrafo passou de quatro linhas (umas 45 palavras)? Divida em dois.
  Cinco linhas, só se não houver outro jeito.
— Os parágrafos estão curtos e visualmente confortáveis para a leitura?

2ª REVISÃO — COMPREENSÃO E ENVOLVIMENTO
Leia como a criança que está curiosa sobre o assunto.
— O começo desperta curiosidade? O texto mantém a atenção até o fim?
— Cada parágrafo traz uma ideia só, e a divisão em parágrafos ajuda a
  entender cada ideia?
— As comparações são com coisas que ela conhece de verdade?
— Existe algum trecho em que ela ficaria entediada ou perdida? Reescreva.

3ª REVISÃO — CONHECIMENTO
Leia como quem quer ter certeza de que a criança aprendeu.
— O texto ensina de verdade o assunto pedido? As informações essenciais
  estão todas lá, e só as essenciais?
— A explicação segue uma ordem que faz sentido, com começo, meio e fim?
— Depois de ler, ela conseguiria recontar o assunto com as próprias
  palavras — hoje e também daqui a alguns dias? Se não, deixe mais claro o
  que é essencial.

Só depois de passar pelas três revisões o texto segue para a conferência
final.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia tudo o que você escreveu e corrija o que não passar nos pontos abaixo.
Não escreva sobre a conferência na resposta e não comente o que mudou:
entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu SÓ este texto conseguiria explicar o
   assunto para outra pessoa? Se ficou faltando um passo, acrescente. Se ficou
   sobrando enfeite, corte.
b) Todo fato é verdadeiro? Não há número, nome, data nem explicação inventada?
   Onde a ciência ainda não sabe, o texto diz isso?
c) Alguma frase passou de vinte e cinco palavras? Algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou no texto alguma palavra difícil que não está em PALAVRAS NOVAS?
   Inclua. Alguma explicação do dicionário usa outra palavra difícil? Troque.
e) Cada explicação do dicionário está no tamanho certo para a dificuldade
   daquela palavra — curta nas fáceis, com comparação nas difíceis?
f) As perguntas podem mesmo ser respondidas por quem leu o texto? Cada
   alternativa errada é um engano possível, e não uma bobagem? A alternativa
   certa está marcada com o asterisco? Cada pergunta tem a linha começando
   com > explicando o porquê?
g) A ortografia, a acentuação e a pontuação estão impecáveis? Este texto é o
   modelo de escrita que a criança vai copiar — um erro aqui ensina errado.
h) Os sinais da escrita pedidos aparecem de forma natural, sem nenhum parecer
   enfiado à força?
i) O formato está exatamente como pedido: os rótulos certos e na ordem certa,
   linha em branco entre os parágrafos, sem negrito, sem #, e emoji só na
   linha do TÍTULO? Cada item da lista começa com • e o nome em destaque
   seguido de dois-pontos? A frase que abre a lista termina com dois-pontos,
   sem ponto depois?
j) Você repetiu alguma ideia com outras palavras só para alongar? Corte.
k) Tem alguma passagem em que o texto usa uma ideia antes de explicá-la?
   Traga a explicação para antes.
l) Para cada ideia difícil, existe mesmo uma comparação com o dia a dia E uma
   explicação direta?
m) Se a criança parasse em qualquer parágrafo e alguém perguntasse "o que
   você entendeu até aqui?", ela saberia responder?

Só então envie a resposta.
```

## 🔄 Adaptar um texto pronto

```
Reescreva o texto do final para uma criança de 6 anos ler em voz alta
junto com o pai. Não é para resumir: é para contar de novo, de um jeito que
prenda a atenção dela e que ela entenda de verdade.

COMO REESCREVER
1. Comece com um gancho: uma cena, uma pergunta ou um fato surpreendente que a
   criança consiga sentir no corpo ou ver dentro de casa.
2. Toda explicação difícil vem com uma comparação com o mundo dela: cozinha,
   banho, escola, bicicleta, bichos, comida, chuva, o próprio corpo.
3. Uma ideia por parágrafo, frases entre 8 e 18 palavras, falando com "você".
   Parágrafos curtos: no máximo quatro linhas (umas 45 palavras); cinco, só em
   caso excepcional.
4. O tamanho quem decide é o assunto: não encha linguiça nem corte no meio.
   Ao terminar, a criança precisa conseguir explicar o assunto para alguém.
5. Mantenha apenas as ideias que estão no texto original e que são corretas.
   Não acrescente fatos novos que não estejam lá.

SINAIS DA ESCRITA (de forma natural, nunca forçada)
6. Um diálogo curto entre personagens que combinem com o assunto (não precisa
   ser pai e filha; os personagens só conversam sobre o que já está no texto,
   sem trazer fatos novos), com travessão, cada fala sozinha na sua linha,
   com linha em branco antes e depois; aspas; parênteses; reticências;
   dois-pontos; uma palavra com hífen; acentos agudo, circunflexo
   e til; uma crase; e uma lista de 3 a 5 itens, cada um numa linha começando
   com • seguido do nome em destaque e de dois-pontos (• Acrux: a estrela mais
   brilhante do Cruzeiro do Sul.). A frase antes da lista termina com
   dois-pontos.

PALAVRAS NOVAS (o dicionário do aplicativo)
7. Inclua TODAS as palavras que uma criança de 6 anos provavelmente
   não conhece. Na dúvida, inclua.
8. O tamanho da explicação acompanha a dificuldade da palavra:
   • fácil: uma frase curta e direta. Ex.: alerta = quando o corpo fica ligado
     e pronto para agir.
   • difícil ou abstrata: 2 ou 3 linhas — o que é em palavras simples, uma
     comparação com algo conhecido e onde ela vê isso na vida dela.
9. Nunca explique uma palavra difícil usando outra palavra difícil.

TAGS
10. De 5 a 8 palavras-chave separadas por vírgula, para o pai reencontrar este
    texto depois. Não aparecem para a criança.

PERGUNTAS
11. Exatamente 3 perguntas de interpretação, cada uma com 3 alternativas. A
    certa leva um asterisco no fim. As erradas precisam ser enganos possíveis,
    nunca alternativas bobas. Depois das alternativas, uma linha começando com
    > explicando com carinho por que a certa é a certa.

FORMATAÇÃO
12. Sem negrito, sem #, sem listas numeradas e sem emoji fora do TÍTULO. Uma
    linha em branco entre cada parágrafo. O único asterisco permitido é o que
    marca a alternativa certa.

Responda somente com este bloco, nesta ordem: PARA O PAI, TÍTULO, TAGS, TEXTO,
PALAVRAS NOVAS, PERGUNTAS e PARA PENSAR, exatamente com esses rótulos. Nas
PERGUNTAS use o formato:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa

Não escreva nada depois de PARA PENSAR.

REVISÃO TRIPLA OBRIGATÓRIA — FAÇA ANTES DA CONFERÊNCIA FINAL
Depois de escrever, revise o texto três vezes, cada vez com um olhar
diferente. Um texto NÃO está pronto só porque está gramaticalmente correto:
ele precisa ser fácil de ler, gostoso de acompanhar, bem dividido na tela e,
principalmente, ensinar de um jeito que fique na memória. O objetivo é o
equilíbrio entre facilidade de leitura, envolvimento e aprendizagem real.

1ª REVISÃO — LEITURA
Leia como uma criança de 6 anos leria, em voz alta, junto com o pai.
— Ela consegue ler e acompanhar cada frase com facilidade, sem se perder?
— Alguma frase ficou longa ou enrolada? Divida.
— Algum parágrafo passou de quatro linhas (umas 45 palavras)? Divida em dois.
  Cinco linhas, só se não houver outro jeito.
— Os parágrafos estão curtos e visualmente confortáveis para a leitura?

2ª REVISÃO — COMPREENSÃO E ENVOLVIMENTO
Leia como a criança que está curiosa sobre o assunto.
— O começo desperta curiosidade? O texto mantém a atenção até o fim?
— Cada parágrafo traz uma ideia só, e a divisão em parágrafos ajuda a
  entender cada ideia?
— As comparações são com coisas que ela conhece de verdade?
— Existe algum trecho em que ela ficaria entediada ou perdida? Reescreva.

3ª REVISÃO — CONHECIMENTO
Leia como quem quer ter certeza de que a criança aprendeu.
— O texto ensina de verdade o assunto pedido? As informações essenciais
  estão todas lá, e só as essenciais?
— A explicação segue uma ordem que faz sentido, com começo, meio e fim?
— Depois de ler, ela conseguiria recontar o assunto com as próprias
  palavras — hoje e também daqui a alguns dias? Se não, deixe mais claro o
  que é essencial.

Só depois de passar pelas três revisões o texto segue para a conferência
final.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia o que você escreveu e corrija o que não passar nestes pontos.
Não comente a conferência na resposta: entregue apenas o texto já corrigido.
a) Uma criança de 6 anos que leu só este texto conseguiria explicar o
   assunto para outra pessoa?
b) Todo fato é verdadeiro, sem número, nome ou data inventada?
c) Alguma frase passou de vinte e cinco palavras, ou algum parágrafo ficou com
   mais de uma ideia? Quebre.
d) Sobrou palavra difícil fora de PALAVRAS NOVAS? Alguma explicação usa outra
   palavra difícil? E o tamanho de cada explicação combina com a dificuldade
   da palavra?
e) As perguntas podem ser respondidas por quem leu o texto, as alternativas
   erradas são enganos possíveis e a certa está marcada com o asterisco?
f) Ortografia, acentuação e pontuação impecáveis?
g) O formato está exato: rótulos certos, linha em branco entre parágrafos, sem
   negrito, sem #, emoji só no TÍTULO?
h) As ideias continuam sendo as do texto original, sem nenhum fato novo que
   não estava lá?

Só então envie a resposta.

TEXTO ORIGINAL:
[o texto que você colar]
```

## ➡️ Continuar o mesmo assunto

```
Continue o mesmo assunto explicando agora [o que você quiser que ela aprenda agora],
com as mesmas regras e exatamente o mesmo formato de antes, incluindo TAGS e
PERGUNTAS. Não repita o que já foi explicado.

Lembretes: comece com um gancho que dê curiosidade; toda explicação difícil
vem com uma comparação com o mundo da criança; mantenha o mesmo tamanho do
texto anterior; parágrafos do mesmo tamanho dos do texto anterior (de três a
quatro linhas; cinco, só se não houver outro jeito); mantenha o diálogo
(entre personagens que combinem com o assunto) e a lista com • e nomes em
destaque (• Nome: explicação); em PALAVRAS NOVAS o tamanho da explicação
acompanha a dificuldade da palavra (fácil = uma frase; difícil = 2 ou 3
linhas com comparação); e as 3 perguntas do final precisam ter alternativas
erradas que sejam enganos possíveis, com a linha > explicando a certa.

REVISÃO TRIPLA OBRIGATÓRIA — FAÇA ANTES DA CONFERÊNCIA FINAL
Depois de escrever, revise o texto três vezes, cada vez com um olhar
diferente. Um texto NÃO está pronto só porque está gramaticalmente correto:
ele precisa ser fácil de ler, gostoso de acompanhar, bem dividido na tela e,
principalmente, ensinar de um jeito que fique na memória. O objetivo é o
equilíbrio entre facilidade de leitura, envolvimento e aprendizagem real.

1ª REVISÃO — LEITURA
Leia como a criança leria, em voz alta, junto com o pai.
— Ela consegue ler e acompanhar cada frase com facilidade, sem se perder?
— Alguma frase ficou longa ou enrolada? Divida.
— Algum parágrafo passou de quatro linhas (umas 45 palavras)? Divida em dois.
  Cinco linhas, só se não houver outro jeito.
— Os parágrafos estão curtos e visualmente confortáveis para a leitura?

2ª REVISÃO — COMPREENSÃO E ENVOLVIMENTO
Leia como a criança que está curiosa sobre o assunto.
— O começo desperta curiosidade? O texto mantém a atenção até o fim?
— Cada parágrafo traz uma ideia só, e a divisão em parágrafos ajuda a
  entender cada ideia?
— As comparações são com coisas que ela conhece de verdade?
— Existe algum trecho em que ela ficaria entediada ou perdida? Reescreva.

3ª REVISÃO — CONHECIMENTO
Leia como quem quer ter certeza de que a criança aprendeu.
— O texto ensina de verdade o assunto pedido? As informações essenciais
  estão todas lá, e só as essenciais?
— A explicação segue uma ordem que faz sentido, com começo, meio e fim?
— Depois de ler, ela conseguiria recontar o assunto com as próprias
  palavras — hoje e também daqui a alguns dias? Se não, deixe mais claro o
  que é essencial.

Só depois de passar pelas três revisões o texto segue para a conferência
final.

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Releia o que você escreveu e corrija o que não passar nestes pontos.
Não comente a conferência na resposta: entregue apenas o texto já corrigido.
a) Uma criança que leu só esta continuação entende a parte nova do assunto?
b) Todo fato é verdadeiro, sem número, nome ou data inventada?
c) Você repetiu algo que já tinha sido explicado antes? Corte.
d) Alguma frase passou de vinte e cinco palavras, ou algum parágrafo ficou com
   mais de uma ideia? Quebre.
e) Sobrou palavra difícil fora de PALAVRAS NOVAS? O tamanho de cada explicação
   combina com a dificuldade da palavra?
f) As perguntas podem ser respondidas por quem leu o texto, as alternativas
   erradas são enganos possíveis e a certa está marcada com o asterisco?
g) Ortografia, acentuação e pontuação impecáveis?
h) O formato está exato: rótulos certos, linha em branco entre parágrafos, sem
   negrito, sem #, emoji só no TÍTULO?

Só então envie a resposta.
```

## 🛠️ Consertar formato

```
Sua resposta saiu do formato combinado. Reescreva exatamente no formato
PARA O PAI / TÍTULO / TAGS / TEXTO / PALAVRAS NOVAS / PERGUNTAS / PARA PENSAR,
com uma linha em branco entre os parágrafos e entre cada fala do diálogo, sem
negrito, sem #, sem listas numeradas, sem emoji fora do TÍTULO e sem escrever
nada depois de PARA PENSAR.

Nas PERGUNTAS use exatamente este formato, com 3 perguntas:
1) pergunta
a) alternativa
b) alternativa certa *
c) alternativa
> por que a certa é a certa

CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR
Antes de responder, confira o que você reescreveu e corrija o que estiver
fora. Não comente a conferência: entregue apenas o texto corrigido.
a) Os sete rótulos estão presentes, escritos exatamente assim e nesta ordem:
   PARA O PAI, TÍTULO, TAGS, TEXTO, PALAVRAS NOVAS, PERGUNTAS, PARA PENSAR?
b) Há uma linha em branco entre cada parágrafo e entre cada fala do diálogo?
c) Não sobrou negrito, asterisco fora das alternativas certas, #, lista
   numerada nem emoji fora da linha do TÍTULO?
d) Cada pergunta tem 3 alternativas, uma marcada com asterisco e uma linha
   começando com > logo depois?
e) O conteúdo do texto continua o mesmo — você só arrumou o formato?

Só então envie a resposta.
```

