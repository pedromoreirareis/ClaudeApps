# Pasta de trabalho — o que tem aqui

- **`modelo-cadastro-novo/`**: as cópias mestras do **cadastro novo da família**, que vieram do 📚 Alfabetização v123:
  - `escola-familia.js` 1.2;
  - `nuvem-sync.js` 4.1;
  - `sw_alfabetizacao_v123.js` (só como modelo de `sw.js`);
  - `LEIA-ME_COMPARTILHADOS.md` (com os md5).

  ⚠️ **O Coruja Explica v3.1 NÃO usa estes arquivos.** Ele usa o `nuvem-sync.js` **v3** que está em `pacote-netlify/`. Estes só entram quando for feito o cadastro novo (capítulo 12 do histórico).
- **`versoes-anteriores/`**: os zips do Netlify de todas as versões entregues, da v1.3 à v3.0. A v3.1 é o `pacote-netlify/`. Servem para voltar atrás, se precisar.
- **`estudo-espacos/`**: o script do estudo do espaço entre palavras (modo "Espaços", v3.1) e o texto de exemplo usado.
  - O resultado está no comentário do código (`ESPACO_MAX_FATOR`) e no capítulo 4 do histórico.
  - ⚠️ O script tem caminhos da conversa antiga: ajuste antes de rodar.
- **`scripts/`**: scripts de capturas de tela e de medida dos pop-ups.
  - ⚠️ Também têm caminhos da conversa antiga: ajuste antes de rodar.
  - Não são testes.
- **`capturas/`**: telas da v3.0/v3.1 tiradas no Chromium (cadastro com teclado, pop-up do código, Configurações, Recuperar, ajustes, Camila formatado, modo Espaços).
- **`scripts-da-passagem/`**: scripts usados nesta passagem (14/10/2026):
  - `fazer_leiame_zip.py`: gera o `LEIA-ME.txt` com os md5 e monta o zip;
  - `smoke_passagem.js`: abre o app no Chromium sem tela, com o Firebase bloqueado, e mostra os erros do console;
  - `gerar_prompts.js`: gera o `documentos/PROMPTS_IA_v3.1.md`.

  O `CHANGELOG_POR_VERSAO_v1.3-v3.1.md` foi feito por um agente que comparou os zips de `versoes-anteriores/`, com scripts de uso único que **não foram guardados**. Ele pode ser refeito comparando os zips.
