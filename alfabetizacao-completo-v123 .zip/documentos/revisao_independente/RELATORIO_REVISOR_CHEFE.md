# Relatório do Revisor-chefe (camada 3 da parte 9-A)

**App:** 📚 Alfabetização (Esforço Vence) · **v121 (publicada) → v122 (zip final, para o SITE DE TESTE)**
**Data:** 07/10/2026 · **Revisor:** revisor-chefe independente (não vi a conversa de quem programou; confiei só nos arquivos e no que eu rodei)

Pastas deste revisor (todas em `/home/claude/revC/`):
- `final/` (zip completo v122), `netlify/` (zip do Netlify), `anterior/` (v121), `r2zip/` e `r3zip/` (zips das rodadas 2 e 3, só para comparar);
- `meus_testes/` (os meus testes: `c1` a `c5`), `scriptsB/` (cópia dos scripts do Revisor B apontada para o zip final);
- `logs/` (tudo o que rodei), `capturas/` (239 capturas de tela).

---

## Resumo em 1 minuto

- **Os 8 achados que bloqueavam estão corrigidos no zip final.** Conferi cada um **rodando de novo** os testes dos revisores contra o zip final (não contra as rodadas antigas):
  - Revisor A: 🟠 A1, A2, A3, A4.
  - Revisor B: 🔴 B1, 🟠 B2, B3 e N1.
- **Atenção a um detalhe do processo:** o zip final **não é igual** ao que os revisores viram por último.
  - O `index.html` mudou depois da rodada 3 do B (6 linhas de CSS e 1 linha de código da barra de cima, para corrigir os 🟡 R3-1 e R3-2).
  - O Revisor A viu por último a rodada 2. Depois dela só mudaram coisas de aparência (conferi o diff).
  - Por isso rodei os scripts do A **e** do B no zip final. Tudo passou como antes. As mudanças novas fazem o que prometem: letra da pílula com 14 px e a 🦉 continua na barra deitado.
- **Todos os testes do zip passam:** 520 de 521. A única falha (`teste_fonte`) acontece **igual na v121**: rodei a v121 aqui e ela também dá 57/58.
- **Os meus testes (5 scripts, 61 conferências) passaram:**
  - tirar criança sem internet, com nuvem dando erro e a última nas 2 semanas;
  - lixeira;
  - migração com 33 chaves por criança e ida e volta v121 ↔ v122 com outro celular gravando;
  - nuvem que falha ao recuperar;
  - 2 famílias;
  - limite de 4 famílias.
- **Achei 5 pontos novos, todos 🟡 (leves).** Nenhum perde histórico neste app. Um deles (chaves de criança tirada que voltam a ser gravadas) precisa ser corrigido no `nuvem-sync.js` **antes** de ele ir para a Matemática e o Fluência.
- **Pacote certo:**
  - 9 arquivos na raiz do zip do Netlify;
  - `nuvem-config.js` com o md5 `1d5f060a…`;
  - `escola-pwa.js` igual ao da v121;
  - `sw.js` com o cache `esforco-vence-v122` e com o `escola-familia.js` na lista;
  - `compartilhados/` igual ao pacote.
- **Veredito: ✅ Pode publicar no SITE DE TESTE** (zero 🔴 e zero 🟠 em aberto).

---

## 1. Conferência de cada achado 🔴/🟠 (rodado de novo, no zip final)

| Achado | Situação | Prova que eu rodei no zip final |
|---|---|---|
| 🟠 **A1** Depois de mudar o bichinho, a ficha antiga virava uma 2ª criança ☁️ na T4 | ✅ Corrigido | `revA/t6_mudar_varios_apps.py`: **2/2**. O cartão `hana_1f98a` não aparece mais na T4. `teste_revisao.py` "A1/A3": OK. |
| 🟠 **A2** Progresso guardado só na lixeira era esquecido quando a criança voltava pela nuvem | ✅ Corrigido | `revA/t5_lixeira_e_nuvem.py`: **7/7**. Meu `c1` também prova: a Bia tirada sem internet (2 frases na nuvem + 3 só na lixeira) volta pelo cartão ☁️ da T4 com **5 frases**. A lixeira esvazia e a nuvem fica com 5. |
| 🟠 **A3** A T6 escondia de vez a ficha antiga; "AGORA NÃO" valia para sempre | ✅ Corrigido | `revA/t1_compat_v3_v4.py`, parte 3: `aparece=1` (a ficha antiga aparece em "📦 Nomes antigos"). `revA/t8_r2_leves.py`: **7/7**: o "AGORA NÃO" vale 1 dia. |
| 🟠 **A4** O `nuvem-sync.js` v4 jogava a fila fora se a lista de crianças desse erro | ✅ Corrigido | `revA/t7_usuarios_erro.py`: na v122 a fila fica `['1']` e a nuvem chega a 2 frases, igual à v121. `teste_revisao.py` "A4": OK. |
| 🔴 **B1** Com o teclado abrindo, o campo do código perdia o foco e às vezes sumia | ✅ Corrigido | `b2_foco.py`: 24 casos (T2, T3 e T5), **nenhum** `focusout`. `b2c_repete20.py`: o foco fica no campo em todas as repetições. `b3_sumico.py`: o campo continua com 272×48 px com a tela baixa. `b1_telas.py`: 18 casos de teclado, todos com campo, botão, ✕/← e os 8 bichinhos à vista. |
| 🟠 **B2** A barra de cima escondia a pílula "☀️ 0/10 · 🌱 Nível…" | ✅ Corrigido | `b6_meta.py`: em 14 larguras (640 a 915 px), **nenhuma sobreposição**. `b14_barra.py`: a pílula nunca fica coberta, em 15 tamanhos × 4 telas. |
| 🟠 **B3** No "Arrumar", o ✏️🗑️ cobria o bichinho | ✅ Corrigido | `b8_dobras.py`: cobre **0%** do bichinho em 568, 640, 740 e 915 px. Olhei a captura `F5_pergunta_tirar.png`. |
| 🟠 **N1** Os botões da barra encolhiam para 42 e 36 px | ✅ Corrigido | `b14_barra.py` (zip final): o menor botão tem **52 px deitado e 46 px em pé**, igual à v121 (rodei a v121 no mesmo script: 46 px em pé). Nenhum botão sobreposto ou para fora da tela. |
| 🟡 R3-1 / R3-2 (corrigidos **depois** da rodada 3; o B não viu) | ✅ Conferido por mim | `b14_barra.py`: pílula com **14 px** de 568 a 700 px de largura e 🦉 **presente** em todos os tamanhos deitado. Só em pé, com 320 px, a 🦉 sai; na v121, nesse tamanho, o ⛶ ficava para fora da tela. É 🟡: o app é usado deitado. |

Também rodei de novo os outros scripts do B, sem nenhum achado novo:
- `b4_t4.py`: as únicas "falhas" são os 46 px em pé, que já eram assim na v121;
- `b7r2_fluxos.py`: **0 achados**, nenhuma caixinha do navegador;
- `b9_smoke.py`: o app antigo inteiro, com **0 erros de JavaScript**;
- `b13_meio.py`: 98% a 100% do cartão à vista.

Os scripts do A também passaram com os mesmos números da rodada 2 dele:
- t1: 21/21;
- t2: 23/24;
- t3: 8/10;
- t4: 10/10;
- t5: 7/7;
- t6: 2/2;
- t8: 7/7.

As 3 "falhas" que sobram são das expectativas antigas do próprio script, como o A já explicou na rodada 2:
- t2 d: o app grava o "dia/hoje" da criança aberta;
- t3 c: agora o backup **junta** (12 frases, e não 10);
- t3 e: o `nuvem_familia` agora só recebe família conferida.

---

## 2. Achados próprios (só 🟡)

### 🟡 C1. As chaves de uma criança tirada podem voltar a ser gravadas por uma "junção" da nuvem que já estava a caminho

- **Onde:**
  - `nuvem-sync.js` v4: `checarNuvem` / `enviarComSeguranca`. Os dois chamam `aplicar(u.id, …)` com a lista de crianças lida **antes** da resposta da nuvem chegar.
  - `index.html`: `nuvemMesclar` (linha 6503). Ele grava `_rawSet(prefixo+chave)` sem conferir se a criança ainda existe.
- **O que acontece:**
  - Ao tirar a criança, o `limparPendencia()` apaga o "meta" dela.
  - Se nessa hora uma leitura da nuvem já estava a caminho, quando a resposta chega o `nuvem-sync` acha que "não conhece" a ficha e junta os dados de volta no celular.
  - Resultado: as chaves `hana_*` da criança que saiu reaparecem, sem dono na lista.
- **Como reproduzir (RODADO):** `meus_testes/c5_orfas.py`, que repete 6 vezes "tirar a criança aberta". Em 2 das 6 vezes reapareceram `hana_done`, `hana_idx`, `hana_day`, `hana_today`, `hana_words` e `hana_trilha_v2`, com os valores da nuvem.
- **Por que é leve neste app:**
  - Não se perde nada: são os dados que já estavam na nuvem.
  - A criança não aparece na v122, porque a lista vazia é respeitada e nada lê `hana_*` sem criança.
  - Na v121, uma lista com crianças também é respeitada.
- **Por que precisa de correção antes dos outros apps:** na **Matemática** e no **Fluência**, o id da criança é o **nome sem acento** (`hinata`). Exemplo:
  1. Tira-se a "Ana 🐼" e as chaves dela reaparecem.
  2. Depois, cadastra-se **outra** criança chamada "Ana" (🦊).
  3. A nova Ana herda o progresso da antiga.
  - O plano manda usar o `nuvem-sync.js` v4 "sem mudar" nos outros apps.
- **Sugestão:**
  - No `nuvem-sync.js`, logo antes de cada `aplicar(id, …)` (em `checarNuvem`, `enviarComSeguranca` e `recuperar`), conferir de novo `usuarioPorId(id)`. Se a criança não está mais na lista, não aplicar.
  - Ou, no adaptador, o `mesclar` ignorar id que não existe.
  - Acrescentar um teste: "tirar com leitura da nuvem a caminho".

### 🟡 C2. A bolinha fica 🟢 "TUDO GUARDADO NA NUVEM" enquanto há progresso guardado **só** na lixeira do celular

- **Onde:** `escola-familia.js`, `situacao()` (linha 313). Ela só olha a fila do `nuvem-sync`.
- **Como reproduzir (RODADO):** `meus_testes/c3_nuvem_falha_2familias.py`, parte C3.4.
  1. Sem internet, a Bia lê mais frases.
  2. Ela é tirada com "GUARDAR UMA CÓPIA NESTE CELULAR E TIRAR".
  3. A internet volta.
  - Resultado: a bolinha mostra `verde: TUDO GUARDADO NA NUVEM`, mas a lixeira tem a Bia com 4 frases e a nuvem só tem 2.
- **Risco:** o adulto confia na bolinha verde e limpa os dados do navegador. As 2 frases que só estavam na lixeira somem. Isso só acontece se ele não trouxer a criança de volta.
- **Sugestão:** quando a lixeira tiver alguém, mostrar na T4 e na seção "☁️ Família e nuvem" uma linha "🗑️ 1 CRIANÇA GUARDADA SÓ NESTE CELULAR". Também dá para deixar a bolinha 🟡 enquanto a lixeira tiver progresso que a nuvem não tem.

### 🟡 C3. Depois das 2 semanas, "tirar todas" + voltar ao v121 deixa a "Hana 👧" fantasma gravar por cima da ficha dela na nuvem

Este é o **risco aceito pelo plano** (parte 9 e T8): o bloqueio das 2 semanas existe e funciona. Medi o tamanho do risco para que ele fique escrito.
- **Como reproduzir (RODADO):** `meus_testes/c4_limites_tirartodas.py`, parte C4.2.
  1. Com o bloqueio já vencido, tira-se a única criança (Hana 👧, 30 frases).
  2. O app é aberto 2 vezes na v121.
  3. Aparece "Hana 👧", vazia.
  4. Ela lê 1 frase.
  - Resultado: a ficha `hana_1f467` da nuvem passa de **30 para 1 frase** (a cópia do dia também é regravada).
- **Dentro das 2 semanas**, o meu `c1` (parte C1.3) prova que o app **não deixa** tirar a última criança.
- **Sugestão:** no zip do **site de verdade**, a lista "conferir antes e depois de publicar" deve dizer em destaque: *"Depois das 2 semanas, se alguma vez todas as crianças forem tiradas de um celular, NUNCA publique de novo o zip v121."* No site de teste isso não se aplica (lá não existe v121).

### 🟡 C4. A matriz da camada 1 tem ✅ que não têm prova completa

Veja a parte 3: "4 famílias: só lido" está ✅, e a migração com **os dados reais** não foi feita.

### 🟡 C5. O roteiro do site de teste não testa o caminho mais arriscado: "guardar uma cópia e tirar" sem internet

- **Onde:** `documentos/INSTRUCOES_SITE_DE_TESTE_v122.md`, parte 4. Ela só testa "Cancelar" e depois "tirar com internet".
- **Sugestão:** acrescentar este passo:
  1. Em modo avião, tire a TESTE BIA **segurando 3 s** em "GUARDAR UMA CÓPIA NESTE CELULAR E TIRAR".
  2. Desligue o modo avião.
  3. Toque na 🐰 TESTE BIA ☁️ da "Quem vai estudar hoje?".
  4. Ela tem que voltar **com as frases lidas sem internet**.

*Observação, sem gravidade e sem relação com a v122:* um valor inválido gravado à mão em `hana_font` (ex.: texto em vez de número) trava o app ao abrir. Isso acontece **igual na v121**: o código do `initFont` é o mesmo. Só acontece com dado estragado de propósito; o app nunca grava assim.

---

## 3. Matriz da camada 1 conferida contra o zip final

Conferi cada linha contra os testes que existem no zip e que eu rodei:
- `teste_familia` 128/128;
- `teste_revisao` 59/59;
- `teste_cadastro` 72/72;
- `teste_nuvem` 81/81;
- `teste_pwa` 34/34;
- Node 89/89.

Os números do relatório (total 520/521) **batem** com o que eu rodei.

| Linha da matriz | Situação |
|---|---|
| T1–T9, 4.10, 4.11, 4.12, parte 3/3-A, regras 1, 2, 4–9, D2–D4, D6, D7, D9, D11, D13–D16, ficha do app (prefixo, Hana fantasma, backup junta, "Continuar de onde parei"), nuvem-sync v4, voltar ao zip anterior, site de teste | ✅ **Com prova.** O teste citado existe e passou. Várias também passaram nos meus testes ou nos scripts do A e do B. |
| Ficha: `hana_abrirhub` (sem laço T4 → recarrega → T4) | ✅ com prova **indireta**: os fluxos de cadastro e de escolher criança (`teste_cadastro` 1ª e `b7r2_fluxos`) passam sem laço. Não há um teste com esse nome. Aceito. |
| **D5** "6 por família, 4 famílias" | ⚠️ Estava **✅ com "4 famílias: só lido"**: ✅ sem prova (vai contra a regra "item sem prova fica ⬜"). **Agora tem prova:** o meu `c4` (parte C4.1) mostra que, com 4 famílias, "ENTRAR EM OUTRA FAMÍLIA" é recusado. Corrigir a matriz. |
| **Migração A–H** "com retratos dos **dados reais**" (parte 9 e parte 9-A, camada 1, item 2) | ⚠️ ✅ **sem a prova pedida.** Os retratos são **inventados** (2 crianças). Não há backup real do Pedro no zip nem nos relatórios. Para o site de teste isso é aceitável. Mas a linha deveria estar **⬜ "falta o retrato dos dados reais"**, e isso tem que ser feito **antes do zip do site de verdade**. (A minha migração com 33 chaves por criança e fila v3, no `c2`, passou byte a byte, mas também é inventada.) |
| **Regra 3** Firebase sem mudança | ✅ com prova parcial (Firebase de mentira) + leitura do guia. Correto dizer "lido" para o Firestore real; só o site de teste confirma o `currentDocument.exists=true` de verdade. |
| **Regra 10** teclado | ✅ com prova no navegador sem tela; o teclado real fica para o celular (está dito). Correto. |
| **D1** arquivo compartilhado (prova "—") | Aceito: a prova é o md5 (cópia mestra = pacote), que eu conferi. |
| D8 ⬜, D10 e D12 (outros apps) | Corretos. |
| Falta uma linha | "Botão voltar do Android" (parte 9) não tem linha própria na matriz. O teste existe (`teste_familia` 11, `b7r2_fluxos`) e passou. Só acrescentar a linha. |

**Resumo da matriz:** 2 ✅ sem prova completa (D5 e "migração com dados reais"). Nenhum deles esconde um defeito: o D5 eu provei agora, e a migração inventada passou. Ficam como 🟡 (C4), com a condição de fazer o retrato real antes do site de verdade.

---

## 4. Pacote conferido (rodado)

| Item | Resultado |
|---|---|
| Zip do Netlify só com os 9 arquivos na raiz (sem pastas) | ✅ `unzip -l`: `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`, `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js`, `escola-familia.js` |
| `nuvem-config.js` md5 `1d5f060a5ae8339921d3d58498807971` | ✅ igual (e igual ao da v121) |
| `escola-pwa.js` igual ao da v121 | ✅ md5 `ec31bf4a…` nos dois |
| `sw.js` com cache novo e com `escola-familia.js` | ✅ `esforco-vence-v122` (a v121 era `-v121`); `./escola-familia.js` está na lista `FILES` |
| `compartilhados/` igual ao pacote | ✅ `escola-familia.js` `8872b010…` e `nuvem-sync.js` `c953cfd3…` iguais no `compartilhados/`, no `pacote-netlify/`, no zip do Netlify e em `testes/` |
| Zip do Netlify = `pacote-netlify/` do zip completo | ✅ md5 de todos os 9 iguais |
| `node --check` | ✅ nos 5 `.js` e nos 2 blocos `<script>` do `index.html` |
| `alert(` / `confirm(` / `prompt(` | ✅ nenhum no `escola-familia.js`; no `index.html` só aparecem em comentários |
| Nenhum `DELETE` na nuvem | ✅ nenhum no código (`nuvem-sync.js`, `escola-familia.js`, `index.html`) e nenhum nas chamadas gravadas pelos meus testes |
| Cache do `sw.js` | 🟡 já conhecido (N3): o nome é o mesmo desde a rodada 1. Só é seguro se **nenhum** zip v122 anterior foi publicado no site de teste (o autor diz que não). Qualquer correção depois desta precisa mudar o nome do cache. |

---

## 5. Os meus testes (escritos e rodados por mim)

Todos com Chromium sem tela e o Firebase de mentira (`fakefb.py`), nunca o Firebase real, nas portas 8901 a 8918. Os resultados ficam em `/home/claude/revC/logs/meu_*.log`.

| Script | O que prova | Resultado |
|---|---|---|
| `c1_tirar_offline_lixeira.py` | **Tirar sem internet** a criança aberta, com fila. A criança (toque rápido e 1,5 s) não consegue tirar; segurando 3 s, tira com cópia na lixeira (5 frases + favorita). Nenhuma chave `p2_*` sobra, a Hana fica intacta e, ao abrir 2× sem internet, nenhuma fantasma aparece. A nuvem não é apagada. Com a internet de volta, o cartão ☁️ traz a Bia com **5** (nuvem 2 + lixeira 3), a lixeira esvazia e a nuvem fica com 5. **Nuvem com erro 403**: não tira sem cópia; quando a nuvem volta, tira direto com as 7 frases na nuvem. **Última criança nas 2 semanas**: não deixa tirar. | **24/24** |
| `c2_migracao_volta.py` | Retrato com **33 chaves × 2 crianças** (Hana "1" 👧 e Hinata 🌸), usado de verdade na v121 (com fila v3 sem internet), enquanto outro celular grava na nuvem. A v122 abre sem internet: **todas as chaves antigas idênticas byte a byte**, a única nova é `escola_familia` e a fila v3 é preservada. Com internet, a fila sobe e a favorita do outro celular chega. **Volta ao v121**: mesmas crianças, mesmo progresso, mesma família; a v3 junta a gravação do outro celular. **De novo na v122**: nada duplicado. Na nuvem, nenhuma ficha extra e nenhum DELETE. **Caso B** + v121: tudo igual e nada sobe sem código. | **22/22** |
| `c3_nuvem_falha_2familias.py` | **Recuperar da nuvem que falha** (503 ao baixar): o cartão ☁️ e a T5 não criam criança vazia, e a nuvem fica intacta. **Cadastrar de novo o mesmo nome + bichinho com a nuvem fora do ar (403)**: a criança é criada, nada vazio sobe por cima, a bolinha não fica verde, e quando a nuvem volta ela recebe as 9 frases. **"Já tenho cadastro" com erro 403**: não entra e não grava nada. **2 famílias**: entrar na 2ª família (trava do adulto), trazer a Lia; cada criança sobe só para a pasta da sua família. **Bolinha com a lixeira** (achado C2). | **18/18** (+ a informação do C2) |
| `c4_limites_tirartodas.py` | **D5**: com 4 famílias, não entra em uma 5ª. **Depois das 2 semanas**: tirar todas → v121 → a fantasma aparece e grava por cima (achado C3, risco aceito pelo plano). | **5/5** (+ a informação do C3) |
| `c5_orfas.py` | Tirar a criança aberta, 6 vezes seguidas: as chaves voltam em 2 das 6 (achado C1) | informação do C1 |

---

## 6. O que foi RODADO e o que foi só LIDO

**RODADO (nesta máquina, no zip final):**
- `npm install` e `node testes/rodar_testes.js`: **89/89**.
- Testes do zip com navegador:

  | Teste | Resultado |
  |---|---|
  | `teste_cadastro.py` | **72/72** |
  | `teste_nuvem.py` | **81/81** |
  | `teste_pwa.py` | **34/34** |
  | `teste_familia.py` | **128/128** |
  | `teste_revisao.py` | **59/59** |
  | `teste_fonte.py` | **57/58** |

- A falha do `teste_fonte.py` ("Ler 412×915 em pé, tamanho 24: 86%") **também acontece na v121**: rodei o mesmo teste na v121 e deu 57/58.
- Os 8 scripts do Revisor A e 12 scripts do Revisor B, apontados para o zip final (e o `b14_barra.py` também na v121, para comparar).
- Os meus 5 scripts (parte 5).
- Os md5, a lista do zip do Netlify, o `node --check` e a busca por `alert`/`confirm`/`prompt`/`DELETE`.
- Olhei as capturas `barra_final_ler_640x360.png` e `F5_pergunta_tirar.png`.

**Só LIDO:**
- O plano inteiro; os 5 relatórios do A e do B; o `RELATORIO_CHECAGEM` e as `INSTRUCOES_SITE_DE_TESTE`.
- O diff `nuvem-sync.js` v3 → v4.
- Os diffs da rodada 2 → final (`escola-familia.js`: só textos e CSS; `index.html`: só a barra de cima).
- As partes do `escola-familia.js` de migração, tirar, lixeira, trazer, T4, T5 e T6, e o adaptador e o `nuvem​Mesclar` do `index.html`.
- O comportamento do **Firestore de verdade** (`PATCH` com `updateMask` e `currentDocument.exists=true`; listagem `familias/{c}/usuarios`): conferido só pelo guia e pelo Firebase de mentira.

---

## 7. O que só o celular de verdade confirma (Pedro, confira no site de teste)

1. **Teclado de verdade** na T2 (código), na T3 (criar código) e na T5 (nome), deitado e em pé: ele abre, **fica aberto**, e o campo continua à vista. Repita umas 5 vezes.
2. **Segurar 3 s** com o dedo (👁 MOSTRAR, CÓPIAS DE CADA DIA, GUARDAR UMA CÓPIA E TIRAR) não abre o menu de copiar do Android.
3. **Botão voltar** do Android no app instalado: fecha o pop-up, sai do "Arrumar", depois fecha a tela.
4. **Modo avião de verdade:** tire a TESTE BIA com "guardar uma cópia" (segurando 3 s), desligue o modo avião e toque nela ☁️ na "Quem vai estudar hoje?". Ela tem que voltar **com tudo** (achados A2 e C5).
5. **2 celulares** com `teste-pedro-2026`: o que um faz aparece no outro (🔄 ATUALIZAR AGORA). Também: mudar o bichinho num celular e ver o aviso "MUDOU PARA…" no outro.
6. **Firestore real:** depois de mudar o bichinho, a ficha antiga some da "Quem vai estudar hoje?" e aparece só em "📦 Nomes antigos".
7. **Barra de cima** no seu celular: botões grandes, pílula inteira e legível, 🦉 aparecendo, chip ao lado da ⚙️.
8. **Na TV a 3 m:** as meninas acham o próprio bichinho, e a letra das telas novas dá para ler.
9. A **faixa roxa** "🧪 SITE DE TESTE" aparece, e o app recusa um código que não comece com "teste".

---

## 8. Pontos 🟡 em aberto (para o OK do Pedro)

**Meus:**
- C1: chaves de criança tirada que voltam. Corrigir no `nuvem-sync.js` **antes** da Matemática e do Fluência.
- C2: bolinha 🟢 com progresso só na lixeira.
- C3: aviso escrito sobre o v121 depois das 2 semanas, no zip do site de verdade.
- C4: matriz (D5 e a migração com dados reais). Fazer o retrato real **antes do site de verdade**.
- C5: um passo a mais no roteiro do site de teste.

**Do A (rodada 2):**
- `sw.js` com o mesmo nome de cache (N3);
- lixeira de criança que voltou com outro nome;
- janela "a conferir" do `nuvem_familia`.

**Do B:**
- B8: T4 sem ⚙️;
- B11: código em minúsculas na T8;
- B15: `teste_fonte` 57/58, igual na v121;
- campo estreito em pé com 320 px;
- 🦉 fora da barra só em pé com 320 px;
- botões de 46 px em pé, iguais aos da v121.

Nenhum deles perde histórico, quebra o app ou contraria uma regra de ouro na v122 do Alfabetização.

---

✅ Pode publicar
