# Relatório de checagem — 📚 Alfabetização v122 (SITE DE TESTE)

**07/10/2026 · PLANO_CADASTRO_FAMILIA.md (aprovado, D1–D16) · protocolo da parte 9-A**

> **Para que serve este zip:** o **site de teste** (`escolasaopedroalfabetizacao-teste.netlify.app`), com a família `teste-pedro-2026`. O site de verdade continua na v121 até você aprovar o teste.
> **Veredito do revisor-chefe: ✅ Pode publicar (no site de teste).** Zero 🔴 e zero 🟠 em aberto.

---

## 1. O que foi RODADO de verdade × só LIDO

**Rodado de verdade (nesta máquina, Chromium sem tela + Firebase de mentira; nunca o Firebase real):**
- `node --check` em todo JavaScript (os 2 `<script>` do `index.html`, `sw.js`, `nuvem-sync.js`, `escola-familia.js`, `escola-pwa.js`).
- Todos os testes: rápidos 89/89 · cadastro 72/72 · nuvem 81/81 · PWA 34/34 · família 128/128 · revisão 59/59 · fonte 57/58 (**total 520/521**).
  - A 1 falha da fonte (Ler 412×915, tamanho 24: 86% em vez de 90%) acontece **igual com a v121** nesta máquina, que não tem as fontes Roboto/Arial (rodei a v121 aqui e deu o mesmo). Não tem relação com o cadastro.
- Migração byte a byte: um retrato com 2 crianças aberto na v121 e na v122 → todas as chaves antigas idênticas; a única nova é `escola_familia`.
- Voltar ao app anterior (v121) depois da migração e depois de tirar uma criança: abre com tudo, sem "Hana fantasma".
- 12 tamanhos de tela (deitado, em pé, tablet e com teclado) + o teclado abrindo **depois** do toque (5 tamanhos × T2/T3/T5, 5 vezes cada).
- `md5` de todos os arquivos; `nuvem-config.js` = o seu (`1d5f060a5ae8339921d3d58498807971`); o zip do Netlify extraído e conferido.

**Só lido no código (não dá para rodar aqui):** as regras do Firebase de verdade (conferi pelo guia: `update` é permitido, e a v122 não precisa de nenhuma regra nova); o envio com `keepalive` ao fechar o app.

**Só o celular de verdade mostra:** lista "Pedro, confira no celular" (parte 6).

---

## 2. Camada 1 — matriz "pedido → prova"

| Item do plano | Onde está | Prova (teste) | |
|---|---|---|---|
| **T1** boas-vindas, 2 botões, "Agora não" só com crianças de antes (D7) | `escola-familia.js` `abrirT1` | família 1, 7-B, 7-C; cadastro 1ª | ✅ |
| **T2** código: confere se existe; não achou; sem tracinho; sem internet "a conferir"; curto | `abrirT2`, `nuvem-sync.js` `existeFamilia` | família 2 | ✅ |
| **T3** sugere bicho-0000; livre → anote; já usado → avisa; sem internet cria e confere depois | `abrirT3`, `conferirFamilias` | família 3, cadastro 1ª | ✅ |
| **T4** sempre ao abrir (D2), crianças ☁️ da família (D6), ➕/☁️/🔄/✏️, bolinha + família no rodapé, sem criança só ➕ e ☁️ | `abrirT4`, `renderT4` | família 1, 2, 5, 7-G; cadastro 1ª; revisão B3/N2 | ✅ |
| **T5** 8 bichinhos numa linha, nenhum marcado, 14 letras, "É você?", mesmo nome+bichinho volta sozinho | `abrirT5` | cadastro 1ª e 2ª; nuvem D | ✅ |
| **T6** buscar na nuvem, apps de cada criança, lixeira, "📦 Nomes antigos" | `abrirT6` | família 5, 6; revisão A1/A3, A2 | ✅ |
| **T7** arrumar: mudar (ficha antiga ganha `movidoPara`), tirar só com tudo guardado ou cópia na lixeira (adulto), pode tirar todas | `pedirTirar`, `efetivarTirar`, `processarMudancas` | família 5, 6; nuvem K; revisão | ✅ |
| **T8** famílias neste celular, 👁 mostrar (adulto), entrar/criar/tirar família, até 4, bloqueio das 2 semanas | `abrirT8`, `liberarOutraFamilia`, `tirarFamilia` | família 4 | ✅ |
| **T9** chip ao lado da ⚙️ e bolinha em todas as telas principais | `montarChip`, `montarPonto`; `index.html` barras | família 10; revisão B2/N1 | ✅ |
| 4.10 seção "☁️ Família e nuvem" no fim das Configurações; linhas antigas saíram | `renderSecao`; `index.html` `#cfgFamilia` | família 1 | ✅ |
| 4.11 bolinha 🟢🟡🔴 com as frases do plano | `situacao` | família 1, 2, 10; nuvem A, B, G | ✅ |
| 4.12 teclado: campo e botão na mesma linha, cartão em cima, letra ≥ 14 px, botões ≥ 48 px | CSS `ef-teclado` / `max-height:300px` | cadastro 2ª; revisão B1 | ✅ |
| **Parte 3 / 3-A** textos exatos, CAIXA ALTA, palavras proibidas fora | `TEXTOS` | família 1; cadastro 1ª | ✅ |
| **Regra de ouro 1** nenhum histórico se perde | — | família 5, 7, 8, 9, 12; nuvem; revisão A2/A4 | ✅ |
| **Regra 2** só acrescenta (chaves antigas intactas) | `migrar` | família 7-A (byte a byte) | ✅ |
| **Regra 3** Firebase sem mudança (só o campo opcional `movidoPara`) | `nuvem-sync.js` `marcarMovido` | nuvem K; família 6 (lido: regras do guia permitem `update`) | ✅ |
| **Regra 4** nada apagado na nuvem | — | família 5 ("a nuvem continua com…") | ✅ |
| **Regra 5** tirar só com garantia ou cópia | `garantirGuardado`, lixeira | família 5 | ✅ |
| **Regra 6** identidade nome + bichinho, bichinhos antigos valem | `chaveUsuario` | cadastro; família 7-E | ✅ |
| **Regra 7** mesmas telas nos 7 apps (arquivo único) | `escola-familia.js` v1 | cópias mestras = pacote (md5) | ✅ |
| **Regra 8** sem alert/confirm/prompt | — | família 13 (nenhuma caixinha em todos os testes) | ✅ |
| **Regra 9** funciona sem internet | — | família 2, 3, 5; PWA (abre offline com o módulo) | ✅ |
| **Regra 10** teclado nunca cobre o campo | — | cadastro 2ª; revisão B1 | ✅ (falta o teclado real: parte 6) |
| Ficha do app (parte 7): prefixo por criança recolocado por cima da vigia | `index.html`, fim do script | nuvem F; família 4 | ✅ |
| Ficha: "Hana fantasma" | `carregarPerfis`, `SEM_CRIANCA` | família 5 (abrir 2×, nenhuma chave `hana_*`) | ✅ |
| Ficha: `hana_abrirhub` respeitado (sem laço T4 → recarrega → T4) | `index.html` abertura | cadastro 1ª; família 4 | ✅ |
| Ficha: backup JUNTA (D14) | `aplicarBackup` | rápidos teste_07; família 9; revisão | ✅ |
| Ficha: "Continuar de onde parei / Menu" depois de escolher | `passoDoApp` | cadastro 1ª; revisão B10 | ✅ |
| nuvem-sync v4: família por criança, família não conferida espera, repetida espera, `garantirGuardado`, `existeFamilia`, `marcarMovido` com `exists=true`, fila nunca jogada fora em silêncio | `nuvem-sync.js` | família 2, 3, 4, 7-D; revisão A4 | ✅ |
| Migração casos A–H | `migrar` | família 7 (A, B, C, D, E, G, H) e 6 (F) | ✅ |
| Voltar ao zip anterior | — | família 8 | ✅ |
| Botão voltar do Android: fecha o pop-up, depois a tela | `popstate` no `escola-familia.js` | família 11; revisão B12 | ✅ |
| Migração com os **dados reais** (backup do Pedro) | — | — | ⬜ falta: o backup não foi anexado; fazer antes do site de verdade |
| Site de teste com família de teste | `siteDeTeste` | família 2 (só aceita código "teste…") | ✅ |
| **D1–D16** | | | |
| D1 arquivo compartilhado | `escola-familia.js` | — | ✅ |
| D2 T4 toda vez | `abrirInicio` | cadastro 1ª | ✅ |
| D3 (a) só tirar do celular | `pedirTirar` | família 5 | ✅ |
| D4 CAIXA ALTA | CSS | família 1 | ✅ |
| D5 6 por família, 4 famílias | `max`, `MAX_FAMILIAS` | cadastro 1ª; o limite de 4 famílias foi provado pelo revisor-chefe | ✅ |
| D6 crianças ☁️ na T4 | `renderT4` | nuvem C; família 4 | ✅ |
| D7 "Agora não" só com crianças de antes | `abrirT1` | família 7-B, 7-C | ✅ |
| D8 atalho "levar a família" | — | — | ⬜ é depois dos 7 apps (plano) |
| D9 "Nomes dos parentes" | `index.html` | cadastro 1ª | ✅ |
| D10 ordem dos apps | — | — | (próximos apps) |
| D11 site de teste | instruções + faixa roxa | família 2 | ✅ |
| D12 Matemática 👪→⚙️ | — | — | (app Matemática) |
| D13/D14 backup junta | `aplicarBackup` | família 9 | ✅ |
| D15 trava do adulto 3 s | `botaoAdulto` | família 4, 5; nuvem V | ✅ |
| D16 👥 para trocar de criança | `TEXTOS.trocar` | família 1 | ✅ |

---

## 3. Camada 2 — 2 revisores independentes

Criados pela ferramenta de agentes, sem ver esta conversa; receberam o plano, o zip anterior (v121) e o zip novo, e escreveram e rodaram os próprios testes (relatórios completos em `/home/claude/revisao/` na máquina de trabalho; resumo aqui).

### Revisor A — dados e nuvem
- **Rodada 1:** 0 🔴, **4 🟠**, 11 🟡.
  - 🟠 A1 depois de mudar o bichinho, a criança antiga (que tinha outro app) aparecia como outra criança ☁️ → **corrigido**: ficha "mudada" nunca aparece como criança; vai para "📦 Nomes antigos".
  - 🟠 A2 progresso guardado só na lixeira era esquecido quando a criança voltava pela nuvem ou pelo cadastro → **corrigido**: a lixeira é juntada sozinha.
  - 🟠 A3 "Buscar na nuvem" escondia de vez a ficha antiga; "Agora não" valia para sempre → **corrigido**: sempre em "📦 Nomes antigos"; "Agora não" vale 1 dia.
  - 🟠 A4 o `nuvem-sync.js` v4 jogava a fila fora se a lista de crianças desse erro → **corrigido**: para tudo e mantém a fila.
  - 🟡 corrigidos também: backup da Hana "1" com 👧, backup só na família atual, ligações não apagadas se a lista der erro, `nuvem_familia` só com família conferida, lista da nuvem recarregada ao abrir, `marcarMovido` não quebra cadeias, "mudar" para outra criança da nuvem pergunta, tirar família com erro.
- **Rodada 2:** os 4 🟠 conferidos rodando os testes dele → **✅ Pode publicar** (0 🔴, 0 🟠). Sobraram 3 🟡 (parte 5).

### Revisor B — telas, crianças e celular
- **Rodada 1:** **1 🔴, 2 🟠**, 12 🟡.
  - 🔴 B1 com o teclado abrindo depois do toque, o campo do código mudava de lugar, perdia o foco e às vezes sumia → **corrigido**: o campo nunca muda de lugar (só CSS). Conferido em 24 casos e 100 repetições.
  - 🟠 B2 o chip empurrava os botões por cima da pílula "☀️ 0/10 · 🌱 Nível…" → corrigido.
  - 🟠 B3 no "Arrumar", ✏️🗑️ cobriam o bichinho → **corrigido**: ficam embaixo do nome.
- **Rodada 2:** B1–B3 ✅, mas a correção do B2 criou o 🟠 **N1** (os botões da barra de cima encolhiam para 36–42 px) → **corrigido**: os botões nunca encolhem (52 px deitado / 46 px em pé, como na v121); quem cede é o espaço entre eles e a pílula.
- **Rodada 3:** N1, N2, N4, B14 ✅ → **✅ Pode publicar** (0 🔴, 0 🟠). Dois 🟡 novos (letra 13 px na pílula; a 🦉 sumia em 568–640 px) **também corrigidos depois** (letra 14 px; a 🦉 só fica menor) — com teste.

---

## 4. Camada 3 — revisor-chefe

Um 3º agente independente recebeu o plano, os 2 zips, os relatórios de A e B e esta matriz.
- **Conferiu rodando de novo no zip final** que A1–A4, B1, B2, B3 e N1 estão corrigidos (inclusive a última mudança da barra de cima, feita depois da 3ª rodada do B: pílula com letra de 14 px e 🦉 que continua na barra).
- **Testes do zip:** 520/521 (a falha da fonte é igual na v121).
- **Passada própria** (5 testes dele, 61 conferências, todas OK): tirar criança sem internet e com erro na nuvem; lixeira; migração com as 33 chaves e ida e volta v121 → v122 → v121 → v122 com outro celular gravando (chaves antigas idênticas byte a byte); trazer da nuvem que falha; 2 famílias e limite de 4.
- **Pacote conferido:** 9 arquivos na raiz, `nuvem-config.js` = o seu, `escola-pwa.js` igual à v121, `sw.js` com cache novo e com o `escola-familia.js`, `compartilhados/` = pacote.
- **Achados novos, só 🟡** (entram na lista da parte 5): C1, C2, C3, C4, C5.

**Veredito: ✅ Pode publicar (no site de teste).**

---

## 5. Pontos 🟡 que ficaram (para o seu OK)

1. **T4 sem ⚙️** (o desenho do plano tem ⚙️ ali): a ⚙️ está em todas as telas do app; na T4 ficou só o ⛶. Motivo: com zero criança, as Configurações do app não fazem sentido.
2. **Código em minúsculas na T8** (o código é guardado assim; é o que se digita).
3. **Lixeira com nome trocado:** se a criança foi tirada como 🦊 e depois mudou para 🐰 em outro app, a lixeira não junta sozinha (continua em "🗑️ Tiradas deste celular" para juntar à mão).
4. **Janela pequena da volta ao app antigo:** se a família atual ficar "a conferir" (ex.: depois de tirar a única família conferida), o `nuvem_familia` fica com o código da família que saiu até conferir.
5. **Na tela de 568×320, no "Arrumar"**, é preciso rolar para ver a bolinha.
6. **Campo do código estreito** em pé com 320 px e teclado aberto (dá para digitar, mas vê pouco do que foi digitado).
7. **`teste_fonte.py` 57/58 nesta máquina** (igual na v121; é a falta das fontes Roboto/Arial aqui).
8. **Cache do `sw.js`:** este é o primeiro zip da v122 que sai daqui (`esforco-vence-v122`). **Qualquer** correção depois precisa subir o nome do cache (`v123`…), senão o celular continua com a versão guardada.

---

9. **C1 (revisor-chefe):** se uma leitura da nuvem já estava a caminho na hora de tirar uma criança, ela pode gravar de volta as chaves da criança que saiu (2 em 6 tentativas). **Neste app não perde nada e ninguém vê** (as chaves ficam órfãs). Mas na Matemática e no Fluência a criança é identificada pelo nome: uma criança nova com o mesmo nome herdaria o progresso da antiga. **Corrigir no `nuvem-sync.js` antes de ele ir para esses apps** (entra no zip final).
10. **C2:** a bolinha fica 🟢 mesmo com progresso guardado só na lixeira do celular. Corrigir no zip final (a bolinha deve avisar).
11. **C3 (risco já aceito pelo plano, agora medido):** depois das 2 semanas, se TODAS as crianças forem tiradas e o app voltar para a v121, a "Hana 👧" vazia da v121 grava por cima da ficha da Hana na nuvem (medido: 30 frases → 1). As cópias dos dias anteriores (🕘) continuam lá. **Regra:** depois de tirar todas as crianças, nunca volte ao zip antigo. Vai em destaque na lista "conferir antes e depois de publicar" do site de verdade.
12. **C4:** a migração ainda não foi testada com os **seus dados reais** (o backup não veio nesta conversa). Fazer antes do zip do site de verdade.
13. **C5:** o roteiro do site de teste ganhou o passo "sem internet, guardar uma cópia e tirar; depois trazer de volta pela ☁️".

## 6. Pedro, confira no celular (o que nenhum teste daqui vê)

- O **teclado de verdade** na T2 (código), T3 (criar código) e T5 (nome): ele abre, **fica aberto**, e o campo continua à vista. Repita umas 5 vezes, deitado e em pé.
- **Segurar 3 segundos** com o dedo (👁 MOSTRAR, CÓPIAS DE CADA DIA) não abre o menu de copiar do Android.
- O **botão voltar** do Android no app instalado: fecha o pop-up, depois a tela.
- **Na TV a 3 m:** as meninas acham o próprio bichinho; a letra das telas novas dá para ler.
- **Barra de cima** no seu celular: botões grandes, pílula de estrelas inteira, 🦉 aparecendo, chip com o bichinho ao lado da ⚙️.
- **2 celulares** com `teste-pedro-2026`: o que um faz aparece no outro (🔄 ATUALIZAR AGORA).
- **Modo avião:** tirar com cópia; depois, com internet, a criança volta com tudo.
- Depois de publicar no site de teste, a **faixa roxa** "🧪 SITE DE TESTE" aparece.
