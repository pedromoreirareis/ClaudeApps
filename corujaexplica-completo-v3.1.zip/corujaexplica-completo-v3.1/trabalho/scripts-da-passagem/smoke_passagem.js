const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=process.argv[2], PORT=9411;
const MIME={'.html':'text/html','.js':'application/javascript','.png':'image/png','.webmanifest':'application/manifest+json'};
const srv=http.createServer((q,r)=>{let p=q.url.split('?')[0]; if(p==='/')p='/index.html'; fs.readFile(path.join(ROOT,p),(e,d)=>{if(e){r.writeHead(404);r.end();return;} r.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream'}); r.end(d);});}).listen(PORT);
(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const erros=[], rede=[];
  for (const caso of ['primeira-abertura','com-1-crianca']){
    const ctx=await b.newContext({viewport:{width:412,height:915}});
    await ctx.route(/googleapis\.com/, r=>{ rede.push(r.request().url()); r.abort(); });
    if (caso==='com-1-crianca') await ctx.addInitScript(()=>{ localStorage.setItem('explica_usuarios',JSON.stringify({us:[{id:'p1',nome:'Ana',av:'🦊'}],atual:'p1'})); });
    const p=await ctx.newPage();
    p.on('pageerror',e=>erros.push(caso+' pageerror: '+e.message));
    p.on('console',m=>{ if(m.type()==='error') erros.push(caso+' console: '+m.text()); });
    await p.goto(`http://localhost:${PORT}/`); await p.waitForTimeout(3500);
    console.log(caso, await p.evaluate(()=>({tela: telaAtual, versao: document.querySelector('.cfgVersao').textContent, nuvemCfg: window.__nuvemCfgArq, nuvem: !!window.NuvemSync && NuvemSync.versao, pwa: !!window.EscolaPWA && EscolaPWA.versao})));
    await ctx.close();
  }
  console.log('erros no console:', erros.length ? erros : 'nenhum');
  console.log('pedidos ao Firebase (bloqueados):', rede.length);
  await b.close(); srv.close();
})();
