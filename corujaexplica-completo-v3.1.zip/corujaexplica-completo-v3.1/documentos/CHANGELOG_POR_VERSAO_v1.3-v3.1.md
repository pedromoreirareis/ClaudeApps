# Coruja Explica — histórico de mudanças, versão por versão (v1.3 → v3.1)

**De onde veio cada informação:** tudo o que está aqui foi tirado da comparação direta dos arquivos entregues em cada versão (`index.html`, `sw.js`, `manifest.webmanifest` e, na v3.x, `nuvem-sync.js`, `escola-pwa.js`, `nuvem-config.js`). Não é memória de conversa nem suposição: é o que o código faz. Onde algo não dá para afirmar só pelo código, está marcado com **⚠️ ambíguo**.

**O que o código NÃO diz:** se cada mudança foi testada no celular e funcionou. Isso só o teste no aparelho confirma.

**Contagem das palavras dos pedidos (prompts):** feita rodando a própria função `montarPrompt` de cada versão e contando as palavras do texto que o app copia. Para conferir, os prompts da v2.0 e da v2.1 foram comparados com os arquivos `prompts-coruja-explica-v2_0.md` e `v2_1.md`: Leitura do dia, Entender de verdade e Consertar são **idênticos, palavra por palavra**. Em Adaptar e Continuar a diferença é só o texto de exemplo colocado no lugar do campo a preencher.

---

## Linha do tempo

| Versão | Data do zip | Tamanho do index.html | Nome do cache (sw.js) |
|---|---|---|---|
| v1.3 | 18/09/2026 20:12 | 264.777 bytes | coruja-explica-v1-3 |
| v1.4 | 18/09/2026 20:48 | 265.101 | coruja-explica-v1-4 |
| v1.5 | 18/09/2026 21:07 | 271.514 | coruja-explica-v1-5 |
| v1.6 | 19/09/2026 00:49 | 282.783 | coruja-explica-v1-6 |
| v1.7 | 19/09/2026 08:33 | 302.585 | coruja-explica-v1-7 |
| v1.8 | 19/09/2026 08:51 | 307.951 | coruja-explica-v1-8 |
| v1.9 | 19/09/2026 09:16 | 313.517 | coruja-explica-v1-9 |
| v2.0 | 23/09/2026 08:37 | 349.090 | coruja-explica-v2-0 |
| v2.1 | 23/09/2026 13:42 | 361.541 | coruja-explica-v2-1 |
| v3.0 | 24/09/2026 13:40 | 429.030 | coruja-explica-v3-0 |
| v3.1 | 24/09/2026 17:36 | 447.863 | coruja-explica-v3-1 |

### Coisas que NÃO mudaram em nenhuma versão (certeza)
- **Dicionário embutido (GLOSSARIO):** **113 palavras** em todas as 11 versões, com conteúdo idêntico (o conteúdo é igual byte por byte, conferido por soma de verificação).
- **As 5 letras embutidas** (HanaSassoon, HanaBeaba, HanaMamae, HanaPlaywrite, HanaNarrow): idênticas em todas as versões.
- **Temas de cor:** a lista de 8 temas existe desde a v1.3, mas o app sempre usa só o primeiro ("Céu"). Não há tela para trocar de tema em nenhuma versão.
- **Ícones** (`icon-192.png`, `icon-512.png`): mesmo tamanho de arquivo em todas as versões.
- **Manifesto:** idêntico da v1.3 até a v2.1. Só muda na v3.0.

### Quantas palavras tem cada pedido à IA (certeza)

| Versão | Leitura do dia (botão 🤖 PROMPT) | Entender de verdade | Adaptar | Continuar | Consertar |
|---|---|---|---|---|---|
| v1.3 / v1.4 / v1.5 | 816 *(chamava "Gerar texto novo")* | — | 98 | 22 | 57 |
| v1.6 | 1.167 | — | 366 | 80 | 57 |
| v1.7 | 1.558 | — | 455 | 101 | 88 |
| v1.8 | 1.849 | — | 634 | 263 | 212 |
| v1.9 | 1.886 | 2.007 | 634 | 263 | 212 |
| v2.0 | 2.649 | 2.628 | 984 | 590 | 212 |
| v2.1 / v3.0 / v3.1 | 2.753 | 2.671 | 1.006 | 604 | 212 |

Os pedidos da v2.1, v3.0 e v3.1 são **idênticos** (conferido texto por texto).

---

## v1.3 — o ponto de partida (a primeira versão disponível)

As versões v1.0 a v1.2 não estão disponíveis. A v1.3 já tinha:

**Telas**
- **Início:** coruja 🦉, título "Coruja Explica", frase "Prepare um texto e leia junto." e dois botões grandes: **📝 PREPARAR TEXTO** ("colar, formatar e salvar") e **📖 LER** (mostra "nenhum texto salvo" / "1 texto salvo" / "N textos salvos").
- **Preparar texto (Estúdio):** campo **Título** para digitar (opcional, até 80 letras), caixa grande "Cole aqui o texto que a IA gerou...", contador de palavras, botões **📋 Colar**, **🧹 Limpar**, **🪄 Formatar**, **↩️ Desfazer**, e embaixo **📖 LER AGORA** e **💾 SALVAR** (vira **💾 ATUALIZAR** quando está editando). No topo, botão azul **🤖 PROMPT**, que copia o pedido para a IA.
- **Meus textos (Biblioteca):** botão **+ Novo**; cada texto vira um cartão com título, resumo de 2 linhas e os botões **📖 Ler**, **✏️** (editar) e **🗑️** (excluir, com confirmação). No rodapé: **⬇️ Exportar backup** e **⬆️ Importar backup** (o importar **substituía** a biblioteca inteira, depois de confirmar).

**Leitura (janela grande sobre a tela)**
- Força o celular **deitado** (se a trava não funcionar, o cartão é girado por CSS) e pede tela cheia.
- Botões no topo: **A−**, **A+**, **Aa** (alterna MAIÚSCULAS ↔ normal), **🔇/🔊** (voz) e **❌**.
- Tocar numa palavra: pinta a linha inteira de amarelo (o "marca-texto"). Com a voz ligada, fala a palavra.
- Palavras do dicionário aparecem sublinhadas com pontinhos; o toque abre a janelinha com a explicação e o botão **"Entendi! 👍"**.
- Itens de lista (•) aparecem num bloco com borda vermelha; o "Para pensar" aparece num balão tracejado com 💭.
- Padrão ao abrir: voz **desligada**, marca-texto **ligado**, letras em **MAIÚSCULAS**.
- Tamanhos de letra (`FSIZES`): **16, 19, 22, 26, 30, 34, 40 px**, começando em 22.
- Letra fixa: a opção nº 3 de uma lista de 9 ("Redonda"), sem tela para escolher.

**Como o app entende o texto ("Formato Coruja")**
- Reconhece os rótulos **TÍTULO:**, **TEXTO:**, **PALAVRAS NOVAS:** (no formato `palavra = explicação`) e **PARA PENSAR:**. O emoji do título vira o ícone da leitura.
- Sem rótulos, o texto é "arrumado" sozinho: tira negrito, # e links; protege números (1.500), abreviações (Dr., etc.) e reticências; junta linhas quebradas; agrupa até 3 frases por parágrafo; trata falas com travessão como parágrafo próprio; transforma marcadores (-, 1.) em •.
- Avisos embaixo da caixa: "✅ Formato Coruja reconhecido", "📏 Texto comprido — considere ler em partes" (mais de 800 palavras), "⚠️ Trecho longo sem pontuação" (40 palavras ou mais sem pontuação).
- O que está sendo preparado fica salvo sozinho como rascunho.

**Pedidos à IA:** o código já tinha 4 pedidos (gerar, adaptar, continuar, consertar), mas **só o "gerar" podia ser usado**, pelo botão 🤖 PROMPT. O pedido principal (816 palavras) pedia: assunto, idade 6 anos, nível "lê bem, como uma criança de 12 anos", tamanho médio (curto 4–6 / médio 8–12 / longo 13–18 parágrafos); uma lista de 11 sinais gráficos (diálogo com travessão, aspas, parênteses, hífen, crase, lista com • etc.); frases de 8–18 palavras; de 3 a 6 PALAVRAS NOVAS com "explicação curtinha"; um bloco "PARA O PAI" antes do título.

**Dados guardados no celular (localStorage):** `explica_textos` (a biblioteca), `explica_rascunho` (o rascunho), `explica_config` (tamanho da letra e MAIÚSCULAS). Nome do arquivo de backup: `coruja-explica-backup-AAAA-MM-DD.json`.

**Funcionamento offline (sw.js):** guarda 5 arquivos (`./`, `index.html`, manifesto, 2 ícones) e usa **sempre a cópia guardada primeiro** para tudo.

**Manifesto:** nome "Coruja Explica", descrição "Cole um texto, arrume sozinho e leia com a Renata — biblioteca pessoal offline.", abre em tela cheia (`fullscreen`), cor `#f0a030`.

---

## v1.3 → v1.4 (18/09, 36 minutos depois)

**O que muda para quem usa**
- Na leitura, **cada parágrafo ganha um recuo** na primeira linha (1,3 vez o tamanho da letra), como nos livros. Os itens de lista (•) e o "Para pensar" ficam **sem** recuo.
- Tentativa de aumentar o espaço entre os cartões da biblioteca (de 20 para 28 px). ⚠️ Segundo um comentário escrito na v1.6, **essa mudança não fazia efeito nenhum** (estava aplicada no lugar errado).

**Atualização do app (sw.js)** — a mudança mais importante desta versão:
- A página principal passa a ser buscada **na internet primeiro** ("rede primeiro"). A cópia guardada só é usada quando não há internet. O comentário no arquivo explica o motivo: antes, uma atualização podia ficar "presa" mostrando a versão antiga.
- Ícones e manifesto continuam usando a cópia guardada primeiro.

Nenhuma função, chave de dados ou pedido à IA mudou.

---

## v1.4 → v1.5 (18/09, 19 minutos depois)

**O que muda para quem usa**
- Ao lado do **🤖 PROMPT** aparece uma setinha **▾** ("Outras variações do pedido"). Ela abre a janela **"Qual pedido você quer copiar?"** com 4 opções:
  - ✨ **Gerar um texto novo**
  - 🔄 **Adaptar um texto pronto**: abre um campo "Cole aqui o texto original..."
  - ➡️ **Continuar o mesmo assunto**: abre um campo para a próxima pergunta
  - 🛠️ **Consertar formato**
- Nas opções com campo há os botões **📋 Copiar pedido** e **← Voltar às opções**. Com o campo vazio aparece o aviso "Cole o texto original primeiro" ou "Escreva a próxima pergunta primeiro".
- O botão "voltar" do Android fecha essa janela.

**Funções novas:** `abrirMenuPrompt`, `fecharPromptMenu`, `escolherPrompt`, `voltarListaPrompt`, `copiarPromptComExtra`.

O texto dos pedidos não mudou. O sw.js mudou só o nome do cache.

---

## v1.5 → v1.6 (19/09, 00:49)

**O que muda para quem usa**
- **O título não é mais digitado.** No lugar do campo aparece uma linha "**Título:** …" com o título lido do próprio texto colado (com o emoji) e um lápis **✏️** para escrever outro título (abre um campo com o botão **OK**).
- Caixa de texto: "Cole aqui o texto que a IA gerou — pelo botão Colar ou segurando o dedo aqui."
- **Colar já formata sozinho**, tanto pelo botão 📋 quanto segurando o dedo na caixa. Aparece o aviso "✨ Colado e formatado".
- Mensagens novas quando o colar automático não funciona: "Neste endereço o navegador não deixa colar sozinho…", "Este navegador não deixa colar sozinho…", "Não encontrei nada copiado ainda", "Segure na caixa e escolha Colar 👆".
- Se o texto for alterado depois de formatar, o botão Formatar volta a funcionar.
- Os 4 botões do Estúdio ficam numa grade fixa de 2×2 (antes caíam 3 + 1 em alguns celulares).
- Início: o texto de apoio do Preparar muda para "colar o texto e salvar".
- Biblioteca: o espaço entre os cartões é corrigido (agora funciona: 22 px). O cartão mostra o emoji do texto antes do título. O texto da biblioteca vazia passa a ser "Toque em **+ Novo**, lá em cima, para começar."
- Janelinha do dicionário fica mais compacta com o celular deitado (as explicações agora são maiores).
- Emoji do título: passa a guardar o emoji inteiro. O comentário do código explica que o sol aparecia sem cor.

**Funções:** novas: `motivoColarIndisponivel`, `aplicarTextoColado`, `tituloEfetivo`, `atualizaTituloDetectado`, `abrirTituloManual`, `fecharTituloManual`, `infoDoCard`. Removida: `resumoDe` (substituída por `infoDoCard`).

**Pedidos à IA**
- **Gerar texto (816 → 1.167 palavras):** nova seção "O QUE FAZ UM TEXTO DAR CERTO AQUI": gancho no começo, dois momentos de "nossa, eu não sabia disso!", números transformados em coisas imagináveis, comparações com o mundo da criança, uma ideia de cada vez. Tamanhos ajustados: curto 5–7, médio 9–13, longo 14–18 parágrafos. **PALAVRAS NOVAS vira "a parte mais importante"**: de 5 a 10 palavras, cada explicação com 2–3 linhas (25–45 palavras), em três partes (significado, comparação, onde ela vê isso), com exemplo ruim e exemplo bom ("atmosfera"). O título pede uma "pergunta que dê curiosidade".
- **Adaptar (98 → 366):** reescrito. Pede para "contar de novo" sem resumir, com gancho, comparações, sinais da escrita e as mesmas regras de PALAVRAS NOVAS.
- **Continuar (22 → 80):** ganha lembretes sobre gancho, comparações e palavras novas.

---

## v1.6 → v1.7 (19/09, 08:33) — busca, quiz e TAGS

**O que muda para quem usa**
- **Quiz de interpretação no fim da leitura.** Se o texto trouxer PERGUNTAS, aparece no final a caixa "Vamos ver o que você entendeu?" com o botão **"🎯 Responder N perguntas"**. A janela do quiz mostra "Pergunta X de N", as alternativas, o resultado ("Isso mesmo! 🎉" ou "Quase! Olha só 👀"), a explicação e o botão **"Próxima pergunta"** / **"Ver o resultado"**. Resultado final:
  - 🏆 "Você acertou tudo!"
  - 🌟 "Muito bem!" (metade ou mais)
  - 📖 "Bora ler mais uma vez?"
  - e o botão **Fechar**.
- **Busca na biblioteca:** caixa "🔎 Buscar por assunto ou título" com botão ✕. Só aparece quando há textos e começa a filtrar a partir de **3 letras**. Não diferencia acento nem maiúscula. Procura no título, nas TAGS e no resumo. Sem resultado aparece: "Nenhum texto encontrado para “…”."
- **Botão ↩️ Desfazer removido** do Estúdio. Ficam 3 botões (Colar, Limpar, Formatar) numa grade de 3 colunas.
- No Estúdio, a caixa de texto vai para o topo. A linha do título fica **escondida enquanto a caixa está vazia** e aparece embaixo do contador.
- Botão "voltar" do Android: agora fecha **uma camada por vez** (primeiro o dicionário ou o quiz, depois a leitura).
- Tela cheia: o app tenta voltar à tela cheia em mais situações (toque, clique, tecla, ao voltar para o app).

**Formato Coruja:** dois rótulos novos: **TAGS:** (palavras-chave invisíveis para a criança, usadas na busca) e **PERGUNTAS:** (ou QUIZ:), no formato `1)` pergunta, `a) b) c)` alternativas, `*` na certa e `>` para a explicação. Só entram perguntas completas. O Formatar passa a reescrever também TAGS e PERGUNTAS.

**Funções:** novas: `limpaLinhaPergunta`, `parsePerguntas`, `guarda`, `normalizaBusca`, `filtrarBiblioteca`, `limparBusca`, `zerarBusca`, `abrirQuiz`, `fecharQuiz`, `mostraPerguntaQuiz`, `responderQuiz`, `quizAvancar`. Removida: `desfazerCaixa`.

**Pedidos à IA**
- **Gerar texto (1.167 → 1.558):** **sai a escolha de TAMANHO.** Entra "O TAMANHO QUEM DECIDE É O ASSUNTO": sem cota, sem "encher linguiça", sem cortar no meio. PALAVRAS NOVAS: o tamanho da explicação depende da dificuldade (palavra fácil = uma frase; difícil = 2–3 linhas). Novas seções **TAGS** (5 a 8 palavras-chave) e **PERGUNTAS** (exatamente 3, com 3 alternativas cada, erradas plausíveis, linha `>` explicando com carinho, pelo menos uma juntando duas partes do texto). "Para pensar" passa a ser "pergunta aberta, de conversa com o pai".
- **Adaptar, Continuar e Consertar:** passam a incluir TAGS e PERGUNTAS no formato.

---

## v1.7 → v1.8 (19/09, 08:51)

**O que muda para quem usa**
- Ao entrar em "Preparar texto", a caixa de título manual que tinha ficado aberta é fechada.
- Importar backup limpa a busca.
- Botão do quiz no singular quando for 1: "Responder 1 pergunta".

**Pedidos à IA** — todos os 4 ganham uma **"CONFERÊNCIA FINAL — FAÇA ANTES DE ENVIAR"**: a IA relê e corrige antes de responder, sem comentar a conferência.
- Gerar: 10 itens (a–j: entendimento, fatos verdadeiros, frases de até 25 palavras, palavras difíceis no dicionário, tamanho das explicações, qualidade das perguntas, ortografia, sinais naturais, formato, repetição) → 1.849 palavras.
- Adaptar: 8 itens → 634. Continuar: 8 itens → 263. Consertar: 5 itens sobre os 7 rótulos → 212.

Nenhuma função nova ou removida.

---

## v1.8 → v1.9 (19/09, 09:16) — cinco pedidos

**O que muda para quem usa**
- O menu ▾ passa a ter **5 opções**. "Gerar um texto novo" é dividido em dois:
  - 📖 **Leitura do dia**: "Texto de 10 a 15 minutos… É o do botão PROMPT."
  - 🧠 **Entender de verdade**: "Sem limite de tamanho: explica o assunto inteiro, do zero…"
- O botão 🤖 PROMPT copia a **Leitura do dia**.
- A janela do menu encolhe em telas baixas: em telas bem baixas o robô some, para as 5 opções caberem sem rolar.

**Pedidos à IA** — reorganizados em **blocos compartilhados** (engajamento, sinais, frases, dicionário, tags, quiz, cuidados, formatação, formato da resposta, conferência), para que uma melhoria valha para os dois pedidos de texto.
- **Leitura do dia (1.886):** **650 a 950 palavras** no TEXTO (10–15 minutos), "conte as palavras antes de enviar". Assunto grande: explicar bem só uma parte. Conferência ganha o item k (conferir 650–950).
- **Entender de verdade (2.007, novo):** sem limite de palavras, começar do zero, degraus pequenos, recapitular a cada 2–3 ideias, explicar ideia difícil duas vezes, de **3 a 6 perguntas**. Conferência com os itens k, l e m.
- Adaptar, Continuar e Consertar: sem mudança de texto.

**Funções novas (dentro da montagem dos pedidos):** `regrasQuiz`, `formatoResposta`, `conferenciaFinal`, `dadosDoTexto`. O nome antigo "explicar" continua funcionando como "leitura".

---

## v1.9 → v2.0 (23/09, 08:37) — Textos lidos, sílabas e TV

**Tela inicial redesenhada**
- **📖 LER** fica grande, no meio, com "nenhum texto para ler" / "N textos para ler".
- Embaixo, dois botões menores: **📝 Preparar texto** e **📦 Textos lidos**.

**Nova tela "📦 Textos lidos" (histórico)**
- Nos cartões de "Meus textos": botão **📖 Ler** de largura inteira e, embaixo, **✏️ Editar**, **✅ Lido** e **🗑️ Excluir**. Tocar no título ou no resumo também abre a leitura.
- **✅ Lido** manda o texto para "Textos lidos" (aviso "✅ Guardado em Textos lidos"). Lá o cartão mostra "✅ Lido em DD/MM/AAAA · aberto N vezes" e os botões **↩️ Ler de novo** ("↩️ De volta em Meus textos") e **🗑️ Excluir**. Tem busca própria ("Buscar nos textos lidos").
- No fim de "Meus textos" aparece o link "📦 Textos lidos (N)".
- O app passa a contar quantas vezes cada texto foi aberto.

**Leitura**
- Novo botão **⚙️** abre **"⚙️ Ajustes da leitura"**:
  - chave **"Separar sílabas no fim da linha"**: a palavra é cortada na sílaba com tracinho, usando o mesmo silabador do Esforço Vence; vem desligada;
  - **"Tipo de letra"** com 2 opções: **Bastão (padrão)** e **Sassoon**;
  - botão **"Pronto 👍"**.
- **A lista de letras cai de 9 para 2** (Bastão e Sassoon). A letra padrão passa a ser **Bastão** (o comentário diz que a antiga "Redonda" já aparecia como bastão no Android).
- **Tamanhos de letra: 10 níveis**: 16, 19, 22, 26, 30, 34, 40, **48, 56, 64** (os 3 últimos para a TV), com nomes de Mínima a "TV máxima". O A−/A+ fica apagado no limite.
- **Avisos grandes dentro do cartão de leitura** (aparecem também na TV): "🔤 Tamanho: Média (nível 3 de 10)", "🔤 Já está no maior tamanho", "✂️ Sílabas no fim da linha: ligado", "🔡 Letra: Sassoon".
- Itens de lista (•): o **nome antes dos dois-pontos fica em destaque vermelho** (ex.: "Acrux:").
- Trocar Aa, sílabas ou letra **mantém o ponto da leitura** (antes voltava para o começo).
- Ao voltar para o app no meio da leitura, a tela continua deitada.
- **Tela sempre acesa** (Wake Lock) enquanto o app está aberto.
- Tocar no texto **não seleciona mais palavras** (some o "Copiar / Pesquisar na Web" do Chrome). As caixas de digitar continuam selecionáveis.
- Correção: frase que termina em dois-pontos não ganha mais um ponto ("são:." → "são:").

**Dados:** as chaves continuam as mesmas. Em `explica_config` entram `fontIdx` e `silabasOn`. Cada texto em `explica_textos` pode ganhar `arquivado`, `arquivadoEm`, `leituras` e `ultimaLeitura`. Backups antigos abrem com todos os textos em "para ler".

**Funções novas (principais):** silabador (`silabasDe`, `hifenizarParte`, `hifenizarPalavra`, `hifenizarTexto` e auxiliares `_s…`), `palavrasDoTermo`, `regrasDestaques`, `revisaoTripla`, `montaCard`, `renderizaLista`, `renderizaArquivo`, `entrarArquivo`, `arquivarTexto`, `devolverTexto`, `registrarLeitura`, `textosParaLer`, `textosLidos`, `ehArquivado`, `dataCurta`, `abrirAjustes`, `fecharAjustes`, `toggleSilabas`, `escolherFonte`, `montaOpcoesFonte`, `avisoLeitura`, `nomeDoTamanho`, `atualizaBotoesTamanho`, `manterTelaAcesa`, `textoParaTela`, `retangulosDasPalavras`, `redesenhaListas`.

**Pedidos à IA**
- **Leitura do dia (1.886 → 2.649):** passa de 650–950 para **300 a 500 palavras**. O comentário do código conta o motivo: no teste real, um texto de cerca de 830 palavras chegou só na metade em 20 minutos. Nova ordem de prioridade: compreensão → retenção → reconto → quantidade. Escolher 3 ou 4 ideias principais e retomar a ideia principal no último parágrafo. Menu: "Texto curto (300 a 500 palavras) para ler, reler e recontar."
- **Entender de verdade (2.007 → 2.628):** referência de **700 a 1.000 palavras**. Menu: "Mais completo: …".
- **Em todos os pedidos que criam texto:** diálogo **entre a filha e o pai**; nova seção **"LISTA COM NOMES EM DESTAQUE"** (`• Nome: explicação`, nome de até 3 palavras, frase anterior terminando em dois-pontos); parágrafos de **no máximo 4 linhas (~45 palavras)**; e a nova **"REVISÃO TRIPLA OBRIGATÓRIA"** (leitura, compreensão/envolvimento, conhecimento) antes da conferência final.
- Adaptar: 634 → 984. Continuar: 263 → 590. Consertar: sem mudança.

---

## v2.0 → v2.1 (23/09, 13:42)

**O que muda para quem usa**
- Ajustes da leitura: nova chave **"Alinhar a margem direita"**. Só funciona junto com as sílabas: a sobra do fim da linha é dividida entre os espaços, com teto de 0,20 do tamanho da letra (`AJUSTE_MAX_EM`). Vem **ligada**. Sem sílabas, o bloco fica apagado com "(ligue as sílabas)". Aviso: "📐 Margem direita alinhada: ligado/desligado".
- **Marca-texto também na explicação do dicionário:** tocar numa linha da explicação pinta a linha.
- O marca-texto passa a funcionar certo com o cartão girado (celular em pé) e durante a animação de abrir.
- Cartões da biblioteca: mais espaço entre o botão Ler e a linha Editar/Lido/Excluir, para evitar toques sem querer.
- Ajustes da leitura mais compactos com o celular deitado.

**Dados:** `explica_config` ganha `alinharOn`.

**Funções novas:** `mapaLocal`, `ponto`, `ret`, `pontoDoEvento`, `blocosDeTexto`, `linhasDoBloco`, `linhaDe`, `limparAjusteMargem`, `ajustaMargemDireita`, `agendaAjusteMargem`, `atualizaChaveAlinhar`, `toggleAlinhar`, `regrasFrases`.

**Pedidos à IA**
- **Diálogo:** deixa de ser obrigatoriamente "filha e pai". Passam a ser **personagens que combinem com o assunto** (marinheiro e capitão, cientista e aluna, ou pai e filha), e o diálogo **sempre aparece**.
- **Leitura do dia (2.649 → 2.753):** parágrafos de **3 a 4 linhas (30 a 45 palavras)**, mais curtos só nas falas, nos itens da lista e na frase que abre a lista. A revisão tripla e a conferência conferem isso.
- Entender: 2.628 → 2.671. Adaptar: 984 → 1.006 (personagens só falam do que já está no texto). Continuar: 590 → 604. Consertar: sem mudança.

---

## v2.1 → v3.0 (24/09, 13:40) — crianças, nuvem e padrão Escola São Pedro

É a maior mudança: o `index.html` cresce cerca de 67 mil bytes e entram 3 arquivos novos.

**Arquivos novos (iguais em todos os apps da escola, segundo os próprios comentários):**
- `escola-pwa.js` (versão "2"): tela sempre acesa (Wake Lock + modo reserva com vídeo invisível + vigia a cada 15 s), volta à tela cheia a cada toque, convite para instalar, e a lista dos **8 bichinhos oficiais**.
- `nuvem-sync.js` (versão "3"): guarda o progresso no Firebase pela internet (API REST), com fila de pendências quando não há internet, recuperação por **nome + bichinho** e **uma cópia por dia** ("versões guardadas").
- `nuvem-config.js`: configuração do Firebase do projeto da escola. O **código da família está vazio** no arquivo, então cada celular precisa digitar o código uma vez.

**Telas novas**
- **"🦉 Quem vai estudar hoje?"**: cartões de cada criança com "N textos lidos · N para ler" e a marca "lendo agora"; cartão "➕ Novo usuário"; botões **✏️ Trocar nome ou bichinho**, **🗑️ Apagar este usuário** e **☁️ Recuperar da nuvem**. Máximo de **6 crianças**.
- **Cadastro**: "🌟 Qual é o seu nome?" (até 14 letras), "Escolha o seu bichinho:" com os 8 bichinhos (🦉 Coruja, 🦊 Raposa, 🐰 Coelho, 🐼 Panda, 🦋 Borboleta, 🐨 Coala, 🐯 Tigre, 🐴 Pônei), botões **← Voltar**, **Pronto! ✅** e **☁️ Já tenho cadastro**.
- **"☁️ Recuperar cadastro"**: lista as crianças guardadas na nuvem, com os botões **🔑 Código da família**, **🔄 Procurar de novo** e **🕘 Versões guardadas** (juntar a cópia de um dia, "nada é apagado").
- **"⚙️ Configurações"** (engrenagem no canto do Início, com uma bolinha colorida da nuvem: verde, laranja ou vermelha). Seções: 👧 Quem está usando (🔄 Trocar); 📺 Tela (chave "Tela sempre acesa"; "📲 Instalar"); ☁️ Nuvem (situação, "🔄 Enviar agora", "🔑 Digitar" código da família, "☁️ Recuperar"); 💾 Backup (Exportar/Importar); rodapé "Coruja Explica · versão 3.0".
- **Janela do código da família**: pede pelo menos 6 letras ou números, com os botões **Cancelar** e **🔑 Guardar código**.
- Início: o nome e o bichinho da criança aparecem no topo (tocar troca de criança). A biblioteca passa a se chamar **"📚 Textos de <nome>"**.

**Como o app abre:** sem criança → cadastro; 1 criança → Início direto; 2 ou mais → "Quem vai estudar hoje?". Na primeira tela, o "voltar" do celular mostra "Para sair do app, toque em voltar de novo".

**Outras mudanças visíveis**
- **Histórico do quiz:** cada vez que a criança termina o quiz, o resultado fica guardado (até 30 tentativas). O cartão mostra "🎯 melhor: X de Y" e "aberto N vezes" também em "Meus textos".
- **Backup por criança:** o arquivo passa a se chamar `coruja-explica-<nome>-AAAA-MM-DD.json` e leva nome, bichinho e textos apagados. **Importar agora JUNTA** em vez de substituir ("Juntar os N textos deste backup aos textos de …? Nada do que já está aqui é apagado." → "✅ Backup juntado!").
- Janelas da leitura (dicionário, quiz, ajustes) **giram junto** com o cartão quando o celular está em pé.
- O aviso de voz passa para dentro do cartão de leitura.
- A tecla Esc só fecha a leitura se ela estiver aberta.
- Texto antigo muito grande pode subir para a nuvem só com o título e o histórico. Nesse caso o cartão mostra "📦 Texto guardado só no backup…".
- Os botões do convite do quiz ganham tamanho mínimo de 14 px.

**Dados no celular (localStorage)** — mudança de estrutura:
- Nova `explica_usuarios` (lista de crianças e qual está usando).
- Por criança: `explica_<id>_textos`, `explica_<id>_excluidos` (registro dos textos apagados, para a nuvem não trazê-los de volta) e `explica_<id>_config` (cada criança tem sua letra, tamanho e ajustes).
- `explica_textos` e `explica_config` antigos **passam para a primeira criança cadastrada**. Uma cópia fica em `explica_textos_antes_v3` / `explica_config_antes_v3`; a cópia dos textos é a primeira coisa apagada se faltar espaço.
- `explica_rascunho` continua do aparelho (não é de uma criança).
- `explica_telaAcesa` passa a ser usada pelo escola-pwa.js. Os arquivos compartilhados usam também `escola_*` e `nuvem_*`.
- Cada texto ganha `alteradoEm` e `estadoEm` (para juntar dois celulares sem perder nada) e `quiz`.
- Nome do app na nuvem: `corujaexplica`. Limite por criança na nuvem: 850.000 bytes.

**Funções:** cerca de 70 novas, entre elas: `carregarUsuarios`, `salvarUsuarios`, `userAtual`, `chaveDe`, `textosDe`, `salvarTextosDe`, `migrarBibliotecaAntiga`, `liberarCopiaAntiga`, `marcarExcluido`, `excluidosDe`, `configPadrao`, `mesclarBibliotecas`, `_juntaTexto`, `_juntaQuiz`, `montarExportacao`, `registrarQuiz`, `abrirUsuarios`, `trocarUser`, `abrirNovoUser`, `editarUser`, `confirmarUser`, `apagarUser`, `abrirConfig`, `alternaTelaAcesa`, `instalarApp`, `iniciarNuvem`, `nuvemExportar`, `nuvemMesclar`, `nuvemSincronizarAgora`, `pedirCodigoFamilia`, `pedirCodigoModal`, `montarNuvemTela`, `montarVersoesTela`, `nuvemRecuperarLeitor`, `travarOrientacaoDaTela`. Nenhuma função antiga foi removida. A antiga tentativa de tela cheia "a cada toque" saiu do index.html e passou para o escola-pwa.js.

**sw.js:** passa a guardar também `nuvem-sync.js` e `escola-pwa.js`. `nuvem-config.js` é buscado na internet primeiro (espera até 2,5 s). A página principal espera até 4 s pela internet antes de abrir a cópia guardada (internet lenta). Pedidos ao Firebase (outro endereço) nunca são guardados no cache.

**Manifesto:** nova descrição ("Textos que explicam o mundo, para ler junto com a criança: dicionário por toque, perguntas de interpretação e histórico de cada leitura. Funciona sem internet. Escola São Pedro 🦉"); `start_url` muda de `./index.html` para `./`; entram `id`, `display_override` (fullscreen → standalone → minimal-ui) e `lang: pt-BR`; sai a entrada "maskable" do ícone de 192.

**Pedidos à IA:** **sem nenhuma mudança** (idênticos aos da v2.1). Dicionário: 113 palavras, sem mudança.

---

## v3.0 → v3.1 (24/09, 17:36)

Os 3 arquivos compartilhados (`escola-pwa.js`, `nuvem-sync.js`, `nuvem-config.js`) e o manifesto são **idênticos** aos da v3.0. O sw.js muda só o nome do cache e o comentário.

**Preparar texto**
- **O ↩️ Desfazer volta**, agora no próprio botão: depois de formatar (sozinho ao colar ou pelo botão), **🪄 Formatar vira ↩️ Desfazer** (destacado em laranja) e um toque volta o texto de antes ("↩️ O texto voltou a ser como estava antes de formatar"). Se o texto for alterado depois, o botão volta a ser "Formatar".
- Os avisos do Formatar passam a dizer o resultado: "🪄 Formatado: título «…» · N parágrafos · N perguntas", "✅ Este texto já está formatado · …" ou "❌ Não consegui formatar este texto — ele continua como estava".
- **Colar com texto já na caixa:** pergunta "Já tem um texto na caixa. Trocar pelo texto que você copiou agora? (Se mudar de ideia, toque em ↩️ Desfazer.)". Antes os dois textos eram juntados. Colar o mesmo texto de novo: "📋 Esse texto já está na caixa ✅".
- **Textos soltos (livro, cartilha, site):** o Formatar reconhece a **primeira linha como título** quando ela parece um título (até 10 palavras, sozinha, TODA EM MAIÚSCULAS ou sem pontuação, com linha em branco depois). Título em maiúsculas vira normal, mas os nomes próprios do texto continuam com maiúscula. **Frases que vinham uma por linha** (como em cartilhas) são juntadas em parágrafos de até 3 frases. Funções novas: `separarTituloSolto`, `juntarFrasesSoltas`.
- O contador de palavras, no Formato Coruja, conta **só a história**, sem rótulos, dicionário e perguntas.
- Os botões não ficam mais apagados sem explicação. Com a caixa vazia aparece "📋 Cole ou escreva um texto primeiro" ou "🧹 A caixa já está vazia". Limpar mostra "🧹 Caixa limpa".
- Salvar: "💾 Texto atualizado!" ou "💾 Salvo em Meus textos de <nome>!".
- Correção: quem estava **editando** um texto, fechava e abria o app, continua editando. Antes, o Salvar criava uma cópia repetida (o rascunho agora guarda `editando` e `crianca`).

**Leitura**
- **Tamanhos de letra em px**, como nos outros apps da escola: **12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 56, 64** (15 tamanhos; padrão **22**). O aviso passa a ser "🔤 Tamanho 22" ("(o menor)" / "(o maior)"). O tamanho guardado nas versões antigas é convertido automaticamente.
- Aa mostra o aviso "🔠 LETRAS MAIÚSCULAS" ou "🔡 Letras maiúsculas e minúsculas".
- **Ajustes da leitura reorganizados** (duas colunas quando a tela é larga e baixa):
  - **"Margem direita do texto"** com 3 opções no lugar das duas chaves antigas (sílabas e alinhar):
    - **☰ Normal**: padrão, margem irregular como no caderno;
    - **✂️ Sílabas**: corta na sílaba e divide a sobra entre os espaços;
    - **↔️ Espaços**: novo, não corta palavras; os espaços crescem no máximo 75% (`ESPACO_MAX_FATOR = 0.75`). O comentário registra um estudo com 9.291 linhas medidas: cerca de 64% das linhas ficam retas no celular e 22% na TV.
  - Nova chave **"Recuo no começo do parágrafo"** (ligada de fábrica), com uma amostra ao vivo.
  - "Tipo de letra" continua igual.

**Configurações e avisos**
- A chave "Tela sempre acesa" já aparece **ligada** na tela. Se o escola-pwa.js faltar, existe um modo simples de reserva que respeita a mesma escolha (`explica_telaAcesa`, ligada de fábrica).
- "📲 Instalar": avisa "✅ O app já está instalado neste celular" ou ensina o menu ⋮ do Chrome se o convite não abrir.
- O botão "🔄 Enviar agora" da nuvem não fica mais apagado.
- Os avisos (toasts) ficam na tela por mais tempo quando são longos (de 2,2 até 6 segundos) e ficam mais largos.
- Rodapé: "Coruja Explica · versão 3.1".

**Dados:** em `explica_<id>_config`, `fsizeIdx` é trocado por `fsize` (o tamanho em px), `silabasOn` e `alinharOn` são trocados por `modoMargem`, e entra `recuo`. A configuração antiga é convertida ao abrir. Quem tinha sílabas ligadas fica com o modo "Sílabas". ⚠️ Quem tinha "alinhar" ligado **sem** sílabas fica com "Normal": pelo código isso não muda nada na tela, porque o alinhar não funcionava sem sílabas.

**Funções:** novas: `clicarFormatar`, `desfazerFormatacao`, `esquecerFormatacao`, `resumoDaFormatacao`, `separarTituloSolto`, `juntarFrasesSoltas`, `juntavel`, `esvazia`, `idxDoTamanho`, `escolherModoMargem`, `atualizaOpcoesMargem`, `aplicarRecuo`, `alternarRecuo`, `telaAcesaReservaLigada`. Removidas: `toggleSilabas`, `atualizaChaveSilabas`, `toggleAlinhar`, `atualizaChaveAlinhar`.

**Pedidos à IA:** **sem mudança** (idênticos aos da v2.1 e da v3.0). Dicionário: 113 palavras, sem mudança.

---

## Pontos ambíguos ou que merecem atenção (tirados do código)

1. **v1.4, espaço entre cartões:** a mudança não fazia efeito. Quem diz isso é um comentário da própria v1.6, que corrigiu.
2. **v1.3 a v1.4, pedidos adaptar/continuar/consertar:** existiam no código, mas não havia botão para usá-los até a v1.5.
3. **v1.7 removeu o ↩️ Desfazer** e a **v3.1 trouxe de volta** em outro formato (o próprio botão Formatar alterna).
4. **"Alinhar margem" (v2.1)** vinha ligado, mas só agia com as sílabas ligadas. Na v3.1 virou parte do modo "Sílabas".
5. **Temas de cor:** a lista de 8 temas existe em todas as versões, mas nenhuma versão tem tela para escolher. Sempre aparece "Céu".
6. **Testes no aparelho:** este documento descreve o que o código faz. Não dá para saber, só pelos arquivos, quais mudanças foram testadas no celular.

---

## O que este documento cobre

- ✅ As 10 comparações (v1.3→v1.4 … v3.0→v3.1) do `index.html`, sem as linhas gigantes de letras e dicionário, que foram conferidas à parte e não mudaram.
- ✅ `sw.js` e manifesto, em todas as versões.
- ✅ Arquivos compartilhados da v3.x (identificados pelo cabeçalho; idênticos entre v3.0 e v3.1).
- ✅ Contagem do dicionário (113 em todas) e das palavras de cada pedido à IA, calculadas rodando o código de cada versão.
- ✅ Pedidos da v2.0 e da v2.1 conferidos com os documentos `prompts-coruja-explica-v2_0.md` e `v2_1.md`.
- ⬜ Leitura linha por linha do `nuvem-sync.js` e do `escola-pwa.js`: só os cabeçalhos e os nomes das chaves foram lidos.
- ⬜ Comparação das 113 palavras do dicionário uma a uma: não foi necessária, porque o conteúdo é idêntico em todas as versões.
- ⬜ Nenhum teste no celular ou no navegador foi feito para este documento.
