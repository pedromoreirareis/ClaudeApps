# Como rodar os testes do Coruja Explica (v3.1)

## Precisa de
- **Node 18 ou mais novo**.
- **Playwright com Chromium** (`npm install playwright` e `npx playwright install chromium`, ou um Chromium já instalado).
  - Se o Playwright não estiver no lugar padrão, use a variável `PLAYWRIGHT_MODULE` (caminho do módulo).
  - Se o Chromium estiver em outro lugar, use `CHROMIUM_PATH` (caminho do executável).

## Rodar tudo
```sh
cd testes
sh rodar_todos.sh
```
Leva uns 3 a 4 minutos. O resultado de cada bateria fica em `testes/saida/<bateria>.txt`, e as capturas de tela também vão para `testes/saida/`.

## Rodar uma bateria só
```sh
cd testes
node teste-v3.js
```

## O que cada teste usa (já vem no zip)
- **O app:** `../pacote-netlify/` (pode trocar com `CORUJA_ROOT=<pasta>` ou `CORUJA_INDEX=<index.html>`).
- **Firebase de mentira:** `_firebase-falso.js`. Imita o login anônimo, a renovação do login e o Firestore REST. **Só o `teste-v3.js` o usa** e intercepta tudo para `*.googleapis.com`.
  - As outras baterias de navegador **não interceptam**. Elas carregam o `nuvem-config.js` verdadeiro e só ficam longe do Firebase real porque o **código da família está vazio** no arquivo.
  - ⚠️ **Nunca rode os testes com um código escrito no `nuvem-config.js`.**
- **Criança de teste:** `_usuario-teste.js` cria "Teste 🦉" (id `p1`) para os testes antigos, feitos antes do cadastro.
- **Texto grande de exemplo:** `fixture-cruzeiro.txt`.
- **Originais do Pedro**, para conferir byte a byte: `originais/` (`3d480a65-nuvem-config.js`, `e783fd2b-nuvem-sync.js` v3, `f56a856b-escola-pwa.js` v2). Pode trocar com `CORUJA_ORIGINAIS`.
- **Compartilhados dos outros apps em 24/09/2026:** `referencias-outros-apps/` (Curiosidades, Alfabetização, Historinhas). Pode trocar com `CORUJA_REF`.
  - Conferido em 14/10/2026: o Curiosidades e o Historinhas **publicados** continuam iguais a essas cópias (`nuvem-sync.js` v3). Só o Alfabetização publicado mudou para a 4.1; para ele, a conferência vale só como registro de 24/09.
- **Pasta de saída:** `CORUJA_OUT` (padrão `testes/saida`).
- **Porta do servidor:** `CORUJA_PORT`, nas 6 baterias de navegador. Padrões: navegador 8951, v2 8961, adversarial e v21 8981, telas 8957, v3 9071.

## Resultado esperado (14/10/2026)
| Bateria | Resultado |
|---|---|
| teste-logica | 272/272 |
| teste-nuvem-logica | 37/37 |
| teste-formatar | 27/27 |
| teste-navegador | 64/64 |
| teste-telas | 96 verificações, nenhum problema |
| teste-adversarial | 26 verificações, nenhum bug |
| teste-v2 | 74/74 |
| teste-v21 | 41/41 |
| teste-v3 | 179/179 |
| **Total** | **816, 0 falhas** |

## O que mudou nesta passagem
Só os **caminhos**: antes eles apontavam para pastas da conversa antiga. Agora apontam para as pastas do zip ou para as variáveis acima. **A lógica dos testes não mudou.**

## Testes antigos (não rodam mais como estão)
- `antigos/teste-entrega.js` e `antigos/teste-logica-entrega.js`: entrega da v1.x; apontam para uma pasta que não existe mais.
- `antigos/regressao-v2.1/`: as baterias como eram antes do cadastro de crianças (v2.1).

**NUNCA publique a pasta `testes/` no Netlify.**
