/* Camada 2 da checagem: navegador real (Chromium), medindo o que aparece na
   tela — não propriedades CSS de elementos que podem nem ser os certos.
   Foi exatamente esse erro (medir o gap do .corpoBiblioteca em vez da
   distância real entre dois cards) que deixou o bug do espaçamento passar. */
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad/verif-entrega';
const PORT = 8961;
const OUT = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad';
const MIME = { '.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json' };

function serve(){
  return http.createServer((req,res)=>{
    let p = req.url.split('?')[0]; if (p === '/') p = '/index.html';
    fs.readFile(path.join(ROOT,p),(e,d)=>{
      if (e){ res.writeHead(404); res.end('nf'); return; }
      res.writeHead(200,{'Content-Type': MIME[path.extname(p)] || 'application/octet-stream'});
      res.end(d);
    });
  }).listen(PORT);
}

const TEXTO_A = `TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?
TEXTO:
Você já sentiu o calor do Sol no rosto durante uma brincadeira? Ele é uma estrela enorme, e a luz dele atravessa a atmosfera antes de chegar até você.

— Pai, será que eu poderia chegar perto do Sol?

— Não seria possível, porque o Sol é quente demais.

PALAVRAS NOVAS:
atmosfera = é a camada de ar que fica em volta de um planeta inteiro, como um cobertor bem fininho e invisível. É ela que segura o ar que você respira e que faz as estrelas cadentes brilharem antes de chegar aqui embaixo.

PARA PENSAR:
Por que a Lua parece brilhar, mesmo não produzindo luz própria?`;

const TEXTO_B = `TÍTULO: 🫁 Por que o coração acelera?

TEXTO:
Você já reparou no que acontece com o seu corpo quando corre bastante? Os seus músculos pedem mais oxigênio, e o coração acelera para entregar.

PALAVRAS NOVAS:
oxigênio = é um gás invisível que existe no ar e que o seu corpo precisa o tempo todo, como se fosse a comida dos músculos. Cada vez que você respira, ele entra e vai parar dentro do seu sangue.

PARA PENSAR:
Você já sentiu seu coração bater rápido?`;

(async () => {
  const server = serve();
  const erros = [];
  const resultados = [];
  function ok(nome, cond, detalhe){ resultados.push({ nome, ok: !!cond, detalhe: detalhe || '' }); }
  function info(nome, detalhe){ resultados.push({ nome, ok: true, detalhe: detalhe || '', info: true }); }

  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  try {
    const ctx = await browser.newContext({ viewport: { width: 412, height: 915 } });
    const page = await ctx.newPage();
    const benigno = s => /favicon\.ico/i.test(s || '');
    page.on('console', m => {
      if (m.type() !== 'error') return;
      const loc = m.location() || {};
      if (benigno(m.text()) || benigno(loc.url)) return;
      erros.push('console: ' + m.text() + (loc.url ? ' @ ' + loc.url : ''));
    });
    page.on('pageerror', e => erros.push('pageerror: ' + e.message));
    page.on('response', r => { if (r.status() >= 400 && !benigno(r.url())) erros.push('http ' + r.status() + ': ' + r.url()); });

    await page.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(300);

    // ---------- TELA INICIAL ----------
    ok('Tela inicial aparece', await page.isVisible('#telaInicio'));
    await page.mouse.click(50, 50); // dispara os ouvintes de tela cheia
    await page.waitForTimeout(100);

    // ---------- PREPARAR TEXTO: título detectado ----------
    await page.click('text=PREPARAR TEXTO');
    await page.waitForTimeout(200);
    ok('Tela Preparar Texto abre', await page.isVisible('#telaEstudio'));
    ok('Não existe mais a caixa de título sempre visível',
      await page.isVisible('#linhaTituloManual') === false);
    ok('A linha "Título:" começa com o aviso de que vai aparecer sozinho',
      (await page.textContent('#tituloDetectado')).includes('aparece sozinho'));

    // ---------- COLAR MANUAL (segurar na caixa) + FORMATAR AUTOMÁTICO ----------
    // Simula o colar nativo do Android: dispara um evento paste de verdade.
    await page.evaluate((txt) => {
      const caixa = document.getElementById('caixaTexto');
      caixa.focus();
      caixa.value = txt;
      const dt = new DataTransfer();
      dt.setData('text/plain', txt);
      caixa.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
      caixa.dispatchEvent(new Event('input', { bubbles: true }));
    }, TEXTO_A);
    await page.waitForTimeout(300);

    const valorAposColar = await page.inputValue('#caixaTexto');
    ok('Colar manual formata sozinho (rótulos reconstruídos)',
      /TÍTULO: ☀️ Você já imaginou/.test(valorAposColar) && /\nTEXTO:\n/.test(valorAposColar));
    ok('Botão Formatar fica desabilitado depois do formatar automático',
      await page.$eval('#btnFormatar', el => el.disabled));
    ok('Botão Desfazer fica disponível depois do formatar automático',
      await page.$eval('#btnDesfazer', el => !el.disabled));
    ok('Botão Colar fica desabilitado depois de colar',
      await page.$eval('#btnColar', el => el.disabled));

    const tituloChip = await page.textContent('#tituloDetectado');
    ok('Título é detectado sozinho, com emoji', /Você já imaginou uma viagem até o Sol\?/.test(tituloChip) && /☀/.test(tituloChip), `"${tituloChip}"`);

    // ---------- Formatar volta a valer depois de editar ----------
    await page.focus('#caixaTexto');
    await page.evaluate(() => {
      const c = document.getElementById('caixaTexto');
      c.value = c.value + '\n\nUm parágrafo novo escrito à mão.';
      c.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await page.waitForTimeout(150);
    ok('Formatar volta a ficar disponível depois de editar o texto',
      await page.$eval('#btnFormatar', el => !el.disabled));

    // ---------- Título manual pelo lápis ----------
    await page.click('.btnEditarTitulo');
    await page.waitForTimeout(150);
    ok('O lápis abre a caixa de título', await page.isVisible('#linhaTituloManual'));
    const preenchido = await page.inputValue('#inpTitulo');
    ok('A caixa de título já vem preenchida com o título detectado', preenchido.length > 5, `"${preenchido}"`);
    await page.fill('#inpTitulo', 'Título escrito pelo pai');
    await page.click('.btnTituloOk');
    await page.waitForTimeout(150);
    ok('O OK fecha a caixa de título', await page.isVisible('#linhaTituloManual') === false);
    ok('A linha "Título:" passa a mostrar o título escrito pelo pai',
      (await page.textContent('#tituloDetectado')).trim() === 'Título escrito pelo pai');

    // volta para o título automático, para o card usar o do texto
    await page.click('.btnEditarTitulo');
    await page.fill('#inpTitulo', '');
    await page.click('.btnTituloOk');
    await page.waitForTimeout(150);

    await page.click('#btnSalvar');
    await page.waitForTimeout(350);
    ok('Salvar leva para a biblioteca', await page.isVisible('#telaBiblioteca'));

    // ---------- SEGUNDO TEXTO (para medir a distância entre cards) ----------
    await page.click('text=+ Novo');
    await page.waitForTimeout(200);
    await page.fill('#caixaTexto', TEXTO_B);
    await page.click('#btnFormatar');
    await page.waitForTimeout(150);
    await page.click('#btnSalvar');
    await page.waitForTimeout(350);

    const qtdCards = await page.$$eval('.cardTexto', els => els.length);
    ok('Os dois textos aparecem na biblioteca', qtdCards === 2, `${qtdCards} cards`);

    // *** A MEDIÇÃO QUE IMPORTA: distância real entre os cards na tela ***
    const distancia = await page.evaluate(() => {
      const cards = document.querySelectorAll('.cardTexto');
      if (cards.length < 2) return null;
      const a = cards[0].getBoundingClientRect();
      const b = cards[1].getBoundingClientRect();
      return Math.round(b.top - a.bottom);
    });
    ok('Existe espaço de verdade entre os cards (>= 18px medidos na tela)',
      distancia !== null && distancia >= 18, `${distancia}px entre um card e outro`);

    const cardsComEmoji = await page.$$eval('.cardTitulo', els => els.map(e => e.textContent));
    ok('Os cards mostram o emoji do texto', cardsComEmoji.some(t => /☀|🫁/.test(t)), JSON.stringify(cardsComEmoji));
    const resumos = await page.$$eval('.cardResumo', els => els.map(e => e.textContent.trim()));
    ok('Nenhum card ficou com o resumo vazio', resumos.length === 2 && resumos.every(r => r.length > 0), JSON.stringify(resumos.map(r => r.slice(0, 30))));

    await page.screenshot({ path: `${OUT}/v2-biblioteca.png` });

    // ---------- LEITURA ----------
    await page.click('.cardTexto .cardLer');
    await page.waitForTimeout(450);
    ok('Popup de leitura abre', await page.evaluate(() => document.getElementById('detOv').classList.contains('open')));

    const fonteAntes = await page.$eval('#detTexto p', el => getComputedStyle(el).fontSize);
    await page.click('button[onclick="mudaFontSize(1)"]');
    await page.waitForTimeout(80);
    await page.click('button[onclick="mudaFontSize(1)"]');
    await page.waitForTimeout(120);
    const fonteDepois = await page.$eval('#detTexto p', el => getComputedStyle(el).fontSize);
    ok('Botão A+ aumenta a fonte de verdade', parseFloat(fonteDepois) > parseFloat(fonteAntes), `${fonteAntes} → ${fonteDepois}`);
    await page.click('button[onclick="mudaFontSize(-1)"]');
    await page.waitForTimeout(120);
    const fonteMenor = await page.$eval('#detTexto p', el => getComputedStyle(el).fontSize);
    ok('Botão A− diminui a fonte de verdade', parseFloat(fonteMenor) < parseFloat(fonteDepois), `${fonteDepois} → ${fonteMenor}`);

    const recuo = await page.evaluate(() => {
      const ps = Array.from(document.querySelectorAll('#detTexto p'));
      const normal = ps.find(p => !p.classList.contains('exemploLinha') && !p.classList.contains('pensarLinha'));
      const pensar = ps.find(p => p.classList.contains('pensarLinha'));
      return {
        normal: normal ? parseFloat(getComputedStyle(normal).textIndent) : null,
        pensar: pensar ? parseFloat(getComputedStyle(pensar).textIndent) : null,
        fonte: normal ? parseFloat(getComputedStyle(normal).fontSize) : null
      };
    });
    ok('Parágrafo normal tem recuo na primeira linha', recuo.normal > 0, `${recuo.normal}px`);
    ok('O recuo acompanha o tamanho da fonte', recuo.normal > recuo.fonte, `recuo ${recuo.normal}px para fonte ${recuo.fonte}px`);
    if (recuo.pensar !== null) ok('Balão "para pensar" fica sem recuo', recuo.pensar === 0, `${recuo.pensar}px`);

    // dicionário com definição longa
    const abriuGloss = await page.evaluate(() => {
      const alvo = Array.from(document.querySelectorAll('#detTexto .gloss'))[0];
      if (!alvo) return false;
      alvo.click();
      return true;
    });
    await page.waitForTimeout(300);
    if (abriuGloss) {
      const aberto = await page.evaluate(() => document.getElementById('glossOv').classList.contains('open'));
      ok('Dicionário abre ao tocar numa palavra', aberto);
      const def = await page.textContent('#glossDef');
      ok('A definição do dicionário é longa (2 a 3 linhas)', def.trim().length > 80, `${def.trim().length} caracteres`);
      const cabe = await page.evaluate(() => {
        const card = document.querySelector('#glossOv .pcard');
        return card.scrollHeight <= card.clientHeight + 2;
      });
      ok('A definição longa cabe no popup sem precisar rolar (retrato)', cabe);
      await page.screenshot({ path: `${OUT}/v2-dicionario.png` });
      await page.click('#glossOv .ok');
      await page.waitForTimeout(200);
    } else {
      ok('Havia palavra de dicionário no texto para testar', false, 'nenhuma palavra sublinhada encontrada');
    }

    await page.click('#detCard .detX');
    await page.waitForTimeout(300);
    ok('Popup de leitura fecha', await page.evaluate(() => !document.getElementById('detOv').classList.contains('open')));

    // ---------- MENU DE PROMPTS ----------
    await page.click('#telaBiblioteca .btnVoltar');
    await page.waitForTimeout(150);
    await page.click('text=PREPARAR TEXTO');
    await page.waitForTimeout(150);
    await page.click('.btnPromptMais');
    await page.waitForTimeout(200);
    ok('Menu de variações do prompt abre', await page.evaluate(() => document.getElementById('promptOv').classList.contains('open')));
    await page.click('text=Adaptar um texto pronto');
    await page.waitForTimeout(150);
    ok('A opção Adaptar pede o texto original', await page.isVisible('#promptPassoExtra'));
    await page.click('.promptVoltarBtn');
    await page.waitForTimeout(120);
    ok('O "Voltar às opções" funciona', await page.isVisible('#promptPassoLista'));
    await page.click('#promptOv', { position: { x: 5, y: 5 } });
    await page.waitForTimeout(150);
    ok('O menu fecha ao tocar fora', await page.evaluate(() => !document.getElementById('promptOv').classList.contains('open')));

    // ---------- PAISAGEM ----------
    await page.click('#telaEstudio .btnVoltar');
    await page.waitForTimeout(150);
    await page.click('text=LER');
    await page.waitForTimeout(250);
    await page.setViewportSize({ width: 915, height: 412 });
    await page.waitForTimeout(250);

    const distanciaPaisagem = await page.evaluate(() => {
      const cards = document.querySelectorAll('.cardTexto');
      if (cards.length < 2) return null;
      return Math.round(cards[1].getBoundingClientRect().top - cards[0].getBoundingClientRect().bottom);
    });
    ok('O espaço entre os cards também existe em paisagem', distanciaPaisagem >= 18, `${distanciaPaisagem}px`);

    await page.click('.cardTexto .cardLer');
    await page.waitForTimeout(450);
    const dims = await page.evaluate(() => {
      const r = document.getElementById('detCard').getBoundingClientRect();
      return { w: r.width, h: r.height, vw: innerWidth, vh: innerHeight };
    });
    const pw = dims.w / dims.vw, ph = dims.h / dims.vh;
    ok('Paisagem: a janela de leitura usa ~97% da largura', pw > 0.93 && pw < 0.995, `${(pw*100).toFixed(1)}%`);
    ok('Paisagem: a janela de leitura usa ~94% da altura', ph > 0.90 && ph < 0.995, `${(ph*100).toFixed(1)}%`);
    await page.screenshot({ path: `${OUT}/v2-leitura-paisagem.png` });

    // dicionário em paisagem (altura curta) — o caso mais apertado
    const abriuGloss2 = await page.evaluate(() => {
      const alvo = Array.from(document.querySelectorAll('#detTexto .gloss'))[0];
      if (!alvo) return false;
      alvo.click(); return true;
    });
    await page.waitForTimeout(300);
    if (abriuGloss2) {
      const cabe2 = await page.evaluate(() => {
        const card = document.querySelector('#glossOv .pcard');
        return { sobra: card.clientHeight - card.scrollHeight, h: card.clientHeight };
      });
      ok('A definição longa cabe no popup em paisagem, sem rolar', cabe2.sobra >= -2, `sobra ${cabe2.sobra}px de ${cabe2.h}px`);
      await page.screenshot({ path: `${OUT}/v2-dicionario-paisagem.png` });

      // teste de estresse: definição no tamanho MÁXIMO que o prompt permite
      // (45 palavras), no pior cenário — tela deitada e fonte grande
      const stress = await page.evaluate(() => {
        const def = 'é a camada de ar que fica em volta de um planeta inteiro, parecida com um cobertor bem fininho e invisível que ninguém consegue tirar. É ela que segura o ar que você respira todos os dias e que faz as estrelas cadentes brilharem bem antes de chegar aqui embaixo, perto da gente.';
        document.getElementById('glossDef').textContent = def;
        const card = document.querySelector('#glossOv .pcard');
        return { palavras: def.split(/\s+/).length, sobra: card.clientHeight - card.scrollHeight };
      });
      ok('Uma definição no tamanho máximo (45 palavras) ainda cabe em paisagem',
        stress.sobra >= -2, `${stress.palavras} palavras, sobra ${stress.sobra}px`);
      await page.screenshot({ path: `${OUT}/v2-dicionario-paisagem-maximo.png` });
    }

    // ---------- OFFLINE ----------
    const ctxOff = await browser.newContext({ viewport: { width: 412, height: 915 } });
    const pageOff = await ctxOff.newPage();
    await pageOff.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await pageOff.waitForFunction(() => navigator.serviceWorker.controller !== null, { timeout: 6000 }).catch(()=>{});
    await pageOff.waitForTimeout(600);
    await ctxOff.setOffline(true);
    await pageOff.reload({ waitUntil: 'load' }).catch(e => erros.push('recarga offline: ' + e.message));
    ok('O app abre sem internet (service worker)', await pageOff.isVisible('#telaInicio').catch(() => false));
    await ctxOff.setOffline(false);

    await browser.close();
  } catch (e) {
    erros.push('FALHA GRAVE: ' + e.stack);
    try { await browser.close(); } catch(_) {}
  }
  server.close();

  console.log('\n===== RESULTADOS NO NAVEGADOR =====');
  let tudoOk = true, n = 0, passaram = 0;
  for (const r of resultados) {
    if (!r.info) { n++; if (r.ok) passaram++; }
    console.log(r.ok ? '✅' : '❌', r.nome, r.detalhe ? '— ' + r.detalhe : '');
    if (!r.ok) tudoOk = false;
  }
  console.log('\n===== ERROS DE CONSOLE/REDE =====');
  if (!erros.length) console.log('(nenhum)');
  else { erros.forEach(e => console.log('❌', e)); tudoOk = false; }
  console.log(`\n${passaram}/${n} verificações — ` + (tudoOk ? '✅ TUDO OK' : '❌ HÁ FALHAS'));
  process.exit(tudoOk ? 0 : 1);
})();
