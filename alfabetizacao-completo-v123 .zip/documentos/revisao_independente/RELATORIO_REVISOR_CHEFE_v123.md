# Revisor-chefe independente — 📚 Esforço Vence — Alfabetização v123 (etapa 3, protocolo versão 3)

**Data:** 08/10/2026 · **Conferi:** `/home/claude/revisao/v123_final/` (zip completo, zip do Netlify, plano, prompt de passagem e texto de colar), comparando com a v122b e a v121.
**Como trabalhei:** descompactei tudo em pastas minhas (`/home/claude/chefe123/`), sem mexer em `/home/claude/v122/`. Usei só o Firebase de mentira. Rodei uma suíte de cada vez, nas portas 8931 a 8966. Meus testes ficaram em `/home/claude/chefe123/meus/`.

---

## 1. Resumo em 1 minuto

- **O zip do Netlify pode ir para o site de verdade.**
  - Os 9 arquivos estão na raiz do zip.
  - O `nuvem-config.js` é o seu (md5 `1d5f060a…`).
  - O `escola-pwa.js` é igual ao da v121.
  - O `sw.js` usa o cache `esforco-vence-v123`, que é diferente do da v122b, e tem o `escola-familia.js` na lista.
  - Os 107 md5 do `LEIA-ME.txt` batem, e não há nenhum arquivo sem linha.
- **Testes:** rodei todos no zip final e deu **690/691**, igual ao que os documentos dizem. A única falha é a antiga do `teste_fonte` (falta de fontes nesta máquina).
- **Os 2 🟠 do conferente foram corrigidos de verdade.** Os 🟡 que o autor disse ter corrigido estão no zip.
- **Escrevi e rodei 4 testes meus (54 verificações), e todas passaram:**
  - migração v121 → v123 com **2 celulares ligados na internet ao mesmo tempo**;
  - volta à v121 e ida de novo à v123;
  - caso B (celular sem o código da família);
  - tirar uma criança com e sem internet;
  - C1 com a lista de crianças dando erro **no envio**;
  - ⚙️ na "Quem vai estudar hoje?" **logo na abertura**, com o botão voltar.
- **Provei que os testes novos pegam os problemas:** o `teste_v123` rodado na v122b falha exatamente no C1, no C2 e na falta da ⚙️.
- **Provei também que o `nuvem-sync.js` 4.1 protege sozinho**, mesmo sem a trava do `index.html`. Isso é o que importa para os próximos apps.
- **A tela cheia está igual à da v121/v122:** o código é o mesmo, palavra por palavra.
- **Achados novos:** nenhum 🔴, nenhum 🟠. São só **4 🟡**, todos em documentos (veja a parte 4).

---

## 2. Achados do conferente: foram corrigidos?

| Achado | Corrigido? | Prova (o que eu RODEI ou LI) |
|---|---|---|
| 🟠1 Plano sem a regra "a criança entra na lista ANTES de juntar" | ✅ | Li no plano a parte 5.3, **item 16** (linha 613), e o Apêndice A (linha 995), que manda seguir o item 16. Rodei o C1 com a trava do app **tirada** (`semguarda/`): o 4.1 sozinho não regravou nada. |
| 🟠2 Relatórios de checagem fora do zip | ✅ | Os relatórios da v122, da v122b e da v123 estão em `documentos/`, com md5 no `LEIA-ME.txt`. |
| 🟡3 Frases velhas (importar "substitui", C1 "a corrigir", `#codOv`) | ✅ | `grep`: o `#codOv` só aparece como histórico ("até a v121"). O PROMPT de continuação, na linha 33, mostra o estado novo. |
| 🟡4 ⚙️ da T4 sem criança: "Nomes salvos" sem salvar | ✅ registrado | Está no capítulo 11 do HISTORICO e na parte 7 do relatório do autor. |
| 🟡5 Cópias antigas da lixeira deixavam a bolinha 🟡 | ✅ | `soAqui===true` no `escola-familia.js` (linha 342). O `teste_v123` parte 3 passou (3/3), e o teste com a cópia sem a marca deu 🟢. |
| 🟡6 Em pé, "← VOLTAR" quebrava em 2 linhas | ✅ (sobra registrada) | `.ef-voltar{white-space:nowrap}`. A minha captura em pé abriu sem nada por cima de nada. A sobra (o título quebra em várias linhas) está no capítulo 11. |
| 🟡7 "Continuar de onde parei" | ✅ | Parte 3, passo 3, das instruções de publicar: separa o Ler das outras atividades. |
| 🟡8 Qual `nuvem-sync.js` anexar na passagem | ✅ | Item 2 do "Como usar" do `PROMPT_HANDOFF_APPS.md`: "os que AQUELE app usa hoje". |
| 🟡9 "poucas centenas" | ✅ | O comentário do `index.html` diz "≈ 2,6 mil". O `teste_v123` parte 4 conta as combinações guardadas (passou). |
| Sobra da rodada 2: `#codOv` no capítulo 7, regra 7 | ✅ | `grep` no HISTORICO: só sobram as linhas 134, 180, 250 e 489, que são histórico ou tabela "até a v121". |

---

## 3. Minha passada própria (os pontos de maior risco)

Tudo nesta parte foi **RODADO**, num Chromium com o Firebase de mentira.

### 3.1 Migração v121 → v123 com 2 celulares online (`chefe_mig.py`, parte 1: 19/19)

**Os 2 celulares de partida:**
- **Celular A:** Hana 👧 com id `"1"` (sem prefixo) e Hinata 🐰 com id `p1727100000000`. Tinha 13 chaves de progresso, código `familia-real` e a v121.
- **Celular B:** as mesmas meninas com os ids **trocados** (Hinata = `"1"`, Hana = `p…`), também na v121.

**O que conferi:**
- Os 2 celulares na v121 subiram tudo para a nuvem.
- **A abre a v123 sem internet:** todas as chaves antigas ficaram iguais **byte a byte**. A única chave nova é `escola_familia`. As 2 meninas ficaram ligadas a `familia-real`, e o app abre em "Quem vai estudar hoje?".
- **A ligado na internet:**
  - a bolinha fica verde;
  - a Hana do A recebe o que a Hana leu no B (as leituras dos dois celulares se juntam);
  - uma frase nova lida na v123 sobe para a **mesma ficha de sempre** (`familias/familia-real/usuarios/hana_1f467`).
- **B ainda na v121** recebe a frase lida no A na v123.
- **B passa para a v123:** nada some e a bolinha fica verde.
- **A volta para a v121 (dentro das 2 semanas):**
  - as mesmas 2 meninas, com os mesmos ids;
  - nenhuma Hana fantasma;
  - a frase lida na v123 continua lá;
  - a mesma família;
  - uma frase lida de novo na v121 sobe para a **mesma** ficha.
- **A abre a v123 de novo:** tudo continua lá, sem erro de JavaScript.

### 3.2 Caso B: celular sem o código da família (`chefe_mig.py`, parte 2: 5/5)

**O celular de partida:** v121 sem código, com a Hana 👧 tendo lido uma frase que só ele tem.

- O app mostra "ESTE CELULAR JÁ TEM… ELAS NÃO VÃO SUMIR" com "AGORA NÃO".
- Depois de "JÁ TENHO CADASTRO" › código › "TRAZER TODAS":
  - fica **uma Hana só** (não duplicou);
  - o que ela tinha no celular continua, e foi juntado com o que estava na nuvem;
  - os favoritos ficaram intactos;
  - a ficha da Hana na nuvem passou a ter a frase que só aquele celular tinha, sem perder as dos outros.

### 3.3 Tirar uma criança (`chefe_mig.py`, parte 3: 5/5, mais as suítes do autor)

- **Sem internet, com uma leitura ainda só no celular:** o app **não tira** a criança. Ele pergunta "não dá para garantir" e oferece guardar uma cópia, só com um adulto. Os dados ficam intactos.
- **A internet volta:** a leitura sobe.
- **Com tudo guardado:** a criança sai do celular, a ficha dela continua na nuvem e as chaves dela não voltam a aparecer.
- A última criança não pode ser tirada nas 2 primeiras semanas. Isso é o `teste_familia` parte 5, que passou.

### 3.4 C1: a forma nova de juntar o que vem da nuvem (`aplicar`, no `nuvem-sync.js` 4.1)

**Li o código:**
- `aplicar` só junta se a criança está em `usuarios()`, e devolve `true`/`false`.
- Se a lista do app der erro, `usuariosParaEnviar` lança o erro, e quem chamou para sem mexer na fila.
- No envio, há uma segunda conferência (`aindaAqui`) logo depois da resposta da nuvem. Se ela der `false`, o envio para sem subir nada.
- `paraNuvem` **nunca tira** ninguém da lista: só marca `segurar`. Então nenhum caminho legítimo deixa de juntar por causa da trava nova.

**Rodei:**
- `teste_v123` parte 2 (recuperar e checar a nuvem com a resposta atrasada): passou.
- **O mesmo teste com a trava do app tirada do `index.html`:** a 4.1 sozinha impediu que as chaves voltassem (recuperar e checar: OK). Só falhou, como esperado, a verificação da própria trava.
- **Meu `chefe_c1lista.py` (5/5):** segurei a resposta da nuvem **no envio** e fiz a lista do app dar erro nesse meio-tempo:
  - nenhuma gravação foi feita na ficha;
  - a criança continuou na fila;
  - a nuvem ficou intacta;
  - quando a lista voltou, o app juntou e subiu a união certinha (`111` + `0000011111` = `1110011111`).

**Observação para o capítulo 11 (já existia na v3, não é da v123):** o `aplicar` ignora um erro **dentro** do `mesclar` do app e segue para o envio. No Alfabetização, o `nuvemMesclar` protege cada leitura com `try`, então isso não acontece. Para os próximos apps, vale escrever no plano que o `mesclar` não pode falhar no meio. Não bloqueia.

### 3.5 ⚙️ na "Quem vai estudar hoje?" (`chefe_t4.py`: 20/20; `teste_v123` parte 1: 28/28)

**Logo na abertura do app (984×432 e 360×740):**
- a ⚙️ abre as Configurações por cima;
- o **botão voltar** fecha as Configurações e volta à T4, sem sair do app;
- o Cantinho dos pais, aberto pela ⚙️, volta à T4 tanto pelo **✕ de verdade** quanto pelo voltar;
- abrir a ⚙️ e voltar 3 vezes seguidas **não empilha** o histórico (3 → 3);
- depois disso, escolher uma criança continua funcionando.

**Pela T4 aberta pelo chip:** ⚙️ e voltar levam de novo à T4, e mais um voltar sai dela (não fica preso).

Nenhum erro de JavaScript.

### 3.6 Tela cheia como era antes

- Comparei o código: `toggleFs`, `tentarTelaCheia` (o pedido ao abrir), `fsFirstTap` e a chamada `EscolaPWA.iniciar` (sem `telaCheia`) estão **idênticos** aos da v121 e aos da v122.
- O `manifest.webmanifest` e o `escola-pwa.js` têm o mesmo md5 da v121.
- O `teste_desenho` item 7 passou.
- **Só o celular confirma** que a "borda azul" sumiu.

### 3.7 As respostas ao Pedro estão honestas

- **Tela preta:** a melhora medida foi de ~15%, e a resposta não promete mais do que isso.
- **Desinstalar:** a resposta está certa. "Limpar e redefinir" só deve ser feito com a bolinha verde.
- **Aviso do Chrome:** é dito que ele continua (D18).

---

## 4. Achados novos (todos 🟡, nenhum bloqueia)

### 🟡A — Instruções de publicar: falta um jeito mais fácil de "desfazer"
- **Onde:** `INSTRUCOES_PUBLICAR_v123.md`, parte 1, item 3, e parte 4.
- **O problema:** o texto pede para "guardar o zip de hoje (`esforco-vence-netlify.zip`)", mas não diz o que fazer se o Pedro não tiver esse zip.
- **Sugestão:** acrescentar "se não tiver o zip, o Netlify guarda os deploys antigos: Deploys › clique no deploy da v121 › **Publish deploy** (volta na hora) ou **Download** (para guardar)". Na parte 4, lembrar de abrir o app 2 vezes depois de voltar.

### 🟡B — Apêndice A × parte 9-A: o que o conferente recebe
- **Onde:** plano, Apêndice A, passo 2 do bloco.
- **O problema:** o bloco diz que o conferente "recebe só o plano, o zip anterior, o zip novo, os testes e o meu pedido". A parte 9-A inclui também o **backup real**, quando o Pedro mandar.
- **Sugestão:** acrescentar "e o backup exportado, se eu mandar".

### 🟡C — `PROMPT_HANDOFF_APPS.md`, "Como usar", item 3
- **O problema:** a linha "**Modelo:** Sonnet 5.5, esforço alto" está no meio da lista sobre o veredito. Ela fica perdida ali.
- **Sugestão:** levar para o item 1 ("antes de colar, escolha Sonnet 5.5, esforço alto").

### 🟡D — Plano, parte 5.3 (para os próximos apps)
- **Sugestão:** acrescentar uma frase: "o `mesclar` do app não pode lançar erro no meio; proteja cada campo com `try`, como o `nuvemMesclar`". O motivo está na observação da parte 3.4.

**Fora destes:** os pontos já registrados no capítulo 11 continuam valendo. São eles:
- ⚙️ sem criança;
- não dá para descartar uma cópia da lixeira;
- o título em pé quebra em várias linhas;
- 568×320 no site de teste;
- "Instalar o app" some na aba do Chrome;
- abertura de ≈ 3 s.

---

## 5. A matriz da etapa 1, conferida

| Linha da matriz | Tem prova? | Como conferi |
|---|---|---|
| ⚙️ na T4 | ✅ | `teste_v123` parte 1 rodado (28/28) + meu `chefe_t4.py` (20/20) |
| Tela cheia como antes | ✅ (o visual só no celular) | comparei o código com a v121 e a v122; `teste_desenho` 7 rodado |
| Abertura lenta | ✅ parcial, explicada | `teste_v123` parte 4 (trilha com md5 igual ao da v122) rodado; não refiz a medição de tempo |
| Desinstalar | ✅ | li a parte 5 das instruções |
| Versão final (cache, C1, C2, C3) | ✅ | `sw.js` conferido; C1 e C2 rodados; C3 lido na parte 4 das instruções |
| Material para os próximos apps | ✅ | md5 de `compartilhados/` = `pacote-netlify/` = `LEIA-ME_COMPARTILHADOS.md` (rodado) |
| Plano e prompts versão 3 | ✅ | o `_COLAR` é **idêntico** ao bloco COPIE…ATÉ AQUI (rodado com Python); os 3 soltos são iguais aos do zip (`cmp`) |
| Nada antigo quebrou | ✅ | todas as suítes rodadas (abaixo) |
| "O teste novo falha na versão anterior" | ✅ | rodei o `teste_v123` na v122b: falha na ⚙️ (sem botão), no C1 (as chaves `p2_hana_done` e `p2_hana_trilha_v2` voltam) e no C2 (bolinha verde) |

**Os números de testes nos documentos estão certos.** São 89 + 72 + 81 + 34 + 130 + 59 + 127 + 41 + 58 = 691, e passam 690. Isso bate com o HISTORICO (linhas 704 e 742), o PROMPT de continuação (linha 33) e o relatório do autor.

---

## 6. Material para os próximos apps

### `compartilhados/`
- Os 4 arquivos (`escola-familia.js` 1.2, `nuvem-sync.js` 4.1, `escola-pwa.js` 2 e `nuvem-config.js` do Pedro) e o modelo `sw_alfabetizacao_v123.js` têm md5 **igual** ao `LEIA-ME_COMPARTILHADOS.md` e ao `pacote-netlify/`.
- O `nuvem-config.js` **não** é o falso dos testes.

### Plano versão 3
- **"2 agentes"** só aparece no bloco "o que mudou da versão 1 para a 2" (linhas 17 e 19) e na frase "antes eram 2 agentes" (linha 8). Isso é o histórico de mudanças, como deve ser.
- As partes 0 (item 8), 9-A, Apêndice A, Apêndice B e 12 dizem todas "autochecagem + 1 agente conferente + revisor-chefe".
- O modelo indicado é Sonnet 5.5, esforço alto. As decisões D17 e D18 estão na tabela.

### `PROMPT_HANDOFF_APPS.md` versão 3
- "3 camadas / 2 agentes" só aparece no bloco "o que mudou da 1 para a 2" (linha 12).
- O bloco de colar fala em 1 conferente + revisor-chefe.
- O texto de colar é igual ao bloco do arquivo completo. Tem só o título a mais, o que não atrapalha se for colado junto.

### O Apêndice A serve sozinho para o 🌍 Curiosidades?
**Sim.** Ele diz o que anexar e traz o bloco pronto, com:
- as cópias mestras, sem mudar, conferindo o md5;
- o Alfabetização como modelo;
- a regra do item 16;
- os tamanhos de tela;
- a checagem em 3 etapas, com o que fazer sem a ferramenta de agentes;
- site de teste e depois site de verdade;
- zip completo e checklist.

Há ainda a linha extra só do Curiosidades (base na v1.8, a v1.9 depois).

Só faltam os ajustes 🟡B e 🟡D.

### `INSTRUCOES_PUBLICAR_v123.md`
- **Seguro:**
  - pede o backup exportado de cada celular **antes** (com a bolinha verde, e "não importe na v121");
  - pede para guardar o zip da v121;
  - dá o aviso em destaque das 2 semanas, mais o "nunca publique a v121 depois de tirar todas as crianças";
  - diz "nunca o código de verdade no site de teste". O próprio site de teste recusa códigos sem "teste".
- **Honesto:** fala da tela preta (melhora parcial, explicada), da pergunta sobre desinstalar e do aviso do Chrome.
- Só falta a sugestão 🟡A.

---

## 7. O pacote

| Item | Resultado |
|---|---|
| Zip do Netlify | **9 arquivos na raiz**: `index.html`, `sw.js`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png`, `nuvem-config.js`, `nuvem-sync.js`, `escola-pwa.js`, `escola-familia.js` |
| `nuvem-config.js` | md5 `1d5f060a5ae8339921d3d58498807971` ✅. Projeto `escola-sao-pedro-5ee62`, sem a config de teste |
| `escola-pwa.js` | `ec31bf4a…`, igual ao da v121 ✅ |
| `sw.js` | `esforco-vence-v123` (v122b: `esforco-vence-v122b`; v121: `esforco-vence-v121`) ✅; `./escola-familia.js` na lista ✅ |
| Zip do Netlify = `pacote-netlify/` | os 9 md5 são iguais ✅ |
| `LEIA-ME.txt` | 107 linhas, 0 erros, nenhum arquivo sem linha ✅ |
| Sintaxe | `node --check` nos 5 `.js` OK; `checar_sintaxe.py` no `index.html`: "SINTAXE OK – 2 blocos" |

**Atenção ao fechar:** quando este relatório entrar em `documentos/revisao_independente/` (o relatório do autor já aponta para ele), o `LEIA-ME.txt` do zip completo precisa ser refeito. O zip do Netlify **não muda**, e não é preciso rodar os testes de novo (só entra um documento).

---

## 8. O que eu RODEI × o que só LI

**Rodei, no zip final, uma suíte de cada vez:**
- **Testes do autor:**
  - node 89/89;
  - v123 41/41;
  - família 130/130;
  - nuvem 81/81;
  - cadastro 72/72;
  - revisão 59/59;
  - desenho 127/127;
  - pwa 34/34;
  - fonte 57/58 (falha antiga: "Ler 412×915 tamanho 24", 86% < 90%).
  - **Total: 690/691.**
- **Testes meus:**
  - `chefe_mig.py`: 19 + 5 + 5;
  - `chefe_t4.py`: 20;
  - `chefe_c1lista.py`: 5.
- **Provas extras:**
  - `teste_v123` rodado na v122b (falha onde deve);
  - `teste_v123` partes 2 a 4 com a trava do app tirada (a 4.1 protege sozinha).
- **Conferências:**
  - md5 do `LEIA-ME.txt` e dos compartilhados;
  - `node --check` e `checar_sintaxe.py`;
  - o `_COLAR` comparado com o bloco (Python);
  - `cmp` entre os documentos soltos e os do zip;
  - `grep` por sobras do protocolo antigo e por config de teste no pacote.

**Só li:**
- os diffs v122b → v123 (`nuvem-sync.js`, `escola-familia.js`, `index.html`, `sw.js`) e o bloco da tela cheia (v121 × v122 × v123);
- `paraNuvem`, `pedirTirar`, `tirarFamilia` e `nuvemMesclar`;
- o plano (cabeçalho, 5.3 item 16, 9-A, 10, Apêndices A e B, 13, 14 e 12), o `PROMPT_HANDOFF_APPS.md`, as instruções de publicar, o capítulo 11 do HISTORICO e os relatórios do conferente e do autor.

**Não refiz:** a medição de tempo da abertura, nem as 42 capturas do conferente. Olhei só as minhas.

---

## 9. O que só o celular confirma

- A tela cheia **sem a borda azul** das barras do Android, aberta pelo ícone, e o aviso do Chrome aparecendo por poucos segundos.
- O tempo real da tela preta ao abrir. A 2ª abertura depois de publicar é a que vale.
- A ⚙️ da "Quem vai estudar hoje?" com o **botão voltar físico**.
- A migração com os dados **de verdade** dos 2 celulares das meninas (v121 → v123) e o aviso "FAMÍLIA •••• — TUDO CERTO ✅".
- Os 2 celulares com o Firebase real: "🔄 ATUALIZAR AGORA" leva o progresso de um celular para o outro.

✅ Pode publicar
