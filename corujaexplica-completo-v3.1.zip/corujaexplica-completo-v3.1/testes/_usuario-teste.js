/* Para os testes de regressão (feitos antes do cadastro de crianças):
   garante que já existe uma criança "Teste 🦉" (id p1) antes do app abrir. */
module.exports = function(ctx){
  return ctx.addInitScript(() => {
    try{
      if (!localStorage.getItem('explica_usuarios'))
        localStorage.setItem('explica_usuarios', JSON.stringify({ us: [{ id: 'p1', nome: 'Teste', av: '🦉' }], atual: 'p1' }));
      /* o convite para instalar tem testes próprios (teste-v3); aqui ele
         ficaria por cima dos botões */
      localStorage.setItem('escola_instalado', '1');
    }catch(e){}
  });
};
