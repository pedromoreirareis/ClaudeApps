# 📦 Prompt de passagem: fechar cada conversa de app e preparar a conversa nova


Olá! Esta conversa ficou muito grande e vou **continuar este aplicativo numa conversa nova**. Antes disso, preciso que você **feche esta conversa** com uma passagem completa e honesta. Ela vai ser a única memória que a conversa nova vai ter.

**⚠️ Importante: não altere nada no aplicativo agora.** Nada de correção, melhoria ou mudança de versão. É só registrar e empacotar exatamente o que existe hoje. (O próximo passo, já na conversa nova, vai ser padronizar o cadastro da família e das crianças nos 7 apps da Escola São Pedro. Por isso o capítulo 6 abaixo precisa ser muito detalhado.)

### Quem sou eu e para quem são os apps

- Sou o **Pedro**, de Mara Rosa (GO). **Não sou programador.** Sonho em criar bons aplicativos para melhorar a aprendizagem das minhas filhas, e você (Claude) escreve todo o código. Eu decido a parte pedagógica e testo com as meninas num **celular Android de verdade**, quase sempre **espelhado na TV**, com elas sentadas a uns 3 metros.
- **Hinata, 6 anos:** está no 1º ano do ensino fundamental, mas já lê e faz matemática no nível de uma criança do 3º ano.
- **Hana, 4 anos:** já lê com certa fluência e faz pequenas contas de adição e subtração.
- Os apps são da **Escola São Pedro** (marca Coruja 🦉 / "Esforço Vence": o esforço vale mais que o talento). São 7 PWAs que funcionam sem internet, cada um em `escolasaopedro<nome>.netlify.app`:
  - 📚 Alfabetização (Esforço Vence)
  - 🔢 Matemática
  - 📖 Fluência
  - 🦉 Coruja Explica
  - 📝 Provinha
  - 📕 Historinhas
  - 🌍 Curiosidades
- Todos usam os mesmos arquivos compartilhados: `nuvem-config.js`, `nuvem-sync.js` e `escola-pwa.js`. O 📚 Alfabetização já passou para o cadastro novo (`escola-familia.js` 1.2 e `nuvem-sync.js` 4.1); os outros continuam com o `nuvem-sync.js` de hoje até chegar a vez deles. **Nesta passagem, use a cópia que ESTE app usa hoje** (veja a pasta `pacote-netlify/` abaixo).
- O plano do novo cadastro (`PLANO_CADASTRO_FAMILIA.md`, versão 3) **já está aprovado** (decisões D1 a D18). Você não precisa dele para esta passagem. Ele vai ser anexado na conversa nova.
- Junte a isso **tudo o que você sabe sobre mim, sobre as meninas e sobre este app** nesta conversa e na memória (preferências, jeito de trabalhar, pedidos, reclamações, o que elas gostaram ou não). Se algo do que você lembra for diferente do que está escrito aqui, registre as duas versões e diga qual é a mais nova.

### O que eu preciso: 3 arquivos

Use no nome dos arquivos o ID do app na nuvem (`alfabetizacao`, `matematica`, `fluencia`, `corujaexplica`, `provinha`, `historinhas` ou `curiosidades`).

**1) `HISTORICO_E_PLANO_<app>.md`: o histórico e plano completo do aplicativo**

Escreva em português simples, mas completo o bastante para alguém que nunca viu este app continuar sem errar. Use estes capítulos:

1. **Identificação**
   - nome do app;
   - endereço no Netlify;
   - ID na nuvem;
   - versão atual e nome do cache do `sw.js`;
   - data da última entrega;
   - lista de arquivos do pacote.
2. **Para quem e para quê:** objetivo pedagógico, como as meninas usam, filosofia do app.
3. **Linha do tempo completa, versão por versão.** Para cada versão:
   - o que pedi;
   - o que foi feito;
   - por quê;
   - o que foi desfeito depois e por quê.
4. **Decisões de design e de pedagogia**, inclusive as **rejeitadas** e o motivo.
5. **Como o app é por dentro**
   - estrutura do arquivo;
   - telas (com os `id`s);
   - funções principais;
   - conteúdo e dados (tamanhos e contagens);
   - orientação da tela (deitado, em pé, rotação);
   - service worker e manifest;
   - **lista completa de TODAS as chaves do `localStorage`** e o que cada uma guarda;
   - o que fica em IndexedDB ou em outros lugares.
6. **Cadastro, família e nuvem: como está HOJE** (capítulo mais importante, bem detalhado):
   - onde ficam a lista de crianças e a criança atual: chaves, formato e tipo de id (ex.: `p…`, nome sem acento, legado `1`);
   - como o progresso de cada criança é separado: prefixos, chaves e lista de isolamento;
   - telas, com os **textos exatos** dos títulos e botões:
     - primeira abertura;
     - escolher a criança;
     - cadastro;
     - mudar nome ou bichinho;
     - apagar;
     - recuperar da nuvem;
     - versões guardadas;
     - pop-up do código da família;
   - o que acontece ao abrir com 0, 1 e 2 ou mais crianças;
   - onde ficam o botão de trocar de criança, a ⚙️ e a bolinha da nuvem, e em quais telas eles aparecem;
   - regras de apagar: pode apagar a última? o que apaga do celular? o que não vai para a nuvem e se perderia?;
   - ligação com o `nuvem-sync.js`: `APP_NUVEM`, `idDaChave`, `exportar`, `mesclar` (regra de juntar campo por campo), `nuvemTentarRecuperarNovo`, `nuvemLevarFichaAntiga`;
   - passos próprios do cadastro deste app (ex.: turma, idade, ano), se houver;
   - pop-ups do navegador (`alert`/`confirm`/`prompt`) que ainda existam, e onde;
   - **riscos e defeitos conhecidos** nessa parte: perda de dados, teclado cobrindo campo, textos diferentes dos outros apps.
7. **Regras que não podem ser quebradas** neste app.
8. **Aprendizados difíceis:** problemas que já aconteceram, a causa de verdade e como foram resolvidos.
9. **Testes automáticos**
   - quais existem e quantos verificam;
   - como rodar;
   - o que eles **não** cobrem;
   - resultado da última vez que rodaram, com a data.
10. **Como empacotar e publicar:** passo a passo da entrega e próximo número de versão do cache.
11. **Estado atual**
    - o que está pronto;
    - o que está pendente;
    - defeitos conhecidos;
    - pedidos meus que ficaram para depois;
    - ideias futuras.
12. **Plano de desenvolvimento:** próximos passos em ordem de prioridade. O primeiro é a **padronização do cadastro da família e das crianças** (código da família + crianças com nome + bichinho, telas e palavras iguais nos 7 apps).
13. **Sobre o Pedro e as meninas, e como trabalhar comigo:**
    - tudo o que você sabe;
    - preferências: português do Brasil; edições cirúrgicas; explicação simples da causa de cada problema; honestidade sobre o que foi ou não testado; checklist ✅/⬜ no fim; pedir autorização antes de coisas grandes; eu às vezes falo por voz e o texto sai trocado (ex.: "Wolf screen" = "Full screen").
14. **Glossário:** as palavras do app e o que cada uma quer dizer.

**2) `PROMPT_CONTINUACAO_<app>.md`: prompt para começar a conversa nova**

- No começo, diga **o que eu preciso anexar** na conversa nova. No mínimo:
  - o zip completo (arquivo 3);
  - o `HISTORICO_E_PLANO_<app>.md`;
  - quando for mexer no cadastro, o `PLANO_CADASTRO_FAMILIA.md`.
- Depois, um bloco entre `COPIE DAQUI` e `ATÉ AQUI` que se explica sozinho:
  - quem sou eu e quem são as meninas;
  - o que é o app e o estado atual (versão, cache, número de testes);
  - as regras que não podem ser quebradas;
  - como entregar (zip para o Netlify, `nuvem-config.js` sem alteração, versão do cache, testes, checklist);
  - a instrução **"leia o HISTORICO_E_PLANO inteiro antes de mexer"**.
- No fim: **"O que eu quero agora: (escreva aqui)"**.

**⚠️ Só para o 🌍 Curiosidades:** eu anexei a **v1.8** (a publicada) e a **v1.9** (novidades ainda não publicadas).
- A **v1.8** é a base do novo cadastro: ela vai em `pacote-netlify/`, e é ela que os capítulos 1, 5 e 6 descrevem.
  - O `index.html`, o `sw.js` e o `manifest` do pacote são **os da v1.8**. Se o `sw.js` da v1.8 não existir aqui nem nos anexos, **pare e me peça**.
  - O zip se chama `curiosidades-completo-v1.8.zip`.
  - Os testes que só valem para a v1.9 ficam em `trabalho/v1.9-pendente/`, junto com o `index` da v1.9 e o seu `sw.js`, se existir.
- A **v1.9** **não** é aplicada agora. Ela vai para `trabalho/v1.9-pendente/`, junto de um arquivo `O_QUE_MUDA_NA_V1.9.md` com **todas** as diferenças entre a v1.8 e a v1.9, feito comparando os dois arquivos linha a linha. Para cada diferença, diga:
  - o que muda para a criança;
  - quais funções mudam;
  - **chaves novas ou alteradas do `localStorage`** (por exemplo, `sayTap`);
  - o que muda no backup;
  - o que muda na nuvem;
  - o que pode conflitar com o novo cadastro.
- No capítulo 12, a 2ª prioridade é **"aplicar as novidades da v1.9 depois que o novo cadastro estiver publicado e conferido"**.

**3) `<app>-completo-v<versão>.zip`: tudo do aplicativo**

Dentro dele, em pastas:
- `pacote-netlify/`: **exatamente** o que vai para o Netlify (`index.html`, `sw.js`, `manifest.webmanifest`, ícones, bibliotecas, `nuvem-sync.js`, `escola-pwa.js` e o meu `nuvem-config.js` **byte a byte igual** ao que eu mandei).
  - **`nuvem-sync.js` e `escola-pwa.js`:** vai a cópia que **este app usa hoje** (a do zip publicado ou a desta conversa), **não** a que eu anexei. Compare o md5 das duas. Se forem diferentes, **não troque**: registre a diferença no capítulo 11.
- `documentos/`: os arquivos 1 e 2, mais toda documentação, prompts, listas de palavras ou de conteúdo e referências que existirem;
- `testes/`: todas as baterias de teste, o "Firebase de mentira" e como rodar;
- `trabalho/`: scripts e arquivos de trabalho que ajudam a continuar (ex.: `montar.py`, silabificador, auditorias), se existirem;
- `LEIA-ME.txt`: lista de **todos** os arquivos, com tamanho e código de conferência (md5), a versão do app e a data. (O próprio `LEIA-ME.txt` e o relatório da conferência ficam fora da lista de md5, porque são escritos por último.)
- `documentos/RELATORIO_CONFERENCIA_PASSAGEM_<app>.md`: o resultado da conferência (veja abaixo).

### Regras para esta passagem

1. **A fonte da verdade é o arquivo, não a memória.**
   - Se eu anexei o `index`/zip mais recente, use **ele** e compare com o que você lembra.
   - Se os arquivos de trabalho desta conversa se perderam e eu não anexei, **pare e me peça**. Não reconstrua o app de memória.
   - **Testes ou scripts perdidos** (ex.: baterias de teste, `montar.py`): **não reescreva**. Liste como **PERDIDOS** no `LEIA-ME.txt` e no capítulo 9, com o que você lembra deles marcado como lembrança.
2. Confira o pacote:
   - `node --check` no JavaScript;
   - abra o zip depois de pronto e confira se todos os arquivos estão lá;
   - confira se o `nuvem-config.js` está byte a byte igual;
   - rode os testes se o ambiente deixar.
   - Diga claramente o que foi **rodado de verdade** e o que foi só **lido no código**.
3. **Separe o que é certeza** (está no arquivo) **do que é lembrança** (da conversa). Se não souber algo, escreva "não sei".
4. **Não mude o código.** Se achar um problema, anote no capítulo 11 e me avise. Não conserte agora.
5. **Só me envie depois da conferência abaixo.** Escreva o veredito também **aqui no chat**, não só no relatório. Termine com um checklist ✅/⬜ do que foi feito e do que eu preciso fazer.
6. **Se esta conversa estiver perto do limite de tamanho:** entregue primeiro o zip e o `HISTORICO_E_PLANO`, depois o prompt de continuação. Se não couber a conferência, avise e termine o relatório com "NÃO CONFERIDO POR AGENTES INDEPENDENTES". Eu faço a conferência em conversas novas.

### Conferência obrigatória antes de me entregar (3 etapas)

**Etapa 1: autochecagem (você mesmo)**
- Uma tabela "pedido → prova": cada item pedido aqui (os 14 capítulos, o prompt de continuação, cada pasta do zip, `LEIA-ME.txt`, md5, `nuvem-config.js` byte a byte, `node --check`, testes) e **como você provou** que está feito.
- Item sem prova fica ⬜, nunca ✅.

**Etapa 2: 1 agente conferente independente**

Crie **1 agente novo**, que **não viu esta conversa**.

> **O que é um "agente" aqui:** outra instância do Claude **criada por uma ferramenta** (por exemplo, a ferramenta Agent/Task), com contexto próprio e vazio. **Fazer o papel de agente nesta mesma conversa NÃO vale**: seria corrigir a própria prova. Sem a ferramenta, siga "Se você não conseguir criar agentes separados", mais abaixo.
- **O que ele recebe:**
  - o `index` (e o zip publicado) que eu anexei;
  - o zip que você montou;
  - os 2 `.md`;
  - este pedido.
- **O que ele não recebe:** as suas explicações.
- **A missão dele é achar erros**, não confirmar. Ele confere as duas partes:

| Parte | O que confere |
|---|---|
| **Pacote** (empacotamento e publicação no Netlify) | o `index.html` do zip é **idêntico** ao que eu anexei (md5); estão lá todos os arquivos que o `index`, o `sw.js` e o `manifest` pedem; `nuvem-config.js` byte a byte; md5 do `LEIA-ME.txt` corretos; `node --check` passa; os testes do zip rodam como o capítulo 9 diz; o app abre num navegador sem tela (Playwright/Chromium) sem erro no console |
| **Histórico** (ler código e comparar com a documentação) | os capítulos 5 e 6 batem com o código: **todas** as chaves do `localStorage` (procurar no código cada `localStorage`, `getItem`, `setItem` e prefixo, e comparar com a lista), os `id`s das telas, os **textos exatos** dos botões e títulos, as funções da nuvem, os `alert`/`confirm`/`prompt` que existem; versão e cache certos; o prompt de continuação funciona sozinho (dá para começar só com ele e os anexos?) |

- Cada achado tem: **gravidade** (🔴 grave = informação errada que pode fazer a conversa nova errar ou perder dados, ou arquivo faltando; 🟠 importante = incompleto; 🟡 leve), **onde** e **a correção sugerida**.
- Você corrige **os documentos e o zip**. **O código do app não muda.** Se o problema for do app, ele só vai para o capítulo 11.
- **Defeitos do próprio app** (ex.: erro no console que já existe na versão publicada, ou rede bloqueada no seu ambiente) **não bloqueiam**: vão para o capítulo 11. Só bloqueiam os 🔴 e 🟠 **dos documentos e do zip**.
- **O mesmo agente confere a correção.** Se a ferramenta não deixar continuar o mesmo agente, vale um agente novo, com o relatório anterior.
- Repita até **zero 🔴 e zero 🟠**, no máximo **3 rodadas**. Se ainda sobrar 🔴 ou 🟠, **pare** e me entregue o relatório com o veredito "❌ Passagem com problemas".

**Etapa 3: revisão final pelo revisor-chefe (outro agente novo)**

Um segundo agente, também novo:
- confere se cada achado foi corrigido, abrindo o zip final de novo;
- faz a sua própria passada pelo capítulo 6 (cadastro, família e nuvem) contra o código;
- dá o veredito: **"✅ Passagem aprovada"** ou **"❌ Passagem com problemas: <quais>"**.

**O relatório:** coloque tudo em `documentos/RELATORIO_CONFERENCIA_PASSAGEM_<app>.md`:
- a tabela da etapa 1;
- os achados do conferente e as correções;
- o veredito do revisor-chefe;
- **o que foi rodado e o que foi só lido**.

A **última linha** do relatório é o veredito.

**Se você não conseguir criar agentes separados:**
- diga isso claramente;
- faça a etapa 1 mesmo assim;
- termine o relatório com **"NÃO CONFERIDO POR AGENTES INDEPENDENTES"**;
- me avise para usar os prompts de conferência em conversas novas.

**Cuidados práticos:** entregue o zip completo assim que ele estiver pronto (o ambiente da conversa pode ser apagado depois de um tempo parado); ao matar processos de teste, não use `pkill -f` com um texto que também apareça no próprio comando (isso derruba o próprio terminal).
