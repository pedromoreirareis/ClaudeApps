/* Cobre uma área que já teve bug no histórico do projeto: o "Marcar
   estudada" tinha um bug de ESCOPO (marcar uma sílaba específica
   "vazava" e marcava a família inteira, ou vice-versa). Testa que a
   família ("M") e a sílaba dentro dela ("M::ma") são entradas
   INDEPENDENTES na mesma lista.
   Também faz o fluxo de ponta a ponta de Monta a Frase e Sílaba
   Perdida (clicar nas palavras/opções de verdade, não só chamar as
   funções internas) pra confirmar que a marcação de "já concluída"
   dispara pelo caminho real que a criança usa. */
const { carregarApp, t, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_08_marcar_estudada_e_fluxos');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);
  // o próprio app já tem um interruptor pra pular a animação de "a
  // palavra voa até a vaga" nos testes (voarAtePosicao chama
  // aoTerminar() na hora, sem esperar requestAnimationFrame/CSS) — é
  // esse aoTerminar() que dispara marcarConcluida(), então sem isso os
  // 2 testes de fluxo completo abaixo precisariam esperar ~560ms cada.
  window.eval('window._testeSemAnimacao = true;');

  t('alternarEstudada: marcar a SÍLABA não marca a FAMÍLIA inteira como estudada', () => {
    window.eval("localStorage.setItem('hana_sil_estudadas','[]');");
    window.eval("alternarEstudada('M::ma');"); // marca só a sílaba "ma" da família M
    const familiaEstudada = window.eval("estaEstudada('M')");
    const silabaEstudada = window.eval("estaEstudada('M::ma')");
    assertEq(silabaEstudada, true, 'a sílaba marcada devia estar estudada');
    assertEq(familiaEstudada, false, 'BUG DE ESCOPO: marcar só a sílaba "M::ma" marcou a família "M" inteira');
  });

  t('alternarEstudada: marcar a FAMÍLIA não marca uma sílaba específica sozinha', () => {
    window.eval("localStorage.setItem('hana_sil_estudadas','[]');");
    window.eval("alternarEstudada('M');"); // marca a família inteira
    const familiaEstudada = window.eval("estaEstudada('M')");
    const silabaEstudada = window.eval("estaEstudada('M::ma')");
    assertEq(familiaEstudada, true, 'a família marcada devia estar estudada');
    assertEq(silabaEstudada, false, 'marcar a família não devia por si só marcar "M::ma" como entrada separada');
  });

  t('estaEstudadaEmAlguma([fam, silaba]) enxerga os 2 níveis ao mesmo tempo (cascata)', () => {
    window.eval("localStorage.setItem('hana_sil_estudadas', JSON.stringify(['M::ma']));");
    const r1 = window.eval("estaEstudadaEmAlguma(['M','M::ma'])"); // sílaba marcada -> true
    window.eval("localStorage.setItem('hana_sil_estudadas', JSON.stringify(['M']));");
    const r2 = window.eval("estaEstudadaEmAlguma(['M','M::mi'])"); // família marcada -> true mesmo pra outra sílaba
    window.eval("localStorage.setItem('hana_sil_estudadas', JSON.stringify(['P']));");
    const r3 = window.eval("estaEstudadaEmAlguma(['M','M::ma'])"); // nada bate -> false
    assertEq(r1, true, 'devia enxergar a sílaba marcada');
    assertEq(r2, true, 'devia enxergar a família marcada mesmo pedindo outra sílaba dela');
    assertEq(r3, false, 'não devia achar nada quando é família diferente (P != M)');
  });

  t('alternarEstudada() devolve true ao MARCAR e false ao DESMARCAR (clique alterna certo)', () => {
    window.eval("localStorage.setItem('hana_sil_estudadas','[]');");
    const marcou = window.eval("alternarEstudada('T')");
    const desmarcou = window.eval("alternarEstudada('T')");
    assertEq(marcou, true, 'primeiro clique devia marcar (true)');
    assertEq(desmarcou, false, 'segundo clique devia desmarcar (false)');
  });

  t('Monta a Frase — clicar nas palavras na ordem certa (fluxo real de clique) marca a frase como concluída', () => {
    window.eval("try{ localStorage.removeItem('hana_monta_ok'); }catch(e){}");
    window.eval('openMonta(30);');
    const alvo = window.eval('window._mtTxt').split(' ');
    // clica em cada botão-palavra do pool na ordem certa da frase, igual
    // a criança faria na tela
    for (let k = 0; k < alvo.length; k++) {
      const palavraAlvo = window.eval('window._mtTxt').split(' ')[k];
      const botoes = Array.from(doc.getElementById('mtPool').children);
      const btn = botoes.find(b => b.textContent === palavraAlvo && b.style.visibility !== 'hidden');
      assert(btn, 'não encontrei o botão da palavra "' + palavraAlvo + '" (posição ' + k + ') ainda visível no pool');
      btn.onclick();
    }
    assertEq(window.estaConcluida('monta', 30), true, 'depois de clicar todas as palavras na ordem certa, a frase 30 devia estar marcada como concluída');
    assert(doc.getElementById('mtWrap').classList.contains('jaConcluida'), '#mtWrap devia ganhar a classe .jaConcluida na hora, sem precisar reabrir a página');
  });

  t('Sílaba Perdida — clicar na opção certa (fluxo real de clique) marca a frase como concluída', () => {
    window.eval("try{ localStorage.removeItem('hana_silaba_ok'); }catch(e){}");
    const jReal = window.eval('openSilaba(30);');
    // acha, entre as opções mostradas, qual é a resposta certa —
    // reconstruída checando qual botão, ao ser clicado, preenche a lacuna
    const ops = Array.from(doc.getElementById('spOps').children);
    // a resposta certa é a que NÃO gera o toast de erro — descobre testando
    // via inspeção do estado interno em vez de tentativa-e-erro repetido:
    // o app guarda a "resposta" só dentro do closure, então usamos o
    // primeiro clique e confirmamos que ALGUM caminho (certo ou raspagem)
    // eventualmente conclui a frase, clicando em todas até achar a certa.
    let concluiu = false;
    for (const b of ops) {
      b.onclick();
      if (window.estaConcluida('silaba', jReal)) { concluiu = true; break; }
    }
    assert(concluiu, 'nenhuma das opções mostradas concluiu a frase — o clique na resposta certa não está marcando mais?');
    assert(doc.getElementById('spWrap').classList.contains('jaConcluida'), '#spWrap devia ganhar a classe .jaConcluida na hora');
  });

  resumo();
})();
