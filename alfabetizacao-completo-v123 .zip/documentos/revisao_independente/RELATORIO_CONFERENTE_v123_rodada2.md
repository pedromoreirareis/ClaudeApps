# Conferente independente: Esforço Vence — Alfabetização v123 (rodada 2)

**Data:** 08/10/2026 · **Conferi:** `/home/claude/revisao/v123_final/` (zip completo, zip do Netlify e os 3 documentos soltos), descompactado numa pasta nova (`/home/claude/conf123r2/`) e comparado arquivo por arquivo com o zip da rodada 1.

## Resumo
Os **2 🟠 foram corrigidos**. Dos 7 🟡:
- **6 foram corrigidos** (3, 5, 6, 7, 8 e 9);
- o 🟡4 ficou **registrado no capítulo 11**, como combinado.

Sobraram só **2 pontos leves**, nenhum deles bloqueia:
- uma menção velha ao `#codOv` na regra 7 do capítulo 7 do histórico;
- em pé, a barra de cima ainda fica ~20 px mais alta que na v122b, porque agora é o título que quebra em 4 linhas (o "← VOLTAR" já não quebra).

O código mudou **só** onde o autor disse:
- `escola-familia.js`: 1 linha de CSS e 1 condição;
- `index.html`: 1 comentário;
- `nuvem-sync.js`, `sw.js`, `escola-pwa.js` e `nuvem-config.js`: iguais aos da rodada 1.

O pacote confere:
- os 9 arquivos na raiz do zip;
- os md5 do `LEIA-ME.txt` (106 linhas, 0 erros, nenhum arquivo sem linha);
- o `nuvem-config.js` com md5 `1d5f060a…`;
- o md5 novo do `escola-familia.js` (`c12df6ca…`) atualizado no `LEIA-ME_COMPARTILHADOS.md`, sem o md5 antigo sobrando em nenhum documento;
- `compartilhados/` = `pacote-netlify/` = `testes/`.

## Achados da rodada 1 → corrigido?

| Achado | Situação | Prova |
|---|---|---|
| 🟠1 Plano: a criança entra na lista ANTES de juntar | ✅ corrigido | Plano, parte 5.3, **item 16** (cita `recuperar`, `juntarVersao`, envio, backup, lixeira e trazer, com o exemplo do Alfabetização). O Apêndice A manda seguir o item 16. Os 3 documentos soltos são iguais aos de dentro do zip (`cmp`). |
| 🟠2 Relatórios de checagem fora do zip | ✅ corrigido | `RELATORIO_CHECAGEM_alfabetizacao_v122.md` e `_v122b.md` são **byte a byte** iguais aos do zip da v122b. O `_v123.md` está presente e descreve meus achados corretamente (gravidade, o que foi feito e o que foi para o capítulo 11). Aceito a explicação: tirá-los do zip da rodada 1 foi de propósito, porque o conferente não pode ver os relatórios do autor. |
| 🟡3 Frases velhas | ✅ corrigido, com 1 sobra 🟡 | **PROMPT de continuação:** o item 4 diz que "importar JUNTA desde a v122", a linha 33 não diz mais "C1 a corrigir", a regra 5 não cita mais o `#codOv`, e a regra 9 ganhou a regra da 4.1. **HISTORICO:** a tabela 5.2 agora tem o `#efRaiz` e marca as telas antigas como "até a v121"; o capítulo 10, item 9, separa v121 (substitui) de v122+ (junta). **Sobra:** HISTORICO, capítulo 7, regra 7 (linha 627) ainda diz "`confirmModal`, `#codOv`". (As linhas 134, 180 e 489 são do histórico ou da descrição da v121, e estão certas.) |
| 🟡4 ⚙️ da T4 sem criança: "Nomes salvos" sem salvar | ✅ registrado | HISTORICO, capítulo 11 (linha 777), e relatório da v123, parte 7. |
| 🟡5 C2: cópias antigas deixavam a bolinha 🟡; não dá para descartar uma cópia | ✅ corrigido; "descartar" registrado | Agora a condição é `soAqui===true`. Meu `mig122b_r2.py` passou 9/9: a v122b tira o Caio com cópia (sem a marca); depois de abrir a v123, as chaves continuam iguais byte a byte e a bolinha fica **🟢**. Tirar a Bia com cópia **na v123** grava `soAqui:true` e a bolinha fica **🟡**. Depois a volta à v121 dá certo. O `teste_v123` agora testa a cópia sem a marca. |
| 🟡6 Em pé, "← VOLTAR" quebrava em 2 linhas | ✅ corrigido; sobra 🟡 | `.ef-topo .ef-voltar{white-space:nowrap}`. Captura 360×740 aberta pelo chip: "← VOLTAR" numa linha. As 42 combinações do meu `telas.py` passaram sem nenhum problema. **Sobra:** o título "QUEM VAI ESTUDAR HOJE?" agora quebra em 4 linhas e os cartões começam em y≈97 (na v122b, y≈78). Só em pé, com o "← VOLTAR"; não fica nada por cima de nada. |
| 🟡7 Instruções de publicar, parte 3, passo 3 | ✅ corrigido | Agora diz: Monta a Frase, Sílaba Perdida ou Treinar → "👋 Bem-vindo de volta!" com "▶ Continuar"; Ler → menu. Bate com o `passoDoApp`. |
| 🟡8 Qual `nuvem-sync.js` anexar | ✅ corrigido | `PROMPT_HANDOFF_APPS.md`, "Como usar", item 2: "os que AQUELE app usa hoje… não as cópias novas do Alfabetização". O bloco de colar não mudou e continua igual ao `_COLAR`. |
| 🟡9 "poucas centenas" | ✅ corrigido | O comentário do `index.html` e o título do teste agora dizem "≈ 2,6 mil". |
| (já existia) "Instalar o app" some na aba | ✅ registrado | HISTORICO, capítulo 11. |

## Problemas NOVOS
Nenhum 🔴 ou 🟠. Só as 2 sobras 🟡 da tabela (`#codOv` no capítulo 7, regra 7; título em 4 linhas em pé).

**Observação:** o `sw.js` continua com `esforco-vence-v123`. Está certo, porque nenhum zip da v123 chegou ao Pedro ainda. Se algum zip da rodada 1 já tiver sido publicado em algum lugar (por exemplo, no site de teste), o cache precisa subir.

## O que RODEI × o que só LI
**Rodei (no zip final, uma suíte por vez, portas 8981–8984 e 8960–8994):**
- node 89/89;
- v123 41/41;
- desenho 127/127;
- família 130/130;
- revisão 59/59;
- cadastro 72/72;
- nuvem 81/81;
- pwa 34/34;
- meu `mig122b_r2.py` 9/9;
- meu `telas_r2.py` (42 combinações, 0 problemas, capturas olhadas);
- md5 de todo o `LEIA-ME.txt` e do `LEIA-ME_COMPARTILHADOS.md`;
- `cmp`/`diff` contra a rodada 1 e a v122b.

**Não rodei de novo:**
- `teste_fonte.py`: o `index.html` mudou só num comentário;
- meu `meu_c1.py`: o `nuvem-sync.js` e o `nuvemMesclar` não mudaram desde a rodada 1, quando ele passou 13/13.

**Só li:** os diffs dos documentos, o `RELATORIO_CHECAGEM_alfabetizacao_v123.md` e o capítulo 11.

## O que só o celular confirma
O mesmo da rodada 1:
- a tela cheia sem a borda azul dos botões do Android;
- o tempo da tela preta ao abrir;
- o botão voltar físico;
- a migração com os dados de verdade dos 2 celulares;
- os 2 celulares com o Firebase real.

✅ Pode publicar
