# Relatório do Revisor A (Dados e nuvem): rodada 1

**App:** 📚 Alfabetização (Esforço Vence), v121 (publicada) → v122 (nova)
**Arquivos compartilhados revisados:** `escola-familia.js` v1 e `nuvem-sync.js` v4, pensando também nos outros 6 apps
**Data:** 07/10/2026

Não li nenhum `documentos/RELATORIO_*`. Não confiei em nada do que o autor escreveu: só nos arquivos e no que eu rodei.

---

## Resumo em 1 minuto

- **Não achei nenhum caminho que apague histórico de vez** (nenhum 🔴). Passaram todos os casos que testei de verdade:
  - tirar criança com fila;
  - lixeira byte a byte;
  - migração a partir de um celular que usou a v121 de verdade;
  - ida e volta v122 → v121 → v122 com fila;
  - 2 celulares, um na v121 (nuvem v3) e outro na v122 (nuvem v4), gravando a mesma ficha;
  - recadastrar sem internet e com rede lenta;
  - "trazer todas" com falha no meio;
  - 2 famílias;
  - backup que junta;
  - nada apagado na nuvem e Firebase sem mudança.
- **Achei 4 problemas 🟠.** Três deles separam a criança em duas ou deixam progresso "escondido" num lugar onde ninguém vê. O quarto é uma fragilidade do `nuvem-sync.js` v4, que vai para os 7 apps.
- **Achei 11 problemas 🟡.**
- **Veredito:** ❌ não pode publicar enquanto houver 🟠 em aberto (regra da parte 9-A).

---

## Achados

### 🟠 A1. Depois de mudar o bichinho, a "criança antiga" aparece como outra criança ☁️ em "Quem vai estudar hoje?", e tocar nela cria uma segunda criança

- **Onde:**
  - `escola-familia.js`, `fichasVisiveis()` (linha 744);
  - o desenho dos cartões ☁️ na T4 (linhas 1185–1192).
- **O que acontece:** a ficha antiga só some quando os apps da ficha nova cobrem todos os apps da antiga. Mas as meninas já usam outros apps com nuvem (Curiosidades, Historinhas…), então a ficha antiga da Hana 🦊 tem `apps/curiosidades` e a nova (🐰) ainda não tem. Por isso, na T4 do Alfabetização aparece **"🦊 HANA ☁️ TOQUE PARA TRAZER"** ao lado da 🐰 HANA. Se a criança toca, o app cria uma **segunda Hana** (🦊) no celular. Ela passa a gravar na ficha antiga, e o histórico fica dividido em duas crianças.
  - O aviso "MUDOU PARA… MUDAR AQUI TAMBÉM?" não aparece para essa segunda Hana, porque a 🐰 já está no celular.
- **Como reproduzir (RODADO):** `meus_testes/t6_mudar_varios_apps.py`.
  1. Na nuvem, a Hana 🦊 tem também `apps/curiosidades`.
  2. No Alfabetização, ✏️ Mudar para 🐰.
  3. Abra o app de novo: a T4 mostra o cartão ☁️ `hana_1f98a`.
  4. Toque nele: o celular fica com duas crianças, `[('Hana','🐰'), ('Hana','🦊')]`.
- **O que deveria acontecer:** a parte 4 (T4) diz: "Cartões de fichas antigas que mudaram de nome **não aparecem**". A parte 5.3, item 6, diz que a ficha antiga "só some da lista quando os apps da nova cobrem todos os da antiga". Isso pode valer para a lista do adulto (T6), mas não para a T4 da criança.
- **Sugestão:**
  - Na T4, esconder sempre a ficha com `movidoPara` cujo fim da cadeia é uma criança deste celular, sem olhar os apps.
  - Deixar a regra dos apps só para a T6 ("📦 Nomes antigos", com "juntar").
  - Ao trazer uma ficha com `movidoPara`, trazer o fim da cadeia (e juntar a antiga nele, como o `juntarAntigas` já faz), nunca criar a antiga como criança separada.

### 🟠 A2. Progresso que só está na lixeira do celular fica "esquecido" quando a criança volta pela nuvem

- **Onde:**
  - `escola-familia.js`, `trazer()` (linha 769);
  - `criarNova()` (linha 1366);
  - `trazerDaLixeira()` (linha 874).
- **O que acontece:**
  1. Sem internet, a Bia lê 3 frases novas e é tirada com "GUARDAR UMA CÓPIA NESTE CELULAR E TIRAR". As 3 frases ficam **só** na lixeira.
  2. Depois, com internet, ela volta pelo caminho natural da criança: o cartão ☁️ na T4 ou cadastrando de novo o mesmo nome e bichinho na T5.
  3. O app traz só o que está na nuvem. Ela volta com **2 frases em vez de 5**.
  4. A cópia continua parada na lixeira, nunca sobe para a nuvem e não há aviso nenhum.
  - Só o adulto, se lembrar de ir em ☁️ Buscar na nuvem › 🗑️ Tiradas deste celular, recupera as 3 frases. Elas não estão perdidas, mas estão num só lugar (este celular) e invisíveis. Se o celular for limpo ou trocado, somem. Fica no limite do 🔴.
- **Como reproduzir (RODADO):** `meus_testes/t5_lixeira_e_nuvem.py`. Resultado nos dois caminhos: `celular=2, lixeira ainda com 1 item, nuvem=2` (esperado: 5).
- **O que deveria acontecer:** regra de ouro 1 ("nenhum histórico se perde") e parte 4 (T7): a lixeira é para a criança "voltar". Quando a mesma criança (mesma família + nome + bichinho) volta por qualquer caminho, o que está na lixeira deveria ser juntado sozinho.
- **Sugestão:** em `trazer()`, no `criarNova()` e no "Sou eu!" da T5, procurar na lixeira um item com a mesma `fam` + `chaveDe(nome, av)`. Se achar, fazer `A.importar(id, item.dados)` (junta), `marcarPendente(id)` e só então tirar o item da lixeira.

### 🟠 A3. "☁️ Buscar na nuvem" esconde de vez a ficha antiga; com "AGORA NÃO" em outro celular, o progresso novo fica inalcançável

- **Onde:**
  - `escola-familia.js`, `renderT6()` (linha 1420): se os apps estão cobertos, a ficha antiga não vai nem para "📦 Nomes antigos";
  - linha 1239: o "AGORA NÃO" do aviso de mudança vale para sempre (`st.recusas`).
- **O que acontece:**
  1. O celular 1 muda 🦊 Hana → 🐰.
  2. O celular 2 (ainda na v121, ou na v122 tocando "AGORA NÃO") continua gravando na ficha 🦊.
  3. No celular 1, a ficha 🦊 **não aparece em lugar nenhum da T6** (medido: `aparece=0`). O progresso que o celular 2 fez depois da mudança fica guardado na nuvem, mas o celular 1 não tem como ver nem juntar.
  4. Se o celular 2 tocou "AGORA NÃO", o aviso nunca mais volta.
- **Como reproduzir (RODADO):** `meus_testes/t1_compat_v3_v4.py`, parte 3. A ficha antiga recebe a 5ª frase do celular v121, e a T6 do celular v122 não mostra a ficha antiga. Quando o celular 2 passa para a v122 e toca "MUDAR", tudo se junta: o caminho existe, mas depende do "MUDAR".
- **O que deveria acontecer:** parte 4 (T6): "Fichas antigas de quem mudou de nome aparecem só num cantinho '📦 Nomes antigos', para o adulto juntar se quiser".
- **Sugestão:**
  - Na T6, mostrar sempre em "📦 Nomes antigos" as fichas com `movidoPara`, com o botão de juntar no fim da cadeia.
  - Fazer o "AGORA NÃO" valer por um tempo (ex.: 7 dias) ou deixar refazer pela T6.

### 🟠 A4. `nuvem-sync.js` v4: se a lista de crianças do app der erro, a fila é jogada fora em silêncio e a bolinha fica 🟢

- **Onde:**
  - `nuvem-sync.js` v4, linha 102: `usuarios()` engole o erro e devolve `[]`;
  - linha 309: `if(!u){ tira(); return; }` tira da fila quem não está na lista.
- **O que acontece:** se o `usuarios()` do app lançar um erro por um instante, a v4 trata **todas** as crianças como "tiradas" e apaga a fila delas. Depois disso:
  - a bolinha mostra 🟢 "TUDO GUARDADO";
  - o que estava na fila não sobe até a criança gravar outra coisa, porque o `checarNuvem` acha a ficha "conhecida".
  - Na v3, o erro escapava, a fila ficava e o envio tentava de novo.
  - Neste app, o `listar()` é simples e não deve dar erro. Mas o arquivo vai para os outros 6 apps sem mudar, e a parte 5.3, item 8, diz que "a fila de quem foi tirado não é descartada em silêncio".
- **Como reproduzir (RODADO):** `meus_testes/t7_usuarios_erro.py`.
  1. Leia 1 frase sem internet.
  2. Faça a lista do app falhar uma vez e sincronize.
  3. Resultado na v122: fila `[]`, nuvem com 1 frase e celular com 2.
  4. Na v121: fila `['1']` e, depois, nuvem com 2.
- **Sugestão:**
  - Se `S.opt.usuarios()` der erro, cancelar a sincronização (estado "erro") e **manter a fila**.
  - Só tirar da fila um id ausente se a lista veio sem erro. O `escola-familia.js` já chama `limparPendencia()` quando tira uma criança, então a v4 nem precisa desse `tira()` silencioso para quem saiu pelo módulo.

### 🟡 Pontos leves (podem ficar para depois, com o OK do Pedro)

1. **Backup antigo com bichinho antigo cria uma segunda criança.** No `index.html`, linha 5746, o `aplicarBackup` procura só pelo nome + bichinho. Um backup da "Hana 👧" num celular onde ela já é 🦊 cria outra "Hana 👧" em vez de juntar. Nada se perde, mas fica duplicado.
   - RODADO em `t3_bordas.py` c): resultado `[('Hana','🦊'), ('Hana','👧')]`.
   - Sugestão: quando o nome bate e o bichinho é antigo, perguntar "É a mesma criança?".
2. **O backup procura a criança em todas as famílias.** Ele não olha a família, então com 2 famílias pode juntar na criança de mesmo nome + bichinho da outra família. (Só LIDO, linha 5746.)
3. **`migrar()` apaga a ligação criança→família de quem não aparece na lista.** É o `escola-familia.js`, linha 274, junto com o `lista()` da linha 239, que devolve `[]` se der erro.
   - Se em outro app o `listar()` falhar, ou rodar antes de a lista carregar, as crianças da 2ª família perdem a ligação. Na abertura seguinte, elas ganham a família atual e passam a subir para a pasta errada (mistura de famílias).
   - Sugestão para os 7 apps: não apagar ligações, ou não fazer nada se a lista vier vazia por erro. (LIDO.)
4. **O `chavesDaCrianca()` do adaptador nunca é usado pelo módulo.** A lixeira usa só o `exportar()`. No Curiosidades, `ultimoDia`/`seqDias`/`sayTap` têm que estar no `exportar` (veja a ficha da parte 7). Sugestão: a cópia da lixeira juntar `exportar(id)` com as chaves de `chavesDaCrianca(id)`. (LIDO.)
5. **"Guardar e conferir depois" (T2 sem internet) já grava o código não conferido em `nuvem_familia`.** Isso acontece no `salvar()`, linhas 222–229. A v122 não sobe nada para lá (correto). Mas, se o Pedro voltar ao v121 antes de conferir, o v121 sobe tudo para o código possivelmente errado. (RODADO em `t3_bordas.py` e): `subiu=True`.) Sugestão: só atualizar `nuvem_familia` com família `conferida`.
6. **2 famílias + volta ao v121 mistura as famílias.** Isso já é esperado no plano, com o aviso e a trava de 2 semanas. Ao voltar à v122, a Bia aparece duplicada como ☁️ na outra família. (RODADO em `t3_bordas.py` d).)
7. **A lista da nuvem fica guardada por 60 segundos** (`listaNuvem`, linha 727). Quem acabou de subir ou de sair não aparece como ☁️ na T4 até tocar 🔄. (RODADO: precisei do 🔄 no `t5`.)
8. **`marcarMovido` zera o `movidoPara` da ficha nova** (`nuvem-sync.js`, linha 538). Se outro app já tinha mudado a nova para uma terceira ficha (B→C), a cadeia se quebra. Não perde dados. (LIDO.)
9. **Mudar para um nome + bichinho que já existe na nuvem como outra criança junta os históricos das duas.** A T5 em modo "mudar" (linha 1339) só confere o celular. Isso já existia na v121. (LIDO.)
10. **`tirarFamilia` segue em frente mesmo se `A.tirar()` der erro** (linhas 1576–1583): tira a ligação e a fila mesmo assim. Neste app o `tirar` não dá erro. (LIDO.)
11. **`teste_fonte.py`: 1 falha** ("Ler 412x915 tamanho 24: 86% < 90%"). A **mesma falha aparece na v121** nesta máquina, então é do ambiente (fontes), não da v122. É assunto do Revisor B.

---

## O que eu RODEI de verdade

**Conferência dos arquivos (md5):**
- `nuvem-config.js` é idêntico ao da v121, byte a byte.
- `escola-pwa.js` é idêntico.
- `compartilhados/escola-familia.js` e `compartilhados/nuvem-sync.js` são idênticos aos do `pacote-netlify` e do zip do Netlify, que tem os 9 arquivos certos.
- `sw.js` tem `esforco-vence-v122` e o `escola-familia.js` na lista.
- O `nuvem-sync.js` v3 dos documentos do projeto é o mesmo da v121.

**Checagem de sintaxe:** `node --check` em todos os `.js` e nos 2 scripts do `index.html`: tudo OK.

**Testes que vieram nos zips:**

| Teste | v122 | v121 |
|---|---|---|
| `node testes/rodar_testes.js` | **89/89** | 89/89 (só o teste do backup mudou de propósito: agora junta) |
| `teste_cadastro.py` | **72/72** | — |
| `teste_nuvem.py` | **81/81** | — |
| `teste_pwa.py` | **34/34** | — |
| `teste_familia.py` | **127/127** | — |
| `teste_fonte.py` | **57/58** | mesma falha, 57/58 |

Os testes de navegador rodaram com `PORTA=8801` a `8807`.

**Meus testes** (Chromium sem tela, Firebase de mentira `fakefb.py`, nunca o Firebase real), em `/home/claude/revA/meus_testes/`:

| Script | O que prova | Resultado |
|---|---|---|
| `t1_compat_v3_v4.py` | 2 celulares (v121 com nuvem v3 e v122 com nuvem v4) na mesma ficha: união das frases e das favoritas; formato do documento igual; v122 sem internet com fila → volta à v121 (sobe a fila) → volta à v122 (nada perdido); mudar bichinho com o outro celular na v121 | 21/21 (+ a informação do A3) |
| `t2_tirar.py` | tirar a Hana "1" (sem prefixo) com outra criança aberta, e ela volta byte a byte; lixeira byte a byte das 33 chaves; gravação no meio da garantia não deixa tirar; tirar a criança aberta não regrava chaves dela nem cria "Hana fantasma"; tirar com a nuvem mais adiantada guarda a união; tirar família (sem internet recusa, com internet tira, e o `nuvem_familia` passa para a família que ficou) | 23/24 (a 1 falha era do meu teste: o app grava o dia/hoje da criança aberta, o que é normal) |
| `t3_bordas.py` | "trazer todas" com falha no meio (não cria criança vazia); recadastro com rede lenta (> 6 s), sem sobrescrever a nuvem; backup 👧; 2 famílias + v121; T2 sem internet + v121 | 10/10 (+ informações dos 🟡 1, 5 e 6) |
| `t4_migracao_real.py` | celular que **usou a v121 pela tela** (2 crianças, leituras, fila sem internet) → v122: chaves antigas byte a byte iguais, fila da v3 preservada e enviada, nuvem igual; v121 → v122 de novo sem perder nada | 10/10 |
| `t5_lixeira_e_nuvem.py` | prova do A2 | falha de propósito (o problema) |
| `t6_mudar_varios_apps.py` | prova do A1 | falha de propósito (o problema) |
| `t7_usuarios_erro.py` | prova do A4 (v122 × v121) | mostra a diferença |

## O que eu só LI (não rodei)

- Os pontos 🟡 2, 3, 4, 8, 9 e 10.
- A volta ao v121 **depois** das 2 semanas com todas as crianças tiradas: a "Hana 👧 fantasma" do v121 voltaria. O plano aceita esse risco com a trava de 2 semanas. Conferi no código que a trava existe (`pedirTirar`, linha 821) e o teste do autor prova que ela segura.
- O comportamento do Firestore de verdade com `currentDocument.exists=true` em ficha que não existe (o código trata 404 como "nada a marcar") e a listagem `familias/{c}/usuarios`, que já era usada pela v3. As regras do guia permitem tudo isso (`read`/`create`/`update`) e nenhum `DELETE` é feito.
- O `sw.js` (lista de arquivos, cache primeiro), lido.

## O que só um celular de verdade pode confirmar

- Dois celulares reais na família `teste-pedro-2026`: a união das frases e o aviso "MUDOU PARA…" (o roteiro do autor cobre isso).
- O Android de verdade em modo avião: o `navigator.onLine` real e a fila sobrevivendo a fechar e abrir o app.
- A troca de versão pelo service worker no celular (v121 → v122) sem abrir uma página "meio velha, meio nova".
- O Firestore real respondendo ao `movidoPara` (`PATCH` com `updateMask` e `currentDocument.exists=true`).
- **Pedro, confira no site de teste:** mude o bichinho de uma criança de teste que **também esteja em outro app** (ex.: Curiosidades) e veja se a T4 do Alfabetização mostra a criança antiga como ☁️ (achado A1).

---

❌ Não pode publicar: 4 problemas 🟠 em aberto (A1: a ficha antiga vira uma 2ª criança na T4; A2: progresso da lixeira esquecido quando a criança volta pela nuvem; A3: a T6 esconde de vez a ficha antiga, diferente do plano; A4: o `nuvem-sync.js` v4 joga a fila fora em silêncio se a lista der erro). Nenhum 🔴 encontrado.
