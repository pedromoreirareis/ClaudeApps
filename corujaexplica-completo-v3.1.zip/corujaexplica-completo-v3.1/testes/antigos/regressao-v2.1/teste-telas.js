/* Camada 3 da checagem: o mesmo app em vários tamanhos de celular e tablet,
   procurando texto vazando para os lados, botões cortados ou sobrepostos. */
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const ROOT = process.env.CORUJA_ROOT || '/home/claude/build', PORT = Number(process.env.CORUJA_PORT || 8957);
const OUT = '/tmp/claude-0/-home-claude/88b40acf-8683-5d3e-a36b-dad4b20661ee/scratchpad';
const MIME = { '.html':'text/html','.js':'application/javascript','.png':'image/png','.webmanifest':'application/manifest+json' };
const server = http.createServer((q,s)=>{
  let p=q.url.split('?')[0]; if(p==='/')p='/index.html';
  fs.readFile(path.join(ROOT,p),(e,d)=>{ if(e){s.writeHead(404);s.end();return;}
    s.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'application/octet-stream'}); s.end(d); });
}).listen(PORT);

const TELAS = [
  { nome: 'celular pequeno',  w: 360, h: 640 },
  { nome: 'celular comum',    w: 412, h: 915 },
  { nome: 'celular grande',   w: 430, h: 932 },
  { nome: 'tablet retrato',   w: 768, h: 1024 },
  { nome: 'celular deitado',  w: 915, h: 412 },
  { nome: 'tablet deitado',   w: 1024, h: 768 }
];

const TXT = `TÍTULO: ☀️ Você já imaginou uma viagem até o Sol?
TAGS: sol, espaço, estrela, astronomia, céu

TEXTO:
Você já sentiu o calor do Sol no rosto durante uma brincadeira? Ele é uma estrela enorme, e a luz dele atravessa a atmosfera antes de chegar até você.

— Pai, será que eu poderia chegar perto do Sol?

— Não seria possível, porque o Sol é quente demais.

PALAVRAS NOVAS:
atmosfera = é a camada de ar que fica em volta de um planeta inteiro, como um cobertor bem fininho e invisível que ninguém consegue tirar do lugar.

PERGUNTAS:
1) Por que a Lua parece brilhar?
a) Porque tem fogo dentro dela.
b) Porque devolve a luz que vem do Sol. *
c) Porque tem lâmpadas escondidas.
> A Lua não faz luz própria: ela devolve para nós a luz que vem do Sol, como um espelho meio fosco faria.

2) O que a atmosfera faz pela gente?
a) Segura o ar que a gente respira. *
b) Faz o Sol girar mais devagar.
c) Deixa a Lua mais quente.
> A atmosfera é o cobertor de ar do planeta, e é ele que mantém o ar por perto da gente.

PARA PENSAR:
O que você acha mais incrível no céu?`;

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const problemas = [];
  let checks = 0;

  for (const tela of TELAS) {
    const ctx = await browser.newContext({ viewport: { width: tela.w, height: tela.h } });
    const page = await ctx.newPage();
    const errosPagina = [];
    page.on('pageerror', e => errosPagina.push(e.message));
    await page.goto(`http://localhost:${PORT}/index.html`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(250);

    async function semVazamento(onde) {
      checks++;
      const v = await page.evaluate(() => ({
        scroll: document.documentElement.scrollWidth,
        cliente: document.documentElement.clientWidth
      }));
      if (v.scroll > v.cliente + 1) problemas.push(`${tela.nome}: vazamento horizontal em ${onde} (${v.scroll} > ${v.cliente})`);
    }
    async function visivel(sel, onde) {
      checks++;
      const vis = await page.isVisible(sel).catch(() => false);
      if (!vis) problemas.push(`${tela.nome}: ${sel} não está visível em ${onde}`);
    }

    await semVazamento('tela inicial');
    await visivel('.btnInicioPreparar', 'tela inicial');
    await visivel('.btnInicioLer', 'tela inicial');

    await page.click('text=PREPARAR TEXTO');
    await page.waitForTimeout(200);
    await semVazamento('preparar texto');
    await visivel('#btnSalvar', 'preparar texto');
    await visivel('.btnPromptMais', 'preparar texto');

    await page.evaluate((t) => {
      const c = document.getElementById('caixaTexto');
      c.value = t;
      const dt = new DataTransfer(); dt.setData('text/plain', t);
      c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true }));
      c.dispatchEvent(new Event('input', { bubbles: true }));
    }, TXT);
    await page.waitForTimeout(400);
    await semVazamento('texto colado');

    // o título detectado não pode quebrar a linha nem empurrar o lápis pra fora
    checks++;
    const lapisOk = await page.evaluate(() => {
      const l = document.querySelector('.btnEditarTitulo').getBoundingClientRect();
      return l.right <= innerWidth + 1 && l.width > 10;
    });
    if (!lapisOk) problemas.push(`${tela.nome}: o lápis do título saiu da tela`);

    await page.click('#btnSalvar');
    await page.waitForTimeout(350);
    await semVazamento('biblioteca');

    checks++;
    const buscaOk = await page.evaluate(() => {
      const l = document.getElementById('linhaBusca');
      if (!l || l.style.display === 'none') return false;
      const r = l.getBoundingClientRect();
      return r.left >= -1 && r.right <= innerWidth + 1 && r.height > 24;
    });
    if (!buscaOk) problemas.push(`${tela.nome}: a caixa de busca não aparece direito`);

    checks++;
    const cardDentro = await page.evaluate(() => {
      const c = document.querySelector('.cardTexto');
      if (!c) return false;
      const r = c.getBoundingClientRect();
      return r.left >= -1 && r.right <= innerWidth + 1;
    });
    if (!cardDentro) problemas.push(`${tela.nome}: card da biblioteca fora da tela`);

    await page.click('.cardTexto .cardLer');
    await page.waitForTimeout(450);
    await semVazamento('leitura');

    // os botões do cabeçalho da leitura precisam caber
    checks++;
    const cabecalho = await page.evaluate(() => {
      const card = document.getElementById('detCard').getBoundingClientRect();
      const botoes = Array.from(document.querySelectorAll('#detCard .detH button'));
      const fora = botoes.filter(b => {
        const r = b.getBoundingClientRect();
        return r.width < 5 || r.height < 5;
      });
      return { qtd: botoes.length, fora: fora.length, largura: Math.round(card.width) };
    });
    if (cabecalho.fora > 0) problemas.push(`${tela.nome}: ${cabecalho.fora} de ${cabecalho.qtd} botões da leitura estão colapsados`);

    // dicionário
    const abriu = await page.evaluate(() => {
      const g = document.querySelector('#detTexto .gloss');
      if (!g) return false; g.click(); return true;
    });
    if (abriu) {
      await page.waitForTimeout(300);
      checks++;
      const dic = await page.evaluate(() => {
        const card = document.querySelector('#glossOv .pcard');
        const btn = document.querySelector('#glossOv .ok').getBoundingClientRect();
        const r = card.getBoundingClientRect();
        return {
          rolando: card.scrollHeight > card.clientHeight + 2,
          botaoVisivel: btn.bottom <= innerHeight + 1 && btn.height > 10,
          dentro: r.left >= -1 && r.right <= innerWidth + 1
        };
      });
      if (dic.rolando) problemas.push(`${tela.nome}: a definição do dicionário precisa rolar`);
      if (!dic.botaoVisivel) problemas.push(`${tela.nome}: o botão "Entendi" do dicionário está fora da tela`);
      if (!dic.dentro) problemas.push(`${tela.nome}: o popup do dicionário vaza para os lados`);
      await page.click('#glossOv .ok');
      await page.waitForTimeout(200);
    }

    // quiz: precisa caber e ter todos os botões utilizáveis
    const temQuiz = await page.evaluate(() => {
      const b = document.querySelector('.conviteQuizBtn');
      if (!b) return false; b.click(); return true;
    });
    if (temQuiz){
      await page.waitForTimeout(350);
      checks++;
      const q = await page.evaluate(() => {
        const card = document.querySelector('#quizOv .pcard');
        const r = card.getBoundingClientRect();
        const ops = Array.from(document.querySelectorAll('.quizOpcao'));
        return {
          rolando: card.scrollHeight > card.clientHeight + 2,
          dentro: r.left >= -1 && r.right <= innerWidth + 1 && r.top >= -1 && r.bottom <= innerHeight + 1,
          opcoesOk: ops.length === 3 && ops.every(o => { const b = o.getBoundingClientRect(); return b.height > 20 && b.width > 40; })
        };
      });
      if (q.rolando) problemas.push(`${tela.nome}: o quiz precisa rolar para ler a pergunta`);
      if (!q.dentro) problemas.push(`${tela.nome}: o quiz vaza para fora da tela`);
      if (!q.opcoesOk) problemas.push(`${tela.nome}: as alternativas do quiz ficaram pequenas demais`);

      // responde e confere se a explicação cabe
      await page.evaluate(() => document.querySelectorAll('.quizOpcao')[0].click());
      await page.waitForTimeout(250);
      checks++;
      const resp = await page.evaluate(() => {
        const card = document.querySelector('#quizOv .pcard');
        const btn = document.getElementById('quizProxima').getBoundingClientRect();
        return { rolando: card.scrollHeight > card.clientHeight + 2, botaoVisivel: btn.bottom <= innerHeight + 1 && btn.height > 10 };
      });
      if (resp.rolando) problemas.push(`${tela.nome}: a explicação do quiz não cabe sem rolar`);
      if (!resp.botaoVisivel) problemas.push(`${tela.nome}: o botão "Próxima pergunta" fica fora da tela`);
      await page.screenshot({ path: `${OUT}/telas-quiz-${tela.w}x${tela.h}.png` });
      await page.evaluate(() => fecharQuiz());
      await page.waitForTimeout(200);
    }

    await page.screenshot({ path: `${OUT}/telas-${tela.w}x${tela.h}.png` });
    if (errosPagina.length) problemas.push(`${tela.nome}: erros de JavaScript — ${errosPagina.join(' | ')}`);
    console.log(`  ✓ ${tela.nome} (${tela.w}x${tela.h}) verificado`);
    await ctx.close();
  }

  await browser.close();
  server.close();

  console.log(`\n${checks} verificações em ${TELAS.length} tamanhos de tela`);
  if (!problemas.length) { console.log('✅ Nenhum problema de layout encontrado'); process.exit(0); }
  problemas.forEach(p => console.log('❌', p));
  process.exit(1);
})();
