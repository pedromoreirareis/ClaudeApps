# Relatório do Revisor B: Telas, crianças e celular (rodada 2)

**App:** 📚 Esforço Vence (Alfabetização) · **v122 corrigida (rodada 2)**, comparada com a v121 (publicada) e com a v122 da rodada 1
**Data:** 07/10/2026 · **Revisor:** B (independente; não abri `documentos/RELATORIO_*`)

Pastas deste revisor:
- pacote da rodada 2 descompactado: `/home/claude/revB/novo_r2/` (o zip do Netlify em `netlify_r2/`);
- capturas novas: `/home/claude/revB/capturas_r2/`;
- registros: `/home/claude/revB/r2/`;
- scripts: `/home/claude/revB/scripts/` (os mesmos da rodada 1, apontados para a pasta nova, mais `b2c_repete20.py`, `b7r2_fluxos.py`, `b12r2_siteteste.py` e `b13_meio.py`).

---

## Resumo em 1 minuto

**Os 3 achados que bloqueavam (B1 🔴, B2 🟠 e B3 🟠) foram corrigidos de verdade.** Rodei de novo os meus testes e olhei as capturas novas.
- **B1:** o campo não muda mais de lugar, não perde o foco e não some com o teclado.
- **B2:** a pílula "☀️ 0/10 · 🌱 Nível 1 de 52" aparece inteira de 640 a 915 px de largura.
- **B3:** o ✏️ 🗑️ fica embaixo do nome e cobre 0% do bichinho.

Dos 🟡, quase todos foram resolvidos. Mas **o conserto do B2 criou um problema novo 🟠 (N1)**: para caber o chip, a barra de cima agora **encolhe os botões das crianças para 42 px** em celulares de 640 a 700 px de largura (deitado) e para **36 px** em 568x320 e em pé. Na v121 eles tinham 52 px; o plano pede pelo menos 48 px.

Achei também 4 problemas novos 🟡.

---

## Os achados da rodada 1, um por um

| # | Gravidade antes | Situação | Prova (o que rodei) |
|---|---|---|---|
| **B1** Campo do código perde o foco e às vezes some com o teclado | 🔴 | ✅ **Corrigido** | `b2_foco.py`: nos mesmos 24 casos (T2, T3 e T5; 740→170, 640→150, 568→140, 915→170, 800→170, 780→180 e o teclado abrindo aos poucos) houve **0** `focusout`. Na rodada 1 eram 24 de 24. `b2c_repete20.py`: **100 de 100** repetições com o foco no campo (na rodada 1, até 1 em 5 falhava). `b3_sumico.py`: com a tela baixa e o campo sem foco, o campo continua com 272×48 px (antes 0×0). `b1_telas.py`: campo, botão, ✕/← e os 8 bichinhos visíveis em todos os 18 casos de teclado. Capturas `kb_t2_k568x140.png`, `kb_t5_k740x170.png` e `kb_t2_kp320x300.png`. No código, o `posicionar()` e o `MutationObserver` saíram; o campo fica numa linha só e os botões pequenos aparecem por CSS. |
| **B2** Barra de cima esconde a pílula "☀️ 0/10 · 🌱 Nível…" | 🟠 | ✅ **Corrigido** (mas veja o N1) | `b6_meta.py` em 14 larguras, de 640 a 915: **nenhuma sobreposição** (antes havia de 640 a 760). Captura `PAG_ler_d740x360.png`. Em 568x320 a pílula ainda fica um pouco por baixo do 🏠, como já era na v121 (captura `PAG_ler_d568x320.png`): não é piora. |
| **B3** No "Arrumar", o ✏️🗑️ cobre o bichinho | 🟠 | ✅ **Corrigido** | `b8_dobras.py`: cobre **0%** do bichinho em 740, 640, 568 e 915 (antes de 87% a 100%). Capturas `T7_d740x360.png` e `T7_p360x740.png`: bichinho, nome e, embaixo, ✏️ e 🗑️ (o 🗑️ com fundo rosado). |
| B4 Botões da barra com 42 px em 568x320 | 🟡 | ❌ **Piorou: virou o N1 🟠** | veja o N1 abaixo |
| B5 Em pé com 320 px, a ⚙️ saía da tela | 🟡 | ✅ **A ⚙️ voltou para dentro** | `b4_t4.py`: na largura 320, a ⚙️ termina em 280–290 px. Só o ⛶ continua saindo, como na v121. |
| B6 T4 com 4 cartões ou mais: bolinha e botões abaixo da tela | 🟡 | ✅ **Corrigido** | `b8_dobras.py`: com 2, 4 e 6 crianças, em 740, 640, 568 e 915, a bolinha, "BUSCAR" e "ARRUMAR" ficam **sempre inteiros** na tela. Só o meio rola. (Efeito colateral em tela pequena: veja o N2.) |
| B7 "Achei a sua família": "Trazer todas" fora do pop-up | 🟡 | ✅ **Corrigido** | `b8_dobras.py`: "TRAZER TODAS" inteiro com 2, 4 e 6 crianças em todos os tamanhos, inclusive 568x320. |
| B8 T4 sem ⚙️ | 🟡 | ⬜ **Mantido de propósito** pelo autor | continua como 🟡 (depende do OK do Pedro) |
| B9 T4 sem criança mostrava "Atualizar agora" | 🟡 | ✅ **Corrigido** | `b7r2_fluxos.py`: só "➕ NOVA CRIANÇA" e "☁️ BUSCAR NA NUVEM". |
| B10 Escolher a mesma criança pelo chip dentro do Monta mostrava "Bem-vindo de volta" | 🟡 | ✅ **Corrigido** | `b7r2_fluxos.py`: agora só fecha a tela. Na **abertura** do app, escolher a criança continua mostrando "▶ Continuar de onde parei", como deve (testado). |
| B11 Código em minúsculas na T8 | 🟡 | ⬜ **Mantido de propósito** pelo autor | continua como 🟡 |
| B12 Voltar não saía do "Arrumar" | 🟡 | ✅ **Corrigido** | `b7r2_fluxos.py`: na T4 de abertura e na T4 aberta pelo chip, o 1º voltar sai do Arrumar e a T4 fica. Na abertura, o 2º voltar continua na T4 (precisa escolher uma criança); pelo chip, o 2º voltar fecha a T4. |
| B13 Faixa do site de teste cobria o campo com o teclado | 🟡 | ✅ **Corrigido** | `b12r2_siteteste.py` (endereço `…-teste.netlify.app` simulado): com o teclado, a faixa some e não cobre nada na T2 nem na T5. |
| B14 Chip padrão com 46 px; textos fora do `TEXTOS` | 🟡 | ⚠️ **Metade**: o chip agora tem 48 px ✅; ainda há textos fora do `TEXTOS`: `sim:'JUNTAR'` (linha 1511) e "Tela cheia" (linha 1165) ❌ | lido no código |
| B15 `teste_fonte.py` 57/58 (a mesma falha da v121) | 🟡 | ⬜ **Igual** (falha antiga, não desta mudança) | rodado: 57/58 |

---

## Problemas NOVOS criados pelas correções

### 🟠 N1. A barra de cima agora encolhe os botões das crianças para 42 px e 36 px (abaixo de 48 px)

- **Onde:** `index.html`
  - linhas 84–90: `efBarraApertada` = 42 px, e o novo `efBarraMinima` = **36 px**;
  - `ajustarBarraDeCima()`, por volta da linha 5900: os 3 níveis de compactação.
- **O que acontece:** a nova conferência da pílula (que resolveu o B2) liga a compactação mais cedo. Medi os botões 🏠 📅 🗺️ ⚙️ ⛶ nas 4 telas principais (Ler, Monta a Frase, Sílaba Perdida, Treinar Sílabas) com `b4_t4.py` e `b6_meta.py` (log `r2/log_b4.txt`):

  | Tamanho | v121 | rodada 1 | **rodada 2** |
  |---|---|---|---|
  | 640 a 700 px deitado (ex.: 640x360) | 52 px | 52 px (em 640) | **42 px** |
  | 720 a 760 px deitado (ex.: 740x360) | 52 px | 52 px | 52 px ✅ (o chip fica só com o bichinho) |
  | 568x320 deitado | 52 px | 42 px | **36 px** |
  | em pé 360 ou 320 | 46 px | 42 px | **36 px** |

  - Captura `PAG_ler_d568x320.png`: os botões ficam visivelmente pequenos para o dedo de uma criança de 4 anos.
  - O plano pede botões com 48 px ou mais (parte 4.12, item 3), e essa barra é a T9 do plano.
  - 640x360 é um tamanho comum de celular Android deitado.
- **O que deveria acontecer:** a pílula inteira **e** os botões com 48 px ou mais.
- **Sugestão:** em vez de encolher os botões, encolher a **pílula**. Por exemplo, em tela estreita mostrar "☀️ 0/10 · 🌱 1/52" ou uma letra um pouco menor, e diminuir o espaço entre os botões (de 11 px para 4–6 px). Nunca deixar os botões abaixo de 48 px (46 px em pé, como já era na v121). Pelas minhas contas, em 640 px cabem 6 botões de 48 px com 6 px de espaço se a pílula ficar cerca de 10 px mais curta.

### 🟡 N2. Em 568x320, o meio da T4 que rola ficou estreito demais

- **Onde:** `escola-familia.js`, `.ef-t4 .ef-meio{flex:1 1 auto;min-height:0;overflow:auto}`.
- **O que acontece:** como agora os botões e o rodapé ficam sempre à vista, numa tela de 320 px de altura sobram só **68 px** para os cartões (48 px no modo Arrumar). Só **metade** do cartão aparece: o nome fica cortado, e no "Arrumar" o ✏️🗑️ só aparece rolando uma faixa de 48 px. Medido com `b13_meio.py`; capturas `T4_d568x320.png` e `T7_d568x320.png`.
  - Em 740x360 **sem internet** (o rodapé quebra em 2 linhas por causa de "📴 SEM INTERNET: … NÃO LIMPE OS DADOS DO NAVEGADOR."), aparece 81% do cartão: bichinho e nome visíveis, aceitável (captura `meio_offline_fila_740x360.png`).
- **Sugestão:** em telas com 340 px de altura ou menos, deixar a tela inteira rolar (como na rodada 1), ou pôr o rodapé numa linha só (por exemplo, a família como ícone 🔑 ao lado da bolinha).

### 🟡 N3. O `sw.js` não mudou de nome entre a rodada 1 e a rodada 2

- **Onde:** `sw.js`, linha 3: `const C='esforco-vence-v122'`, igual à rodada 1. O `index.html`, o `escola-familia.js` e o `nuvem-sync.js` mudaram.
- **Risco:** o `sw.js` guarda os arquivos e os entrega primeiro da memória do celular. Como ele ficou idêntico, o celular **não percebe** que há versão nova.
  - **Se o zip da rodada 1 já tiver sido publicado no site de teste** e aberto num celular, esse celular continua mostrando a rodada 1 mesmo depois de publicar a rodada 2. O Pedro testaria a versão antiga (e aí isto vira 🟠).
  - Se a rodada 1 nunca foi publicada, não há problema agora, mas a próxima correção terá o mesmo risco.
- **Sugestão:** mudar o nome do cache a cada zip entregue (ex.: `esforco-vence-v122b`) ou dizer claramente nas instruções que a rodada 1 nunca foi ao site de teste.

### 🟡 N4. Detalhes de aparência nos botões pequenos de quando o teclado está aberto

- Na T5 com teclado, "PRONTO! ✅" e o "←" ficam com o texto **encostado em cima** do botão, não no meio (captura `kb_t5_k740x170.png`).
- Em pé com 320 px e teclado aberto, o campo do código fica com cerca de 120 px e mostra só "EX.: PANDA·". Um código como `teste-pedro-2026` não aparece inteiro enquanto se digita (captura `kb_t2_kp320x300.png`). O app é usado deitado, por isso é leve.
- **Sugestão:** `align-items:center` nos botões `.ef-so-compacto`; em tela estreita, o "🔑 PROCURAR A FAMÍLIA" pequeno pode virar só "🔑 ›".

---

## O que eu RODEI de verdade (rodada 2)

**Conferências e testes do zip**
- O zip do Netlify da rodada 2 é **idêntico, byte a byte,** à pasta `pacote-netlify/`. As cópias em `compartilhados/` e `testes/` são iguais. `nuvem-config.js` é o do Pedro (md5 `1d5f060a…`). `node --check` OK nos 5 arquivos `.js`.
- Testes do zip em Node: **89/89**.
- Testes do zip com navegador (Chromium + Firebase de mentira, portas 8851/8852):

  | Teste | Resultado |
  |---|---|
  | `teste_familia.py` | **128/128** |
  | `teste_revisao.py` (novo) | **46/46** |
  | `teste_cadastro.py` | **72/72** |
  | `teste_nuvem.py` | **81/81** |
  | `teste_pwa.py` | **34/34** |
  | `teste_fonte.py` | **57/58** (a mesma falha antiga da v121) |

**Os meus scripts de novo, contra a rodada 2**
- `b1_telas.py`: T1, T2, T3, "anote" e T5 em 8 tamanhos, mais o teclado abrindo depois do toque em 6 tamanhos × 3 telas. Única "falha": os bichinhos em pé têm 33 a 43 px, o que o plano permite (de 30 a 62 px).
- `b2_foco.py`, `b2b_repete.py` e `b2c_repete20.py` (100 repetições), mais `b3_sumico.py`: confirmam o B1.
- `b4_t4.py`: T4, T7, pergunta de tirar, T5 "mudar", T6, T8, Configurações, e o chip e a ⚙️ com bolinha nas 4 telas, em 7 tamanhos.
  - Chip colado à esquerda da ⚙️ e ⚙️ com bolinha: OK em todas.
  - "☁️ Família e nuvem" é a última seção: OK.
  - Telas do módulo com letras de 14 px ou mais e botões de 48 px ou mais: OK.
  - Só a barra de cima ficou com botões abaixo de 48 px (N1).
- `b6_meta.py` (B2), `b8_dobras.py` (B3, B6, B7), `b13_meio.py` (N2), `b12r2_siteteste.py` (B13).
- `b7r2_fluxos.py`: tudo OK:
  - primeira abertura T1→T3→T5→parentes→menu;
  - D2 (a T4 toda vez que abre) e "Continuar de onde parei";
  - chip → mesma criança só fecha a tela;
  - "Já tenho cadastro" com "Trazer todas";
  - código errado e "Você quis dizer";
  - "Agora não" → bolinha 🔴;
  - botão voltar (pop-up → tela → Arrumar);
  - trava do adulto com o dedo (1,5 s não abre, 3 s abre);
  - tirar com a nuvem em dia;
  - **nenhum alert/confirm/prompt**.
- `b9_smoke.py`: o app antigo (frases, áudio, tipo e tamanho da letra, calendário, mapa, Configurações, Cantinho dos pais, Nomes dos parentes, Monta a Frase, Sílaba Perdida, Treinar Sílabas, menu): **0 erros**.
- **Olhei** as capturas novas: T2 normal e com teclado (deitado e em pé), T5 com teclado, T4, T4 sem internet, T7 (740, 568 e em pé) e a barra do Ler (740, 640 e 568).

## O que eu só LI

- O diff do `escola-familia.js` (rodada 1 → rodada 2) e o do `index.html` (43 linhas).
- O diff do `nuvem-sync.js`: a fila não é jogada fora se a lista de crianças der erro, e o `movidoPara` não apaga a ficha errada. Isso é da área do Revisor A; os testes do zip sobre isso passaram.
- B14 (os textos fora do `TEXTOS`) e N3 (`sw.js`) foram só lidos.

## O que só um celular de verdade pode confirmar

1. **Teclado de verdade** na T2, na T3 e na T5, deitado: o teclado abre, **fica aberto**, e o campo e o botão aparecem (repetir umas 5 vezes). Agora o campo não muda mais de lugar, o que deve resolver, mas só o celular confirma.
2. Celulares em que o teclado cobre a página em vez de encolher.
3. **O tamanho dos botões da barra de cima no seu celular** (N1): veja se a 🏠, o 📅 e a ⚙️ ficaram pequenos demais para as meninas.
4. Segurar 3 s com o dedo não abre o menu de "copiar/selecionar" do Android.
5. O botão voltar no app instalado.
6. Na TV a 3 m: as crianças acham o próprio bichinho na T4 e no Arrumar.
7. Se o site de teste já recebeu a rodada 1: confira que o app mostra a rodada 2 (N3). Se não mostrar, limpe os dados do **site de teste** (nunca do app de verdade).

---

## Veredito

❌ Não pode publicar: B1 🔴, B2 🟠 e B3 🟠 foram corrigidos, mas o conserto do B2 criou um problema 🟠 novo (N1: os botões da barra de cima encolhem para 42 px de 640 a 700 px de largura e para 36 px em 568x320 e em pé, abaixo dos 48 px do plano e dos 52 px da v121).
