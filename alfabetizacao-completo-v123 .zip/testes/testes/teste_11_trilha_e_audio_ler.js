/* v117 — as duas correções urgentes:
   1) O Ler nunca pode falar sozinho com o áudio desligado (antes, a cada
      5 frases lidas, o app montava Monta a Frase / Sílaba Perdida
      escondidos por trás do Ler, e eles falavam a frase).
   2) Ordem das frases: primeiro SÓ sílabas simples, frases curtas, número
      de palavras crescendo aos poucos; depois complexas, começando pelo R.
      Vale pro Ler, Monta a Frase e Sílaba Perdida. */
const { carregarApp, t, tAsync, assert, assertEq, resumo, esperar } = require('./_harness');

(async () => {
  console.log('teste_11_trilha_e_audio_ler');
  const dom = carregarApp();
  const { window } = dom;
  const doc = window.document;
  await esperar(300);
  window.eval('window._testeSemAnimacao = true;');

  // ---------- trilha ----------
  const info = JSON.parse(window.eval(`JSON.stringify((function(){
    var seq = construirOrdemDificuldade();
    return {
      seq: seq,
      etapas: seq.map(function(i){ return ETAPAS_TRILHA[classificarFrase(fraseDe(i)).etapa].id; }),
      nPal: seq.map(function(i){ return classificarFrase(fraseDe(i)).nPal; }),
      textos: seq.map(function(i){ return fraseDe(i); })
    };
  })())`));

  t('A trilha passa por TODAS as 2039 frases, cada uma uma vez só', () => {
    assertEq(info.seq.length, 2039);
    assertEq(new Set(info.seq).size, 2039);
  });

  t('As 20 primeiras frases usam só sílabas simples', () => {
    const fora = info.etapas.slice(0, 20).filter(e => e !== 'simples');
    assert(fora.length === 0, 'etapas fora de "simples" no começo: ' + JSON.stringify(fora));
  });

  t('As primeiras frases são curtinhas (no máximo 3 palavras nas 10 primeiras)', () => {
    const max = Math.max.apply(null, info.nPal.slice(0, 10));
    assert(max <= 3, 'uma das 10 primeiras frases tem ' + max + ' palavras');
  });

  t('Dentro das sílabas simples, o número de palavras só cresce (nunca volta a pular pra frase grande e depois curta)', () => {
    let ant = 0;
    for (let k = 0; k < info.seq.length && info.etapas[k] === 'simples'; k++) {
      assert(info.nPal[k] >= ant, 'frase ' + (k + 1) + ' ("' + info.textos[k] + '") tem menos palavras que a anterior');
      ant = info.nPal[k];
    }
  });

  t('Nenhuma sílaba complexa aparece antes de terminarem as simples', () => {
    const simplesFase = new Set(['simples', 'simples2', 'ditongo']);
    const primeiroComplexo = info.etapas.findIndex(e => !simplesFase.has(e));
    const simplesDepois = info.etapas.slice(primeiroComplexo).findIndex(e => simplesFase.has(e));
    assertEq(simplesDepois, -1, 'apareceu frase simples DEPOIS de uma complexa');
  });

  t('A primeira sílaba complexa da trilha é a do R (primeiro R entre vogais, depois PR/TR/R no fim)', () => {
    const simplesFase = new Set(['simples', 'simples2', 'ditongo']);
    const complexos = info.etapas.filter(e => !simplesFase.has(e));
    assertEq(complexos[0], 'r_brando');
    const fimRbrando = complexos.lastIndexOf('r_brando');
    assertEq(complexos[fimRbrando + 1], 'r', 'depois do R entre vogais devia vir o resto do R');
  });

  t('Palavras com R entre vogais (a·do·ra, ca·ro) NÃO ficam mais na fase das sílabas simples', () => {
    const simplesFase = new Set(['simples', 'simples2', 'ditongo']);
    const errado = info.textos.filter((f, k) => simplesFase.has(info.etapas[k]) && /[aeiouáéíóúâêôãõ]·r[aeiouáéíóúâêôãõ]/i.test(f));
    assert(errado.length === 0, 'ainda na fase simples: ' + JSON.stringify(errado.slice(0, 5)));
  });

  t('"a·ten·de", "a·do·ra" e "pri·ma" não aparecem mais nas 100 primeiras frases', () => {
    const cedo = info.textos.slice(0, 100).filter(f => /a·ten·de|a·do·ra|pri·ma/i.test(f));
    assert(cedo.length === 0, 'ainda aparecem cedo: ' + JSON.stringify(cedo));
  });

  t('Mapa de Níveis: o Nível 1 é de sílabas simples e começa pela 1ª frase da trilha', () => {
    const r = JSON.parse(window.eval(`JSON.stringify({et:LEVELS[0].etapa, primeiro:LEVELS[0].ix[0], seq0:construirOrdemDificuldade()[0]})`));
    assertEq(r.et, 'simples');
    assertEq(r.primeiro, r.seq0);
  });

  t('Monta a Frase: ▶ vai pra PRÓXIMA frase da trilha (não pra próxima do array cru)', () => {
    window.eval(`idxMonta = construirOrdemDificuldade()[5]; irMonta(1);`);
    assertEq(window.eval('idxMonta'), info.seq[6]);
    window.eval('irMonta(-1);');
    assertEq(window.eval('idxMonta'), info.seq[5]);
  });

  t('Sílaba Perdida: ▶ vai pra PRÓXIMA frase da trilha', () => {
    window.eval(`idxSilaba = construirOrdemDificuldade()[5]; irSilaba(1);`);
    const pos = window.eval('_posDificuldade.get(idxSilaba)');
    assert(pos >= 6 && pos <= 8, 'Sílaba Perdida pulou pra posição ' + pos + ' da trilha');
  });

  // ---------- áudio no Ler ----------
  window.eval(`
    window._falas = 0;
    window.speak = function(){ window._falas++; };
    speechSynthesis.speak = function(){ window._falas++; };
  `);

  await tAsync('Ler com áudio DESLIGADO: ler 10 frases seguidas (passando pelo quiz de 5 em 5) não fala nada', async () => {
    window.eval(`audioOn = false; window._falas = 0; idx = construirOrdemDificuldade()[0];`);
    for (let k = 0; k < 10; k++) { window.eval('go(1);'); await esperar(20); }
    await esperar(3000); // quiz agenda em 1,4s + a fala antiga vinha 1s depois
    assertEq(window.eval('window._falas'), 0, 'o Ler falou sozinho com o áudio desligado');
  });

  await tAsync('Monta a Frase montado com a página FECHADA não fala (trava de segurança)', async () => {
    window.eval(`document.getElementById('pgMonta').classList.remove('open'); window._falas = 0; openMonta(10);`);
    await esperar(1300);
    assertEq(window.eval('window._falas'), 0);
  });

  await tAsync('Monta a Frase com a página ABERTA continua falando a frase sozinho (pedido anterior mantido)', async () => {
    window.eval(`document.getElementById('pgMonta').classList.add('open'); window._falas = 0; openMonta(10);`);
    await esperar(1300);
    assert(window.eval('window._falas') > 0, 'deveria ter falado com a página aberta');
    window.eval(`document.getElementById('pgMonta').classList.remove('open');`);
  });

  resumo();
})();
