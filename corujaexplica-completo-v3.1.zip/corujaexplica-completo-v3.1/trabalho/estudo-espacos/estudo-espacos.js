const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT='/home/claude/build',PORT=9192;
const MIME={'.html':'text/html','.js':'application/javascript','.png':'image/png','.webmanifest':'application/manifest+json'};
const srv=http.createServer((q,r)=>{let p=q.url.split('?')[0]; if(p==='/')p='/index.html'; fs.readFile(path.join(ROOT,p),(e,d)=>{if(e){r.writeHead(404);r.end();return;} r.writeHead(200,{'Content-Type':MIME[path.extname(p)]||'x'}); r.end(d);});}).listen(PORT);
let TX=fs.readFileSync('/root/.claude/uploads/88b40acf-8683-5d3e-a36b-dad4b20661ee/07e71ae2-Texto_exemplo.txt','utf8').split('\n').slice(1).join('\n');
const TX2=`TÍTULO: Camila e o cavalo\n\nTEXTO:\nCamila tem um cavalo. O cavalo é o Caco. Camila cuida do cavalo Caco.\n\nCamila come cocada. O cavalo come capim. Camila cavalga no cavalo Caco.\n\nEla é esperta. O cavalo obedece a Camila.`;
(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const res=[];
  for (const [w,h] of [[770,340],[915,412]]) for (const font of [0,1]) for (const caps of [true,false]) {
    const ctx=await b.newContext({viewport:{width:w,height:h},serviceWorkers:'block'});
    await ctx.route(/googleapis/,r=>r.abort());
    await ctx.addInitScript(()=>{localStorage.setItem('escola_instalado','1');localStorage.setItem('explica_usuarios',JSON.stringify({us:[{id:'p1',nome:'Ana',av:'🦊'}],atual:'p1'}));});
    const p=await ctx.newPage(); await p.goto(`http://localhost:${PORT}/`); await p.waitForTimeout(300);
    for (const tx of [TX,TX2]) for (const px of [16,22,28,32,40,48,56,64]) {
      const r=await p.evaluate(async ([t,px,font,caps])=>{
        fontIdx=font; applyFont(); capsMode=caps; modoMargem='espacos'; silabasOn=false; AJUSTE_MAX_EM_ESPACOS=100;
        fsizeIdx=FSIZES.indexOf(px);
        abrirLeitura({titulo:'x',texto:t}); await document.fonts.ready;
        const box=document.getElementById('detTexto'); box.style.setProperty('--fsize',px+'px'); await new Promise(r=>setTimeout(r,120));
        ajustaMargemDireita = ajustaMargemDireita; // noop
        limparAjusteMargem(box);
        const mapa=mapaLocal(box); const out=[];
        blocosDeTexto(box).forEach(bl=>{
          const linhas=linhasDoBloco(bl,mapa); if(linhas.length<2) return;
          const cs=getComputedStyle(bl); const rb=mapa.ret(bl.getBoundingClientRect());
          const dir=rb.r-parseFloat(cs.paddingRight||0);
          const fsz=parseFloat(cs.fontSize);
          linhas.slice(0,-1).forEach(l=>{ if(!l.espacos.length) return;
            const ws=[...bl.querySelectorAll('.wsp')].map(x=>{const q=mapa.ret(x.getClientRects()[0]||x.getBoundingClientRect());return q.r-q.l;}).filter(v=>v>0).sort((a,b)=>a-b); const spw=ws[ws.length>>1];
            out.push({need:(dir-l.dir)/l.espacos.length/fsz, sp:spw/fsz, gaps:l.espacos.length});
          });
        });
        fecharDet(true);
        return out;
      },[tx,px,font,caps]);
      r.forEach(x=>res.push(Object.assign({w,px,font,caps,tx:tx===TX?'longo':'curto'},x)));
    }
    await ctx.close();
  }
  fs.writeFileSync('estudo-espacos.json',JSON.stringify(res));
  await b.close(); srv.close();
})();
