import re,subprocess,sys
s=open(sys.argv[1],encoding='utf-8').read()
blocos=[m.group(1) for m in re.finditer(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>',s,re.S)]
ok=True
for i,b in enumerate(blocos):
    open('/tmp/_b.js','w',encoding='utf-8').write(b)
    r=subprocess.run(['node','--check','/tmp/_b.js'],capture_output=True,text=True)
    if r.returncode: ok=False; print('BLOCO',i,'ERRO:\n',r.stderr[:800])
print('SINTAXE OK' if ok else 'SINTAXE COM ERRO', '-', len(blocos),'blocos')
